import styled from "styled-components";
export const StyledInput = styled.div`
  &.inputWithIcon {
    margin: 10px 0px 2px 0px;
    display: flex;
    align-items: center;
    background: #f4f6f8;
    border-radius: 5px;
    border: 1px solid #E3E9EE;
  }
  .left-icon {
    // position: absolute;
    margin-left: 1rem;
  }
  .right-icon {
    // position: absolute;
    // right: 10px;
    // margin-top: -26px;
    // transform: translateY(-50%);
  }
`;
export const InputLabel = styled.label`
  color: #3a3951;
  font-size: max(0.9vw, 14px);
  font-weight: 500;
  font-size: 14px;
  line-height: 19px;
  font-family: Medium;
`;

export const Button = styled.button`
  border: none;
  border-radius: 5px;
  color: white;
  padding: 15px;
  text-decoration: none;
  font-size: 16px;
  font-weight: 500;
  font-family:Regular
  cursor: pointer;
  display: flex;
  justify-content: center;
`;

export const formControl = {
  display: "block",
  padding: " 0.375rem 0.75rem",
  fontSize:"14px",
  lineHeight: "2.4rem",
  backgroundClip: "padding-box",
  // background: ThemeColors.bg,
  border: "none",
  // textIndent: "2.5rem",
  borderRadius: "5px",
  // fontWeight: " 400",
  // color: "black",
  // width: "100%",
};
export const formControlOtp = {
  display: "block",
  width: "50%",
  padding: "0.375rem 0.75rem",
  fontSize: " 1rem",
  lineHeight: " 2.4rem",
  backgroundClip: "padding-box",
  // background: ThemeColors.inputbg,
  border: "none",
  borderRadius: "5px",
  textAlign: "center",
};
export const formSelect = {
  display: "block",
  width: "100%",
  fontSize: "1rem",
  height: "3rem",
  // background: ThemeColors.inputbg,
  border: "none",
  paddingTop: "0.9rem",
  paddingBottom: "0.9rem",
  paddingLeft: "1rem",
  textIndent: "2.5rem",
  borderRadius: "5px",
  backgroundClip: "padding-box",
};
