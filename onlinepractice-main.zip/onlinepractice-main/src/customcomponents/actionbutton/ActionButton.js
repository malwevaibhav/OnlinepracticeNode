import React from "react";
import { BlueEditIcon, DeleteRedIcon, EyeIcon } from "../../assets/svgs/svg";
import { DownloadIcon } from "../../assets/icons/Inputicon";
export default function ActionButton({
  veiwFunction,
  editfunction,
  deletefunction,
  viewDetail,
  eye = true,
  edit = true,
  del = true,
  download = false,
  downloadfunction,
}) {
  return (
    <div
      className="btn-group btn-group-sm"
      role="group"
      aria-label="First group"
    >
      {eye && (
        <button
          type="button"
          title="view"
          className="btn acBtn border border-1 border-end-0 ps-2 pe-0 p-1 m-0  bg-white"
          onClick={veiwFunction}
        >
          <EyeIcon />
        </button>
      )}
      {edit && (
        <button
          type="button"
          title="edit"
          className="btn acBtn border border-1 border-end-1 ps-2 pe-0 p-1 m-0 bg-white"
          onClick={editfunction}
        >
          <BlueEditIcon />
        </button>
      )}
      {del && (
        <button
          type="button"
          title="delete"
          className="btn acBtn border border-1 ps-2 pe-0 p-1 m-0 bg-white"
          onClick={deletefunction}
        >
          <DeleteRedIcon />
        </button>
      )}
      {download && (
        <button
          type="button"
          className="btn acBtn border border-1 ps-2 pe-0 p-1 m-0 bg-white"
          onClick={downloadfunction}
        >
          <DownloadIcon />
        </button>
      )}
    </div>
  );
}
