import React from "react";
import styled from "styled-components";
import { ThemeColors } from "../../theme/theme";
export default function UnderLineText({ text, subText, boldText = "" }) {
  const P = styled.p`
    color: ${ThemeColors.primary};
    position: relative;
    font-family: "Medium";
    font-size: 32px;
    margin-bottom: 1px;
  `;
  const Para = styled.p`
    color: #8b8b8b;
    letter-spacing: -0.02em;
    font-weight: 400;
    font-size: 16px;
    line-height: 21px;
    font-family: "Regular";
    margin-inline: auto 10px;
    @media screen and (max-width: 1000px) {
      padding-inline: 18%;
    }
  `;
  const BoldText = styled.p`
    color: ${ThemeColors.primary};
    position: relative;
    font-family: Light;
    font-size: 1rem;
    font-style: normal;
    font-weight: 700;
    line-height: 19px;
  `;
  const Text = styled.div`
    @media screen and (max-width: 1000px) {
      text-align: center;
      width: 17rem;
      margin-block: 3rem 0rem;
      min-width: 500px;
    }
  `;
  return (
    <Text>
      <P>{text}</P>
      <Para>{subText}</Para>
      <BoldText>{boldText}</BoldText>
    </Text>
  );
}
