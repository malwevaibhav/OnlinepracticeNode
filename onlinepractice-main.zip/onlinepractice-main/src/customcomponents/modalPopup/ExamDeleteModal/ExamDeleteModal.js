import React from 'react'
import { CheckboxIcon, WarningIcon } from '../../../assets/svgs/svg'
import { ThemeColors } from '../../../theme/theme'
import Modal from '../CustomModal'

const ExamDeleteModal = ({onRequestClose,closeBtnSize,dynBtnSize,onPress,name}) => {
  return (
    <Modal
      onRequestClose={onRequestClose}
      dynButton="Delete"
      closeBtnSize={closeBtnSize}
      dynBtnSize={dynBtnSize}
      onPress={onPress}
      backgroundColor={ThemeColors.danger}
    >
      <div className="m-0 text-center">
        <WarningIcon/>
        {/* <SubHeading text="Delete" /> */}
        <p className="mb-0 my-3" style={{ fontFamily: "Medium",paddingInline:'20%' }}>
       {` Are you sure you want to delete “${name}”?`}
        </p>
        <div className='mt-4 text-start w-100'>
            <p  style={{fontSize:"12px"}}>This operation cannot be undone</p>
            <div className='exam-modal-background p-3 '>
                <div className='boxes d-flex align-items-start '>
                    <CheckboxIcon/>
                    <p>All courses will be permanently deleted.</p>
                </div>
                <div className='boxes d-flex align-items-start '>
                    <CheckboxIcon/>
                    <p>All the content belongs to this category will permanently deleted</p>
                </div>
            </div>
                  </div>
        </div>
    </Modal>
  )
}

export default ExamDeleteModal