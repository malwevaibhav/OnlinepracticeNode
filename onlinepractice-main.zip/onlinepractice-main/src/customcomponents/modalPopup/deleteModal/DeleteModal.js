import React from "react";
import { ThemeColors } from "../../../theme/theme";
import { SubHeading } from "../../DynamicText/Heading";
import Modal from "../CustomModal";

export default function DeleteModal({
  onRequestClose,
  name,
  dynBtnSize = "119px",
  closeBtnSize,
  onPress,
}) {
  return (
    <Modal
      onRequestClose={onRequestClose}
      dynButton="Delete"
      closeBtnSize={closeBtnSize}
      dynBtnSize={dynBtnSize}
      onPress={onPress}
      backgroundColor={ThemeColors.danger}
    >
      <div className="row m-0">
        <SubHeading text="Delete" />
        <p className="mb-0 mt-3" style={{ fontFamily: "Regular" }}>
          Are you sure you want to delete this <strong>“{name}”</strong> ? You
          can’t undo this action.
        </p>
      </div>
    </Modal>
  );
}
