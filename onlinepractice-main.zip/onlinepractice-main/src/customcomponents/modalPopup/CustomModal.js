import React, { useEffect, useRef } from "react";
import { ThemeColors } from "../../theme/theme";
import Button from "../button/Button";
import "./modal.css";
import img from "../../assets/Images/close.png";
const Modal = ({
  onRequestClose,
  children,
  onPress,
  dynButton,
  dynBtnSize,
  closeBtn = true,
  closeBtnSize = "122px",
  maxModalWidth = "560px",
  width,
  wrap,
  backgroundColor,
  me = "",
  noFooter = true
}) => {
  const modalRef = useRef();
  useEffect(() => {
    
    // function onKeyDown(event) {
    //   if (event.keyCode === 27) {
        
    //     onRequestClose();
    //   }
    // }
    // const listener = (event) => {
    //   if (!modalRef.current || modalRef.current.contains(event.target)) {
    //     return;
    //   }
      
    //   onRequestClose();
    // };
   
    // document.body.style.overflow = "hidden";
    // document.addEventListener("keydown", onKeyDown);

    // //For click outside
    // document.addEventListener("mousedown", listener);
    // document.addEventListener("touchstart", listener);
   
    // return () => {
    //   document.body.style.overflow = "visible";
    //   document.removeEventListener("keydown", onKeyDown);
  
    //   document.removeEventListener("mousedown", listener);
    //   document.removeEventListener("touchstart", listener);
     
      
    // };
  }, [onRequestClose]);

  return (
    <div className="modal__backdrop">
      <div >
        <div className="modal__container rounded-1 position-relative" ref={modalRef} style={{ maxWidth: maxModalWidth, width: width }} >

          <div className="d-flex justify-content-end ">
          <img src={img}  width={15}  onClick={onRequestClose}/>
             {/* <span><CrossModalIcon/></span> */}
            </div>
          {children}
          {noFooter && <div className={`modal-footer mt-4 gap-3 mb-3 ${me}`} style={{ flexWrap: wrap }}>
            {dynButton && (
              <Button title={dynButton} func={onPress} width={dynBtnSize} background={backgroundColor} />
              

            )}
            {closeBtn && (
              <Button
                title="Cancel"
                func={onRequestClose}
                background={ThemeColors.secondary}
                width={closeBtnSize}
              />
            )}
          </div>}
        </div>

      </div>
    </div>
  );
};
export default Modal;
