import { observer } from "mobx-react-lite";
import "./customDropdown.css";
const CustomDropdown = ({
  menu,
  height,
  menuStyle,
  customClass,
  selectedEntity,
  isSelect,
  handlefunc,
  placeholder,
  disable,
  name,
  name1,
  setFieldValue,
  entityName
}) => {
  const setData = (data) => {
    // console.log("data",data);
     if(entityName) {
      handlefunc(data, data?.Title, entityName)   
     }else{
      handlefunc(data, data?.Title)
     }
    
    if ((name || name1) && setFieldValue) {
      setFieldValue(name, data?.Title)
      setFieldValue(name1, data?.id)
    }
  };
  return (
    <div className="dropdown">
      <button
        className={`btn dropdown customtoggle mx-0 d-flex justify-content-between ps-3 ${customClass}`}
        type="button"
        id="dropdownButton"
        name="dropdownButton"
        data-bs-toggle="dropdown"
        aria-expanded="false"
        disabled={disable}
        style={{ ...menuStyle, height: height }}
      >
        {/* {selectedEntity || placeholder} */}
        {(selectedEntity?.length > 18 ? selectedEntity?.substring(0, 18 - 3) + "..." : selectedEntity) || placeholder}
      </button>

      <ul
        className={
          isSelect
            ? "dropdown-menu width dropcenter"
            : "dropdown-menu dropcenter margin-ul"
        }
        aria-labelledby="dropdownButton"
        style={{ backgroundColor: "white", color: "rgba(0, 117, 255, 1)" }}
      >
        {menu && menu?.map((data, key) => (

          <li className="p-0 m-0" key={key}>

            <p
              className={`dropdown-item pb-0 py-0 mb-1 hover-class`}
              // data-bs-toggle="dropdown"
              aria-expanded={data?.opened}
              id={key}
              onClick={(e) => { setData(data, key) }}
            >
              {data?.Title}
            </p>
          </li>

        ))}
      </ul>
    </div>
  );
}
export default observer(CustomDropdown)