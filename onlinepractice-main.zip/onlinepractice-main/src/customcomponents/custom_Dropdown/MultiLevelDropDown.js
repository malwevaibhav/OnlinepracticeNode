import { useState } from "react";
import "./customDropdown.css";

export default function MultiLevelDropDown({
  menu,
  preText,
  menuStyle,
  onSort,
}) {
  const [show, setShow] = useState(false);
  const [mainMenu, setMainMenu] = useState(false);
  const [selectedValue, setSelectedValue] = useState(menu[0]);
  const setData = (data, index) => {
    if (!data.subMenu) {
      setSelectedValue(data);
      setShow(false);
      setMainMenu(false);
    } else {
      setShow(!show);
    }
  };
  return (

    <div className="dropdown">
      <button
      className="btn customtoggle rounded-1 multiLevelDD "
       type="button"
        id="dropdownButton"
        data-bs-toggle="dropdown"
        aria-expanded="false"
        onClick={() => {
          setShow(false);
          setMainMenu(true);
        }}
        style={{ ...menuStyle }}
      >
        <p className="text-muted">{preText}</p>&nbsp;{selectedValue?.title}
        {/* <BlackDropDownArrow /> */}
      </button>
      <ul
        className={`dropdown-menu ${mainMenu ? "show" : "hide"}`}
        aria-labelledby="dropdownButton"
        style={{
          backgroundColor: "white",
          color: "rgba(0, 117, 255, 1)",
          // minWidth: "9.5rem",
        }}
      >
        {menu.map((data, i) => (

          <li className="p-0 pointer" key={i}>
            <p
              className={`${data.subMenu && "dropdown-toggle subDropDown"
                } dropdown-item items mb-0`}
              // data-bs-toggle="dropdown"
              aria-expanded="false"
              id={i}
              onClick={(e) => {
                setData(data, i);
                onSort && onSort(data?.title);
              }}
            >
              {data.title}
            </p>
          </li>
        ))}
        {/* {i === ndx && show && data.subMenu && (
          <ul className={`dropdown-submenu ps-0`} aria-labelledby={i}>
            {data.subMenu.map((elm, k) => (
              <li key={k}>
                <p
                  className="dropdown-item border-bottom subItems"
                  onClick={() => {
                    setSelectedValue({ title: elm?.title });
                    setMainMenu(false);
                  }}
                >
                  {elm?.title}
                </p>
              </li>
            ))}
          </ul>
        )} */}

      </ul>
    </div>
  );
}
