import React from "react";
import "./radioButtoncss.css";
export default function RadioButton({ text, customcheckcss }) {
  return (
    <p>
      {" "}
      <div className="f-align" style={{ columnGap: "10px", marginTop: "15px" }}>
        <input
          type={`checkbox`}
          className={`rounded-checkbox  ${customcheckcss}`}
          id="checkbox"
        />{" "}
        <label className="Cheakbox_head">{text}</label>
      </div>
    </p>
  );
}
