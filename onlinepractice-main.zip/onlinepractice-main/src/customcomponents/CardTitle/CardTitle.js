import React from "react";
import { SubHeading } from "../DynamicText/Heading";
import "./CardTitle.css";

export default function CardTitle({ number, title }) {
  return (
    <div className="d-flex m-0">
      {number && <p className="round me-3">{number}</p>}
      <SubHeading margin="5px 0 0 0px" text={title} />
    </div>
  );
}
