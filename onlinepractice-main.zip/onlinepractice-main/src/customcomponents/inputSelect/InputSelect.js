import React from "react";
import { InputLabel } from "../customTextInput/indexCss";
import "./inputSelect.css";

export default function InputSelect({
  option = [],
  title,
  marginTop = "",
  backgroundColor = "#F4F6F8 ",
  onChange,
  id,
  name,
  height = "",
  width,
  value,
  border="solid 1px #E5E5E5",
}) {
  return (
    <>
      {title && <InputLabel>{title}</InputLabel>}
      <select
        className="form-select form-control "
        id={id}
        name={name}
        style={{
          marginTop: marginTop,
          backgroundColor: backgroundColor,
          height: height,
          width: width,
          border:border,
        }}
        onChange={onChange}
      >
        <option value="" disabled selected>
          Select {title}
        </option>
        {option.map((options, index) => {
          return (
            <option selected={options?.id === value} value={options?.id} key={index}>
              {options?.title}
            </option>)
        })}
      </select>
    </>
  );
}
