import React, { useEffect, useRef, useState } from "react";
import { toast } from "react-toastify";
import { PdfSvg, UploadIcon } from "../../assets/svgs/svg";
import { ThemeColors } from "../../theme/theme";
import Button from "../button/Button";

function DocUpload({
  onDrop,
  maxFiles = 1,
  name,
  name2,
  setFieldValue,
  // orgFileSrc,
  // orgFileName,
  fileSrc,
  fileName,
  accept,
  set,
  touched, setDisable


}) {
  const [isFile, setIsFile] = useState(true);
  const [over, setover] = useState(false);
  const [files, setfiles] = useState();
  const $input = useRef(null);
  // const location = useLocation();
  useEffect(() => {

    if (fileSrc && files === undefined) {
      setIsFile(false);
      setfiles(fileSrc);
    }
    if (onDrop) {
      onDrop(files);
    }
  }, [files, onDrop, fileSrc]);

  const ImgUpload = async (file) => {
    if (file[0]?.type === "application/pdf") {
      setFieldValue(name, file[0]);
      setFieldValue(name2, file[0]?.name);
      set(URL.createObjectURL(file[0]));
      setIsFile(false);
      setfiles(URL.createObjectURL(file[0]));
      touched.paperPdfUrl = false;
    } else {
      toast.error("file format is not valid");
    }
  };

  // const handleChange = () => {
  //   if (location?.state?.id) { set(""); setFieldValue(name, files); setFieldValue(name2, files[0]?.name); } else {
  //     set("")
  //     setFieldValue(name, "")
  //     setFieldValue(name2, "")

  //   }
  //   // setThumbnails("")
  //   setIsFile(true)
  //   setFieldValue("paperPdfUrl", "")
  // }
  return (
    <>
      <div className="row m-0">
        {isFile && (
          <div
            className="card  rounded-3 text-center"
            style={{ backgroundColor: "#ECF5FF", border: "1px dashed #ABB6C0" }}
          >
            <div
              onClick={() => {
                $input.current.click();
              }}
              onDrop={(e) => {
                e.preventDefault();
                e.persist();
                ImgUpload(e.dataTransfer.files);
                setIsFile(false);
                setover(false);
              }}
              onDragOver={(e) => {
                e.preventDefault();
                setover(true);
              }}
              onDragLeave={(e) => {
                e.preventDefault();
                setover(false);
              }}
            >
              <div
                className={`${over ? "upload-container over" : "upload-container"
                  } mt-4`}
              >
                <UploadIcon width="35" height="25" />
                <h6 className="SemiBold mt-2 d-flex justify-content-center">
                  Drag and drop your file here or &nbsp;
                  <p className="text-primary pointer">Browse</p>
                </h6>
                <input
                  name={name}
                  style={{ display: "none" }}
                  type="file"
                  accept={`${accept}`}
                  ref={$input}
                  onChange={(e) => {
                    ImgUpload(e.target.files);
                    setDisable(false)

                  }}
                  multiple={maxFiles > 1}
                />
              </div>
            </div>
          </div>
        )}
        {!isFile && (
          <div className="blob-container d-flex align-items-center ps-0 gap-3">
            <div>
              <PdfSvg />
            </div>
            <div>{fileName}</div>
            <div
              className="ms-4"
              onClick={() => {
                $input.current.click(); setDisable(false)
              }}
            >
              <input
                name={name}
                onChange={(e) => {
                  ImgUpload(e.target.files);
                }}
                multiple={maxFiles > 1}
                style={{ display: "none" }}
                type="file"
                accept={`${accept}`}
                ref={$input}
              />
              {/*  */}

              <Button
                title="Change file"
                textColor={ThemeColors.primary}
                width="fit-content"
                height="0"
                func={(e) => e.preventDefault()}
                background=""
              />
            </div>

            {/* {!location?.state?.id && <Button
              title="Cancel"
              textColor={ThemeColors.secondary}
              width="fit-content"
              height="0"
              func={(e) => { handleChange() }}
              background=""
            />} */}

          </div>
        )}
      </div>
    </>
  );
}

export { DocUpload };

