import React from 'react'
import { CrossIcon, RightTickIcon } from '../../assets/svgs/svg'

export default function CourseAction({ right=true, cross=true, rightFunction, crossFunction ,disable}) {
    return (
        <div className="btn-group btn-group-sm" role="group" aria-label="First group">
            {right && <button type="button" className="btn acBtn border border-1 border-end-0 ps-2 pe-0 p-1 m-0  bg-white" onClick={rightFunction} disabled={disable}>
                <RightTickIcon />
            </button>}
            {cross && <button type="button" className="btn acBtn border border-1 border-end-1 ps-2 pe-0 p-1 m-0 bg-white" onClick={crossFunction} >
                <CrossIcon />
            </button>}

        </div>
    )
}
