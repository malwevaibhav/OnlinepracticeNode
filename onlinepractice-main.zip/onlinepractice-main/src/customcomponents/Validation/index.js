import React from "react";
import CustomInput from "../customTextInput/index";
const index = () => {
  return (
    <div>
      index
      <div style={{ width: "200px" }}>
        <CustomInput type={"number"} placeholder={"phoneNumber"} />;
      </div>
    </div>
  );
};

export default index;
