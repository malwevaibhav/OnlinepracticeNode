import React from 'react';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { Pie } from 'react-chartjs-2';

ChartJS.register(ArcElement, Tooltip, Legend);

export const data = {
  labels: ['Allen Institute', 'Akash Institute', 'CatalyseR Institute', 'Kautilya Acadamy', 'Other'],
  datasets: [
    {
      label: '# of Votes',
      data: [12, 19, 3, 5, 2],
      backgroundColor: [
        'rgba(110, 177, 255, 1)',
        'rgba(169, 209, 255, 1)',
        'rgba(52, 145, 255, 1)',
        'rgba(0, 95, 207, 1)',
        'rgba(0, 117, 255, 1)',
      ],
      borderColor: [
        'rgba(110, 177, 255, 1)',
        'rgba(169, 209, 255, 1)',
        'rgba(52, 145, 255, 1)',
        'rgba(0, 95, 207, 1)',
        'rgba(0, 117, 255, 1)',
      ],
      borderWidth: 1,
    },
  ],
};

export default function PieChart() {
  return <Pie data={data} options={{maintainAspectRatio:false,
    plugins: {
      legend: {
        position:'right'
      }}
  }}  height={250}/>;
}
