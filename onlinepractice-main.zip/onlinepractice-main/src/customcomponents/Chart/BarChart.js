import React, { useEffect, useState } from "react";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
import { Bar } from "react-chartjs-2";
import { getMonth } from "../../utils/helper";
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

export default function BarChart({ Enrolment, id }) {
  const [labels, setlabel] = useState([]);
  let dataoption = [];
  const labelsweek = [
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thrusday",
    "Friday",
    "Saturday",
    "Sunday",
  ];

  // const labelsMonth= [
  //   'January',
  //   'February',
  //   'March',
  //   'April',
  //   'May',
  //   'June',
  //   'July',
  //   'August',
  //   'September',
  //   'October',
  //   'November',
  //   'December'
  // ];

  useEffect(() => {
    if (id === 3) {
      let labelsMonth = [];
      Enrolment.map((emp) => {
        labelsMonth.push(emp?.key);
      });
      setlabel(labelsMonth);
    }
    if (id === 2) {
      setlabel(labelsweek);
    }
    if (id === 1) {
      let lablesToday = [];
      Enrolment.map((emp) => {
        lablesToday.push(emp?.key);
      });
      setlabel(lablesToday);
    }
  }, []);
  Enrolment.map((emp) => {
    dataoption.push(emp?.value);
  });

  const options = {
    type: "bar",
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      scales: {
        xAxes: {
            title: {
              display: true,
              text: getMonth(),
            },
        },
        yAxes: {
          title: {
            display: true,
            text: "left",
          },
      },
      },

      // title: {
      //   display: true,
      // },
    },
  };

  let data = {
    labels,
    datasets: [
      {
        label: "Dataset 1",
        data: dataoption,
        backgroundColor: "rgba(0, 117, 255, 1) ",
        // borderColor: 'rgb(255, 0, 0)',
        borderWidth: 2,
        borderRadius: 20,
      },
    ],
  };

  return <Bar options={options} data={data} height={250} />;
}
