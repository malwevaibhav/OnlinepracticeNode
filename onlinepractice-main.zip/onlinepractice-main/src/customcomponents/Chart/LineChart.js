import {
  CategoryScale,
  Chart as ChartJS,
  Filler,
  Legend,
  LinearScale,
  LineElement,
  PointElement,
  Title,
  Tooltip,
} from "chart.js";
import React, { useEffect, useState } from "react";
import { Line } from "react-chartjs-2";
import { getMonth } from "../../utils/helper";
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Filler,
  Legend
);

export default function LineChart({ salesgraph, id }) {
  const [labels, setlabel] = useState([]);
  let dataoption = [];

  const labelsweek = [
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thrusday",
    "Friday",
    "Saturday",
    "Sunday",
  ];

  // const labelsMonth= [
  //     'January',
  //     'February',
  //     'March',
  //     'April',
  //     'May',
  //     'June',
  //     'July',
  //     'August',
  //     'September',
  //     'October',
  //     'November',
  //     'December'
  // ];

  useEffect(() => {
    if (id === 3) {
      let labelsMonth = [];
      salesgraph.map((emp) => {
        labelsMonth.push(emp?.key);
      });
      setlabel(labelsMonth);
    }
    if (id === 2) {
      setlabel(labelsweek);
    }
    if (id === 1) {
      let lablesToday = [];
      salesgraph.map((emp) => {
        lablesToday.push(emp?.key);
      });
      setlabel(lablesToday);
    }
  }, []);

  salesgraph.map((emp) => {
    dataoption.push(emp?.value);
  });

  let detail = {
    labels,
    datasets: [
      {
        fill: true,
        label: "Dataset 2",
        data: dataoption,
        borderColor: "rgb(53, 162, 235)",
        backgroundColor: "rgba(53, 162, 235, 0.5)",
      },
    ],
  };

  return (
    <Line
      data={detail}
      options={{
        maintainAspectRatio: false,
        plugins:{
          legend: false
        },
        // scales: {
        //   xAxis: {
        //       title: {
        //         display: true,
        //         text: "bottom",
        //       },
        //   },
        //   yAxis: {
        //     title: {
        //       display: true,
        //       text: "left",
        //     },
        // },
        // },
      }}
      height={250}
    />
  );
}
