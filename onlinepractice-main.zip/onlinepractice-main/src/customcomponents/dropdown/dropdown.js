import React, { useState } from "react";
import {
  InputLabel,
  StyledInput,
} from "../customTextInput/indexCss";

export default function Dropdown(props) {
  const { option = [], label,  formSelect } = props;
  const [isOpen, setIsOpen] = useState(false);
  

  const onOptionClicked = () => () => {
   
    setIsOpen(!isOpen);
  };

  return (
    <>
      <InputLabel>{label}</InputLabel>
      <StyledInput className={"inputWithIcon"}>
        {/* <div className="left-icon">{lefticon}</div> */}
        <select style={formSelect} className="form-control form-select">
          {option.map((option,key) => (
            <option onClick={onOptionClicked(option)} value={option} key={key}>
              {option}
            </option>
          ))}
        </select>
      </StyledInput>
    </>
  );
}
