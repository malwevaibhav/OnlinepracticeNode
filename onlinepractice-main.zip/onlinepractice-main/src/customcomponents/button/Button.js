import React from "react";

import { ThemeColors } from "../../theme/theme";

export default function Button(props) {

  const {
    title,
    type,
    icon,
    background = ThemeColors.primary,
    textColor = "white",
    func,
    width,
    height = "48px",
    fontSize,
    marginTop,
    border,
    disable,
    
  } = props;  

  return (
    <button
      className="btn rounded-1 d-flex align-items-center justify-content-center "
      type={type}
      disabled={disable}
      style={{
        backgroundColor: background,
        color: textColor,
        fontSize: fontSize,
        width: width,
        height: height,
        border: border,
        marginTop: marginTop,
        ...props
      }}
      onClick={func}
    >
      {icon}
      {title}
    </button>
  );
}
