import { ThemeColors } from "../../theme/theme";
import { Button } from "../customTextInput/indexCss";
export default function CustomButton(props) {
  const {
    title,
    type,
    width = "100%",
    background = ThemeColors.primary,
    fontSize='16px',
    func,
  } = props;
  return (
    <>
      <Button
        type={type}
        style={{ width: width, background: background ,fontSize: fontSize }}
        onClick={func}
      >
        {title}
      </Button>
    </>
  );
}
