import React from "react";
import styled from "styled-components";
import { ThemeColors } from "../../theme/theme";
import "../../pages/privatePage/dashboard/dashboard.css";
export default function Carddynamic(props) {
  const { title, subTitle, detail, icon, dropdown, link, menuStyle ,height } = props;
  const StyledCard = styled.div`
    position: relative;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -ms-flex-direction: row;
    flex-direction: column;
    word-wrap: break-word;
    background-clip: border-box;
    border-radius: 8px;
    background-color: ${ThemeColors.white};
    justify-content: space-between;
    align-items: inherit;
     height: ${height};
    display: flex;
  `;
  return (
    <>
      <StyledCard>
        {/* <Cardbody> */}
        <div className="d-flex justify-content-between align-items-start ">
          <div className={!link ? "detail align-item-start" : "detail d-flex"}>
            {title}{" "}
            <span className={!link ? "subtitle" : "subtitle mt-2 ms-2"}>
              {subTitle}
            </span>
          </div>
          {dropdown && (
            <div className="detail align-item-end me-0 ms-2">{dropdown}</div>
          )}
          {link && (
            <div
              className="detail link"
              style={{ color: menuStyle, cursor: "pointer",fontSize:'14px' }}
            >
              {link}
            </div>
          )}
        </div>
        {!subTitle && (
          <div className="d-flex justify-content-between" style={{marginRight: '2rem'}}>
            {detail && (
              <>
                <div className="detail align-item-start">{detail}</div>
                <div className="detail align-item-end">{icon}</div>
              </>
            )}
          </div>
        )}
        {subTitle && (
          <div className="justify-content-between">
            {detail && <div className="detail align-item-start">{detail}</div>}
          </div>
        )}
      </StyledCard>
    </>
  );
}
