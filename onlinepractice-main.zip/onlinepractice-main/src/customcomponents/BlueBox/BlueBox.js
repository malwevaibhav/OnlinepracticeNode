import React from 'react'

export default function BlueBox({ array }) {
    const myStyle = {
        padding: '2px 10px',
        gap: '20px',
        minWidth: 'max-content',
        height: '29px',
        borderRadius: '3px',
        color: '#0075ff',
        margin:"0",
        background: '#ecf5ff',
        border: '1px solid #d0e6ff',
    }
    return (
        <>
            {
                array.map((a, key) => (
                    <p style={myStyle} key={key} className="me-2">{a}</p>
                )
                )
            }
        </>
    )
}
