import React, { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { DataNotFound2, KebaDots } from "../../assets/svgs/svg";
import CheckStatus from "../../component/statusTable";
import AuthStore from "../../MobX/Auth";
import { ThemeColors } from "../../theme/theme";
import ActionButton from "../actionbutton/ActionButton";
import BlueBox from "../BlueBox/BlueBox";
import Button from "../button/Button";
import Checkbox from "../checkbox/Checkbox";
import DeleteModal from "../modalPopup/deleteModal/DeleteModal";
import "./Table.css";

export default function MockTable({
    tableData,
    tableHead,
    checkbox = true,
    SerialNumbers = false,
    tHeadBackgoundColor,
    tHeadPadding = "py-3 ps-2",
    action = true,
    navigateTo = "",
    isQuickView = false,
    showId = false,
    QuickViewClick,
    toggleEditModal,
    setId,
    viewDetail,
    deleteData,
    eye = true,
    del = true,
    edit = true,
    actionShowHide
}) {
    const Role = AuthStore?.user?.user;
    const navigate = useNavigate();
    const [showIcon, setShowIcon] = useState(false);
    const [isCheckAll, setIsCheckAll] = useState(false);
    const [isCheck, setIsCheck] = useState([]);
    const [keysArr, setKeysArr] = useState([]);
    const [showModal, setShowmodal] = useState('');
    const [Id, setDataId] = useState('');
    const [DeletingName, setDeletingName] = useState('');
    const activeRef = useRef();

    useEffect(() => {
        if (tableData?.length > 0) {
            setKeysArr(Object.keys(tableData[0]));
        }
        function handleClickOutside(event) {
            if (activeRef.current && !activeRef.current.contains(event.target)) {
                setShowIcon(false)
            }
        }
        document.addEventListener("mousedown", handleClickOutside);
        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [activeRef, tableData]);

    const timeZoneOption = {
        dateStyle: "medium",
        timeStyle: "short",
        hour12: true,
        timeZone: "IST",
    };

    const selectAll = (e) => {
        setIsCheckAll(!isCheckAll);
        setIsCheck(tableData.map((li) => li.id));
        if (isCheckAll) {
            setIsCheck([]);
        }
    };

    const selected = (e) => {
        let tempChecked = isCheck;
        const { id, checked } = e?.target;
        setIsCheck([...isCheck, id]);
        tempChecked.push(id);
        if (!checked) {
            tempChecked = tempChecked.filter((item) => item !== id);
            setIsCheck(tempChecked);
        }
        if (tempChecked?.length === tableData?.length) {
            setIsCheckAll(true);
        } else {
            setIsCheckAll(false);
        }
    };

    return (
        <div className="table-responsive">
            <table className="Customtable table table-borderless">
                <thead style={{ background: tHeadBackgoundColor }}>
                    <tr>
                        <th
                            className="d-flex ms-3 py-3"
                            scope="col"
                            style={{ paddingTop: "" }}
                        >
                            {checkbox && (
                                <Checkbox
                                    id="selectAll"
                                    handleClick={selectAll}
                                    isChecked={isCheckAll}
                                />
                            )}
                        </th>
                        {tableHead?.map((data, i) => (
                            <th className={`${tHeadPadding} cells ${data === "action" && 'text-end'}`} scope="col" key={i}>
                                {data === "action" ? <KebaDots /> : data}
                            </th>
                        ))}
                    </tr>
                </thead>
                <tbody>
                    {(keysArr.length > 0 && tableData?.length > 0) ? tableData?.map((dataObj, i) => {
                        return (
                            <tr key={i}>
                                <td
                                    style={{
                                        paddingBlock: "1rem",
                                        paddingLeft: "1.5rem",
                                    }}
                                >
                                    {checkbox && (
                                        <Checkbox
                                            id={dataObj.id}
                                            handleClick={selected}
                                            isChecked={isCheck.includes(dataObj.id)}
                                        />
                                    )}

                                </td>
                                {SerialNumbers && <td style={{
                                    paddingBlock: "1rem",
                                    paddingLeft: "1.5rem",
                                }}>{i + 1}</td>}

                                {keysArr?.map(
                                    (obj, ind) =>
                                    (obj !== "creationUserId" &&
                                        (showId || obj !== "id") && (
                                            <td key={ind}
                                                style={{ paddingBlock: "1rem" }}
                                                className={
                                                    Array.isArray(dataObj[obj]) ? "" : "fw-normal"
                                                }
                                            >
                                                {Array.isArray(dataObj[obj]) ?
                                                    (
                                                        <div className="d-flex flex-wrap gap-2">
                                                            <BlueBox array={dataObj[obj]} />
                                                        </div>
                                                    ) :
                                                    obj === "status" ?
                                                        (
                                                            CheckStatus(dataObj[obj])
                                                        ) :
                                                        (obj === "action" && !action) ? (obj === "action" && <div
                                                            className="actionTd "
                                                            onClick={() => {
                                                                setShowIcon(i);

                                                            }}
                                                            onMouseOver={() => { setShowIcon(i) }}
                                                        >

                                                            {showIcon === i ? (
                                                                <ActionButton
                                                                    veiwFunction={() => {
                                                                        navigateTo && navigate(`/${navigateTo}`, { state: { id: dataObj?.id }, }); viewDetail && viewDetail(dataObj)
                                                                    }}
                                                                    eye={eye}
                                                                    del={dataObj?.creationUserId === Role?.userId || Role?.role === "Admin"}
                                                                    // del={dataObj?.creationUserId===Role?.userid || Role?.role==="Admin"}
                                                                    edit={dataObj[actionShowHide.keyName][actionShowHide.index] === actionShowHide.value ? false : edit && (Role?.role === "Admin" || dataObj?.creationUserId === Role?.userId)}
                                                                    // edit={dataObj[actionShowHide.keyName][actionShowHide.index] === actionShowHide.value ? false : edit && (Role?.role === "Admin" || dataObj?.creationUserId === Role?.userid)}
                                                                    deletefunction={() => { setShowmodal('delete'); setDeletingName(dataObj[keysArr[1]]); setDataId(dataObj?.id) }}
                                                                    editfunction={() => { toggleEditModal(dataObj); setId && setId(dataObj?.id) }}
                                                                />
                                                            ) : <div><KebaDots /></div>}
                                                        </div>) :
                                                            (
                                                                <div className="d-flex align-items-center justify-content-between gap-3">
                                                                    {obj.toLowerCase() === "creationdate" || obj.toLowerCase() === "lastmodifieddate"
                                                                        ? new Date(dataObj[obj] + "z").toLocaleString("en-IN", timeZoneOption)
                                                                        : dataObj[obj]}

                                                                    {ind === 0 && isQuickView && (
                                                                        <Button
                                                                            title="Quick View"
                                                                            width="93px"
                                                                            height="28px"
                                                                            fontSize="13px"
                                                                            background={ThemeColors.secondary}
                                                                            func={() => QuickViewClick(dataObj)}
                                                                        />
                                                                    )}

                                                                </div>
                                                            )}



                                            </td>
                                        )
                                    )
                                )}
                            </tr>
                        )
                    }) : <tr><td colSpan="10" className="text-center p-5"><DataNotFound2 /></td></tr>}
                </tbody>
            </table>

            {
                showModal === "delete" && (
                    <DeleteModal
                        onRequestClose={() => {
                            setShowmodal('');
                        }}
                        onPress={() => {
                            setShowmodal(''); deleteData(Id);
                        }}
                        name={DeletingName}
                    />
                )
            }
        </div>
    );
}
