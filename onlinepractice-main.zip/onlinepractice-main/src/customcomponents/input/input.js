import React from "react";
import { InputLabel } from "../customTextInput/indexCss";
import "./input.css";

export default function Input({

  title,
  marginTop = "",
  backgroundColor = "#ffff ",
  onChange,
  id,
  name,
  width,
  height,
  marginRight,
  marginBottom,
  value,
  disabled

}) {
  return (
    <>
      {title && <InputLabel>{title}</InputLabel>}

      <input
        className="input-field inputField form-control"
        id={id}
        name={name}
        style={{
          marginTop: marginTop,
          backgroundColor: backgroundColor,
          width: width,
          height: height,
          marginRight: marginRight,
          marginBottom: marginBottom,

          value: value,


        }}
        disabled={disabled}
        onChange={onChange}
      />
    </>
  );
}
