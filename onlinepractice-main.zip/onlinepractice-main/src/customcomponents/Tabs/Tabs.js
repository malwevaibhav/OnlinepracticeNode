import React from "react";
import { useState } from "react";
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Tab, Tabs as TabsComponent, TabList, TabPanel } from "react-tabs";
import "react-tabs/style/react-tabs.css";
import { toast } from "react-toastify";
import MockTestStore from "../../MobX/MockTestStore";
import EbookServices from "../../Services/EbookService";
import MocktestServices from "../../Services/MockTestService";
import PYPServices from "../../Services/PYPService";
import VideoServices from "../../Services/videoService";
import { ClientRoutesConstants } from "../../shared/constant";
import Table from "../table/Table";
import './Tabs.css'
const tHead = ["Heading", "Description", "Category", "Last Update (Date & Time)"]

const Tabs = ({ data, getFunction }) => {
  const navigate = useNavigate()
  const [tabData, setTabData] = useState([]);
  /* eslint-disable */
  useEffect(() => {
    createTabData(data)
  }, [data])

  const createTabData = (moduleData) => {
    /* eslint-disable */
    moduleData && moduleData.map((data) => {
      if (data?.moduleName === "MockTest") {
        data.body = <Table tableHead={["Heading", "Description", "Category",  "Last Update (Date & Time)"]} tableData={data?.moduleData} deleteData={deleteMockTest} viewDetail={viewMockTest} toggleEditModal={editMockTest} hideDots={true} />
      }
      if (data?.moduleName === "Videos") {
        data.body = <Table tableHead={tHead} tableData={data?.moduleData} deleteData={deleteVideo} viewDetail={viewVideo} toggleEditModal={editVideo} hideDots={true} />
      }
      if (data?.moduleName === "Ebook") {
        data.body = <Table tableHead={tHead} tableData={data?.moduleData} deleteData={deleteEbook} viewDetail={viewEbook} toggleEditModal={editEbook} hideDots={true} />
      }
      if (data?.moduleName === "Previous Year Paper") {
        data.body = <Table tableHead={["Heading", "Description", "Category", "Last Update (Date & Time)"]} tableData={data?.moduleData} deleteData={deletePYP} viewDetail={viewPYP} toggleEditModal={editPYP} hideDots={true} />
      }
      if (data?.moduleName === "Live Classes") {
        data.body = <Table tableHead={tHead} tableData={data?.moduleData} hideDots={true} />
      }
    })
    setTabData(moduleData)
  }

  //#region Mock Test
  const viewMockTest = (data) => {
    localStorage.setItem("step1Res", data?.id);
    if (data?.mockTestType[0] === "Automatic") {
      navigate(ClientRoutesConstants.viewMockAutomatic, {
        state: { id: data?.id, language: data?.languages[0] },
      });
    } else {
      MockTestStore.setStepCount(3);
      MockTestStore.setCurrentStep({ step: 3, from: 0 });
      navigate(ClientRoutesConstants.createMockTest, {
        state: {
          id: data?.id,
          publish: data.status === "Pending" ? false : true,
        },
      });
    }
  };

  const editMockTest = async (data) => {
    localStorage.setItem("step1Res", data?.id);
    MockTestStore.setStepCount(3);
    MockTestStore.setCurrentStep({ step: 1, from: 0 });
    navigate(ClientRoutesConstants.createMockTest, { state: { id: data?.id } });
  }
  const deleteMockTest = async (id) => {
    const deleteData = await MocktestServices.deleteMockTest({ id: id });
    if (deleteData?.isSuccess) {
      toast.success(deleteData?.messages);
      getFunction()
    } else {
      toast.error(deleteData?.messages);
    }
  }
  //#endregion

  //#region Videos
  const viewVideo = async (data) => {
    navigate(ClientRoutesConstants?.videoPurchase, { state: { id: data?.id } })
  }
  const editVideo = async (data) => {
    navigate(ClientRoutesConstants?.addNewvideo, { state: { id: data?.id } })
  }

  const deleteVideo = async (id) => {
    const del = await VideoServices.deleteVideo({ id: id });
    if (del?.isSuccess) {
      toast.success(del?.messages);
      getFunction()
    } else {
      toast.error(del?.messages);
    }
  }
  //#endregion

  //#region Ebook
  const viewEbook = async (data) => {
    navigate(ClientRoutesConstants?.purchaseEbook, { state: { id: data?.id } })
  }
  const editEbook = async (data) => {
    navigate(ClientRoutesConstants?.addnewbook, { state: { id: data?.id } })
  }

  const deleteEbook = async (id) => {
    const deleteData = await EbookServices.deleteEbook({ id: id });
    if (deleteData?.isSuccess) {
      toast.success(deleteData?.messages);
      getFunction()
    } else {
      toast.error(deleteData?.messages);
    }
  }
  //#endregion

  //#region PYP
  const viewPYP = async (data) => {
    navigate(ClientRoutesConstants?.PYPDetail, { state: { id: data?.id } })
  }
  const editPYP = async (data) => {
    navigate(ClientRoutesConstants?.addUpdatePYP, { state: { id: data?.id } })
  }

  const deletePYP = async (id) => {
    const del = await PYPServices.deletePaper({ id: id });
    if (del?.isSuccess) {
      toast.success(del?.messages);
      getFunction();
    } else {
      toast.error(del?.messages);
    }
  }
  //#endregion

  return (
    data && tabData &&
    <TabsComponent>
      <TabList>
        {tabData?.map(({ moduleName }, i) => (
          <Tab key={i}>{moduleName}</Tab>
        ))}
      </TabList>

      {tabData.map(({ body }, i) => (
        <TabPanel key={i}>
          <div className="d-grid">
            {body}
          </div>
        </TabPanel>
      ))}

    </TabsComponent>
  );
}

export default Tabs;
