import axios from "axios";
import { Navigate } from "react-router-dom";
import AuthServices from "../Services/AuthService";
let baseURL=process.env.REACT_APP_API_URL
const MainService=axios.create({
    baseURL,
})
MainService.interceptors.request.use( 
    (config) => {
     var token = localStorage.getItem("key");
    const authToken = JSON.parse(token);
    if(token){
        config.headers['Authorization']='Bearer ' + authToken?.token ; 
        if(!config.headers['Content-Type']){
        config.headers['Content-Type'] =  "application/json";
        }
    }

    return config ;
    },
    (error) => {
        if (error && error.response) {
            if (error.response.status === 401) {
                AuthServices.removeLogin();   
                <Navigate to={"/auth/login"} replace />
                return Promise.reject(error.response)
            }
            return Promise.reject(error)
        }
    }
)
MainService.interceptors.response.use(
    response=>{
        return response
    },
    function(error){
        // const originalRequest= error.config
        if(error.response.status===401){
            AuthServices.removeLogin();    
            <Navigate to={"/auth/login"} replace />
        }
        return Promise.reject(error);
    }
)





export default MainService