import axios from "axios";
import { Navigate} from "react-router-dom";
import AuthServices from "../../Services/AuthService";
export async function apiReq(
  endPoint,
  data,
  method,
  headers,
  requestOptions = {}
) {

  return new Promise(async (res, rej) => {
    // loaderStore.setLoader(true);
    // const getTokenHeader = await getHeaders();
    headers = {
      ...headers,
    };

    if (method === "get" || method === "delete") {
      data = {
        ...requestOptions,
        ...data,
        headers,
      };
    }

    axios[method](endPoint, data, { headers })
      .then((result) => {
        // const { data } = result;

        // if (data.status === false) {
        //   return rej(data);
        // }

        return res(result);
      })
      .catch((error) => {
        if (error && error.response && error.response.status === 401) {
          AuthServices.removeLogin();
          // navigate("/auth/login", { replace: true });
          <Navigate to={"/auth/login"} replace />
        }
        if (error && error.response && error.response.data) {
          if (!error.response.data.message) {
            return rej({
              ...error.response.data,
              msg: error.response.data.message || "Network Error",
            });
          }

          return rej(error.response.data);
        } else {
          return rej({ message: "Network Error", msg: "Network Error" });
        }
      });
  });
}

export function apiPost(path, data, headers = {}) {
  var token = localStorage.getItem("key");
  const authToken = JSON.parse(token);
  let config;
  if (authToken?.token) {
    config = {
      headers: {
        Authorization: `Bearer ${authToken?.token}`,
        "Content-Type": "application/json",
      },
    };
  } else {
    config = {
      headers: {
        "Content-Type": "application/json",
      },
    };
  }
  return apiReq(path,data,"post",config.headers)
 
}

export function apiPostUpload(path, data, headers = {}) {
  var token = localStorage.getItem("key");
  const authToken = JSON.parse(token);
  let config;
  if (authToken?.token) {
    config = {
      headers: {
        Authorization: `Bearer ${authToken?.token}`,
        // "Content-Type": "application/json",
        "Content-Type": "multipart/form-data"
      },
    };
  } else {
    config = {
      headers: {
        // "Content-Type": "application/json",
        "Content-Type": "multipart/form-data"
      },
    };
  }

   return apiReq(path,data,"post",config.headers)
}

export function apiGet(path, headers = {}) {
  var token = localStorage.getItem("key");
  const authToken = JSON.parse(token);

  let config;
  if (authToken?.token) {
    config = {
      headers: {
        Authorization: `Bearer ${authToken.token}`,
        "Content-Type": "application/json",
      },
    };
  } else {
    config = {
      headers: {
        "Content-Type": "application/json",
      },
    };
  }
  return apiReq(path,'','get',config?.headers)
  // return axios.get(path, config);
}

export function apiPatch(path, data, headers = {}) {
  var token = localStorage.getItem("key");
  const authToken = JSON.parse(token);
  let config;
  if (authToken?.token) {
    config = {
      headers: {
        Authorization: `Bearer ${authToken?.token}`,
        "Content-Type": "application/json",
        ...headers,
      },
    };
  } else {
    config = {
      headers: {
        "Content-Type": "application/json",
        ...headers,
      },
    };
  }

  return axios.patch(path, data, config);
}

export function apiPut(path, data) {
  var token = localStorage.getItem("key");
  const authToken = JSON.parse(token);
  let config;
  if (authToken?.token) {
    config = {
      headers: {
        Authorization: `Bearer ${authToken?.token}`,
        "Content-Type": "application/json",
      },
    };
  } else {
    config = {
      headers: {
        "Content-Type": "application/json",
      },
    };
  }

  return axios.put(path, data, config);
}

export function apiDelete(path, data) {
  var token = localStorage.getItem("key");
  const authToken = JSON.parse(token);
  let config;
  if (authToken?.token) {
    config = {
      headers: {
        Authorization: `Bearer ${authToken?.token}`,
        "Content-Type": "application/json",
      },
    };
  } else {
    config = {
      headers: {
        "Content-Type": "application/json",
      },
    };
  }

  return axios.delete(path, { ...config, data: data });
}
