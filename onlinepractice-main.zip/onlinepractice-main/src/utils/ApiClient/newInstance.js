import axios from "axios";

var token = localStorage.getItem("key");
const authToken = JSON.parse(token);
// if(token){
//     config.headers['Authorization']='Bearer ' + authToken  
// }
// else if (!config.headers['Content-Type']) {
//     config.headers['Content-Type'] = 'application/json';
// }

