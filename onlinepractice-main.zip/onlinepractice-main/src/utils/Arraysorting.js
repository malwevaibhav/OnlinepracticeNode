export const removeDuplicateFromArr = (array, key) => {
  const counterVar = new Set();

  const filteredArr = array.filter((el) => {
    const duplicate = counterVar.has(el[key]);
    counterVar.add(el[key]);
    return !duplicate;
  });
  return filteredArr;
};

export const sortArrayAlphabatically = (arr, key, mode = "asc") => {
  return arr.sort((a, b) => {
    let fa = a[key]?.toLowerCase(),
      fb = b[key]?.toLowerCase();
    if (mode === "asc") {
      if (fa < fb) {
        return -1;
      }
      if (fa > fb) {
        return 1;
      }
      return 0;
    } else {
      if (fb < fa) {
        return -1;
      }
      if (fb > fa) {
        return 1;
      }
      return 0;
    }
  });
};

export const sortArrayByDate = (arr, key, mode = "asc") => {
  return arr.sort((a, b) => {
    const date1 = new Date(b[key]);
    const date2 = new Date(a[key]);
    if (mode === "asc") {
      return date1 - date2;
    } else {
      return date2 - date1;
    }
  });
};
