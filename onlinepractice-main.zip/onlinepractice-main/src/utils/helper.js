import { toJS } from "mobx";
import { toast } from "react-toastify";
import EbookStore from "../MobX/Ebook";
import QuestionStore from "../MobX/Question";


const month = ["January","February","March","April","May","June","July","August","September","October","November","December"];

export const filterQuestionCategory = (inputArray, item) => {
    return inputArray?.filter((element) => element?.id === item?.id);
};

export const removeExtraSpace = (inputString) => {
    if (typeof inputString === "string") {
        var name = inputString;
        var nArr = name.split(" ");
        var NewName = "";
        nArr.forEach((a) => {
            if (a !== "") {
                NewName += a + " ";
            }
        });
        return NewName.trim();
    } else {
        return inputString;
    }
};


//Optimize code .//
export const validateQuestion = (checkdata) => {

    let count = 0;
    let language = [];
    let languageData = [];
    language = toJS(QuestionStore?.Language).filter(emp => emp?.name !== 'English');
    languageData = toJS(QuestionStore?.Language);
    //Select integer Type//
    //#endregion
    if ([QuestionStore?.languageSelected][0] === "English" && checkdata?.questionType === 3) {
        if (checkdata?.questionTableData[QuestionStore?.languageSelected]?.questionText === "") {
            toast.error("Please select Question");
        } else if (checkdata?.questionTableData[QuestionStore?.languageSelected]?.optionA === "") {
            toast.error("Please select Answer");
        }
        else if (checkdata?.mark === 0 || checkdata?.mark === "") {
            toast.error("Please select total marks");
        }
        else {
            language?.forEach((item, index) => {
                if (checkdata?.questionTableData[item?.name]?.questionText !== "") {
                    if (checkdata?.questionTableData[item?.name]?.optionA === "") {
                        return count++;
                    }
                }
                else if (checkdata?.questionTableData[item?.name]?.optionA !== "") {
                    if (checkdata?.questionTableData[item?.name]?.questionText === "") {
                        return count++
                    }
                }
            })
            if (count > 0) {
                toast.error("please fill all Fields");
                return false;
            } else {
                return true;
            }
        }
    }
    else if ([QuestionStore?.languageSelected][0] !== "English" && checkdata?.questionType === 3) {
        languageData?.forEach((item, index) => {
            if (item?.name === 'English') {
                if (checkdata?.questionTableData[item?.name]?.questionText === "") {
                    return count++;
                }
                else if (checkdata?.questionTableData[item?.name]?.optionA === "") {
                    return count++
                }
                else if (checkdata?.mark === 0 || checkdata?.mark === "") {
                    return count++
                }
            } else {
                if (checkdata?.questionTableData[item?.name]?.questionText !== "") {
                    if (checkdata?.questionTableData[item?.name]?.optionA === "") {
                        return count++;
                    }
                }
                else if (checkdata?.questionTableData[item?.name]?.optionA !== "") {
                    if (checkdata?.questionTableData[item?.name]?.questionText === "") {
                        return count++
                    }
                }
            }

        })
        if (count > 0) {
            toast.error("please fill all Fields");
            return false;
        } else {
            return true;
        }
    }

    //Select integer Type//
    //#endregion

    //-----------------select another type------//
    //#region 
    if ([QuestionStore?.languageSelected][0] === "English" && checkdata?.questionType !== 3) {
        if (checkdata?.questionTableData[QuestionStore?.languageSelected]?.questionText === "") {
            toast.error("Please fill Question");
        }
        else if (checkdata?.questionTableData[QuestionStore?.languageSelected]?.optionA ===
            "" ||
            checkdata?.questionTableData[QuestionStore?.languageSelected]?.optionB ===
            "" ||
            checkdata?.questionTableData[QuestionStore?.languageSelected]?.optionC ===
            "" ||
            checkdata?.questionTableData[QuestionStore?.languageSelected]?.optionD ===
            "") {
            toast.error("Please fill all options");
        }
        else if ((checkdata?.questionTableData[QuestionStore?.languageSelected]
            ?.isCorrectA === false &&
            checkdata?.questionTableData[QuestionStore?.languageSelected]
                ?.isCorrectB === false &&
            checkdata?.questionTableData[QuestionStore?.languageSelected]
                ?.isCorrectC === false &&
            checkdata?.questionTableData[QuestionStore?.languageSelected]
                ?.isCorrectD === false)) {
            toast.error("Please select atleast one correct Answer");
        }
        else if (checkdata?.mark === 0 || checkdata?.mark === "") {
            toast.error("Please select total marks");
        }
        else {
            language?.forEach((item, index) => {
                if (checkdata?.questionTableData[item?.name]?.questionText !== "") {
                    if ((checkdata?.questionTableData[item?.name]?.optionA === "" || checkdata?.questionTableData[item?.name]?.optionB === "" ||
                        checkdata?.questionTableData[item?.name]?.optionC === "" || checkdata?.questionTableData[item?.name]?.optionD === "")) {
                        return count++;
                    }
                }
                else if ((checkdata?.questionTableData[item?.name]?.optionA !== "" || checkdata?.questionTableData[item?.name]?.optionB !== "" ||
                    checkdata?.questionTableData[item?.name]?.optionC !== "" || checkdata?.questionTableData[item?.name]?.optionD !== "")) {
                    if (checkdata?.questionTableData[item?.name]?.questionText === "") {
                        return count++
                    }
                }
                else if ((checkdata?.questionTableData[item?.name]?.isCorrectA === false && checkdata?.questionTableData[item?.name]?.isCorrectB === false &&
                    checkdata?.questionTableData[item?.name]?.isCorrectC === false && checkdata?.questionTableData[item?.name]?.isCorrectD === false)) {
                    return count++;
                }
                else if (checkdata?.mark === 0 || checkdata?.mark === "") {
                    return count++;
                }
            })
            if (count > 0) {
                toast.error("please fill all Fields");
                return false;
            } else {
                return true;
            }
        }
    }
    else if ([QuestionStore?.languageSelected][0] !== "English" && checkdata?.questionType !== 3) {
        languageData?.forEach((item, index) => {
            if (item?.name === 'English') {
                if (checkdata?.questionTableData[item?.name]?.questionText === "") {
                    if ((checkdata?.questionTableData[item?.name]?.optionA === "" || checkdata?.questionTableData[item?.name]?.optionB === "" ||
                        checkdata?.questionTableData[item?.name]?.optionC === "" || checkdata?.questionTableData[item?.name]?.optionD === "")) {
                        return count++;
                    }
                }
                else if (checkdata?.questionTableData[item?.name]?.questionText !== "") {
                    if ((checkdata?.questionTableData[item?.name]?.optionA === "" || checkdata?.questionTableData[item?.name]?.optionB === "" ||
                        checkdata?.questionTableData[item?.name]?.optionC === "" || checkdata?.questionTableData[item?.name]?.optionD === "")) {
                        return count++;
                    }
                }
                else if ((checkdata?.questionTableData[item?.name]?.optionA !== "" || checkdata?.questionTableData[item?.name]?.optionB !== "" ||
                    checkdata?.questionTableData[item?.name]?.optionC !== "" || checkdata?.questionTableData[item?.name]?.optionD !== "")) {
                    if (checkdata?.questionTableData[item?.name]?.questionText === "") {
                        return count++
                    }
                }
                else if ((checkdata?.questionTableData[item?.name]?.isCorrectA === false && checkdata?.questionTableData[item?.name]?.isCorrectB === false &&
                    checkdata?.questionTableData[item?.name]?.isCorrectC === false && checkdata?.questionTableData[item?.name]?.isCorrectD === false)) {
                    return count++;
                }
                else if (checkdata?.mark === 0 || checkdata?.mark === "") {
                    return count++;
                }

            } else {
                if (checkdata?.questionTableData[item?.name]?.questionText !== "") {
                    if ((checkdata?.questionTableData[item?.name]?.optionA === "" || checkdata?.questionTableData[item?.name]?.optionB === "" ||
                        checkdata?.questionTableData[item?.name]?.optionC === "" || checkdata?.questionTableData[item?.name]?.optionD === "")) {
                        return count++;
                    }
                }
                else if ((checkdata?.questionTableData[item?.name]?.optionA !== "" || checkdata?.questionTableData[item?.name]?.optionB !== "" ||
                    checkdata?.questionTableData[item?.name]?.optionC !== "" || checkdata?.questionTableData[item?.name]?.optionD !== "")) {
                    if (checkdata?.questionTableData[item?.name]?.questionText === "") {
                        return count++
                    }
                }
                else if ((checkdata?.questionTableData[item?.name]?.isCorrectA === false && checkdata?.questionTableData[item?.name]?.isCorrectB === false &&
                    checkdata?.questionTableData[item?.name]?.isCorrectC === false && checkdata?.questionTableData[item?.name]?.isCorrectD === false)) {
                    return count++;
                }
                else if (checkdata?.mark === 0 || checkdata?.mark === "") {
                    return count++;
                }

            }
        })
        if (count > 0) {
            toast.error("please fill all Fields");
            return false;
        } else {
            return true;
        }
    }
    //#endregion
};

export const validateUpdateQuestion = (checkdata) => {
    let count = 0;
    let language = [];
    let languageData = [];
    language = toJS(QuestionStore?.Language).filter(emp => emp?.name !== 'english');
    languageData = toJS(QuestionStore?.Language);
    //#endregion
    if ([QuestionStore?.languageSelected][0] === "english" && checkdata?.questionType === 3) {
        if (checkdata?.questionTableData[QuestionStore?.languageSelected]?.questionText === "") {
            toast.error("Please select Question");
        } else if (checkdata?.questionTableData[QuestionStore?.languageSelected]?.optionA === "") {
            toast.error("Please select Answer");
        }
        else if (checkdata?.mark === 0 || checkdata?.mark === "") {
            toast.error("Please select total marks");
        }
        else {
            language?.forEach((item, index) => {
                if (checkdata?.questionTableData[item?.name.toLowerCase()]?.questionText !== "") {
                    if (checkdata?.questionTableData[item?.name.toLowerCase()]?.optionA === "") {
                        return count++;
                    }
                }
                else if (checkdata?.questionTableData[item?.name.toLowerCase()]?.optionA !== "") {
                    if (checkdata?.questionTableData[item?.name.toLowerCase()]?.questionText === "") {
                        return count++
                    }
                }
            })
            if (count > 0) {
                toast.error("please fill all Fields");
                return false;
            } else {
                return true;
            }
        }
    }
    else if ([QuestionStore?.languageSelected][0] !== "english" && checkdata?.questionType === 3) {
        languageData?.forEach((item, index) => {
            if (item?.name.toLowerCase() === 'english') {
                if (checkdata?.questionTableData[item?.name.toLowerCase()]?.questionText === "") {
                    return count++;
                }
                else if (checkdata?.questionTableData[item?.name.toLowerCase()]?.optionA === "") {
                    return count++
                }
                else if (checkdata?.mark === 0 || checkdata?.mark === "") {
                    return count++
                }
            } else {
                if (checkdata?.questionTableData[item?.name.toLowerCase()]?.questionText !== "") {
                    if (checkdata?.questionTableData[item?.name.toLowerCase()]?.optionA === "") {
                        return count++;
                    }
                }
                else if (checkdata?.questionTableData[item?.name.toLowerCase()]?.optionA !== "") {
                    if (checkdata?.questionTableData[item?.name.toLowerCase()]?.questionText === "") {
                        return count++
                    }
                }
            }

        })
        if (count > 0) {
            toast.error("please fill all Fields");
            return false;
        } else {
            return true;
        }
    }
    //Select integer Type//
    //#endregion

    //-----------------select another type------//
    //#region 
    if ([QuestionStore?.languageSelected][0] === "english" && checkdata?.questionType !== 3) {
        if (checkdata?.questionTableData[QuestionStore?.languageSelected]?.questionText === "") {
            toast.error("Please fill Question");
        }
        else if (checkdata?.questionTableData[QuestionStore?.languageSelected]?.optionA ===
            "" ||
            checkdata?.questionTableData[QuestionStore?.languageSelected]?.optionB ===
            "" ||
            checkdata?.questionTableData[QuestionStore?.languageSelected]?.optionC ===
            "" ||
            checkdata?.questionTableData[QuestionStore?.languageSelected]?.optionD ===
            "") {
            toast.error("Please fill all options");
        }
        else if ((checkdata?.questionTableData[QuestionStore?.languageSelected]
            ?.isCorrectA === false &&
            checkdata?.questionTableData[QuestionStore?.languageSelected]
                ?.isCorrectB === false &&
            checkdata?.questionTableData[QuestionStore?.languageSelected]
                ?.isCorrectC === false &&
            checkdata?.questionTableData[QuestionStore?.languageSelected]
                ?.isCorrectD === false)) {
            toast.error("Please select atleast one correct Answer");
        }
        else if (checkdata?.mark === 0 || checkdata?.mark === "") {
            toast.error("Please select total marks");
        }
        else {
            language?.forEach((item, index) => {
                if (checkdata?.questionTableData[item?.name.toLowerCase()]?.questionText !== "") {
                    if ((checkdata?.questionTableData[item?.name.toLowerCase()]?.optionA === "" || checkdata?.questionTableData[item?.name.toLowerCase()]?.optionB === "" ||
                        checkdata?.questionTableData[item?.name.toLowerCase()]?.optionC === "" || checkdata?.questionTableData[item?.name.toLowerCase()]?.optionD === "")) {
                        return count++;
                    }
                }
                else if ((checkdata?.questionTableData[item?.name.toLowerCase()]?.optionA !== "" || checkdata?.questionTableData[item?.name.toLowerCase()]?.optionB !== "" ||
                    checkdata?.questionTableData[item?.name.toLowerCase()]?.optionC !== "" || checkdata?.questionTableData[item?.name.toLowerCase()]?.optionD !== "")) {
                    if (checkdata?.questionTableData[item?.name.toLowerCase()]?.questionText === "") {
                        return count++
                    }
                }
                else if ((checkdata?.questionTableData[item?.name.toLowerCase()]?.isCorrectA === false && checkdata?.questionTableData[item?.name.toLowerCase()]?.isCorrectB === false &&
                    checkdata?.questionTableData[item?.name.toLowerCase()]?.isCorrectC === false && checkdata?.questionTableData[item?.name.toLowerCase()]?.isCorrectD === false)) {
                    return count++;
                }
                else if (checkdata?.mark === 0 || checkdata?.mark === "") {
                    return count++;
                }
            })
            if (count > 0) {
                toast.error("please fill all Fields");
                return false;
            } else {
                return true;
            }
        }
    }
    else if ([QuestionStore?.languageSelected][0] !== "english" && checkdata?.questionType !== 3) {
        languageData?.forEach((item, index) => {
            if (item?.name.toLowerCase() === 'english') {
                if (checkdata?.questionTableData[item?.name.toLowerCase()]?.questionText === "") {
                    if ((checkdata?.questionTableData[item?.name.toLowerCase()]?.optionA === "" || checkdata?.questionTableData[item?.name.toLowerCase()]?.optionB === "" ||
                        checkdata?.questionTableData[item?.name.toLowerCase()]?.optionC === "" || checkdata?.questionTableData[item?.name.toLowerCase()]?.optionD === "")) {
                        return count++;
                    }
                }
                else if (checkdata?.questionTableData[item?.name.toLowerCase()]?.questionText !== "") {
                    if ((checkdata?.questionTableData[item?.name.toLowerCase()]?.optionA === "" || checkdata?.questionTableData[item?.name.toLowerCase()]?.optionB === "" ||
                        checkdata?.questionTableData[item?.name.toLowerCase()]?.optionC === "" || checkdata?.questionTableData[item?.name.toLowerCase()]?.optionD === "")) {
                        return count++;
                    }
                }
                else if ((checkdata?.questionTableData[item?.name.toLowerCase()]?.optionA !== "" || checkdata?.questionTableData[item?.name.toLowerCase()]?.optionB !== "" ||
                    checkdata?.questionTableData[item?.name.toLowerCase()]?.optionC !== "" || checkdata?.questionTableData[item?.name.toLowerCase()]?.optionD !== "")) {
                    if (checkdata?.questionTableData[item?.name.toLowerCase()]?.questionText === "") {
                        return count++
                    }
                }
                else if ((checkdata?.questionTableData[item?.name.toLowerCase()]?.isCorrectA === false && checkdata?.questionTableData[item?.name.toLowerCase()]?.isCorrectB === false &&
                    checkdata?.questionTableData[item?.name.toLowerCase()]?.isCorrectC === false && checkdata?.questionTableData[item?.name.toLowerCase()]?.isCorrectD === false)) {
                    return count++;
                }
                else if (checkdata?.mark === 0 || checkdata?.mark === "") {
                    return count++;
                }

            } else {
                if (checkdata?.questionTableData[item?.name.toLowerCase()]?.questionText !== "") {
                    if ((checkdata?.questionTableData[item?.name.toLowerCase()]?.optionA === "" || checkdata?.questionTableData[item?.name.toLowerCase()]?.optionB === "" ||
                        checkdata?.questionTableData[item?.name.toLowerCase()]?.optionC === "" || checkdata?.questionTableData[item?.name.toLowerCase()]?.optionD === "")) {
                        return count++;
                    }
                }
                else if ((checkdata?.questionTableData[item?.name.toLowerCase()]?.optionA !== "" || checkdata?.questionTableData[item?.name.toLowerCase()]?.optionB !== "" ||
                    checkdata?.questionTableData[item?.name.toLowerCase()]?.optionC !== "" || checkdata?.questionTableData[item?.name.toLowerCase()]?.optionD !== "")) {
                    if (checkdata?.questionTableData[item?.name.toLowerCase()]?.questionText === "") {
                        return count++
                    }
                }
                else if ((checkdata?.questionTableData[item?.name.toLowerCase()]?.isCorrectA === false && checkdata?.questionTableData[item?.name.toLowerCase()]?.isCorrectB === false &&
                    checkdata?.questionTableData[item?.name.toLowerCase()]?.isCorrectC === false && checkdata?.questionTableData[item?.name.toLowerCase()]?.isCorrectD === false)) {
                    return count++;
                }
                else if (checkdata?.mark === 0 || checkdata?.mark === "") {
                    return count++;
                }

            }
        })
        if (count > 0) {
            toast.error("please fill all Fields");
            return false;
        } else {
            return true;
        }
    }
    //     //#endregion



};

export const checkDefault = async (e) => {
    e.preventDefault();
};

export const checkValidation = async (bookDetails, image, pdf) => {
    if (!EbookStore?.ebookselectedids?.examTypeId
        || !EbookStore?.ebookselectedids?.instituteId
        || !EbookStore?.ebookselectedids?.courseId ||
        !EbookStore?.ebookselectedids?.subCourseId ||
        !EbookStore?.ebookselectedids?.subjectCategory || !image || !pdf ||
        bookDetails?.EbookTitle==="" ||
        bookDetails?.AuthorName==="" ||
        bookDetails?.Language===""
        ) {
        toast.error("Please fill all feilds");
        return true
    }
    else{
        return false
    }


}

export const HHMMSSToHM = (time) => {
    var a = time?.split(':');
    var minutes = (+a?.[0]) * 60 + (+a?.[1]);
    var Hours = Math.floor(minutes / 60)
    var Min = minutes % 60
    return `${Hours > 0 ? `${Hours} hr` : ""} ${Min > 0 ? `${Min} Min` : ""}`
}

export const getMonth=()=>{
const d = new Date();
let name = month[d.getMonth()];

return  `Month - ${name}`
}
