import { PerformanceblueIcon, PerformancewhiteIcon } from "../assets/icons/Inputicon";
import {
  CourseIcon,
  CourseWhiteIcon,
  DashboardBlueIcon,
  DashboardInstBlueIcon,
  DashboardInstIcon,
  DashboardWhiteIcon,
  PatternBlueIcon,
  PatternWhiteIcon,
  QuestionBankIcon,
  QuestionWhiteIcon,
  SettingBlueIcon,
  SettingWhiteIcon,
  StudyMaterialBlueIcon,
  StudyMaterialWhiteIcon,
  UserBlueIcon,
  UserWhiteIcon,
  WalletBlueIcon,
  WalletWhiteIcon
} from "../assets/svgs/svg";
import { ClientRoutesConstants } from "../shared/constant";

export const Navmenu = [
  {
    tooltip: "heading",
    text: "Dashboard",
    url: ClientRoutesConstants?.dashboard,
    active: false,
    icon: {
      clickedicon: <DashboardWhiteIcon />,
      blueicon: <DashboardBlueIcon />,
    },
    allowedRole: ["Admin"],
  },

  {
    tooltip: "heading",
    text: "Study Material",
    opened: false,
    active: false,
    icon: {
      clickedicon: <StudyMaterialWhiteIcon />,
      blueicon: <StudyMaterialBlueIcon />,
    },
    allowedRole: ["Staff", "Admin"],
    submenus: [
      {
        tooltip: "subheading",
        text: "E-book",
        url: ClientRoutesConstants?.ebook,
        active: false,
        icon: "",
        permissions: "Ebook",
      },
      {
        tooltip: "subheading",
        text: "Videos",
        url: ClientRoutesConstants?.videos,
        active: false,
        icon: "",
        permissions: "Videos",
      },
      {
        tooltip: "subheading",
        text: "Previous Year Paper",
        url: ClientRoutesConstants?.previousYearPaper,
        active: false,
        icon: "",
        permissions: "Previous Year Paper",
      },
    ],
  },

  {
    tooltip: "heading",
    text: "Users",
    icon: { clickedicon: <UserWhiteIcon />, blueicon: <UserBlueIcon /> },
    opened: false,
    active: false,
    allowedRole: ["Admin"],
    submenus: [
      {
        tooltip: "subheading",
        text: "Staff",
        url: ClientRoutesConstants?.stafflist,
        active: false,
        icon: "",
        permissions: "Staff",
      },
      {
        tooltip: "subheading",
        text: "Student",
        url: ClientRoutesConstants?.studentlist,
        active: false,
        icon: "",
        permissions: "Student",
      },
    ],
  },

  {
    tooltip: "heading",
    text: "Courses",
    url: ClientRoutesConstants?.courses,
    icon: { clickedicon: <CourseWhiteIcon />, blueicon: <CourseIcon /> },
    opened: false,
    active: false,
    allowedRole: ["Admin"],
  },

  {
    tooltip: "heading",
    text: "Question Bank",
    url: ClientRoutesConstants?.questionBank,
    active: false,
    icon: {
      clickedicon: <QuestionWhiteIcon />,
      blueicon: <QuestionBankIcon />,
    },
    permissions: "",
    allowedRole: ["Staff", "Admin"],
  },

  {
    tooltip: "heading",
    text: "Pattern",
    url: ClientRoutesConstants?.pattern,
    active: false,
    icon: {
      clickedicon: <PatternWhiteIcon />,
      blueicon: <PatternBlueIcon />,
    },
    permissions: "",
    allowedRole: ["Admin"],
  },

  {
    tooltip: "heading",
    text: "Mock Test",
    url: ClientRoutesConstants?.mocktest,
    active: false,
    icon: {
      clickedicon: <QuestionWhiteIcon />,
      blueicon: <QuestionBankIcon />,
    },
    permissions: "",
    allowedRole: ["Staff", "Admin"],
  },

  {
    tooltip: "heading",
    text: "Institute",
    url: ClientRoutesConstants?.institute,
    active: false,
    icon: {
      clickedicon: <DashboardInstIcon />,
      blueicon: <DashboardInstBlueIcon />,
    },
    permissions: "",
    allowedRole: ['Admin'],
  },

  {
    tooltip: "heading",
    text: "Wallet",
    url: ClientRoutesConstants?.transaction,
    active: false,
    icon: { clickedicon: <WalletWhiteIcon />, blueicon: <WalletBlueIcon /> },
    permissions: "",
    allowedRole: ["Admin"],
  },

  {
    tooltip: "heading",
    text: "Setting",
    url: ClientRoutesConstants?.settings,
    active: false,
    icon: {
      clickedicon: <SettingWhiteIcon />,
      blueicon: <SettingBlueIcon />,
    },
    permissions: "",
    allowedRole: ["Staff", "Admin"],
  },

  {
    tooltip: "heading",
    text: "Performance",
    opened: false,
    active: false,
    icon: {
      clickedicon: <PerformancewhiteIcon />,
      blueicon: <PerformanceblueIcon />,
    },
    allowedRole: ["Admin"],
    submenus: [
      {
        tooltip: "subheading",
        text: "Result",
        url: ClientRoutesConstants?.result,
        active: false,
        icon: "",
        permissions: "Result",
      },
    ],
  },
];

// const allowedRoleCheck = () => {
//   const auth = toJS(AuthStore?.user?.user);
//   const allowedRole = auth?.allowedRole;
// };
