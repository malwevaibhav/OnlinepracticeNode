import background from "../assets/Images/background.svg";
import logo from "./Images/logo.svg";
import WhiteLogo from "./Images/WhiteLogo.svg";

export const PNG = {
  Background: background,
  Logo: logo,
  WhiteLogo: WhiteLogo,
};
