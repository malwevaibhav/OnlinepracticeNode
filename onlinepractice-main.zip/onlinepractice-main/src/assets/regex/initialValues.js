const InitValue = {
    StaffList: { fullName: "", email: "", mobileNumber: "", institute: "",instituteId:"", permission: [] },
    Institute: { instituteName: "", email: "", mobileNumber: "", address: "",contactPerson:'' },
    editEbook: { title: "", author: "", description: "", price: "", category: "",imgUrl:"" },
    StudentList:{ email: "", mobileNumber: "", password: "",fullName: "" }
}

export default InitValue
