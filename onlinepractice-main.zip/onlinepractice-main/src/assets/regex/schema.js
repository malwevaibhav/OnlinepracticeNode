import * as Yup from "yup";
import {
  alphabetOnly,
  emailregex,
  mobileNumber,
  mobileNumberWithCode,
  numberOnly,
  passwordRegex,
  positiveNumber,
} from ".";

export const StaffSchema = () =>
  Yup.object().shape({
    fullName: Yup.string()
      .min(3, "Too Short!")
      .max(25, "Too Long!")
      .required("Full name is required")
      .matches(alphabetOnly, "Full name is not valid"),
    email: Yup.string()
      .required("Email is required")
      .matches(emailregex, "Email is not valid"),
    mobileNumber: Yup.string()
      .required("Mobile number is required")
      .matches(mobileNumber, "Mobile Number is not valid"),
    institute: Yup.string().required("Institute is required"),
    permission: Yup.array()
      .required("Permission is required")
      .min(1, "Permission field must have at least 1 item"),
  });
export const StudentSchema = () =>
  Yup.object().shape({
    fullName: Yup.string()
      .min(3, "Too Short!")
      .max(25, "Too Long!")
      .required("Full name is required")
      .matches(alphabetOnly, "Full name is not valid"),

    email: Yup.string()
      .required("Email is required")
      .matches(emailregex, "Email is not valid"),

    mobileNumber: Yup.string()
      .required("Mobile number is required")
      .matches(mobileNumber, "Mobile Number is not valid"),

    password: Yup.string()
      .required("Password is required")
      .matches(passwordRegex, "Password is not valid"),
  });

export const EditStaffSchema = () =>
  Yup.object().shape({
    fullName: Yup.string()
      .min(3, "Too Short!")
      .max(25, "Too Long!")
      .required("Full name is required")
      .matches(alphabetOnly, "Full name is not valid"),
    email: Yup.string()
      .email()
      .required("Email is required")
      .matches(emailregex, "Email is not valid"),
    mobileNumber: Yup.string()
      .required("Mobile number is required")
      .matches(mobileNumber, "Mobile Number is not valid"),
    instituteName: Yup.string().required("Institute is required"),
    // permission: Yup.array().required("Permission is required").min(1, 'Permission field must have at least 1 items'),
  });

export const EditEbookSchema = () =>
  Yup.object().shape({
    title: Yup.string()
      .min(3, "Too Short!")
      .max(25, "Too Long!")
      .required("Title is required"),
    author: Yup.string().required("Author is required"),
    price: Yup.string()
      .required("Price is required")
      .matches(numberOnly, "Price is not valid"),
    category: Yup.string().required("Category is required"),
    description: Yup.string().required("Category is required"),
    imgUrl: Yup.string(),
  });

export const InstituteSchema = () =>
  Yup.object().shape({
    instituteCode: Yup.string().required("Institute code is required"),
    instituteName: Yup.string()
      .min(3, "Too Short!")
      .required("Institute name is required"),
    instituteEmail: Yup.string()
      .email("Email must be valid")
      .required("Email is required")
      .matches(emailregex, "Email is not valid"),
    instituteContactNo: Yup.string()
      .required("Contact number is required")
      .matches(mobileNumber, "Contact Number is not valid"),
    instituteAddress: Yup.string().required("Institute address is required"),
    instituteCity: Yup.string().required("City is required"),
    instituteContactPerson: Yup.string()
      .min(3, "Too Short!")
      .max(25, "Too Long!")
      .required("Contact person name is required")
      .matches(alphabetOnly, "Contact person name is not valid"),
    instituteLogo: Yup.string().required("Institute logo is required"),
    // instituteLogo: Yup.string(),
  });

export const EditInstituteSchema = () =>
  Yup.object().shape({
    instituteCode: Yup.string().required("Institute code is required").matches(alphabetOnly ,"Institute code is not valid"),
    instituteName: Yup.string()
      .min(3, "Too Short!")
      .required("Institute name is required"),
    instituteEmail: Yup.string()
      .email("Email must be valid")
      .required("Email is required")
      .matches(emailregex, "Email is not valid"),
    instituteContactNo: Yup.string()
      .required("Contact number is required")
      .matches(mobileNumber, "Contact Number is not valid"),
    instituteAddress: Yup.string().required("Institute address is required"),
    instituteCity: Yup.string().required("City is required"),
    instituteContactPerson: Yup.string()
      .min(3, "Too Short!")
      .max(25, "Too Long!")
      .required("Contact person name is required")
      .matches(alphabetOnly, "Contact person name is not valid"),
    // instituteLogo: Yup.string().required("Institute logo is required"),
    instituteLogo: Yup.string(),
  });

export const createCourseSchema = () =>
  Yup.object().shape({
    examTypeName: Yup.string().required("Exam type name is required"),
    courseName: Yup.string().required("Course name is required"),
    subCourseName: Yup.string().required("Sub-Course name is required"),
    // subjectName: Yup.string().required("Subject name is required"),
  });

export const editCourseSchema = () =>
  Yup.object().shape({
    examTypeName: Yup.string().required("Exam type name is required"),
    courseName: Yup.string().required("Course name is required"),
    subCourseName: Yup.string().required("Sub-Course name is required"),
    // subjectName: Yup.string().required("Subject name is required"),
  });

export const pypSchema = () =>
  Yup.object().shape({
    examTypeId: Yup.string().required("Exam type name is required"),
    courseId: Yup.string().required("Course name is required"),
    subCourseId: Yup.string().required("Sub-Course name is required"),
    instituteId: Yup.string().required("Institute Name is required"),
    year: Yup.string().required("Year is required"),
    paperTitle: Yup.string().required("Title is required"),
    language: Yup.string().required("Language is required"),
    paperPdfUrl: Yup.string().required("pdf is required"),
    price: Yup.string().matches(positiveNumber, "Price is not valid"),
  });

export const videoSchema = () =>
  Yup.object().shape({
    examTypeId: Yup.string().required("Exam type name is required"),
    courseId: Yup.string().required("Course name is required"),
    subCourseId: Yup.string().required("Sub-Course name is required"),
    subjectCategory: Yup.string().required("subject name is required"),
    // topicId: Yup.string().required("   topic name is required"),
    instituteId: Yup.string().required("Institute Name is required"),
    videoTitle: Yup.string().required("Video Title is required"),
    facultyName: Yup.string().required(" faculty is required"),
    language: Yup.string().required("Language is required"),
    description: Yup.string().required("Description is required"),
    price: Yup.string().matches(positiveNumber, "Price is not valid"),
    videoUrl: Yup.string().required("video is required"),
  });
