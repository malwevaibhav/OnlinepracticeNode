import { Field, Formik } from "formik";
import React from "react";
import { useNavigate } from "react-router-dom";
import * as Yup from "yup";
import { EmailIcon, Eye, Lock } from "../../../assets/icons/Inputicon";
import { toast } from "react-toastify";
import { emailregex, passwordRegex } from "../../../assets/regex";
import { RightIcon } from "../../../assets/svgs/svg";
import CustomButton from "../../../customcomponents/button/customButton";
import CustomInput from "../../../customcomponents/customTextInput/index";
import UnderLineText from "../../../customcomponents/under-line-text/underLineText";
import AuthServices from "../../../Services/AuthService";
import "./login.css";
import { ClientRoutesConstants } from "../../../shared/constant";

function Login() {
  const navigate = useNavigate();
  const loginCall = async (values) => {
    const res = await AuthServices.login(values);
    if (res?.isSuccess && res?.responseCode === 200) {
      toast.success(res?.messages, {
        position: toast.POSITION.TOP_RIGHT,
      });
      navigate(ClientRoutesConstants?.dashboard);
    } else {
      toast.error(res?.messages, {
        position: toast.POSITION.TOP_RIGHT,
      });
    }
  };
  const forgot = () => {
    navigate(ClientRoutesConstants?.forgetPassword);
  };
  return (
    <div className="login-container">
      <UnderLineText text="Admin / Staff Dashboard" subText="Sign in to your account" />
      <div className="CustomCard">
        {/* <div className="custom-card-body"> */}
        <Formik
          initialValues={{ email: "", password: "", rememberme: false }}
          onSubmit={(values) => {
            loginCall(values);
          }}
          validationSchema={Yup.object().shape({
            email: Yup.string()
              .matches(emailregex, "Email is not valid")
              .required("Email is required"),
            password: Yup.string()
              .required("Password is required")
              .matches(passwordRegex, "Password is not valid"),
          })}
        >
          {(props) => {
            const { touched, errors, dirty, handleChange, handleSubmit } =
              props;
            return (
              <form onSubmit={handleSubmit}>
                <CustomInput
                  name="email"
                  id="email"
                  onChange={handleChange}
                  placeholder="Email Address"
                  label="Email Address"
                  lefticon={<EmailIcon />}
                  righticon={<RightIcon />}
                  errors={!errors?.email && touched?.email}
                  dirty={dirty}
                />
                {errors?.email && touched.email && (
                  <div className="input-feedback">{errors.email}</div>
                )}

                <div className="mt-2">
                  <CustomInput
                    name="password"
                    id="password"
                    type="password"
                    onChange={handleChange}
                    placeholder="Password"
                    label="Password"
                    lefticon={<Lock />}
                    righticon={<Eye />}
                    forgotpass="Forgot password?"
                    forgot={forgot}
                    errors={errors}
                  />
                </div>
                {errors.password && touched.password && (
                  <div className="input-feedback">{errors.password}</div>
                )}

                <div className="d-flex align-items-center mt-3">
                  <Field
                    type="checkbox"
                    name="rememberme"
                    checked={props.values.rememberme}
                  />
                  <span className="text-dark ms-1 " style={{fontFamily:'Medium'}}>Remember me</span>
                </div>
                <CustomButton title="Sign In" type="submit" />
              </form>
            );
          }}
        </Formik>{" "}
      </div>{" "}
      {/* </div> */}
    </div>
  );
}
export default Login;
