import { Formik } from "formik";
import React from "react";

import { useNavigate } from "react-router-dom";
import { GreenWriteIcon } from "../../../assets/icons/Inputicon";
import CustomButton from "../../../customcomponents/button/customButton";

import { ClientRoutesConstants } from "../../../shared/constant";
import "../login/login.css";
import "./Style.css";
const SuccessEmail = () => {
  const navigate = useNavigate();

  return (
    <div className="Success-email">
      <div className="Custom-Card ">
        <Formik>
          {(props) => {
            return (
              <form>
                <div className="Success-Field ">
                  <div>
                    <GreenWriteIcon />
                    We have e-mailed your password
                  </div>
                  <CustomButton title="Continue" func={()=>{navigate(ClientRoutesConstants.login)}} />
                </div>
              </form>
            );
          }}
        </Formik>
      </div>
    </div>
  );
};

export default SuccessEmail;
