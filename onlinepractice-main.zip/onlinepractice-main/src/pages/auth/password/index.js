import { Formik } from "formik";
import React from "react";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import * as Yup from "yup";
import { EmailIcon } from "../../../assets/icons/Inputicon";
import CustomButton from "../../../customcomponents/button/customButton";
import CustomInput from "../../../customcomponents/customTextInput/index";
import UnderLineText from "../../../customcomponents/under-line-text/underLineText";
import "./password.css";
import { emailregex } from "../../../assets/regex";
import { useNavigate } from "react-router-dom";
import { RightIcon } from "../../../assets/svgs/svg";
import AuthServices from "../../../Services/AuthService";
import "../login/login.css";
import "./password.css";

const ForgotPassword = () => {
  const navigate = useNavigate();
  const OnSubmit = async (values) => {
    try {
      const res = await AuthServices.forgot(values);
      if (res?.isSuccess) {
        toast.success(res?.messages);
        navigate('/auth/success-Email');
      } else {
        toast.error(res?.messages)
      }
    } catch (e) {
    
    }
  }

  return (
    <>
      <UnderLineText
        text="Forgot Password"
        subText="Enter the email address associate with your account."
      />
      <div className="Custom-Card">
        <Formik
          initialValues={{email: "" }}
          onSubmit={(values) => {
            OnSubmit(values);
          }}
          validationSchema={Yup.object().shape({
            email: Yup.string()
              .required("Email is required")
              .matches(emailregex, "Email is not valid"),
          })}
        >
          {(props) => {
            const { touched, errors, handleChange, handleSubmit } = props;
            return (
              <form onSubmit={handleSubmit}>
                <CustomInput
                  name="email"
                  id="email"
                  onChange={handleChange}
                  placeholder="demo@gmail.com"
                  label="Email Address"
                  lefticon={<EmailIcon />}
                  righticon={<RightIcon />}
                  errors={!errors?.email && touched?.email}
                />
                {errors.email && touched.email && (
                  <div className="input-feedback">{errors.email}</div>
                )}
                <CustomButton title="Continue" type="submit" />{" "}
              </form>
            );
          }}
        </Formik>{" "}
      </div>
    </>
  );
};

export default ForgotPassword;
