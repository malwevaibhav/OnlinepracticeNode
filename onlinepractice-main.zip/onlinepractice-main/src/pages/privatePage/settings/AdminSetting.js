import React, { useEffect, useRef, useState } from "react";
import { toast } from "react-toastify";
import im from "../../../assets/Images/blankProfile.png";
import Button from "../../../customcomponents/button/Button";
import { HeadTitle } from "../../../customcomponents/headtitle/headTitle";
import AuthServices from "../../../Services/AuthService";
import { ThemeColors } from "../../../theme/theme";
import BasicInfoForm from "./components/BasicInfoForm";
import LinkContainer from "./components/LinkContainer";
import ResetPasswordForm from "./components/ResetPasswordForm";
import "./Settings.css";
const AdminSetting = () => {
  const [userData, setUserData] = useState({});
  const [adminData, setAdminData] = useState({});
  const [height, setHeight] = useState(0);
  const [img, setImg] = useState();
  const [file, setFile] = useState();
  const $input = useRef(null);

  useEffect(() => {
    let data = JSON.parse(localStorage.getItem("key"));
    setUserData(data.user);
    // getAdminProfile(data.user.userid);
    getAdminProfile(data.user.userId);
  }, []);

  const imageChange = (file) => {
    if (
      file[0]?.type === "image/png" ||
      file[0]?.type === "image/jpg" ||
      file[0]?.type === "image/jpeg" ||
      file[0]?.type === "image/bmp"
    ) {
      if (file[0].size < 5000) {
        //console.log("hi");
        toast.error("file size must be greater than 5 kb");
      }
      if (file[0].size >= 1.6e7) {
        toast.error("file size must be less than 16 mb");
      } else {
        setImg(URL.createObjectURL(file[0]));
        setFile(file[0]);
      }
    } else {
      toast.error("file format is not valid");
    }
  };

  const getAdminProfile = async (id) => {
    const getRes = await AuthServices.getAdminProfile({ id: id });
    setImg(getRes?.data?.profileImage);
    setAdminData(getRes?.data);
  };

  const removeprofile = async () => {
    const getRes = await AuthServices.removeAdminProfile({
      id: userData.userId,
      // id: userData.userid,
    });
    if (getRes?.isSuccess) {
      setImg();
      toast.success(getRes?.messages);
      setTimeout(() => {
        window.location.reload();
      }, 500);
    } else {
      toast.error(getRes?.messages);
    }
  };
  const handleScroll = (event) => {
    setHeight(event.currentTarget.scrollTop);
  };
  return (
    <div>
      <div className="d-grid mb-4">
        <HeadTitle text="General Setting" />
        <div className="w-100 d-flex gap-2 justify-content-between flex-wrap mt-4">
          <div className="settings-links w-100 bg-white">
            <div className="profile-settings">
              <h4>Profile Settings</h4>
              <LinkContainer height={height} />
            </div>
          </div>

          <div
            style={{ height: "500px", overflowY: "scroll" }}
            className="d-flex flex-column gap-3 justify-content-start settings-form scroll-view"
            onScroll={handleScroll}
          >
            <div className="general-section w-100 bg-white py-3 general-screen">
              <h4>General</h4>
              <div className="d-flex justify-content-start flex-direction align-items-center gap-2 mb-2">
                <div className="width-label pt-4">
                  <label>Profile Photo</label>
                  <p className="subtext">
                    This will be display on your profile{" "}
                  </p>
                </div>
                <img
                  style={{ objectFit: "cover", width: "78px", height: "78px" }}
                  src={img ? img : im}
                  alt="profile"
                  className="rounded-circle ms-3"
                />
                <input
                  style={{ display: "none" }}
                  type="file"
                  accept="image/png, image/jpeg, image/jpg, image/bmp"
                  ref={$input}
                  onChange={(e) => {
                    imageChange(e.target.files);
                  }}
                />
                <div className="width-input-box d-flex ms-3 gap-3">
                  <Button
                    type="button"
                    title="Change"
                    func={() => {
                      $input.current.click();
                    }}
                    width="127px"
                  />
                  <Button
                    title="Remove"
                    width="105px"
                    background={ThemeColors.danger}
                    disable={img ? false : true}
                    func={removeprofile}
                  />
                </div>
              </div>
            </div>
            <div className="general-section w-100 bg-white py-3 basic-info-screen ">
              <h4>Basic Information</h4>
              <BasicInfoForm
                userData={userData}
                adminData={adminData}
                file={file}
              />
            </div>
            <div className="general-section w-100 bg-white py-3 password-screen">
              <h4>Privacy Setting</h4>
              <ResetPasswordForm adminData={adminData} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminSetting;
