import { Formik } from "formik";
import React from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import * as Yup from "yup";
import { Eye, Lock } from "../../../../assets/icons/Inputicon";
import { passwordRegex } from "../../../../assets/regex";
import Button from "../../../../customcomponents/button/Button";
import CustomInput from "../../../../customcomponents/customTextInput";
import AuthServices from "../../../../Services/AuthService";

const ResetPasswordForm = ({ adminData }) => {
  const navigate = useNavigate()

  const UpdatePassword = async (value) => {
    // value.id = adminData.id;
    const updateRes = await AuthServices.changePassword(value);
    if (updateRes?.isSuccess) {
      toast.success(updateRes?.messages);
      AuthServices.removeLogin();
      navigate("/auth/login", { replace: true });
    } else {
      toast.error(updateRes?.messages);
    }
  }

  return (
    <Formik
      enableReinitialize
      initialValues={{
        id: adminData.id,
        currentpassword: "",
        newpassword: "",
        confirmpassword: "",
      }}
      onSubmit={(values, { resetForm }) => {
        UpdatePassword(values)
        resetForm({ values: "" })

      }}
      validationSchema={Yup.object().shape({
        currentpassword: Yup.string().required("Current password is required"),
        newpassword: Yup.string().matches(passwordRegex, "Password not valid").required("New password is required"),
        confirmpassword: Yup.string().when("newpassword", {
          is: val => (val && val.length > 0 ? true : false),
          then: Yup.string().oneOf(
            [Yup.ref("newpassword")],
            "Both password need to be the same"
          ).required("Confirm password is required")
        }),
      })}
    >
      {(props) => {
        const {
          handleSubmit,
          values,
          errors, touched, handleChange
        } = props;
        return (
          <div className="scroll-view">
            <form onSubmit={handleSubmit}>
              <div className="d-flex justify-content-start flex-direction align-items-center gap-2 mb-2">
                <div className="width-label">
                  <label>Current Password</label>
                </div>
                <div className="width-input-box d-flex">
                  <div className="position-relative">
                    <CustomInput
                      name="currentpassword"
                      id="currentpassword"
                      type="password"
                      onChange={handleChange}
                      placeholder="Current password"
                      lefticon={<Lock />}
                      righticon={<Eye />}
                      errors={errors}
                      value={values?.currentpassword ? values?.currentpassword : ""}
                    />
                    {errors?.currentpassword && touched.currentpassword && (
                      <div className="input-feedback postion-absolute">
                        {errors.currentpassword}
                      </div>
                    )}
                  </div>
                </div>
              </div>
              <div className="d-flex justify-content-start flex-direction align-items-center gap-2 mb-2">
                <div className="width-label">
                  <label>New Password</label>
                </div>
                <div className="width-input-box d-flex">
                  <div className="position-relative">
                    <CustomInput
                      name="newpassword"
                      id="newpassword"
                      type="password"
                      onChange={handleChange}
                      placeholder="New password"
                      lefticon={<Lock />}
                      righticon={<Eye />}
                      errors={errors}
                      value={values?.newpassword ? values?.newpassword : ""}
                    />
                    {errors?.newpassword && touched.newpassword && (
                      <div className="input-feedback postion-absolute">
                        {errors.newpassword}
                      </div>
                    )}
                  </div>
                </div>
              </div>
              <div className="d-flex justify-content-start flex-direction align-items-center gap-2 mb-2">
                <div className="width-label">
                  <label>Confirm Password</label>
                </div>
                <div className="width-input-box d-flex">
                  <div className="position-relative">
                    <CustomInput
                      name="confirmpassword"
                      id="confirmpassword"
                      type="password"
                      onChange={handleChange}
                      placeholder="Confirm password"
                      lefticon={<Lock />}
                      righticon={<Eye />}
                      errors={errors}
                      value={values?.confirmpassword ? values?.confirmpassword : ""}

                    />
                    {errors?.confirmpassword && touched.confirmpassword && (
                      <div className="input-feedback postion-absolute">
                        {errors.confirmpassword}
                      </div>
                    )}
                  </div>
                </div>
              </div>
              <div className="password-requirements mt-4">
                <p>Password requirements:</p>
                <small >Ensure that these requirements are met:</small>
                <ul className="req-list mt-1">
                  <li>Minimum 8 characters long the more, the better</li>{" "}
                  <li>At least one lowercase character</li>{" "}
                  <li>At least one uppercase character</li>{" "}
                  <li>At least one number, symbol, or whitespace character</li>
                </ul>
                <Button title="Save" width="108px" type="submit" />
              </div>
            </form>
          </div>
        );
      }}
    </Formik>

  );
};

export default ResetPasswordForm;
