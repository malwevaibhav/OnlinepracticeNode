import React, { useEffect, useState } from "react";
import Commonservice from "../../../../Services/commonService";
/* eslint-disable */
const LinkContainer = ({height}) => {
  const [Links, setLinks] = useState([
    { linkName: " General", active: false, scrollClass: "general-screen" },
    {
      linkName: "Basic Information",
      active: false,
      scrollClass: "basic-info-screen",
    },
    {
      linkName: "Privacy Setting",
      active: false,
      scrollClass: "password-screen",
    },
  ]);
  const handleLinkClick = (scrollClass, index) => {
    let LinksCopy = [...Links];
    LinksCopy[index].active = true;
    LinksCopy.forEach((item, i) => {
      if (i !== index) {
        item.active = false;
      }
    });
    setLinks([...LinksCopy]);
    Commonservice?.handleScroll(scrollClass);
  };
  useEffect(()=>{
    if(height>=0 && height<10){
      let LinksCopy = [...Links];
      
      LinksCopy[0].active=true
      LinksCopy.forEach((item, i) => {
        if (i !== 0) {
          item.active = false;
        }
      });
    return  setLinks([...Links])
    }
    if(height>=180 && height<200){
      let LinksCopy = [...Links];
      
      LinksCopy[1].active=true
      LinksCopy.forEach((item, i) => {
        if (i !== 1) {
          item.active = false;
        }
      });
     return setLinks([...Links])
    }
    if(height>=600 && height<624){
      let LinksCopy = [...Links];
      
      LinksCopy[2].active=true
      LinksCopy.forEach((item, i) => {
        if (i !== 2) {
          item.active = false;
        }
      });
     return setLinks([...Links])
    }
    // if(180<=height<=200){
    //   let LinksCopy = [...Links];
      
    //   LinksCopy[1].active=true
    //   LinksCopy.forEach((item, i) => {
    //     if (i !== 1) {
    //       item.active = false;
    //     }
    //   });
    //   setLinks([...Links])
    // }
    // if(600<=height<=624){
    //   let LinksCopy = [...Links];
      
    //   LinksCopy[2].active=true
    //   LinksCopy.forEach((item, i) => {
    //     if (i !== 2) {
    //       item.active = false;
    //     }
    //   });
    //   setLinks([...Links])
    // }
  },[height])
  return (
    <>
      {Links.map((item, index) => (
        <div className="px-4 py-2 pt-3 sett-headings">
          <p
            onClick={() => handleLinkClick(item?.scrollClass, index)}
            className={item?.active && "active-link"}
          >
            {item?.linkName}
          </p>
        </div>
      ))}
    </>
  );
};

export default LinkContainer;
