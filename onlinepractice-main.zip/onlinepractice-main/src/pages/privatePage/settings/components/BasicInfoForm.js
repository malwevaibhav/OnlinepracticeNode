import { Formik } from "formik";
import React from "react";
import { toast } from "react-toastify";
import * as Yup from "yup";

import { EmailIcon } from "../../../../assets/icons/Inputicon";
import { emailregex } from "../../../../assets/regex";
import Button from "../../../../customcomponents/button/Button";
import CustomInput from "../../../../customcomponents/customTextInput";
import AuthServices from "../../../../Services/AuthService";
import { removeExtraSpace } from "../../../../utils/helper";

const BasicInfoForm = ({ adminData, file }) => {
  const UpdateProfile = async (value) => {
    value.fullName=removeExtraSpace(value.fullName)
    if (value?.mobileNumber.length < 12) {
      value.mobileNumber = `91${value?.mobileNumber}`
    }
    if (file) {
      const formData = new FormData();
      formData.append("Image", file);
      const uploadImgRes = await AuthServices.uploadImage(formData);
      if (uploadImgRes?.isSuccess) {
        value.profileImage = uploadImgRes?.data
        toast.success(uploadImgRes?.messages);
      } else {
        toast.error(uploadImgRes?.messages);
      }
    }
    const updateRes = await AuthServices.updateAdmin(value);
    if (updateRes?.isSuccess) {
      toast.success(updateRes?.messages);
      window.location.reload()
    } else {
      toast.error(updateRes?.messages);
    }

  }

  return (
    <>
      <Formik
        enableReinitialize
        initialValues={{
          id: adminData?.id,
          fullName: adminData?.name,
          email: adminData?.email,
          profileImage: adminData?.profileImage,
          mobileNumber: adminData?.mobileNumber,
          location: adminData?.location,
        }}
        onSubmit={(values) => {
          UpdateProfile(values);
        }}
        validationSchema={Yup.object().shape({
          fullName: Yup.string().required("Full name is required"),
          email: Yup.string()
            .matches(emailregex, "Email is not valid")
            .required("Email is required"),
          mobileNumber: Yup.string().required("Phone no. is required"),
          location: Yup.string().required("Location is required"),
        })}
      >
        {(props) => {
          const {
            handleSubmit,
            values,
            errors, touched, handleChange
          } = props;
          return (
            <div className="scroll-view">
              <form onSubmit={handleSubmit}>
                <div className="d-flex justify-content-start flex-direction align-items-center gap-2 mb-1">
                  <div className="width-label">
                    <label>Full Name</label>
                  </div>
                  <div className="width-input-box d-flex gap-2">
                    <div className="position-relative">
                      <CustomInput
                        onChange={handleChange}
                        placeholder="Enter full name"
                        errors={!errors?.fullName && touched?.fullName}
                        id="fullName"
                        name="fullName"
                        value={values?.fullName}
                      />
                      {errors?.fullName && touched.fullName && (
                        <div classfullName="input-feedback postion-absolute">
                          {errors.fullName}
                        </div>
                      )}
                    </div>

                  </div>
                </div>
                <div className="d-flex justify-content-start flex-direction align-items-center gap-2 mb-1">
                  <div className="width-label">
                    <label>Email</label>
                  </div>
                  <div className="width-input-box d-flex">
                    <div className="position-relative">
                      <CustomInput
                        onChange={handleChange}
                        placeholder="Email"
                        errors={!errors?.email && touched?.email}
                        id="email"
                        name="email"
                        value={values?.email}
                        isDisabled={true}
                      />
                      {errors?.email && touched.email && (
                        <div className="input-feedback postion-absolute">
                          {errors.email}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                <div className="d-flex justify-content-start flex-direction align-items-center gap-2 mb-1">
                  <div className="width-label">
                    <label>Phone Number</label>
                  </div>
                  <div className="width-input-box d-flex">
                    <div className="position-relative">
                      <CustomInput
                        onChange={handleChange}
                        placeholder="enter 10 digit mobile no."
                        errors={!errors?.mobileNumber && touched?.mobileNumber}
                        id="mobileNumber"
                        name="mobileNumber"
                        value={values?.mobileNumber}
                      />
                      {errors?.mobileNumber && touched.mobileNumber && (
                        <div className="input-feedback postion-absolute">
                          {errors.mobileNumber}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                <div className="d-flex justify-content-start flex-direction align-items-center gap-2 mb-1">
                  <div className="width-label">
                    <label>Location</label>
                  </div>
                  <div className="width-input-box d-flex">
                    <div className="position-relative">
                      <CustomInput
                        onChange={handleChange}
                        placeholder="enter Location"
                        errors={!errors?.location && touched?.location}
                        id="location"
                        name="location"
                        value={values?.location}
                      />
                      {errors?.location && touched.location && (
                        <div className="input-feedback postion-absolute">
                          {errors.location}
                        </div>
                      )}
                    </div>

                  </div>
                </div>
                <div className="d-flex mb-0 mt-3" style={{marginInline:"26%"}}>
                  <Button title="Save" width="108px" />
                </div>
              </form>
            </div>
          );
        }}
      </Formik>
    </>
  );
};

export default BasicInfoForm;
