import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import ResultData from '../../../../Services/ResultService';
import { CardSubHeading, SmallHeading } from '../../../../customcomponents/DynamicText/Heading';
import { ThemeColors } from '../../../../theme/theme';
import { TitleHeading } from '../../../../customcomponents/DynamicText/Heading';
import { HeadTitle } from '../../../../customcomponents/headtitle/headTitle';


export default function TransactionDetail() {

 const location = useLocation();
 const [transData,settransData]=useState("");
   useEffect(()=>{
    getTransDetail()
   },[])

const getTransDetail= async()=>{
  // console.log("transaction=>>>>>",location.state)
  let payload={
    orderId:location?.state?.orderId,
  }
  const res = await ResultData?.getTransactionDetail(payload);
  if(res?.isSuccess && res?.responseCode===200){
    settransData(res?.data)
  }
}
const timeZoneOption = {
    dateStyle: "medium",
    timeStyle: "short",
    hour12: true,
    timeZone: "IST",
  };


  return (
    <>
    <div className="mb-2">
    <HeadTitle text="Transaction Detail"/>
    </div>
     <div className="card p-3 border-0">
      <div className="d-flex">
        <div className="flex-grow-1 ps-4" >
          {/* <div className="col-lg-10 col-md-8 col-sm-12 col-xs-12"> */}
          <div className="row m-0" style={{ rowGap: "1rem" }}>
            <div className="col-lg-2 col-md-6 col-sm-6">
              <small className="m-0 text-muted">Order ID</small>
              <CardSubHeading text={transData?.orderId} />
            </div>
            <div className="col-lg-2 col-md-6 col-sm-6">
              <small className="m-0 text-muted">Student Name</small>
              <CardSubHeading text={transData?.studentName} color={ThemeColors?.link}/>
            </div>
            
            <div className="col-lg-2 col-md-6 col-sm-6">
              <small className="m-0 text-muted">Institute Name</small>
              <CardSubHeading text={transData?.instituteName} />
            </div>
            
            <div className="col-lg-2 col-md-6 col-sm-6">
              <small className="m-0 text-muted">Total Item</small>
              <CardSubHeading text={transData?.totalItem} />
            </div>
            <div className="col-lg-2 col-md-6 col-sm-6">
              <small className="m-0 text-muted">Total Amount</small>
              <CardSubHeading text={`₹${transData?.totalAmount}`} />
            </div>
            <div className="col-lg-2 col-md-6 col-sm-6">
              <small className="m-0 text-muted">Order Date</small>
              <CardSubHeading text={new Date(transData?.orderDate + "z").toLocaleString("en-IN", timeZoneOption)} />
            </div>
          </div>
        </div>
      </div>
    </div>
    <div  className="row mt-5 ">
      <div className="col-md-5">
      <div className="card p-3 border-0" style={{height:'300px'}}>
        <div className='mt-2 mb-2'>
        <SmallHeading text={"Order Summary"} />
        </div>
    
       {/* <div className="d-flex justify-content-between px-2 py-2 " style={{backgroundColor:ThemeColors?.transaction}}> */}
       {/* </div> */}
       <>
        <div style={{backgroundColor:ThemeColors?.transaction}} className='px-2 py-3  '>
          <div className='d-flex justify-content-between px-3 '>
            <div ><SmallHeading text={"Item Name"}  color={ThemeColors.grey}/></div>
            <div><SmallHeading text={"Amount"}  color={ThemeColors.grey}/></div>
          </div>
        </div>
       <div style={{textAlign: 'center'}}>
            { 
            transData?.orderSummaries &&  transData?.orderSummaries.map((data)=>{
                return (
                        <div className='d-flex justify-content-between px-4 py-2'>
                            <p className='pl-1' ><TitleHeading text={data?.itemName}/> </p>               
                            <p className='pr-1'>{` ₹${data?.amount}`}</p>
                        </div>                            
            )}         
          )}
       </div>
       </>
        <hr/>
        <div className="d-flex justify-content-between px-4">
        <SmallHeading text={"Total Amount"}  color={ThemeColors.grey}/>
        <TitleHeading text={ `₹${transData?.totalAmount }`}/>
        </div>
        {/* <table>
        <thead>
          <tr>
            <th colSpan="1"><SmallHeading text={"Total Amount"}  color={ThemeColors.grey}/></th>
            <th className=''><TitleHeading text={transData?.totalAmount}/></th>
          </tr>
        </thead>
        </table> */}
      
        </div>
        </div>
    </div>
    </>
   

  );
}
