import React, { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { DataNotFound2, KebaDots } from '../../../../assets/svgs/svg';
import ActionButton from '../../../../customcomponents/actionbutton/ActionButton';
import Checkbox from '../../../../customcomponents/checkbox/Checkbox';

export default function TransactionTable({tableData,
    tableHead,
    checkbox = true,
    SerialNumbers = false,
    tHeadBackgoundColor,
    tHeadPadding = "py-3 ps-2",
    action = true,
    navigateTo = "",
    eye = true,
    del=false,
    edit=false,
})  
{
    const [showIcon, setShowIcon] = useState(false);
    const [isCheckAll, setIsCheckAll] = useState(false);
    const [isCheck, setIsCheck] = useState([]);
    const [keysArr, setKeysArr] = useState([]);
    const activeRef = useRef();
    const navigate =useNavigate();
    // 

useEffect(() => { 

    if (tableData?.length > 0) {
        setKeysArr(Object.keys(tableData[0]));
    }
    function handleClickOutside(event) {
        if (activeRef.current && !activeRef.current.contains(event.target)) {
            setShowIcon(false)
        }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
        document.removeEventListener("mousedown", handleClickOutside);
    };
}, [activeRef, tableData]);

const selectAll = (e) => {
    setIsCheckAll(!isCheckAll);
    setIsCheck(tableData.map((li) => li.id));
    if (isCheckAll) {
        setIsCheck([]);
    }
};

const timeZoneOption = {
    dateStyle: "medium",
    timeStyle: "short",
    hour12: true,
    timeZone: "IST",
  };

const selected = (e) => {
    let tempChecked = isCheck;
    const { id, checked } = e?.target;
    setIsCheck([...isCheck, id]);
    tempChecked.push(id);
    if (!checked) {
        tempChecked = tempChecked.filter((item) => item !== id);
        setIsCheck(tempChecked);
    }
    if (tempChecked?.length === tableData?.length) {
        setIsCheckAll(true);
    } else {
        setIsCheckAll(false);
    }
};


return (
<div className="table-responsive">
       <table className="Customtable table table-borderless ">
       <thead  style={{ background: tHeadBackgoundColor }}>
                <tr>
                    <th
                        className="d-flex ms-3 py-3v pe-2 mt-2"
                        scope="col"
                        style={{ paddingTop: "" }}
                    >
                        {checkbox && (
                            <Checkbox
                                id="selectAll"
                                handleClick={selectAll}
                                isChecked={isCheckAll}
                            />
                        )}
                    </th>
                    {tableHead?.map((data, i) => (
                        <th className={`${tHeadPadding} cells pe-2`} scope="col" key={i}>
                            {data}
                        </th>
                    ))}
                    {action && (
                        <th className={`${tHeadPadding} text-end pe-3`} scope="col">
                            <KebaDots />
                        </th>
                    )}
                </tr>
            </thead>
            <tbody>
                {(keysArr.length > 0 && tableData?.length > 0) ? tableData?.map((dataObj, i) => {
                    return (
                        <tr key={i}>
                            <td
                                style={{
                                    paddingBlock: "1rem",
                                    paddingLeft: "1.5rem",
                                }}
                            >
                                {checkbox && (
                                    <Checkbox
                                        id={dataObj.id}
                                        handleClick={selected}
                                        isChecked={isCheck.includes(dataObj.id)}
                                    />
                                )}

                            </td>
                            {SerialNumbers && <td style={{
                                paddingBlock: "1rem",
                                paddingLeft: "1.5rem",
                            }}>{i + 1}</td>}

                            {keysArr?.map(
                                (obj, ind) =>
                                        <td key={ind}
                                            style={{ paddingBlock: "1rem" }}
                                            className=''
                                        >
                           <div className="d-flex align-items-center justify-content-between gap-3">
                          {
                          obj === "orderDate"  && obj !=="amount"
                            ? new Date(dataObj[obj] + "z").toLocaleString("en-IN", timeZoneOption)
                            : 
                            
                                obj ==="amount" ? ` ₹${dataObj[obj]}` : dataObj[obj]
                            
                            
                           
                            }
                                    {/* <div className="d-flex align-items-center justify-content-between gap-3" >{dataObj[obj]} */}
                            </div>


                                            {
                                       (action && obj === "action" && <div
                                                        className="actionTd"
                                                        onClick={() => {
                                                            setShowIcon(i);

                                                        }}
                                                        onMouseOver={() => { setShowIcon(i) }}
                                                    >
                                                        {showIcon === i ? (
                                                            <ActionButton 
                                                             eye={eye}
                                                             del={del}
                                                             edit={edit}
                                                             veiwFunction={() => {
                                                                navigateTo && navigate(`/${navigateTo}`, { state: { orderId: dataObj?.orderId}})
                                                            }}
                                                            

                                     
                                                            />
                                                        ) : 
                                        <div><KebaDots /></div>}
                                        </div>) 
                                               }

                                        </td>
                                    
                                
                            )}
                        </tr>
                    )
                }) : <tr><td colSpan="10" className="text-center p-5"><DataNotFound2 /></td></tr>}
            </tbody>
       </table>
</div>
)
}

