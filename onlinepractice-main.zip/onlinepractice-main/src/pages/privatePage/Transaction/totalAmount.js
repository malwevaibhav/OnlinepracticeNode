import React from 'react'
import { Heading } from '../../../customcomponents/DynamicText/Heading'

export default function TotalAmount({totalAmount , text}) {
  return (
    <div className='d-flex justify-content-between flex-wrap p-0 px-4 pe-2 pt-2'>
    <div className="col-lg-6 col-md-6  col-sm-6  col-xs-6 mt-2"><Heading text={text} /></div>
    <div className="col-lg-6 col-md-6  col-xs-6  cm-justify-content d-flex  mb-3 gap-3">
    <div className='mt-2'>
     <span style={{color:"#787F86",fontSize:'20px',fontWeight:500}}> Total Amount :</span> 
     <span className='fw-bold' style={{ fontSize:'20px'}}> ₹{totalAmount}</span> 
    </div>
      
   
    </div>
</div>
  )
}
