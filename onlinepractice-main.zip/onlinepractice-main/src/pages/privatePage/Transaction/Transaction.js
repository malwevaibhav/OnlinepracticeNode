import React, { useEffect, useState } from "react";
import { HeadTitle } from "../../../customcomponents/headtitle/headTitle";
import MultiLevelDropDown from "../../../customcomponents/custom_Dropdown/MultiLevelDropDown";
import Pagination from "../../../customcomponents/pagination/Pagination";
import TransactionTable from "./component/transactionTable";
import ResultData from "../../../Services/ResultService";
import InstituteServices from "../../../Services/InstituteService";
import CustomDropdown from "../../../customcomponents/custom_Dropdown/CustomDropdown";
import TotalAmount from "./totalAmount";

export const dropDown = [
  { title: "Date", tooltip: "link", active: false },
  { title: "Name", tooltip: "link", active: false },
];

export default function Transaction() {
  const tableHead = [
    "Order ID",
    "Student Name",
    "Institute Name",
    "Total Item",
    "Amount",
    "Order Date",
  ];
  const [TransList, setTransList] = useState([]);
  const [Institute, setInstitute] = useState([]);
  const [InstituteID, setInstituteID] = useState("");
  const [totalAmount, setTotalAmount] = useState("");
  const [InstituteName, setInstituteName] = useState("");
  const [pageNoSize, setPageNoSize] = useState({ no: 1, size: 10 });
  const [TransLength, setTransLength] = useState("");

  const myStyle = {
    backgroundColor: "white",
    width: "max-content",
    display: "flex",
    height: "46px",
    padding: "9px 13px",
    paddingLeft: "18px",
  };

  const onSortData = (type) => {
    if (type === "Date") {
      const sorted = sortArrayByDate(TransList, "orderDate");
      // console.log("object",sorted);
      setTransList(sorted);
    } else if (type === "Name") {
      const sorted = sortArrayAlphabatically(TransList, "studentName");
      // console.log("object1",sorted);
      setTransList(sorted);
    }
  };

  useEffect(() => {
    getAllInstitute();
  }, [InstituteID , TransList]);

  const getAllInstitute = async () => {
    const resData = await InstituteServices.getAllInstitute();
    if (resData) {
      let temp = resData?.institutes.map((data, i) => {
        return (resData[i] = {
          ...resData?.institutes[i],
          Title: data.instituteName,
        });
      });

      setInstitute([...temp]);
    }
  };
  const setInstituteData = async (props) => {
    setInstituteID(props?.id);
    setInstituteName(props?.instituteName);
    getAllTransaction(pageNoSize?.no, pageNoSize?.size, props?.id);
  };

  const getAllTransaction = async (
    no = 1,
    size = 10,
    instituteID = InstituteID
  ) => {
    setPageNoSize({ no: 1, size: 10 });
    let payload = {
      instituteId: instituteID,
      pageNumber: no,
      pageSize: size,
    };

    const res = await ResultData?.getAllTransaction(payload);
    if (res?.isSuccess) {
      if (res) setTotalAmount(res?.data?.totalAmount);
      setTransLength(res?.data?.totalRecords);
      const transdata = res?.data?.adminWallets.map((elm) => {
        return {
          ...elm,
          action: true,
        };
      });
      setTransList(transdata);
      return transdata.length;
    }else{
      setTransList([])
    }
  };
  return (
    <div className="mt-2">
      <div className="d-grid mb-4">
        <HeadTitle
          text="All Transaction"
          component1={
            <CustomDropdown
              menuStyle={{ border: "1px solid #E3E9EE", width: "max-content" }}
              isSelect={true}
              menu={Institute}
              customClass="InstituteDropdown"
              placeholder="Select Institute"
              handlefunc={setInstituteData}
              selectedEntity={InstituteName}
            />
          }
          component2={
            <MultiLevelDropDown
              menu={dropDown}
              preText="Sort By : "
              menuStyle={myStyle}
              onSort={(e) => onSortData(e)}
            />
          }
        />
        {totalAmount && (
          <div
            className=""
            style={{ backgroundColor: "#FFFFFF", width: "100%" }}
          >
            <TotalAmount totalAmount={totalAmount} text="Transaction"/>
          
          </div>
        )}

        <div className="d-flex w-100"></div>
        <TransactionTable
          tableData={TransList}
          tableHead={tableHead}
          navigateTo="translation-details"
        />
        {TransList.length > 0 && (
          <Pagination
            getFunction={getAllTransaction}
            totalLength={TransLength}
            setPageNoSize={setPageNoSize}
            pageNoSize={pageNoSize}
            length={TransList.length}
          />
        )}
      </div>
    </div>
  );
}
export const sortArrayByDate = (arr, key, mode = "asc") => {
  return arr.sort((a, b) => {
    const date1 = new Date(b[key]);
    const date2 = new Date(a[key]);
    if (mode === "asc") {
      return date1 - date2;
    } else {
      return date2 - date1;
    }
  });
};

export const sortArrayAlphabatically = (arr, key, mode = "asc") => {
  return arr.sort((a, b) => {
    let fa = a[key]?.toLowerCase(),
      fb = b[key]?.toLowerCase();
    if (mode === "asc") {
      if (fa < fb) {
        return -1;
      }
      if (fa > fb) {
        return 1;
      }
      return 0;
    } else {
      if (fb < fa) {
        return -1;
      }
      if (fb > fa) {
        return 1;
      }
      return 0;
    }
  });
};
