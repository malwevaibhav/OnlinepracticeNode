import { toJS } from "mobx";
import { observer } from "mobx-react-lite";
import React, { useState } from "react";
import { Navigate, Outlet } from "react-router-dom";
import "../../App.css";
import { BreadcrumbIcon } from "../../assets/svgs/svg";
import WindowSize from "../../component/hooks/windowSize.js";
import AuthStore from "../../MobX/Auth";
import Commonservice from "../../Services/commonService";
import { ThemeColors } from "../../theme/theme";
import Navbar from "../layout/navBar/NavBar.js";
import Sidebar from "../layout/sidebar/sidebar.js";
/* eslint-disable */
const PrivateLayout = ({ allowedroles }) => {
  const auth = toJS(AuthStore?.user?.user);
  // const pathname = useLocation();
  const outerdiv = {
    width: "100vw",
    height: "100vh",
    overflow: "hidden",
  };

  const [breadcrumb, setbreadcrumb] = useState("");
  const [sidebarActive, setSidebarActive] = useState(false);
  const [initalpath] = useState(
    Commonservice.getLeftMenuOptions()[0]?.url
      ? Commonservice.getLeftMenuOptions()[0]?.url
      : Commonservice.getLeftMenuOptions()[0]?.submenus[0]?.url
  );
  const [submenu, setMenu] = useState("");
  const { width } = WindowSize();
  const isWidth = () => (width < 768 ? "tab-width" : "");
  const isTabWidth = isWidth();
  return (
    <div style={outerdiv}>
      <div className="d-flex m-0 w-100 h-100" id="wrapper">
        <div
          className={`h-100 border-left sidebar-wrapper ${sidebarActive && "sidebar-wrapper-active"
            } `}
        >
          <Sidebar
            isTabWidth={isTabWidth}
            setbreadcrumb={setbreadcrumb}
            breadcrumb={breadcrumb}
            setMenu={setMenu}
            setSidebarActive={setSidebarActive}
          />
        </div>
        <div className="w-100 left-main-height">
          <Navbar
            sidebarActive={sidebarActive}
            setSidebarActive={setSidebarActive}
          />
          <div
            className="content-section"
            style={{
              backgroundColor: ThemeColors.bg,
            }}
          >
            {breadcrumb && (
              <nav aria-label="breadcrumb">
                <ol className="breadcrumb">
                  <li className="breadcrumb-item">
                    <a>{breadcrumb}</a>
                  </li>
                  {submenu && (
                    <>
                      <li className="ms-2">
                        <BreadcrumbIcon />
                      </li>
                      <li className="breadcrumb-item" aria-current="page">
                        {" "}
                        {submenu}
                      </li>
                    </>
                  )}
                </ol>
              </nav>
            )}
            {auth ? (allowedroles?.includes(auth?.role) && <Outlet />

) : (

<Navigate to={initalpath} />

)}
          </div>
        </div>
      </div>
    </div>
    // Comment for check 7 june
    //new-changtes
  );
};

export default observer(PrivateLayout);
