import { toJS } from 'mobx';
import React, { useEffect, useState } from 'react';
import { useNavigate } from "react-router-dom";
import { toast } from 'react-toastify';

import { PlusIcon } from '../../../assets/svgs/svg';
import DataExtractor from '../../../component/hooks/dataExtractor';
import Button from "../../../customcomponents/button/Button";
import MultiLevelDropDown from '../../../customcomponents/custom_Dropdown/MultiLevelDropDown';
import { HeadTitle } from '../../../customcomponents/headtitle/headTitle';
import Pagination from '../../../customcomponents/pagination/Pagination';
import AuthStore from '../../../MobX/Auth';
import VideoStore from '../../../MobX/videostore';
import QuestionTypeServices from '../../../Services/QuestionTypeService';
import VideoServices from '../../../Services/videoService';
import { sortArrayAlphabatically, sortArrayByDate } from '../../../utils/Arraysorting';
import VideoCard from './component/videocard';
import VideoCarddata from './component/videoCarddata';

export const dropDown = [
    { title: "Date", tooltip: "link", active: false },
    { title: "Name", tooltip: "link", active: false },
];
const myStyle = {
    backgroundColor: "white",
    width: "max-content",
    display: "flex",
    height: "46px",
    padding: "9px 13px",
    paddingLeft: "18px",
};
/* eslint-disable */
const Video = () => {
    const navigate = useNavigate();
    const [feildValue, setFieldValue] = useState({})
    const [allVideos, setAllVideos] = useState([])
    const [videoLength, setvideoLength] = useState("")
    const [language, setLanguage] = useState([{ title: VideoStore.selectedLanguage || "All", tooltip: "link", active: false },]);
    const [pageNoSize, setPageNoSize] = useState({ no: 1, size: 10 });
    const user = toJS(AuthStore?.user?.user)

    useEffect(() => {
        getAllLanguage();
        if (VideoStore?.selectedItemsNw?.subjectList?.id &&
            VideoStore?.selectedItemsNw?.facultyList?.selectedName &&
            VideoStore?.selectedItemsNw?.InstituteList?.id) {
            getAllVideos()
        }
    }, [])

    const setvalues = (name, value) => {
        setFieldValue({ ...feildValue, [name]: value })
    }

    const showfun = () => {
        VideoStore.setSelectedItems({})
        navigate("/add-NewVideo");
    };

    const getAllVideos = async (no = 1, size = 10) => {
        setPageNoSize({ no: 1, size: 10 })
        let post = {
            subjectCategoryId: VideoStore?.selectedItemsNw?.subjectList?.id,
            topicId: VideoStore?.selectedItemsNw?.topicList?.id || "00000000-0000-0000-0000-000000000000",
            facultyName: VideoStore?.selectedItemsNw?.facultyList?.selectedName,
            instituteId: VideoStore?.selectedItemsNw?.InstituteList?.id,
            language: VideoStore.selectedLanguage || "All",
            pageNumber: no,
            pageSize: size
        };
        if (user?.role === "Staff") {
            post.instituteId = user?.instituteId
        }
        if (!post.subjectCategoryId || !post.topicId || !post.facultyName || !post.instituteId) {
            return
        }
        const res = await VideoServices.getAllVideos(post);
        if (!res?.data?.videos) {
            setPageNoSize({ ...pageNoSize, no: pageNoSize.no - 1 })
            if ((pageNoSize.no - 1) <= 0) {
                setAllVideos([])
                setvideoLength()
                return false;
            }
            else {
                return getAllVideos(pageNoSize?.no - 1, pageNoSize?.size)
            }
        }
        setvideoLength(res?.data?.totalRecords)
        setAllVideos(res?.data?.videos)
        return res?.data?.videos
    }

    const deleteFunc = async (id) => {
        const del = await VideoServices.deleteVideo({ id: id });
        if (del?.isSuccess) {
            toast.success(del?.messages);
            getAllVideos(pageNoSize?.no, pageNoSize?.size);
        } else {
            toast.error(del?.messages);
        }

    };

    const onSortData = (type) => {
        if (type === "Date") {
            const sorted = sortArrayByDate(allVideos, "creationDateTime");
            const extracted = DataExtractor(sorted, ["isSelected"]);
            setAllVideos(extracted);
        } else if (type === "Name") {
            const sorted = sortArrayAlphabatically(allVideos, "videoTitle");
            const extracted = DataExtractor(sorted, ["isSelected"]);
            setAllVideos(extracted);
        }
    };

    const getAllLanguage = async () => {
        const res = await QuestionTypeServices.getAllLanguage();
        if (res?.isSuccess) {
            if (res?.data) {
                let language = res?.data.map((item) => {
                    return {
                        title: item?.name,
                        tooltip: "link",
                        active: false
                    };
                });
                language.push({
                    title: "All",
                    tooltip: "link",
                    active: false
                })
                setLanguage(language);
            }
        }
    };

    return (
        <div>
            <HeadTitle
                text="Videos"
                component3={
                    <Button
                        title="Add Video"
                        width="135px"
                        height="45px"
                        func={showfun}
                        icon={<PlusIcon />}
                    />
                }

                component1={
                    <MultiLevelDropDown
                        menu={dropDown}
                        preText="Sort By : "
                        menuStyle={myStyle}
                        onSort={(e) => onSortData(e)}
                    />
                }
                component2={
                    <MultiLevelDropDown
                        menu={language}
                        preText="Language : "
                        menuStyle={myStyle}
                        onSort={(e) => { VideoStore.setSelectedlanguage(e); getAllVideos() }}
                    />}
            />
            <div className="mb-3">
                <VideoCard applyFunc={getAllVideos} setFieldValue={setvalues} show={true} />
            </div>
            <VideoCarddata data={allVideos} deleteFunc={deleteFunc} />
            {videoLength && (
                <Pagination
                    getFunction={getAllVideos}
                    totalLength={videoLength}
                    setPageNoSize={setPageNoSize}
                    pageNoSize={pageNoSize}
                    length={allVideos?.length}
                />
            )}

        </div>
    )
}

export default Video