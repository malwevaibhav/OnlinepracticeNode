import { Formik } from "formik";
import { toJS } from "mobx";
import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { videoSchema } from "../../../../assets/regex/schema";
import { RupeeIcon } from "../../../../assets/svgs/svg";
import Button from "../../../../customcomponents/button/Button";
import CustomInput from "../../../../customcomponents/customTextInput";
import { InputLabel } from "../../../../customcomponents/customTextInput/indexCss";
import CustomDropdown from "../../../../customcomponents/custom_Dropdown/CustomDropdown";
import { NormalHeading, TitleHeading } from "../../../../customcomponents/DynamicText/Heading";
import { HeadTitle } from "../../../../customcomponents/headtitle/headTitle";
import AuthStore from "../../../../MobX/Auth";
import PatternStore from "../../../../MobX/Pattern";
import VideoStore from "../../../../MobX/videostore";
import InstituteServices from "../../../../Services/InstituteService";
import QuestionTypeServices from "../../../../Services/QuestionTypeService";
import VideoServices from "../../../../Services/videoService";
import { ClientRoutesConstants } from "../../../../shared/constant";
import { ThemeColors } from "../../../../theme/theme";
import { removeExtraSpace } from "../../../../utils/helper";
import { UploadVideo } from "./uploadVideo";
import VideoCard from "./videocard";
import VideoPreview from "./videoPreview";

const AddNewVideo = () => {
    /* eslint-disable */
    const location = useLocation();
    const [VideoDetails, setVideoDetails] = useState({ id: location?.state?.id, price: 0 });
    const navigate = useNavigate();
    const [institutes, setInstitute] = useState();
    const [language, setLanguage] = useState([]);
    const user = toJS(AuthStore?.user?.user)
    const [disable, setDisable] = useState(true)
    useEffect(() => {
        if (user?.role === "Admin") {
            getAllInstitute();
        } else {
            VideoStore.setSelectedItemsNw({ selectedName: "Institute", props: { id: user?.instituteId, entityName: user?.instituteName }, entityName: user?.instituteName })
            setVideoDetails({ ...VideoDetails, instituteId: user?.instituteId })
        }
        getAllLanguage();
        if (location?.state?.id) {
            getvideoById();
        }
    }, [location?.state?.id]);

    const getAllInstitute = async () => {
        let data = await InstituteServices?.getAllInstitute();
        if (data?.institutes) {
            let inst = data.institutes?.map((elm) => {
                return {
                    id: elm?.id,
                    Title: elm?.instituteName,
                    label: "Institute",
                };
            });
            setInstitute(inst);
        }
    };

    const getAllLanguage = async () => {
        const res = await QuestionTypeServices.getAllLanguage();
        if (res?.isSuccess) {
            if (res?.data) {
                let lang = res?.data.map((item) => {
                    return {
                        id: item?.value,
                        Title: item?.name,
                    };
                });
                setLanguage(lang);
                PatternStore.setSelectedItemsPattern({
                    selectedName: "Language",
                    props: lang[0],
                    entityName: lang[0]?.Title,
                });
                VideoStore.setvideo({ language: lang[0]?.Title });
            }
        }
    };

    const getvideoById = async () => {
        const res = await VideoServices.getvideoById({ id: location?.state?.id });
        if (res?.isSuccess) {
            setVideoDetails(res?.data);
            VideoStore.setSelectedItemsNw({
                selectedName: "Exam",
                props: { id: res?.data?.examTypeId, Title: res?.data?.examTypeName },
                entityName: res?.data?.examTypeName,
            });
            VideoStore.setSelectedItemsNw({
                selectedName: "Course",
                props: { id: res?.data?.courseId, Title: res?.data?.courseName },
                entityName: res?.data?.courseName,
            });
            VideoStore.setSelectedItemsNw({
                selectedName: "SubCourse",
                props: { id: res?.data?.subCourseId, Title: res?.data?.subCourseName },
                entityName: res?.data?.subCourseName,
            });
            VideoStore.setSelectedItemsNw({
                selectedName: "Subject",
                props: { id: res?.data?.subjectCategoryId, Title: res?.data?.subjectName },
                entityName: res?.data?.subjectName,
            });
            VideoStore.setSelectedItemsNw({
                selectedName: "Topic",
                props: { id: res?.data?.topicId, Title: res?.data?.topicName },
                entityName: res?.data?.topicName,
            });
            setInstitutedata({ id: res?.data?.instituteId, Title: res?.data?.instituteName }, res?.data?.instituteName)
            VideoStore.setSelectedItemsNw({ selectedName: "author", props: { id: "", Title: res?.data?.facultyName }, entityName: res?.data?.facultyName })
            VideoServices?.getFilterData({ id: res?.data?.subjectCategoryId, label: "Topic" });
        }
    };

    const submitFunction = async (values) => {
        if (user?.role === "Staff") {
            values.instituteId = user?.instituteId
        }
        values.price = removeExtraSpace(values.price) === "" ? 0 : values.price
        if (location?.state?.id) {
            if (values.videoUrl !== VideoDetails.videoUrl) {
                const formData = new FormData();
                formData.append("VideoLinkUrl", values.videoUrl);
                const uploadVideo = await VideoServices.uploadVideo(formData);
                if (uploadVideo?.isSuccess) {
                    toast.success(uploadVideo?.messages);
                    values.videoUrl = uploadVideo.data;
                    const formData1 = new FormData();
                    formData1.append("Image", values.videoThumbnail);
                    
                    const thumbUrl = await VideoServices.thumbUpload(formData1);
                    values.videoThumbnail = thumbUrl?.data
                } else {
                    return toast.error(uploadVideo?.messages);
                }
            }
            const putResp = await VideoServices.updateVideo(values);
            if (putResp?.isSuccess) {
                VideoStore.setSelectedItemsNw({
                    selectedName: "author",
                    props: { id: putResp?.data?.authorName },
                    entityName: putResp?.data?.authorName,
                });
                // 
                toast.success(putResp?.messages);
                navigate(ClientRoutesConstants.videos)
            } else {
                toast.error(putResp?.messages);
            }

        } else {
            const formData = new FormData();
            formData.append("VideoLinkUrl", values.videoUrl);
            const videourl = await VideoServices.uploadVideo(formData);
            if (videourl?.isSuccess) {
                toast.success(videourl?.messages);
                values.videoUrl = videourl.data;
                const formData1 = new FormData();
                formData1.append("Image", values.videoThumbnail);
                const thumbUrl = await VideoServices.thumbUpload(formData1);
                values.videoThumbnail = thumbUrl?.data

                const postResp = await VideoServices.createVideo(values);
                if (postResp?.isSuccess) {
                    VideoStore.setSelectedItemsNw({
                        selectedName: "author",
                        props: { id: postResp?.data?.authorName },
                        entityName: postResp?.data?.authorName,
                    });
                    toast.success(postResp?.messages);
                    navigate(ClientRoutesConstants.videos);
                } else {
                    toast.error(postResp?.messages);
                }
            } else {
                toast.error(videourl?.messages);
            }
        }
    };

    const setInstitutedata = (props, entityName) => {
        VideoStore.setSelectedItemsNw({ selectedName: "Institute", props, entityName })
    }

    return (
        <Formik
            enableReinitialize
            initialValues={{
                id: VideoDetails?.id,
                examTypeId: VideoDetails?.examTypeId,
                courseId: VideoDetails?.courseId,
                subCourseId: VideoDetails?.subCourseId,
                subjectCategory: VideoDetails?.subjectCategoryId,
                topicId: VideoDetails?.topicId,
                instituteId: VideoDetails?.instituteId,
                instituteName: VideoDetails?.instituteName,
                videoTitle: VideoDetails?.videoTitle,
                language: VideoDetails?.language,
                facultyName: VideoDetails?.facultyName,
                description: VideoDetails?.description,
                price: VideoDetails?.price,
                videoUrl: VideoDetails?.videoUrl,
                videoThumbnail: VideoDetails?.videoThumbnail,
            }}
            onSubmit={(values) => {
                submitFunction(values);
            }}
            validationSchema={videoSchema()}
        >
            {(props) => {
                const {
                    touched,
                    errors,
                    values,
                    handleChange,
                    setFieldValue,
                    handleSubmit,
                } = props;
                return (
                    <div onSubmit={handleSubmit}>
                        <div>
                            <HeadTitle text={!location?.state?.id ? "Add New Video" : "Update Video"} />
                            <div className="mb-3 mt-3">
                                <VideoCard
                                    show={false}
                                    setFieldValue={setFieldValue}
                                    errors={errors}
                                    touched={touched}
                                    values={values}
                                    disabled={location?.state?.id}
                                    setDisable={setDisable}
                                />
                            </div>

                            <div>
                                <div className="transaction-container">
                                    <div>
                                        <div className="card  border-0 p-30 mt-2">
                                            <div className="f-16  f-w500  mb-15 " style={{ color: "#3A3951" }}>
                                                <NormalHeading text="Upload Video"></NormalHeading>{" "}
                                                <span className="f-12">(MOV, MP4, AVI, MPEG Format)</span>
                                            </div>

                                            <UploadVideo
                                                name="videoUrl"
                                                setFieldValue={setFieldValue}
                                                handleChange={handleChange}
                                                accept="video/mp4"
                                                orgvideoSrc={VideoDetails?.videoUrl}
                                                orgThumbnail={VideoDetails?.videoThumbnail}
                                                videoSrc={values?.videoUrl}
                                                values={values}
                                                setDisable={setDisable}

                                            />
                                            {errors.videoUrl && touched.videoUrl && (
                                                <div className="input-feedback">{errors.videoUrl}</div>
                                            )}
                                        </div>

                                        <div className="card  border-0 p-30 mt-25">
                                            <NormalHeading text="Video Basic Details"></NormalHeading>
                                            <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12 mb-3">
                                                <div className="card rounded-0 border-0 p-3">
                                                    <CustomInput
                                                        height="48px"
                                                        label="Video Title"
                                                        marginBottom="10px"
                                                        marginTop="10px"
                                                        name="videoTitle"
                                                        value={values?.videoTitle}
                                                        onChange={(e) => { setFieldValue("videoTitle", e.target.value); setDisable(false) }}
                                                    />
                                                    {errors.videoTitle && touched.videoTitle && (
                                                        <div className="input-feedback ">
                                                            {errors.videoTitle}
                                                        </div>
                                                    )}

                                                    <InputLabel className="mt-2">Description</InputLabel>
                                                    <textarea
                                                        className="input-field inputField form-control mt-2"
                                                        style={{ background: ThemeColors.bg }}
                                                        name="description"
                                                        value={values?.description}
                                                        placeholder="description"

                                                        onChange={(e) => { setFieldValue("description", e.target.value); setDisable(false) }}
                                                    ></textarea>
                                                    {errors.description && touched.description && (
                                                        <div className="input-feedback ">
                                                            {errors.description}
                                                        </div>
                                                    )}

                                                    <CustomInput
                                                        height="48px"
                                                        label="Faculty Name"
                                                        marginBottom="10px"
                                                        marginTop="10px"
                                                        name="facultyName"
                                                        value={values?.facultyName}
                                                        onChange={(e) => { setFieldValue("facultyName", e.target.value); setDisable(false) }}
                                                    />
                                                    {errors.facultyName && touched.facultyName && (
                                                        <div className="input-feedback ">
                                                            {errors.facultyName}
                                                        </div>
                                                    )}

                                                    <div className="mt-2">
                                                        <InputLabel className="pb-2 ">Institute</InputLabel>
                                                        <CustomDropdown
                                                            customClass="form-dropdown"
                                                            placeholder="Select Institute"
                                                            height="48px"
                                                            name1="instituteId"
                                                            name="instituteName"
                                                            menu={institutes}
                                                            handlefunc={(data) => { setFieldValue("instituteId", data?.id); setInstitutedata(data, data?.Title); setDisable(false) }}
                                                            menuStyle={{ border: "1px solid #E3E9EE" }}
                                                            selectedEntity={VideoStore.selectedItemsNw?.InstituteList?.selectedName}
                                                            disable={user?.role === "Staff"}
                                                        />
                                                        {errors.instituteId && touched.instituteId && (
                                                            <div className="input-feedback ">
                                                                {errors.instituteId}
                                                            </div>
                                                        )}
                                                    </div>

                                                    <InputLabel className="pb-2 pt-2">
                                                        Language
                                                    </InputLabel>
                                                    <CustomDropdown
                                                        customClass="form-dropdown"
                                                        placeholder="Select Language"
                                                        name="language"
                                                        menu={language}
                                                        selectedEntity={values?.language}
                                                        handlefunc={(data) => {
                                                            setFieldValue("language", data?.Title); VideoStore.setSelectedlanguage(data?.Title); setDisable(false)
                                                        }}
                                                        menuStyle={{ border: "1px solid #E3E9EE" }}
                                                    />
                                                    {errors.language && touched.language && (
                                                        <div className="input-feedback ">
                                                            {errors.language}
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                        </div>
                                        <div className="card border-0 rounded-0 p-3 mt-4 ">
                                            <TitleHeading text="Price Setting" />
                                            <hr />
                                            <InputLabel>Price</InputLabel>
                                            <div className="f f-a-row gap10">
                                                <div className="RupeyBox" style={{ marginTop: "8px" }}>
                                                    <RupeeIcon />
                                                </div>
                                                <div className="price">
                                                    <CustomInput
                                                        height="48px"
                                                        marginBottom="10px"
                                                        marginTop="10px"
                                                        placeholder="00"
                                                        name="price"
                                                        value={values?.price}
                                                        onChange={(e) => { setFieldValue("price", e.target.value); setDisable(false) }}
                                                        isDisabled={location?.state?.id && (user?.role === "Staff")}
                                                    />
                                                    {errors.price && touched.price && (
                                                        <div className="input-feedback position-absolute">
                                                            {errors.price}
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="mt-2">
                                        <VideoPreview video={values} />
                                        <div className="f gap16 f-justify-end ">
                                            <div className="Settingbtn mt-25">
                                                <Button
                                                    background="rgb(171, 182, 192)"
                                                    title="Cancel"
                                                    width="137px"
                                                    type="submit"
                                                    func={(e) => {
                                                        e.preventDefault();

                                                        navigate(ClientRoutesConstants.videos);
                                                    }}
                                                /></div>
                                            <div className="Settingbtn mt-25">
                                                <Button
                                                    title={location?.state?.id ? "Update" : "Continue"}
                                                    width="137px"
                                                    type="submit"
                                                    func={handleSubmit}
                                                    disable={location?.state?.id ? disable : false}

                                                />
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                );
            }}
        </Formik>
    );
};

export default AddNewVideo;
