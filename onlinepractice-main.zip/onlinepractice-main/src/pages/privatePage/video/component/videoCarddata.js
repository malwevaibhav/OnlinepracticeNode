import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { DataNotFound2, VerticalKebaDots, WhiteEyeIcon } from "../../../../assets/svgs/svg";
import Button from "../../../../customcomponents/button/Button";
import DeleteModal from "../../../../customcomponents/modalPopup/deleteModal/DeleteModal";
import AuthStore from "../../../../MobX/Auth";
import { ClientRoutesConstants } from "../../../../shared/constant";
import "../video.css";
import CustomTest from "./customTest";

const VideoCarddata = ({ data, deleteFunc }) => {

    const [videoObj, setVideoObj] = useState({ id: "", name: "" });
    const [show, setShow] = useState("");
    const [showModal, setShowModal] = useState(false)
    const user = AuthStore?.user?.user;
    const navigate = useNavigate()
    const editDetail = (data) => {
        navigate(ClientRoutesConstants?.videoPurchase, { state: { id: data?.id } })
    }

    return (
        <div className="card px-3 pb-4 mb-4 border-0">
            <div className="row m-0 gy-3">
                {
                    data?.length > 0 ? data?.map((video, i) => {
                        return (
                            <div className="col-xl-3 col-lg-4 col-md-6 col-sm-12 ">
                                <div className=" cardContainer c-b">
                                    <div className="f-between cardField ">
                                        <div className="f-14 f-w500" style={{ color: "#F4F6F8" }}>
                                        </div>
                                        {(video?.creatorUserId === user?.userId || (user.role === "Admin")) ?
                                            (<>
                                                <div className="pointer" onClick={() => show === i ? setShow("") : setShow(i)}>
                                                    <VerticalKebaDots />
                                                </div>
                                                {show === i &&
                                                    <ul ul class="list-group position-absolute list-group pointer" style={{ width: "49px", height: "45px", right: "20px", top: "35px" }}>
                                                        <li class="list-group-item list-group-item-action p-1" style={{ fontSize: "10px" }} onClick={() => { navigate(ClientRoutesConstants.addNewvideo, { state: { id: video?.id } }) }}>Edit</li>

                                                        <li class="list-group-item list-group-item-action p-1" style={{ fontSize: "10px" }} onClick={() => { setVideoObj({ id: video?.id, name: video?.videoTitle }); setShowModal(true); }}>Delete</li>

                                                    </ul>}
                                            </>) : (<div style={{ height: "25px" }}>


                                            </div>)
                                        }
                                    </div>
                                    <div>
                                        <video
                                            style={{ height: "15rem" }}
                                            src={video?.videoUrl}
                                            className="VideoInput_video"
                                            controls controlsList={user?.role === "Staff" && "nodownload"}
                                        />
                                        <div
                                            className="p-2 f-16 f-w600"
                                            style={{ color: "#3A3951", background: "#F4F6F8" }}
                                        >

                                            {video?.videoTitle}
                                            {/* {video?.description} */}
                                            {/* Introduction to Physics, Part 1 (Force, Motion & Energy) */}
                                        </div>
                                    </div>
                                    <div className="f-around c-bt ">
                                        <div>
                                            {" "}
                                            <CustomTest
                                                fontWeight="500"
                                                title={video?.subjectName}
                                                color="#0075FF"
                                                background="#DCEEFF"
                                                subject="subject"
                                                width={"fit-content"}
                                                height="26px"
                                                fontSize="14px"
                                            />
                                        </div>
                                        <div>
                                            {" "}
                                            <CustomTest
                                                fontWeight="500"
                                                title={video?.instituteName}
                                                color="#0075FF"
                                                background="#DCEEFF"
                                                subject="Institute"
                                                width={"fit-content"}
                                                height="26px"
                                                fontSize="14px"
                                            />
                                        </div>
                                        <div>
                                            {" "}
                                            <CustomTest
                                                fontWeight="500"
                                                title={video?.facultyName}
                                                color="#0075FF"
                                                background="#DCEEFF"
                                                subject="Faculty"
                                                width={"fit-content"}
                                                height="26px"
                                                fontSize="14px"
                                            />
                                        </div>
                                    </div>
                                    <div className="flex-between p-2 c-bt">
                                        <div className="f-align">
                                            <Button
                                                icon={<WhiteEyeIcon />}
                                                title="View Details"
                                                height="36px"
                                                fontSize="14px"
                                                func={() => { editDetail(video) }}
                                            />
                                        </div>
                                        <div className="f-align gap-1 ">
                                            <div className="t-p f-w600" style={{ fontSize: "14px" }}>Price</div>
                                            <CustomTest
                                                fontWeight="500"
                                                title={`₹${video?.price}`}
                                                color="#0075FF"
                                                background="#DCEEFF"
                                                width={"fit-content"}
                                                height="26px"
                                                fontSize="14px"
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )
                    }) : <div className="card border-0 rounded-0 d-flex align-items-center p-5">
                        <DataNotFound2 />
                    </div>
                }
            </div>
            {
                showModal && (
                    <DeleteModal
                        onRequestClose={() => {
                            setShowModal(false)
                        }}
                        onPress={() => {
                            deleteFunc(videoObj?.id); setShowModal(false)
                        }}
                        name={videoObj?.name}
                    />
                )
            }
        </div >
    );
};

export default VideoCarddata;
