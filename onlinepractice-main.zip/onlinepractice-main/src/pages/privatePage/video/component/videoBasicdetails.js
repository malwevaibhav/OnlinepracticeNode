import React from 'react'

const videoBasicdetails = () => {
    return (
        <div>videoBasicdetails</div>
    )
}

export default videoBasicdetails