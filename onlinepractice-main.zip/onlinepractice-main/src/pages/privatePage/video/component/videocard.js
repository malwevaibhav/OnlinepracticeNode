import { toJS } from 'mobx'
import { observer } from 'mobx-react-lite'
import React, { useEffect, useState } from 'react'

import Button from '../../../../customcomponents/button/Button'
import { InputLabel } from '../../../../customcomponents/customTextInput/indexCss'
import CustomDropdown from '../../../../customcomponents/custom_Dropdown/CustomDropdown'
import AuthStore from '../../../../MobX/Auth'
import VideoStore from '../../../../MobX/videostore'
import InstituteServices from '../../../../Services/InstituteService'
import VideoServices from '../../../../Services/videoService'
/* eslint-disable */
const VideoCard = (props) => {
    const { show = true, setFieldValue, errors, touched, applyFunc, disabled, setDisable } = props
    const [toggle, setToggle] = useState(false);
    const examList = toJS(VideoStore?.examList);
    const courseList = toJS(VideoStore?.course);
    const SubCourseList = toJS(VideoStore?.subcourse);
    const subjectList = toJS(VideoStore?.subject);
    const topicList = toJS(VideoStore?.topic)
    const [institutes, setInstitute] = useState()
    const addedBY = toJS(VideoStore?.faculty)
    const user = toJS(AuthStore?.user?.user)
    useEffect(() => {
        getExamType()
        if (user?.role === "Admin") {
            getAllInstitute()
        }
        else {
            VideoStore.setSelectedItemsNw({ selectedName: "Institute", props: { id: user?.instituteId, entityName: user?.instituteName }, entityName: user?.instituteName })
        }
        if (VideoStore?.selectedItemsNw?.subjectList?.id && VideoStore?.selectedItemsNw?.InstituteList?.id) {
            getallauthors()
        }

    }, [show]);

    const getExamType = async () => {
        let exam = await VideoServices?.getFilterData({ label: "Exam" });
        VideoStore.setexamList(exam)
    };

    const getAllInstitute = async () => {
        let data = await InstituteServices?.getAllInstitute();
        if (data?.institutes) {
            let inst = data.institutes?.map((elm) => {
                return {
                    id: elm?.id,
                    Title: elm?.instituteName,
                    label: "Institute",
                };
            });
            setInstitute(inst)
        }

    };

    const getallauthors = async () => {
        let post = {
            "subjectCategoryId": VideoStore?.selectedItemsNw?.subjectList?.id,
            "topicId": VideoStore?.selectedItemsNw?.topicList?.id || "00000000-0000-0000-0000-000000000000",
            "instituteId": VideoStore?.selectedItemsNw?.InstituteList?.id
        }
        const resData = await VideoServices.getallauthors(post);
        let addedby = resData?.videoAuthors?.map((elm, i) => {
            return {
                id: i + 1,
                Title: elm?.facultyName,
                label: "author",
            };
        });
        VideoStore.setFaculty(addedby)
    };

    const getdataCard = async (props, entityName) => {
        if (props?.label === 'Course') {
            VideoStore.setSelectedItemsNw({ selectedName: "Exam", props, entityName })
            VideoStore.setSelectedItemsNw({ selectedName: "Subject", props: {}, entityName: "" })
            if (user?.role === "Admin") {
                VideoStore.setSelectedItemsNw({ selectedName: "Institute", props: {}, entityName: "" })
            }
            VideoStore.setSelectedItemsNw({ selectedName: "Topic", props: {}, entityName: "" })
            VideoStore.setSelectedItemsNw({ selectedName: "author", props: {}, entityName: "" })
            let course = await VideoServices?.getFilterData(props);
            VideoStore.setCourse(course)
        }
        if (props?.label === "SubCourse") {
            VideoStore.setSelectedItemsNw({ selectedName: "Course", props, entityName })
            let subCourse = await VideoServices?.getFilterData(props);
            VideoStore.setSubCourse(subCourse)
        }
        if (props?.label === "Subject") {
            VideoStore.setSelectedItemsNw({ selectedName: "SubCourse", props, entityName })
            await VideoServices?.getFilterData(props);
        }
        if (props?.label === "Topic") {
            VideoStore.setSelectedItemsNw({ selectedName: "Subject", props, entityName })
            await VideoServices?.getFilterData(props);
            if (user?.role === "Staff") {
                getallauthors();
            }
        }
        if (props?.label === "SubTopic") {
            VideoStore.setSelectedItemsNw({ selectedName: "Topic", props, entityName })
            await VideoServices?.getFilterData(props);

        }
        if (props?.label === "Institute") {
            VideoStore.setSelectedItemsNw({ selectedName: "Institute", props, entityName })
            getallauthors()
        }
        if (props?.label === "author") {
            VideoStore.setSelectedItemsNw({ selectedName: "author", props, entityName })
        }
        setToggle(!toggle)
    };

    return (
        <>
            <div className="card rounded-0 border-0 px-3 pb-3 py-1 mb-3">
                <div className="row m-0 g-2">
                    <div className="col-xl-3 col-lg-4 col-md-6 col-sm-12 pb-2">
                        <InputLabel>Exam Type</InputLabel>
                        <CustomDropdown
                            customClass="form-dropdown"
                            placeholder="Select Exam"
                            height="48px"
                            menu={examList}
                            handlefunc={(data) => { setFieldValue("examTypeId", data?.id); getdataCard(data, data?.Title) }}
                            menuStyle={{ border: "1px solid #E3E9EE" }}
                            selectedEntity={
                                VideoStore?.selectedItemsNw?.examList?.selectedName
                            }
                            disable={disabled}
                        />
                        {errors?.examTypeId && touched?.examTypeId && (
                            <div className="input-feedback position-absolute">
                                {errors?.examTypeId}
                            </div>
                        )}
                    </div>
                    <div className="col-xl-3 col-lg-4 col-md-6 col-sm-12 pb-2">
                        <InputLabel>Course</InputLabel>
                        <CustomDropdown
                            customClass="form-dropdown"
                            placeholder="Select Course"
                            height="48px"
                            menu={courseList}
                            handlefunc={(data) => { setFieldValue("courseId", data?.id); getdataCard(data, data?.Title) }}
                            menuStyle={{ border: "1px solid #E3E9EE" }}
                            selectedEntity={
                                VideoStore?.selectedItemsNw?.courseList?.selectedName
                            }
                            disable={disabled || !VideoStore?.selectedItemsNw?.examList?.id}
                        />
                        {errors?.courseId && touched.courseId && (
                            <div className="input-feedback position-absolute">
                                {errors?.courseId}
                            </div>
                        )}
                    </div>
                    <div className="col-xl-3 col-lg-4 col-md-6 col-sm-12 pb-2">
                        <InputLabel>Sub-course</InputLabel>
                        <CustomDropdown
                            customClass="form-dropdown"
                            placeholder="Select SubCourse"
                            height="48px"
                            handlefunc={(data) => { setFieldValue("subCourseId", data?.id); getdataCard(data, data?.Title) }}
                            menu={SubCourseList}
                            menuStyle={{ border: "1px solid #E3E9EE" }}
                            selectedEntity={
                                VideoStore?.selectedItemsNw?.SubCourseList?.selectedName
                            }
                            disable={disabled || !VideoStore?.selectedItemsNw?.courseList?.id}
                        />
                        {errors?.subCourseId && touched.subCourseId && (
                            <div className="input-feedback position-absolute">
                                {errors?.subCourseId}
                            </div>
                        )}
                    </div>
                    <div className="col-xl-3 col-lg-4 col-md-6 col-sm-12 pb-2">
                        <InputLabel>Subject</InputLabel>
                        <CustomDropdown
                            customClass="form-dropdown"
                            placeholder="Select Subject"
                            height="48px"
                            menu={subjectList}
                            handlefunc={(data) => { setFieldValue("subjectCategory", data?.id); getdataCard(data, data?.Title) }}
                            menuStyle={{ border: "1px solid #E3E9EE" }}
                            selectedEntity={
                                VideoStore?.selectedItemsNw?.subjectList?.selectedName
                            }
                            disable={disabled || !VideoStore?.selectedItemsNw?.SubCourseList?.id}
                        />
                        {errors?.subjectCategory && touched.subjectCategory && (
                            <div className="input-feedback position-absolute">
                                {errors?.subjectCategory}
                            </div>
                        )}
                    </div>
                    <div className="col-xl-3 col-lg-4 col-md-6 col-sm-12 pb-2">
                        <InputLabel>Topic {!show && <span>{'(Optional)'}</span>} </InputLabel>
                        <CustomDropdown
                            customClass="form-dropdown"
                            placeholder="Select Topic"
                            height="48px"
                            handlefunc={(data) => { setDisable && setDisable(false); setFieldValue("topicId", data?.id); getdataCard(data, data?.Title) }}
                            menu={topicList}
                            menuStyle={{ border: "1px solid #E3E9EE" }}
                            selectedEntity={
                                VideoStore?.selectedItemsNw?.topicList?.selectedName
                            }
                            disable={!VideoStore?.selectedItemsNw?.subjectList?.id}
                        />
                        {/* {errors?.topicId && touched.topicId && (
                            <div className="input-feedback position-absolute">
                                {errors?.topicId}
                            </div>
                        )} */}
                    </div>
                    {show && <>
                        <div className="col-xl-3 col-lg-4 col-md-6 col-sm-12 pb-2">
                            <InputLabel>Institute</InputLabel>
                            <CustomDropdown
                                customClass="form-dropdown"
                                placeholder="Select Institute"
                                height="48px"
                                menu={institutes}
                                handlefunc={(data) => { setFieldValue("instituteId", data?.id); getdataCard(data, data?.Title) }}
                                menuStyle={{ border: "1px solid #E3E9EE" }}
                                selectedEntity={VideoStore?.selectedItemsNw?.InstituteList?.selectedName}
                                disable={!VideoStore?.selectedItemsNw?.subjectList?.id || (user?.role === "Staff")}
                            />
                            {errors?.instituteId && touched.instituteId && (
                                <div className="input-feedback position-absolute">
                                    {errors?.instituteId}
                                </div>
                            )}
                        </div>

                        <div className="col-xl-3 col-lg-4 col-md-6 col-sm-12 pb-2">
                            <InputLabel>Faculty</InputLabel>
                            <CustomDropdown
                                customClass="form-dropdown"
                                placeholder="Select Faculty"
                                height="48px"
                                menu={addedBY}
                                handlefunc={(data) => {
                                     getdataCard(data, data?.Title) 
                                    }}
                                selectedEntity={
                                    VideoStore?.selectedItemsNw?.facultyList?.selectedName
                                }
                                disable={!VideoStore?.selectedItemsNw?.InstituteList?.id}
                                menuStyle={{ border: "1px solid #E3E9EE" }}
                            />
                        </div>
                        <div className="col-xl-3 col-lg-4 col-md-6 col-sm-12 pb-2 d-flex align-items-end">
                            <Button
                                title="Apply"
                                width="114px"
                                height="48px"
                                disable={!VideoStore?.selectedItemsNw?.facultyList?.selectedName}
                                func={(e) => { e.preventDefault(); applyFunc() }} />
                        </div>
                    </>}
                </div>
            </div>
        </>
    )
}

export default observer(VideoCard)
