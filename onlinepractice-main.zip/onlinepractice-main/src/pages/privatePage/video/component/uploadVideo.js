import { generateVideoThumbnails } from "@rajesh896/video-thumbnails-generator";
import React, { useEffect, useRef, useState } from "react";
import { toast } from "react-toastify";
import { UploadIcon } from "../../../../assets/svgs/svg";
import Button from "../../../../customcomponents/button/Button";
import { ThemeColors } from "../../../../theme/theme";
import "../video.css";
function UploadVideo({
  maxFiles = 1,
  name,
  onDrop,
  setFieldValue,
  // orgvideoSrc,
  orgThumbnail,
  videoSrc,
  // values,
  setDisable
}) {

  const [isFile, setIsFile] = useState(true);
  const [over, setover] = useState(false);
  const [files, setfiles] = useState();
  const [thumbnails, setThumbnails] = useState(orgThumbnail);
  const $input = useRef(null);
  // const location = useLocation();
  useEffect(() => {
    if (videoSrc && files === undefined) {
      setIsFile(false);
      setfiles(videoSrc);
    }
    if (onDrop) {
      onDrop(files);
    }
  }, [files, onDrop, videoSrc]);

  useEffect(() => {
    setThumbnails(orgThumbnail);
  }, [orgThumbnail]);

  function dataURLtoFile(dataurl, filename) {
    var arr = dataurl.split(","),
      mime = arr[0].match(/:(.*?);/)[1],
      bstr = atob(arr[1]),
      n = bstr.length,
      u8arr = new Uint8Array(n);

    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }
    return new File([u8arr], filename, { type: mime });
  }

  const ImgUpload = async (file) => {
    if (file[0]?.type === "video/mp4") {
      generateVideoThumbnails(file[0], 3).then((thumbs) => {
        var file = dataURLtoFile(thumbs[0], "thumb.png");
        setFieldValue("videoThumbnail", file);
        setThumbnails(URL.createObjectURL(file));
      });
      setFieldValue(name, file[0]);
    } else {
      toast.error("file format is not valid");
    }
  };
  // const handleChange = () => {
  //   if (location?.state?.id) { setThumbnails(orgThumbnail); setFieldValue(name, files); } else {
  //     setThumbnails("")
  //     setFieldValue(name, "")

  //   }
  //   // setThumbnails("")
  //   setFieldValue("videoThumbnail", "")
  //   // setFieldValue(name, "");
  // }

  return (
    <>
      <div className="row m-0 mt-2">
        {(!videoSrc) && (
          <div
            className="card  rounded-1 text-center"
            style={{ backgroundColor: "#ECF5FF", border: "1px dashed #ABB6C0" }}
          >
            <div
              onClick={() => {
                $input.current.click();
              }}
              onDrop={(e) => {
                e.preventDefault();
                e.persist();
                setIsFile(false);
                setover(false);
                ImgUpload(e.dataTransfer.files);
              }}
              onDragOver={(e) => {
                e.preventDefault();
                setover(true);
              }}
              onDragLeave={(e) => {
                e.preventDefault();
                setover(false);
              }}
            >
              <div
                className={`${over ? "upload-container over" : "upload-container"
                  } mt-4`}
              >
                <UploadIcon width="35" height="25" />
                <h6 className="SemiBold mt-2 d-flex justify-content-center">
                  Drag and drop your file here or &nbsp;
                  <p className="text-primary pointer">Browse</p>
                </h6>
                <input
                  name={name}
                  style={{ display: "none" }}
                  type="file"
                  accept="video/mp4"
                  ref={$input}
                  onChange={(e) => {
                    ImgUpload(e.target.files);
                    setDisable(false)

                  }}
                  multiple={maxFiles > 1}
                />
              </div>
            </div>
          </div>
        )}
        {!isFile && (
          <div className="blob-container d-flex align-items-center ps-0 mt-2">
            <div>
              {thumbnails && (
                <>
                  <img
                    src={thumbnails}
                    style={{
                      width: 250,
                      height: 200,
                      margin: 10,
                      cursor: "pointer",
                    }}
                    alt=""
                    onClick={() => {
                      window.scrollTo({ top: 0, behavior: "smooth" });
                    }}
                  />
                </>
              )}
            </div>
            {thumbnails && (
              <div className="">
                <input
                  name={name}
                  onChange={(e) => {
                    ImgUpload(e.target.files);
                    setDisable(false)
                  }}
                  multiple={maxFiles > 1}
                  style={{ display: "none" }}
                  type="file"
                  accept="video/*"
                  ref={$input}
                />
                <div className="f f-align-row gap5 BrouseFiel  rounded-3">
                  <div
                    onClick={() => {
                      $input.current.click();
                    }}
                  >
                    <Button
                      title="Change"
                      textColor={ThemeColors.primary}
                      width="fit-content"
                      height="0"
                      background=""
                      type="button"
                    />
                  </div>
                  {/* <div>
                    {!location?.state?.id && <Button
                      title="Cancel"
                      textColor={ThemeColors.secondary}
                      width="fit-content"
                      height="0"
                      type="button"
                      func={handleChange}
                      background=""
                    />}
                  </div> */}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </>
  );
}

export { UploadVideo };

