
import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

import { DeleteIcon, EditIcon } from "../../../../assets/svgs/svg";
import Button from "../../../../customcomponents/button/Button";
import CustomInput from "../../../../customcomponents/customTextInput";
import { InputLabel } from "../../../../customcomponents/customTextInput/indexCss";
import CustomDropdown from "../../../../customcomponents/custom_Dropdown/CustomDropdown";
import { HeadTitle } from "../../../../customcomponents/headtitle/headTitle";
import Modal from "../../../../customcomponents/modalPopup/CustomModal";
import DeleteModal from "../../../../customcomponents/modalPopup/deleteModal/DeleteModal";
import AuthStore from "../../../../MobX/Auth";
import VideoServices from "../../../../Services/videoService";
import { ClientRoutesConstants } from "../../../../shared/constant";
import { ThemeColors } from "../../../../theme/theme";
import "../video.css";
const menuStyle = {
    marginTop: "10px",
    border: "1px solid #E3E9EE",
    backgroundColor: "#F4F6F8"
};
const VideoPurchase = () => {
    const Role=AuthStore?.user?.user;
    const [category, setCategory] = useState("")
    const [details, setDetail] = useState([]);
    const [popup, setPopup] = useState(false);
    const location = useLocation();
    const navigate = useNavigate()
    const user = AuthStore?.user?.user;

    useEffect(() => {
        // getAllLanguage();
        // getting data from state id 
        getById(location?.state?.id)
    }, [location?.state?.id])

    const getById = async (Id) => {
        const res = await VideoServices?.getvideoById({ id: Id });
        if (res?.isSuccess) {
            setDetail(res?.data)
            setCategory(`${res?.data?.examTypeName} > ${res?.data?.courseName} > ${res?.data?.subCourseName} > ${res?.data?.subjectName} >${res?.data?.topicName}`)
        }
    }

    const deleteFunc = async (id) => {
        const del = await VideoServices.deleteVideo({ id: id });
        if (del?.isSuccess) {
            toast.success(del?.messages);
            navigate(ClientRoutesConstants.videos)
        } else {
            toast.error(del?.messages);
        }

    };
    return (
        <>
            <HeadTitle
                text={details?.videoTitle}
                component1={<div className="totalPurchase">Total Purchase : {details?.totalPurchase}</div>}
                component2={(details?.creatorUserId === user?.userId || (user.role === "Admin")) &&
                    <Button
                        icon={<DeleteIcon />}
                        background={ThemeColors.danger}
                        title="Delete"
                        height="42px"
                        width="121px"
                        func={() => setPopup("delete")}
                    />
                }
                component3={(details?.creatorUserId === user?.userId || (user.role === "Admin")) && <Button title="Edit Details" width="160px" height="42px" icon={<EditIcon />} func={() => navigate(ClientRoutesConstants.addNewvideo, { state: { id: location?.state?.id } })} />}
            />
            <div>
                <div className="card p-3 border-0 ">
                    <div className="row m-0 ">
                        <div className="col-xl-5 col-lg-12 col-md-12 col-sm-12">
                            <div className="detailBox pb-3 pt-2">
                                <img
                                    src={details?.videoThumbnail}
                                    // src={Thumb}
                                    style={{ width: "100%", height: 480, cursor: "pointer" }}
                                    alt=""
                                />
                            </div>
                            {
                                 (Role.role === "Admin") &&
                                 <Button
                                 background={ThemeColors.primary}
                                 title="Preview"
                                 height="48px"
                                 width="121px"
                                 marginTop="6px"
                                 func={(e) => { setPopup("video") }}
                             />
                            }
                          
                        </div>
                        <div className="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                            <InputLabel>Video Title</InputLabel>
                            <CustomInput
                                height="48px"
                                backgroundColor="#F4F6F8"
                                value={details?.videoTitle}
                                isDisabled={true}
                            />
                            <InputLabel style={{ marginTop: "10px" }}>Description</InputLabel>
                            <CustomInput
                                height="48px"
                                backgroundColor="#F4F6F8"
                                value={details?.description}
                                isDisabled={true}
                            />
                            <InputLabel style={{ marginTop: "10px" }}>Category</InputLabel>
                            <div>
                                <textarea
                                    style={{ backgroundColor: "#F4F6F8" }}
                                    className="customInput mt-2 w-100 form-control"
                                    placeholder="Categories"
                                    value={category}
                                    rows={2}
                                    disabled
                                    width={100}
                                >
                                </textarea>
                            </div>

                            <InputLabel style={{ marginTop: "10px" }}>Author</InputLabel>
                            <CustomInput
                                height="48px"
                                backgroundColor="#F4F6F8"
                                value={details?.facultyName}
                                isDisabled={true}
                            />

                            <InputLabel style={{ marginTop: "10px" }}>Language</InputLabel>
                            <CustomDropdown
                                height="48px"
                                customClass="form-dropdown"
                                menuStyle={menuStyle}
                                // menu={language}
                                disable={true}
                                selectedEntity={details?.language}
                            />

                            <InputLabel style={{ marginTop: "10px" }}>Price</InputLabel>
                            <CustomInput
                                height="48px"
                                backgroundColor="#F4F6F8"
                                value={` ₹${details?.price}`}
                                isDisabled={true}
                            />
                        </div>
                    </div>
                </div>
            </div>

            {popup === "video" &&
                <Modal
                    onRequestClose={() => setPopup("")}
                    backgroundColor={ThemeColors.danger}
                    noFooter={false}
                    maxModalWidth="850px"
                >
                    <video src={details?.videoUrl}
                        style={{ width: "800px", height: "600px" }}
                        className="VideoInput_video"
                        controls
                    />
                </Modal>}
            {
                popup === "delete" && (
                    <DeleteModal
                        onRequestClose={() => {
                            setPopup("")
                        }}
                        onPress={() => {
                            deleteFunc(location?.state?.id); setPopup("")
                        }}
                        name={details?.videoTitle}
                    />
                )
            }

        </>
    );
};

export default VideoPurchase;
