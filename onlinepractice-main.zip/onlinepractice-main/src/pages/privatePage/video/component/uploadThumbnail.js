import { useEffect, useRef, useState } from "react";
import {
    generateVideoThumbnails,
    importFileandPreview
} from "@rajesh896/video-thumbnails-generator";

export default function Generatethumbnail() {
    const [video, setVideo] = useState();
    const [thumbNumber, setThumbNumber] = useState(0);
    const [videoUrl, setVideoUrl] = useState("");
    const [videoThumb, setVideoThumb] = useState("");
    const [thumbnails, setThumbnails] = useState([]);
    const refs = useRef({
        video: null,
        numberInput: null,
        thumbButton: null
    });

    useEffect(() => {
        if (video) {
            importFileandPreview(video).then((res) => {
                setVideoUrl(res);
            });
            setVideoThumb("");
            setThumbnails([]);
            if (refs.current.video) {
                refs.current.video.style.transform = "scale(1)";
            }

            if (refs.current.numberInput) {
                refs.current.numberInput.style.display = "block";
            }
            if (refs.current.thumbButton) {
                refs.current.thumbButton.style.display = "block";
            }
        }
    }, [video]);
    return (
        <>
            <div
                style={{
                    display: "flex",
                    justifyContent: "center",
                    flexDirection: "column",
                    alignItems: "center"
                }}
            >
                <video
                    poster={videoThumb}
                    style={{
                        maxWidth: 600,
                        maxHeight: 400,
                        transform: "scale(0)",
                        transition: "all 0.3s"
                    }}
                    controls
                    id="video"
                    ref={(el) => (refs.current.video = el)}
                    src={videoUrl}
                >
                    <source src={videoUrl} type={video?.type} />
                    Your browser does not support the video tag.
                </video>
                <div style={{ display: "flex", marginTop: 25 }}>
                    <input
                        type="file"
                        id="inputfile"
                        accept="video/*"
                        onChange={(e) => {
                            if (e.target.files?.length > 0) {
                                setVideo(e.target.files[0]);
                            }
                        }}
                    />
                    <div
                        id="numberWrapper"
                        style={{ display: "none" }}
                        ref={(el) => (refs.current.numberInput = el)}
                    >
                        <label for="numberofthumbnails" style={{ marginLeft: 15 }}>
                            Enter number of thumbnails to generate
                        </label>
                        <input
                            type="number"
                            id="numberofthumbnails"
                            onChange={(e) => {
                                setThumbNumber(parseInt(e.target.value, 0));
                            }}
                        />
                    </div>
                </div>
                <div
                    style={{ marginTop: 25, display: "none" }}
                    id="buttonWrapper"
                    ref={(el) => (refs.current.thumbButton = el)}
                >
                    <button
                        id="generatethumbnails" 
                        onClick={() => {
                            if (video) {
                                generateVideoThumbnails(video, thumbNumber).then((thumbs) => {
                                    setThumbnails(thumbs);

                                });
                            }
                        }}
                    >
                        Generate Thumbnails
                    </button>
                </div>
            </div>

            <div
                id="thumbnails"
                style={{
                    display: "flex",
                    justifyContent: "center",
                    flexWrap: "wrap",
                    alignItems: "center",
                    transition: "all 0.3s"
                }}
            >
                {thumbnails.map((item) => {
                    return (
                        <img
                            src={item}
                            style={{ width: 200, margin: 10, cursor: "pointer" }}
                            alt=""
                            onClick={() => {
                                setVideoThumb(item);
                                window.scrollTo({ top: 0, behavior: "smooth" });
                            }}
                        />
                    );
                })}
            </div>

        </>
    );
}
