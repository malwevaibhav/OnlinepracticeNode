import React from 'react'

const videodetails = () => {
    return (
        <div>videodetails</div>
    )
}

export default videodetails
