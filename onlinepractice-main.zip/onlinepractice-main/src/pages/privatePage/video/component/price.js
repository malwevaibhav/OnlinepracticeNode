import React from 'react'

const price = () => {
    return (
        <div>price</div>
    )
}

export default price