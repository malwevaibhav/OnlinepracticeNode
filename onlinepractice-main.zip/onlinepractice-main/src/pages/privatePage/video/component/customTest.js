import React from "react";
import { InputLabel } from "../../../../customcomponents/customTextInput/indexCss";
import { ThemeColors } from "../../../../theme/theme";

export default function CustomTest(props) {
    const {
        title,
        subject,
        background = ThemeColors.primary,
        textColor = "white",
        width,
        height,
        fontSize,
        marginTop,
        border,
        fontWeight
    } = props;
    return (
        <>
            <InputLabel style={{fontSize:"12px"}}>{subject}</InputLabel>

            <div
                className="p-2 rounded-1 d-flex align-items-center justify-content-center "
                style={{
                    backgroundColor: background,
                    color: textColor,
                    fontSize: fontSize,
                    width: width,
                    height: height,
                    fontFamily: "Regular",
                    fontWeight: fontWeight,
                    border: border,
                    marginTop: marginTop,
                    ...props,
                }}>
                {title}
            </div>
        </>
    );
}
