import React from "react";
import { useState } from "react";
import { useEffect } from "react";
import { DataNotFound2 } from "../../../../assets/svgs/svg";
import { BoldHeading, NormalHeading } from "../../../../customcomponents/DynamicText/Heading";
import AuthStore from "../../../../MobX/Auth";
import VideoStore from "../../../../MobX/videostore";
import { ThemeColors } from "../../../../theme/theme";
import "../video.css";

const languageBox = {
    padding: '2px 10px',
    width: 'min-content',
    height: '29px',
    borderRadius: '3px',
    color: '#0075ff',
    margin: "0",
    background: '#ecf5ff',
    border: '1px solid #d0e6ff',
}
const VideoPreview = ({ video }) => {
    const user= AuthStore?.user?.user;
    const [show, setShow] = useState(false)
    useEffect(() => {
        if (video?.videoUrl || video?.videoTitle || video?.description || video?.facultyName || VideoStore.selectedItemsNw?.InstituteList?.selectedName || video?.language || video?.price) {
            setShow(true)
        }
        else {
            setShow(false)
        }
    }, [video])
    return (
        <div>
            <div className="card rounded-0 border-0 p-3" style={{ backgroundColor: !show ? ThemeColors.white : ThemeColors.lightBlue, }}>
                <BoldHeading text="Video Preview" />
                <hr style={{ marginTop: "20px" }} />
                <div className="row m-0 gap-3 mt-3">
                    {!show ? <div className="text-center pt-5 pb-5">
                        <DataNotFound2 />
                    </div> :
                        <>
                            {
                                video?.videoUrl && (
                                    <div>
                                        <video
                                            src={video?.videoUrl?.type ? URL.createObjectURL(video?.videoUrl) : video?.videoUrl}
                                            className="VideoInput_video"
                                            controls
                                            controlsList={user?.role === "Staff" && "nodownload"}
                                            width="180"
                                            height="350"
                                        />
                                    </div>
                                )
                            }
                            {video?.videoTitle && (
                                <div>
                                    <NormalHeading text="Video Title" />
                                    {video?.videoTitle}
                                    {/* <video
                                    src={video?.playVideo}
                                    className="VideoInput_video"
                                    controls
                                /> */}
                                </div>
                            )}
                            {video?.description && (
                                <div>
                                    <NormalHeading text="Video Description" />
                                    <div>{video?.description}</div>
                                </div>
                            )}

                            {video?.facultyName && (
                                <div>
                                    <NormalHeading text="Faculty Name" />
                                    <div>{video?.facultyName}</div>
                                </div>
                            )}
                            {VideoStore.selectedItemsNw?.InstituteList?.selectedName && (
                                <div>
                                    <NormalHeading text="Institute" />
                                    <div>{VideoStore.selectedItemsNw?.InstituteList?.selectedName}</div>
                                    {/* <div>{video?.instituteName}</div> */}
                                </div>
                            )}
                            {video?.language && (
                                <div>
                                    <NormalHeading text="Language" />
                                    <div style={languageBox}>{video?.language}</div>
                                </div>
                            )}
                            <div>
                                <NormalHeading text="Price" />
                                <div>{`₹${video?.price}` || 0}</div>
                            </div>
                            {/* )} */}
                        </>}
                </div>
            </div>
        </div >
    );
};
export default VideoPreview;

