import html2canvas from "html2canvas";
import jsPDF from "jspdf";
import React, { useEffect, useState } from "react";
import AuthStore from "../../../MobX/Auth";
import EbookStore from "../../../MobX/Ebook";
import ResultData from "../../../Services/ResultService";
import { ReportFooterLogo, ReportLogo } from "../../../assets/icons/Inputicon";
import { CardSubHeading, SmallHeading } from "../../../customcomponents/DynamicText/Heading";
import Button from "../../../customcomponents/button/Button";
import { HeadTitle } from "../../../customcomponents/headtitle/headTitle";
import Pagination from "../../../customcomponents/pagination/Pagination";
import { ThemeColors } from "../../../theme/theme";
import ResultCard from "./customcomponent/resultCard";
import ResultTable from "./customcomponent/resultTable";
import { DataNotFound2 } from "../../../assets/svgs/svg";

export default function Result() {
  const [allResult, setAllResult] = useState([]);
  const [, setShow] = useState(false);
  const [pageNoSize, setPageNoSize] = useState({ no: 1, size: 10 });
  const [resultLength, setResultLength] = useState("");
  const [resultData, setresultData] = useState("");
  const tableHead = [
    "Students",
    "Test Title",
    "Total Marks",
    "Total Obtained Marks",
    "Percentage",
  ];
  const Role = AuthStore?.user?.user;

  const downloadfunc = async (props) => {
    // console.log("dataIds", props);
   let payload=
     {
      studentId: props?.studentId,
      mockTestId: props?.mockTestId
    }
    const res = await ResultData?.getResultDetail(payload);
    if (res?.isSuccess && res?.responseCode === 200) {
      //console.log("res", res);
      setresultData(res?.data);
      printFunction();
  //     const input = document.querySelector("#resultData");
  //     input.removeAttribute("hidden")
  //     html2canvas(input)
  //       .then((canvas) => {
  //           const imgData = canvas.toDataURL('image/png');
  //           const pdf =  new jsPDF();
  //           pdf.addImage(imgData, 'JPEG', 0, 0);
  //           pdf.save(`result.pdf`);
  //       });
  //    input.setAttribute("hidden", true) 
   }
  };
   const printFunction=()=>{
    const input = document.querySelector("#resultData");
    // console.log("kjdjfjdf",input);
         input.removeAttribute("hidden")
      html2canvas(input)
        .then((canvas) => {
            const imgData = canvas.toDataURL('image/png');
            const pdf =  new jsPDF();
            pdf.addImage(imgData, 'JPEG', 0, 0);
            pdf.save(`result.pdf`);
        });
     input.setAttribute("hidden", true) 
   }
  
  useEffect(() => {
    if (
      (EbookStore?.ebookselectedids.subCourseId &&
        EbookStore?.ebookselectedids.instituteId) ||
      Role?.instituteId
    ) {
      getResult();
    }
  }, []);

  const getResult = async (no = 1, size = 10) => {
    setPageNoSize({ no: 1, size: 10 });
    let payload = {
      subCourseId: EbookStore?.ebookselectedids.subCourseId,
      instituteId:
        EbookStore?.ebookselectedids.instituteId || Role?.instituteId,
      mockTestId:EbookStore?.ebookselectedids.mocktestId,
      pageNumber: no,
      pageSize: size,
    };
    const resData = await ResultData.getAllResult(payload);
    if (resData?.isSuccess) {
      setResultLength(resData?.data.totalRecords);
      let list = resData?.data?.studentResults?.map((elm) => {
        return {
          mockTestId: elm?.mockTestId,
          studentId: elm?.studentId,
          studentName: elm?.studentName,
          mockTestName: elm?.mockTestName,
          totalMarks: elm?.totalMarks,
          totalObtainMark: elm?.totalObtainMark,
          percentage: elm?.percentage,
          action: true,
        };
      });
      setAllResult(list);
      return list.length;
    }else{
      setAllResult([])
    }
  };
  return (
    <>
      <HeadTitle text="Result" />
       <ResultCard getResult={getResult} />
 
      <div className="row mt-3 ">
        <div className="d-grid">
          <ResultTable
            tableData={allResult}
            tableHead={tableHead}
            downloadfunc={downloadfunc}
            navigateTo="resultDetail"
           
          />
          {allResult.length > 0 && (
            <Pagination
              getFunction={getResult}
              totalLength={resultLength}
              setPageNoSize={setPageNoSize}
              pageNoSize={pageNoSize}
              length={allResult.length}
            />
          )}
        </div>
      </div>
    
    
    <div id="resultData"  style={{height:"100vh",width:"50%" }} hidden={true}>
    <div style={{height:"85vh"}}>

     <div className="d-flex flex-row p-3" style={{backgroundColor:ThemeColors?.inputbg,width:'99%'}}>
     <div className="ms-3">
                        <ReportLogo/>
                        </div>
                        <div className="flex-column">
                        <CardSubHeading text="Score Card"/>
                        <p>Demonstrates how well you have performed relative to your objectives.</p>
                        </div>

      </div>
      <div className="card p-3 my-2 mx-5 pt-5">
        <div className="d-flex justify-content-start flex-column" style={{borderBottom: "5px solid #F0F5FB"}}>
         <p style={ThemeColors?.font?.pdfFont} className="m-0">StudentName</p>
          <CardSubHeading text={resultData?.studentName}/>
        </div>
        <div className="row justify-content-between m-0 mt-2">
          <div className="col-12">
            {resultData?.mocktestResultDetails?.mockTestName}
          </div>
          <div className="col-6">
            <SmallHeading text="Total Questions" />
          </div>
          <div className="col-6">
            <Button
              title={resultData?.mocktestResultDetails?.totalQuestions}
              background={ThemeColors.skyBlue}
              height="26px"
              width=""
              color={ThemeColors.blue}  
            />
          </div>
          <div className="col-6 mt-2 ">
            <SmallHeading text="Total Marks" />
          </div>
          <div className="col-6 mt-2">
            <Button
              title={resultData?.mocktestResultDetails?.totalMarks}
              background={ThemeColors.skyBlue}
              height="26px"
              width=""
              color={ThemeColors.blue}
            />
          </div>
        </div>


      </div>
      <div className="card p-3 my-4 mx-5">
        <div className="row justify-content-between m-0">
          <div className="col-6">
            <SmallHeading text="Rank" />
          </div>

          <div className="col-6">
            <SmallHeading text={resultData?.resultDetail?.rank} />
          </div>

          <div className="col-6">
            <SmallHeading text="Marks Obtained" />
          </div>

          <div className="col-6">
            {resultData?.resultDetail?.totalObtainMark}
          </div>
        </div>
      </div>
 
      <div className="mx-5 mb-2">
        <SmallHeading text="Your Performance" />
      </div>

      <div className="card my-4 mx-5  p-2">
      <table className="table ms-5" style={{ width: "90%" }}>
        <thead>
          <tr>
            <th scope="col">
              <SmallHeading
                text={"Subject"}
                color={ThemeColors.grey}
              />
            </th>
            <th scope="col">
              {" "}
              <SmallHeading text={"Correct"} color={ThemeColors.green} />
            </th>
            <th scope="col">
              {" "}
              <SmallHeading text={"Incorrect"} color={ThemeColors.danger} />
            </th>
            <th scope="col">
              {" "}
              <SmallHeading text={"Skipped"} color={ThemeColors.blue} />
            </th>
          </tr>
        </thead>
        <tbody>
          {resultData?.subjectDetail?.subjectResultDetails.map(
            (data, key) => {
              return (
                <tr>
                  <td>
                    <SmallHeading
                      text={data?.subjectName}
                      color={ThemeColors.grey}
                    />
                  </td>
                  <td>{data?.correct}</td>
                  <td>{data?.inCorrect}</td>
                  <td>{data?.skipped}</td>
                </tr>
              );
            }
          )}

          <tr>
            <td>
              <SmallHeading text="Total" />
            </td>
            <td>{resultData?.subjectDetail?.totalCorrect}</td>
            <td>{resultData?.subjectDetail?.totalIncorrect}</td>
            <td>{resultData?.subjectDetail?.totalSkipped}</td>
          </tr>
        </tbody>
      </table>
      </div>

      <div className="d-flex flex-row p-3" style={{backgroundColor:ThemeColors?.Darkblue,width:"80vw",color:ThemeColors?.white,top:''}}>
        <div className="col-md-2 mt-3 ms-5"><ReportFooterLogo/></div>
        <div className="col-md-1">
        <SmallHeading color={ThemeColors.grey} text={"Contact Us"}/>
            <p>9754508541</p>
        </div>
        <div className="col-md-9">
        <div className="flex-column">
                    <SmallHeading color={ThemeColors.grey} text={"Email Us"}/>
                    <p>braincordeducation@gmail.com</p>
                    </div>   
              
        </div>                         
      </div>


      </div>
      </div>

      </>
  );
}
