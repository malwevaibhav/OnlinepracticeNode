import React, { useEffect, useState } from 'react'
import { CardSubHeading, SmallHeading } from '../../../customcomponents/DynamicText/Heading';
import ResultDetailCard from './customcomponent/resultDetailCard';
import { useLocation } from 'react-router-dom';
import ResultData from '../../../Services/ResultService';
import im from "../../../assets/Images/blankProfile.png";
import { HeadTitle } from '../../../customcomponents/headtitle/headTitle';
import Button from '../../../customcomponents/button/Button';
import { ReportFooterLogo, ReportLogo, ReportNew } from '../../../assets/icons/Inputicon';
import { ThemeColors } from '../../../theme/theme';
import html2canvas from "html2canvas";
import jsPDF from "jspdf";

export default function ResultDetail() {

 const location = useLocation();
 const [resultData,setresultData]=useState("");

   useEffect(()=>{
    getResultDetail()
    // let button = document.getElementById("pdfGen");
    // button.addEventListener("click",
    //     printDocument
    // );
   },[])



const getResultDetail= async()=>{
  let payload={
    studentId:location?.state?.studentId,
    mockTestId:location?.state?.mockTestId
  }
  const res = await ResultData?.getResultDetail(payload)
  if(res?.isSuccess && res?.responseCode===200){
    setresultData(res?.data)
    
  }
  
}


const printDocument=() =>{
  const input = document.querySelector("#pdfContainer");
  input.removeAttribute("hidden")
  html2canvas(input)
      .then((canvas) => {
          const imgData = canvas.toDataURL('image/png');

          const pdf =  new jsPDF("portrait",'in',[10,8.3]);
          pdf.addImage(imgData, 'JPEG', 0, 0);
          pdf.save(`result.pdf`);
      });
  input.setAttribute("hidden", true)
}
  return (
    <>
    <HeadTitle text="Result Detail" component1={ resultData && <Button title="Download Result" icon={<ReportNew/> } func={printDocument}/> }/>
    <div className="card p-3 border-0">
  
      <div className="d-flex">
        <div className="flex-shrink-0" >
          {/* <div className="col-lg-2 col-md-4 col-sm-12 col-xs-12"> */}
          <img
            src={resultData?.profileImage || im}
            width= "140"
            height= "140"
            style={{ borderRadius: "100px" }}
          />
        </div>

        <div className="flex-grow-1 ps-4" >
          {/* <div className="col-lg-10 col-md-8 col-sm-12 col-xs-12"> */}
          <div className="row m-0" style={{ rowGap: "1rem" }}>
            <div className="col-lg-3 col-md-6 col-sm-6">
              <small className="m-0 text-muted">Student Name</small>
              <CardSubHeading text={resultData?.studentName} />
            </div>
            <div className="col-lg-3 col-md-6 col-sm-6">
              <small className="m-0 text-muted">Institute</small>
              <CardSubHeading text={resultData?.instituteName} />
            </div>
            
            <div className="col-lg-3 col-md-6 col-sm-6">
              <small className="m-0 text-muted">Institute Code</small>
              <CardSubHeading text={resultData?.instituteCode} />
            </div>
            
            <div className="col-lg-3 col-md-6 col-sm-6">
              <small className="m-0 text-muted">Course</small>
              <CardSubHeading text={resultData?.courseName} />
            </div>
            <div className="col-lg-3 col-md-6 col-sm-6">
              <small className="m-0 text-muted">Sub-course</small>
              <CardSubHeading text={resultData?.subCourseName} />
            </div>
           
          </div>
        </div>
      </div>
    </div>

    <div className="row mt-5">
      
      <div className="col-md-4"><ResultDetailCard title={resultData?.mocktestResultDetails?.mockTestName} data={resultData?.mocktestResultDetails} type={"marks"}/></div>
      <div className="col-md-4"><ResultDetailCard title={""} data={resultData?.resultDetail} type={"rank"}/></div>
      <div className="col-md-4"><ResultDetailCard title={""} data={resultData?.subjectDetail} type={"subject"}/></div>
     
    </div>


    <div id="pdfContainer"  style={{height:"100vh",width:"50%" }} hidden={true}>
    <div style={{height:"85vh"}}>

     <div className="d-flex flex-row p-3" style={{backgroundColor:ThemeColors?.inputbg,width:'99%'}}>
     <div className="ms-3">
                        <ReportLogo/>
                        </div>
                        <div className="flex-column">
                        <CardSubHeading text="Score Card"/>
                        <p>Demonstrates how well you have performed relative to your objectives.</p>
                        </div>

      </div>
      <div className="card p-3 my-2 mx-5 pt-5">
        <div className="d-flex justify-content-start flex-column" style={{borderBottom: "5px solid #F0F5FB"}}>
         <p style={ThemeColors?.font?.pdfFont} className="m-0">StudentName</p>
          <CardSubHeading text={resultData?.studentName}/>
        </div>
        <div className="row justify-content-between m-0 mt-2">
          <div className="col-12">
            {resultData?.mocktestResultDetails?.mockTestName}
          </div>
          <div className="col-6">
            <SmallHeading text="Total Questions" />
          </div>
          <div className="col-6">
            <Button
              title={resultData?.mocktestResultDetails?.totalQuestions}
              background={ThemeColors.skyBlue}
              height="26px"
              width=""
              color={ThemeColors.blue}  
            />
          </div>
          <div className="col-6 mt-2 ">
            <SmallHeading text="Total Marks" />
          </div>
          <div className="col-6 mt-2">
            <Button
              title={resultData?.mocktestResultDetails?.totalMarks}
              background={ThemeColors.skyBlue}
              height="26px"
              width=""
              color={ThemeColors.blue}
            />
          </div>
        </div>


      </div>
      <div className="card p-3 my-4 mx-5">
        <div className="row justify-content-between m-0">
          <div className="col-6">
            <SmallHeading text="Rank" />
          </div>

          <div className="col-6">
            <SmallHeading text={resultData?.resultDetail?.rank} />
          </div>

          <div className="col-6">
            <SmallHeading text="Marks Obtained" />
          </div>

          <div className="col-6">
            {resultData?.resultDetail?.totalObtainMark}
          </div>
        </div>
      </div>
 
      <div className="mx-5 mb-2">
        <SmallHeading text="Your Performance" />
      </div>

      <div className="card my-4 mx-5  p-2">
      <table className="table ms-5" style={{ width: "90%" }}>
        <thead>
          <tr>
            <th scope="col">
              <SmallHeading
                text={"Subject"}
                color={ThemeColors.grey}
              />
            </th>
            <th scope="col">
              {" "}
              <SmallHeading text={"Correct"} color={ThemeColors.green} />
            </th>
            <th scope="col">
              {" "}
              <SmallHeading text={"Incorrect"} color={ThemeColors.danger} />
            </th>
            <th scope="col">
              {" "}
              <SmallHeading text={"Skipped"} color={ThemeColors.blue} />
            </th>
          </tr>
        </thead>
        <tbody>
          {resultData?.subjectDetail?.subjectResultDetails.map(
            (data, key) => {
              return (
                <tr>
                  <td>
                    <SmallHeading
                      text={data?.subjectName}
                      color={ThemeColors.grey}
                    />
                  </td>
                  <td>{data?.correct}</td>
                  <td>{data?.inCorrect}</td>
                  <td>{data?.skipped}</td>
                </tr>
              );
            }
          )}

          <tr>
            <td>
              <SmallHeading text="Total" />
            </td>
            <td>{resultData?.subjectDetail?.totalCorrect}</td>
            <td>{resultData?.subjectDetail?.totalIncorrect}</td>
            <td>{resultData?.subjectDetail?.totalSkipped}</td>
          </tr>
        </tbody>
      </table>
      </div>

      <div className="d-flex flex-row p-3" style={{backgroundColor:ThemeColors?.Darkblue,width:"80vw",color:ThemeColors?.white,top:''}}>
        <div className="col-md-2 mt-3 ms-5"><ReportFooterLogo/></div>
        <div className="col-md-1">
        <SmallHeading color={ThemeColors.grey} text={"Contact Us"}/>
            <p>9754508541</p>
        </div>
        <div className="col-md-9">
        <div className="flex-column">
                    <SmallHeading color={ThemeColors.grey} text={"Email Us"}/>
                    <p>braincordeducation@gmail.com</p>
                    </div>   
              
        </div>                         
      </div>


      </div>
      </div>
    </>
  );
}
