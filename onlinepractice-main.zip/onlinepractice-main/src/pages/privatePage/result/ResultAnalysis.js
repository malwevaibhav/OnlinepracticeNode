import React from 'react'

export default function ResultAnalysis() {
  return (
    <div>ResultAnalysis</div>
  )
}
