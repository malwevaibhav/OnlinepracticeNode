import React, { useEffect, useState } from "react";
import AuthStore from "../../../../MobX/Auth";
import CourseStore from "../../../../MobX/Courses";
import EbookStore from "../../../../MobX/Ebook";
import PatternStore from "../../../../MobX/Pattern";
import QuestionStore from "../../../../MobX/Question";
import EbookServices from "../../../../Services/EbookService";
import InstituteServices from "../../../../Services/InstituteService";
import Button from "../../../../customcomponents/button/Button";
import { InputLabel } from "../../../../customcomponents/customTextInput/indexCss";
import CustomDropdown from "../../../../customcomponents/custom_Dropdown/CustomDropdown";
import { checkDefault } from "../../../../utils/helper";

export default function  ResultCard({getResult,student}) {
  const Role = AuthStore?.user?.user;
  const [institute,setInstitute]=useState("");
  const [mockTest,setMocktest]=useState([]);
  const [toggle,setToggle]=useState(false);

  const [Errorcard, setErrorcard] = useState({
    examType: false,
    courseType: false,
    subCourseType: false,
    instituteType: false,
    mockTestType:false
})

  useEffect(() => {
    if (Role?.role === "Admin") {
      getAllInstitute();
    }
    EbookServices.getCourseFilterData({ label: "Exam" });
  }, []);

  
  const getAllInstitute = async () => {
    const resData = await InstituteServices.getAllInstitute();
    let temp = resData?.institutes?.map((data) => {
      return {
        id: data?.id,
        Title: data?.instituteName,
        label: "Institute",
      };
    });
    setInstitute(temp);
  };

  const getDropdownEbook = async (props, entityName) => {
    if (props?.label === "Course") {
      CourseStore.setSubCourse([]);
      QuestionStore.setSelectedItemsNw({
        selectedName: "Exam",
        props,
        entityName,
      });
      EbookStore.setEbookSelectedid({ examTypeId: props?.id });
      setErrorcard && setErrorcard({ ...Errorcard, examType: false });
    }
    if (props?.label === "SubCourse") {
      QuestionStore.setSelectedItemsNw({
        selectedName: "Course",
        props,
        entityName,
      });
      EbookStore.setEbookSelectedid({ courseId: props?.id });
      setErrorcard && setErrorcard({ ...Errorcard, courseType: false });
    }
    if (props?.label === "Subject") {
      QuestionStore.setSelectedItemsNw({
        selectedName: "SubCourse",
        props,
        entityName,
      });
      EbookStore.setEbookSelectedid({ subCourseId: props?.id });
      setErrorcard && setErrorcard({ ...Errorcard, subCourseType: false });
    }
    if (props?.label === "Institute") {
        PatternStore.setSelectedItemsPattern({
          selectedName: "Institute",
          props,
          entityName,
        });
        EbookStore?.setEbookSelectedid({ instituteId: props.id });
     if(!student){
       const res = await EbookServices?.mockTestType({
           subCourseId: EbookStore?.ebookselectedids?.subCourseId,
           instituteId:props.id 
         })
        setMocktest(res)
     }
       setErrorcard && setErrorcard({ ...Errorcard, instituteType: false });
       }

       if (props?.label === "MockTest" && !student) {
        PatternStore.setSelectedItemsPattern({
          selectedName: "mockTestType",
          props,
          entityName,
        });
        EbookStore?.setEbookSelectedid({ mocktestId: props.id });
        setToggle(!toggle)
       }
     
    return EbookServices?.getCourseFilterData(props);
}


const checkValidate = () => {
    if (!EbookStore.ebookselectedids.examTypeId) {
      return setErrorcard({ ...Errorcard, examType: true });
    }
    if (!EbookStore.ebookselectedids.courseId) {
      return setErrorcard({ ...Errorcard, courseType: true });
    }
    if (!EbookStore.ebookselectedids.subCourseId) {
      return setErrorcard({ ...Errorcard, subCourseType: true });
    }
    if (!EbookStore.ebookselectedids.instituteId && Role?.role === "Admin") {
        return setErrorcard({ ...Errorcard, instituteType: true });
      }
    if (!EbookStore.ebookselectedids.mocktestId ) {
        return setErrorcard({ ...Errorcard, mocktestId: true });
      }
}

  return (
    <div className="card  border-0">
     <form className="card px-3 pb-4 border-0 mt-3">
        <div className="row m-0 gy-3">
          <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
            <InputLabel>Exam Type</InputLabel>
            <CustomDropdown
              menuStyle={{ border: "1px solid #E3E9EE" }}
              customClass="form-dropdown"
              placeholder="Select Exam"
              menu={CourseStore?.examList}
              selectedEntity={
                QuestionStore.selectedItemsNw.examList.selectedName
              }
              handlefunc={getDropdownEbook}
            />
            {Errorcard?.examType && (
              <span className=" ms-2 input-feedback">
                Exam Type is required{" "}
              </span>
            )}
          </div>
          <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
            <InputLabel>Course</InputLabel>
            <CustomDropdown
              menuStyle={{ border: "1px solid #E3E9EE" }}
              customClass="form-dropdown"
              placeholder="Select Course"
              isSelect={true}
              menu={CourseStore?.course}
              selectedEntity={
                QuestionStore.selectedItemsNw.courseList.selectedName
              }
              handlefunc={getDropdownEbook}
            />
            {Errorcard?.courseType && (
              <span className="ms-2  input-feedback">Course is required </span>
            )}
          </div>
          <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
            <InputLabel>Sub-course</InputLabel>
            <CustomDropdown
              menuStyle={{ border: "1px solid #E3E9EE" }}
              customClass="form-dropdown"
              placeholder="Select SubCourse"
              isSelect={true}
              menu={CourseStore?.subcourse}
              selectedEntity={
                QuestionStore.selectedItemsNw.SubCourseList.selectedName
              }
              handlefunc={getDropdownEbook}
            />
            {Errorcard?.subCourseType && (
              <span className=" ms-2  input-feedback">
                SubCourse is required{" "}
              </span>
            )}
          </div>
          <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
                <InputLabel>Institute</InputLabel>
                <CustomDropdown
                  menuStyle={{ border: "1px solid #E3E9EE" }}
                  isSelect={true}
                  menu={institute}
                  customClass="form-dropdown"
                  placeholder="Select Institute"
                  handlefunc={getDropdownEbook}
                  selectedEntity={
                    Role?.role == "Admin"
                      ? PatternStore.selectedItemsPattern.Institute.selectedName
                      : Role?.instituteName
                  }
                />
                {Errorcard?.instituteType && (
                  <span className="ms-2 input-feedback">
                    Institute is required{" "}
                  </span>
                )}
              </div>
              {
             (   mockTest?.length >0 && !student) &&
                <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
                <InputLabel>Mock Test</InputLabel>
                <CustomDropdown
                  menuStyle={{ border: "1px solid #E3E9EE" }}
                  isSelect={true}
                  menu={mockTest}
                  customClass="form-dropdown"
                  placeholder="Select Mock-test"
                  handlefunc={getDropdownEbook}
                  selectedEntity={
                    PatternStore?.selectedItemsPattern?.mockTestType?.selectedName
                  }
                />
                {Errorcard?.mockTestType && (
                  <span className="ms-2 input-feedback">
                    mockTest is required{" "}
                  </span>
                )}
              </div>
              }
       
          <div className="w-25 ">
                <Button
                  title="Apply"
                  width="114px"
                  height="48px"
                  marginTop="25px"
                  func={(e) => {
                    checkDefault(e);
                    checkValidate();
                    getResult();
                  }}
                />
              </div>
    </div>
    </form>
    </div>
  );
}
