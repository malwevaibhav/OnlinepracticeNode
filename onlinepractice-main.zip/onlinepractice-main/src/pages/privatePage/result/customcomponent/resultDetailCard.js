import React from "react";
import { SmallHeading } from "../../../../customcomponents/DynamicText/Heading";
import { ThemeColors } from "../../../../theme/theme";
import { HHMMSSToHM } from "../../../../utils/helper";

export default function ResultDetailCard(props) {
  const { title, data, type } = props;

  const myStyle = {
    padding: '2px 10px',
    gap: '20px',
    minWidth: 'max-content',
    height: '29px',
    borderRadius: '3px',
    color: '#4FA4F4',
    margin:"0",
    background: '#ecf5ff',
    border: '1px solid #d0e6ff',
}

  return (
    <div className="card p-3 border-0" style={{height:'200px'}}>
      <SmallHeading text={title} />
      {type === "marks" ? (
        <div className="d-flex mt-2 justify-content-between">
          <div className="flex-column">
          <p style={ThemeColors?.TitleHeading}  className="me-2 mb-2">Total Questions</p>
          <p style={ThemeColors?.TitleHeading}  className="me-2 mb-2">Total Marks</p>
          <p style={ThemeColors?.TitleHeading}  className="me-2 mb-2">Total Time</p>
        
          </div>
          <div className="flex-column">
          <p style={myStyle} className="me-2 mb-2">{data?.totalQuestions}</p>
          <p style={myStyle} className="me-2 mb-2">{data?.totalMarks}</p>
          <p style={myStyle} className="me-2 mb-2">{HHMMSSToHM(data?.duration)}</p>
          </div>
        </div>
      ) : type === "rank" ? (
         <div className="d-flex gap-5">
          <div className="flex-column">
          <p style={ThemeColors?.TitleHeading}  className="me-2 mb-2">Rank</p>
          <p style={ThemeColors?.TitleHeading}  className="me-2 mb-2">Total Obtained Marks</p>
          </div>
          <div className="flex-column" style={{color:"#787F86",fontWeight:600}}>
          <p className="me-2 mb-2">:</p>
          <p className="me-2 mb-2">:</p>
          </div>
          <div className="flex-column" style={{color:"#787F86",fontWeight:600}}>
          <p className="me-2 mb-2"> {data?.rank}</p>
          <p className="me-2 mb-2">{data?.totalObtainMark}</p>
          </div>
         </div>
      ) : (
        <table className="table"  style={{ width: "80%" }}>
        <thead>
            <tr>
                <th scope="col"><SmallHeading text={"Subject"} color={ThemeColors.grey} /></th>
                <th scope="col"><SmallHeading text={"Correct"} color={ThemeColors.danger} /></th>
                <th scope="col"><SmallHeading text={"Incorrect"} color={ThemeColors.green} /></th>
                <th scope="col"><SmallHeading text={"Skipped"} color={ThemeColors.blue} /></th>

            </tr>
        </thead>
        <tbody>
            { data?.subjectResultDetails.map((data, key) => {
                                return (
                        <tr>
                            <td ><SmallHeading text={data?.subjectName} color={ThemeColors.grey}  /></td>
                            <td >{data?.correct}</td>
                            <td >{data?.inCorrect}</td>
                            <td >{data?.skipped}</td>
                        </tr>
                                
            )}
            
          )}
            
            <tr>
                <td><SmallHeading text="Total" /></td>
                <td>{data?.totalCorrect}</td>
                <td>{data?.totalIncorrect}</td>
                <td>{data?.totalSkipped}</td>
            </tr>
        </tbody>
      </table>
      )}
    </div>
  );
}
