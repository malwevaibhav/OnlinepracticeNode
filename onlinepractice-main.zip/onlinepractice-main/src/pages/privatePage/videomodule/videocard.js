import { toJS } from 'mobx';
import React, { useEffect } from 'react'
import { useState } from 'react';
import { useLayoutEffect } from 'react';
import { InputLabel } from '../../../customcomponents/customTextInput/indexCss'
import CustomDropdown from '../../../customcomponents/custom_Dropdown/CustomDropdown'
import CourseStore from '../../../MobX/Courses';
import QuestionStore from '../../../MobX/Question'
import CourseServices from '../../../Services/CourseService';

export default function Videocard() {
  const [toggle ,setToggle]=useState("")

  useEffect(()=>{
    CourseServices?.getCourseFilterData({ label: "Exam" });
  },[])

  useLayoutEffect(() => {
  
    CourseStore.setexamList([]);
    CourseStore.setCourse([]);
    CourseStore.setSubCourse([]);
    CourseStore.setSubjectSelected([]);
    CourseStore.setTopicList([]);
  }, [])

  const examList = toJS(CourseStore?.examList);
  const courseList = toJS(CourseStore?.course);
  const subcourseList = toJS(CourseStore?.subcourse);
  const subjectList = toJS(CourseStore?.selectedSubjectList);
  const topicList = toJS(CourseStore?.topicList);

  //change function to sdet dropdown value //
  const setExamModule = (props, entityName) => {
    if (props?.label === "Course") {
      CourseStore.setSubCourse([]);
      CourseStore.setSubjectSelected([]);
      CourseStore.setTopicList([]);
      CourseStore.setSubTopicList([]);
      QuestionStore.setSelectedItemsNw({ selectedName: "Exam", props, entityName })

    }
    if (props?.label === "SubCourse") {
      CourseStore.setSubCourse([]);
      CourseStore.setSubjectSelected([]);
      CourseStore.setTopicList([]);
      CourseStore.setSubTopicList([]);
      QuestionStore.setSelectedItemsNw({ selectedName: "Course", props, entityName })

    }
    if (props?.label === "Subject") {
      CourseStore.setSubjectSelected([]);
      CourseStore.setTopicList([]);
      CourseStore.setSubTopicList([]);
      QuestionStore.setSelectedItemsNw({ selectedName: "SubCourse", props, entityName })

    }
    if (props?.label === "Topic") {
      CourseStore.setTopicList([]);
      CourseStore.setSubTopicList([]);
      QuestionStore.setSelectedItemsNw({ selectedName: "Subject", props, entityName })

    }
    if (props?.label === "SubTopic") {
      CourseStore.setSubTopicList([]);
      QuestionStore.setSelectedItemsNw({ selectedName: "Topic", props, entityName })

    }
    setToggle(!toggle)
    return CourseServices?.getCourseFilterData(props);
  }
  return (
    <form className="card px-3 pb-4 border-0">
      <div className="row m-0 gy-3">
        <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
          <InputLabel>Exam Type</InputLabel>
          <CustomDropdown
            height="48px"
            menu={examList}
            customClass="form-dropdown"
            placeholder="Select Exam"
            menuStyle={{ border: "1px solid #E3E9EE" }}
            selectedEntity={QuestionStore.selectedItemsNw.examList.selectedName}
            handlefunc={setExamModule}
          />
        </div>
        <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
          <InputLabel>Course</InputLabel>
          <CustomDropdown
            height="48px"
            menu={courseList}
            customClass="form-dropdown"
            placeholder="Select Course"
            menuStyle={{ border: "1px solid #E3E9EE" }}
            selectedEntity={QuestionStore.selectedItemsNw.courseList.selectedName}
            handlefunc={setExamModule}

          />
        </div>
        <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
          <InputLabel>Sub-course</InputLabel>
          <CustomDropdown
            height="48px"
            menu={subcourseList}
            customClass="form-dropdown"
            placeholder="Select SubCourse"
            selectedEntity={QuestionStore.selectedItemsNw.SubCourseList.selectedName}
            menuStyle={{ border: "1px solid #E3E9EE" }}
            handlefunc={setExamModule}
          />
        </div>
        <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
          <InputLabel>Subject</InputLabel>
          <CustomDropdown
            height="48px"
            menu={subjectList}
            customClass="form-dropdown"
            placeholder="Select Subject"
            selectedEntity={QuestionStore.selectedItemsNw.SubjectList.selectedName}
            handlefunc={setExamModule}

          />
        </div>

        <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
          <InputLabel>Topic</InputLabel>
          <CustomDropdown
            height="48px"
            menu={topicList}
            customClass="form-dropdown"
            placeholder="Select Topic"
            selectedEntity={QuestionStore.selectedItemsNw.TopicList.selectedName}
            menuStyle={{ border: "1px solid #E3E9EE" }}
            handlefunc={setExamModule}
          />
        </div>
      </div>
    </form>
  )
}


