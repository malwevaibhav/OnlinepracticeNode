import React from 'react'
import { PlusIcon } from '../../../assets/svgs/svg'
import Button from '../../../customcomponents/button/Button'
import MultiLevelDropDown from '../../../customcomponents/custom_Dropdown/MultiLevelDropDown'
import { HeadTitle } from '../../../customcomponents/headtitle/headTitle'
import Videocard from './videocard'

export default function VideoModule() {
    const myStyle = {
        backgroundColor: "white",
        width: "max-content",
        display: "flex",
        height: "46px",
        padding: "9px 13px",
        paddingLeft: "18px",
      };
    return (
        <div>
            <HeadTitle
                text="Videos"
                component3={
                    <Button
                        title="Add video"
                        width="135px"
                        height="45px"
                        icon={<PlusIcon />}
                    />
                }
                component2={<MultiLevelDropDown menu={dropDown} menuStyle={myStyle} />}
                component1={
                  <MultiLevelDropDown
                    menu={dropDown}
                    preText="Sort By : "
                    menuStyle={myStyle}
                  />
                }
            />

            <Videocard />
        </div>

    )
}

export const dropDown = [
    { title: "Date", tooltip: "link", active: false },
    { title: "Name", tooltip: "link", active: false },
    { title: "Institute", tooltip: "link", active: false },
  ];