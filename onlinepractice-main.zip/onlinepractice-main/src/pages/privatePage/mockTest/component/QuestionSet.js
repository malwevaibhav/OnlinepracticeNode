import { toJS } from "mobx";
import { observer } from "mobx-react-lite";
import React from "react";
import { toast } from "react-toastify";
import { DeleteRedIcon } from "../../../../assets/svgs/svg";
import Button from "../../../../customcomponents/button/Button";
import { SmallHeading } from "../../../../customcomponents/DynamicText/Heading";
import MockTestStore from "../../../../MobX/MockTestStore";
import MocktestServices from "../../../../Services/MockTestService";

/* eslint-disable */
function QuestionSet({ setPublish }) {
  const deleteSection = (subjectId, sectionId) => {
    let copyArr = { ...toJS(MockTestStore.mockTestArray) };
    let subIndex = copyArr.mockTestQuestions?.findIndex(
      (x) => x.subjectId === subjectId
    );
    let secIndex = copyArr.mockTestQuestions[
      subIndex
    ]?.sectionDetails?.findIndex((y) => y.sectionId === sectionId);
    copyArr.mockTestQuestions[subIndex]?.sectionDetails.splice(secIndex, 1);
    MockTestStore.setMockTestArray(copyArr);
  };

  const checkMockTest = async () => {
    let copyArr = { ...toJS(MockTestStore.mockTestArray) };
    let data = copyArr.mockTestQuestions.filter((e) => e.totalQuestions > 0);
    copyArr.mockTestQuestions = data;
    let checkMock;
    copyArr.mockTestQuestions.map((arr) => {
      arr?.sectionDetails.map((subArr) => {
        if (subArr?.mockTestQuestions.length < 1) {
          checkMock = {
            subjectName: arr?.subjectName,
            sectionName: subArr?.sectionName,
          };
        }
      });
    });
    if (checkMock) {
      toast.error(`Please fill section in ${checkMock.subjectName} subject`);
      return;
    }
    let unableMock = copyArr.mockTestQuestions.find(
      (x) => x?.totalQuestions && !x?.noOfQue
    );
    if (unableMock) {
      toast.error(`Please fill questions in ${unableMock.subjectName} subject`);
    } else {
      MockTestStore.setMocktestIDs({
        MocktestSettingId: localStorage.step1Res,
      });
      let postData = {
        ...copyArr,
        ...toJS(MockTestStore.mocktestIDs),
        MocktestSettingId: localStorage.step1Res,
      };
      let res = await MocktestServices.updatemocktestquestions(postData);
      if (res.isSuccess) {
        MockTestStore.setMockTestArray(copyArr);
        MockTestStore.setCurrentStep({ step: 3, from: 2 });
        MockTestStore.setStepCount(3);
        setPublish(false);
      }
    }
  };
  return (
    <div className="quetionSetContainer">
      <div className="questionSetHead f-align-justify">Question Set</div>
      <div className="questionSetField px-2">
        {MockTestStore.mockTestArray?.mockTestQuestions &&
          MockTestStore.mockTestArray?.mockTestQuestions.map((que) => {
            return (
              que.totalQuestions > 0 && (
                <div className="row m-0 gap-2 pt-2">
                  <div className="p-0">
                    <SmallHeading text={que?.subjectName} />
                  </div>
                  {que?.sectionDetails.map((obj, j) => {
                    return (
                      <div
                        className="d-flex align-items-center gap-2 flex-wrap"
                        key={j}
                      >
                        S-{obj?.sectionName?.split("-")[1]}
                        {[...Array(obj?.totalQuestions).keys()].map(
                          (item, key) => {
                            return (
                              <div
                                className="questionSetbox d-flex justify-content-center align-items-center "
                                key={key}
                              >
                                {obj?.mockTestQuestions?.length >= key + 1
                                  ? key + 1
                                  : ""}
                              </div>
                            );
                          }
                        )}
                        {obj?.mockTestQuestions?.length < 1 && (
                          <div
                            className="pointer"
                            onClick={() => {
                              deleteSection(que?.subjectId, obj?.sectionId);
                            }}
                          >
                            <DeleteRedIcon />
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )
            );
          })}
      </div>
      <div className="row m-0 g-0 mb-3">
        <div className="col"></div>
        <div className="col d-flex justify-content-end">
          <Button
            title="Check Mocktest"
            fontSize="15px"
            width="170px"
            height="48px"
            marginTop="15px"
            func={checkMockTest}
          />
        </div>
      </div>
      {/* style={{background:que?.subjectName === PatternStore?.selectedItemsPattern?.SubjectList?.selectedName &&  ThemeColors.skyBlue}} */}
    </div>
  );
}
export default observer(QuestionSet);
