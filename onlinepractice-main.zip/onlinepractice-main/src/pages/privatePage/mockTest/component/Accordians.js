import { toJS } from "mobx";
import React, { useState } from "react";
import { BluePlusIcon } from "../../../../assets/svgs/svg";
import Button from "../../../../customcomponents/button/Button";
import {
  TitleHeading,
  SmallHeading,
} from "../../../../customcomponents/DynamicText/Heading";
import MockTestStore from "../../../../MobX/MockTestStore";
import PatternStore from "../../../../MobX/Pattern";
import QuestionStore from "../../../../MobX/Question";
import { ThemeColors } from "../../../../theme/theme";
import { checkQuesLength } from "./createpage/selectMockTest/manualMockTest/manualMockTestPage";

/* eslint-disable */
export default function Accordians({ array, subjectId }) {
  const languageSelected =
    PatternStore?.selectedItemsPattern?.Language?.selectedName.toLowerCase();
  const [show, setshow] = useState(true);
  const [queArray, setqueArray] = useState(array);

  const removeQuestion = (
    sectionId,
    questionRefId,
    subTopicId,
    topicId,
    questionType
  ) => {
    PatternStore.selectedItemsPattern.SubjectList.id = subjectId;
    PatternStore.selectedItemsPattern.TopicList.id = topicId;
    PatternStore.selectedItemsPattern.SubTopicList.id = subTopicId;
    PatternStore.selectedItemsPattern.SectionList.id = sectionId;
    QuestionStore.selectedItemsNw.questionType.id = questionType;
    let mainArr = { ...toJS(MockTestStore.mockTestArray) };
    let copyArr = [...queArray];

    copyArr.map((obj) => {
      if (sectionId === obj.sectionId) {
        return obj.mockTestQuestions.map((subObj) => {
          if (questionRefId === subObj.questionRefId) {
            return (subObj.questionTableData = null);
          }
        });
      }
    });
    setqueArray(copyArr);
    mainArr?.mockTestQuestions?.map((data) => {
      if (data?.sectionDetails && data.subjectId === subjectId) {
        data?.sectionDetails.map((sectionOBJ) => {
          if (sectionOBJ?.sectionId === sectionId) {
            sectionOBJ.mockTestQuestions.splice(
              sectionOBJ.mockTestQuestions?.findIndex(
                (e) => e.questionRefId === questionRefId
              ),
              1
            );
            return;
          }
        });
      }
    });
    MockTestStore.setMockTestArray(mainArr);
    checkQuesLength(subjectId);
  };
  return (
    queArray &&
    queArray?.map((obj, key) => {
      return (
        <>
          <div
            className="card rounded-0 border-0 p-2"
            style={{ background: ThemeColors.skyBlue }}
            onClick={() => setshow(!show)}
            key={key}
          >
            <div className="row m-0 d-flex justify-content-between">
              <TitleHeading text={obj?.sectionName} />
            </div>
          </div>
          {obj?.mockTestQuestions?.length > 0 &&
            obj?.mockTestQuestions.map((subObj, subIndex) => {
              return (
                show && (
                  <div key={subIndex} className="px-3">
                    <div className="row m-0 d-flex justify-content-between">
                      <div className="col ps-0">
                        <Button
                          title={`Question ${subIndex + 1}`}
                          fontSize="12px"
                          width="fit-content"
                          height="26px"
                        />
                      </div>
                      {subObj?.questionTableData && (
                        <div
                          className="col pe-0"
                          style={{ textAlign: "-webkit-right" }}
                        >
                          <Button
                            title="Remove"
                            fontSize="12px"
                            width="69px"
                            height="32px"
                            background={ThemeColors.danger}
                            func={() =>
                              removeQuestion(
                                obj?.sectionId,
                                subObj?.questionRefId,
                                subObj?.subTopicId,
                                subObj?.topicId,
                                subObj?.questionType
                              )
                            }
                          />
                        </div>
                      )}
                    </div>
                    {!subObj.questionTableData ? (
                      <div
                        className="d-flex justify-content-center pb-3 pointer"
                        onClick={() =>
                          MockTestStore.setCurrentStep({ step: 2, from: 3 })
                        }
                      >
                        <div className="card d-flex align-items-center p-3 spCard2 rounded-0 ">
                          <label
                            className="d-flex pointer"
                            htmlFor=""
                            style={{
                              color: ThemeColors.primary,
                              paddingInline: "75px",
                            }}
                          >
                            <SmallHeading text={<BluePlusIcon />} />
                            Add Question
                          </label>
                        </div>
                      </div>
                    ) : (
                      <div className="row m-0 mt-2">
                        <div className="ps-0">
                          <b
                            dangerouslySetInnerHTML={{
                              __html:
                                subObj?.questionTableData[languageSelected]
                                  ?.questionText,
                            }}
                          />
                        </div>

                        {subObj?.questionType === 3 ? (
                          <span
                            className="p-2 ps-3 d-flex mt-2"
                            style={{
                              fontSize: "14px",
                              background:
                                subObj?.questionTableData[languageSelected]
                                  ?.isCorrectA && ThemeColors.lightBlue,
                            }}
                          >
                            {"Answer:- "}
                            <span
                              dangerouslySetInnerHTML={{
                                __html:
                                  subObj?.questionTableData[languageSelected]
                                    ?.optionA,
                              }}
                            />
                          </span>
                        ) : (
                          <>
                            <span
                              className="p-2 ps-3 d-flex mt-2"
                              style={{
                                fontSize: "14px",
                                background:
                                  subObj?.questionTableData[languageSelected]
                                    ?.isCorrectA && ThemeColors.lightBlue,
                              }}
                            >
                              {"A) "}
                              <span
                                dangerouslySetInnerHTML={{
                                  __html:
                                    subObj?.questionTableData[languageSelected]
                                      ?.optionA,
                                }}
                              />
                            </span>
                            <span
                              className="p-2 ps-3 d-flex"
                              style={{
                                fontSize: "14px",
                                background:
                                  subObj?.questionTableData[languageSelected]
                                    ?.isCorrectB && ThemeColors.lightBlue,
                              }}
                            >
                              {"B) "}
                              <span
                                dangerouslySetInnerHTML={{
                                  __html:
                                    subObj?.questionTableData[languageSelected]
                                      ?.optionB,
                                }}
                              />
                            </span>
                            <span
                              className="p-2 ps-3 d-flex"
                              style={{
                                fontSize: "14px",
                                background:
                                  subObj?.questionTableData[languageSelected]
                                    ?.isCorrectC && ThemeColors.lightBlue,
                              }}
                            >
                              {"C) "}
                              <span
                                dangerouslySetInnerHTML={{
                                  __html:
                                    subObj?.questionTableData[languageSelected]
                                      ?.optionC,
                                }}
                              />
                            </span>
                            <span
                              className="p-2 ps-3 d-flex"
                              style={{
                                fontSize: "14px",
                                background:
                                  subObj?.questionTableData[languageSelected]
                                    ?.isCorrectD && ThemeColors.lightBlue,
                              }}
                            >
                              {"D) "}
                              <span
                                dangerouslySetInnerHTML={{
                                  __html:
                                    subObj?.questionTableData[languageSelected]
                                      ?.optionD,
                                }}
                              />
                            </span>
                          </>
                        )}
                      </div>
                    )}
                    <hr />
                  </div>
                )
              );
            })}
        </>
      );
    })
  );
}
