import { toJS } from "mobx";
import React, { useEffect, useLayoutEffect, useState } from "react";
import Button from "../../../../customcomponents/button/Button";
import { InputLabel } from "../../../../customcomponents/customTextInput/indexCss";
import CustomDropdown from "../../../../customcomponents/custom_Dropdown/CustomDropdown";
import AuthStore from "../../../../MobX/Auth";
import CourseStore from "../../../../MobX/Courses";
import PatternStore from "../../../../MobX/Pattern";
import QuestionStore from "../../../../MobX/Question";
import CourseServices from "../../../../Services/CourseService";
import InstituteServices from "../../../../Services/InstituteService";
import PatternServices from "../../../../Services/patternService";
import QuestionTypeServices from "../../../../Services/QuestionTypeService";
import { checkDefault } from "../../../../utils/helper";

const MockTestCard = ({ applyFunc }) => {
  const [institute, setInstitute] = useState([]);
  const [language, setLanguage] = useState([]);
  const [toggle, setToggle] = useState(false);
  const [examPatterns, setExamPatterns] = useState([]);

  const examList = toJS(CourseStore?.examList);
  const courseList = toJS(CourseStore?.course);
  const subcourseList = toJS(CourseStore?.subcourse);
  const Role = AuthStore?.user?.user;

  /* eslint-disable */
  useEffect(() => {
    if (Role?.role === "Admin") {
      getAllInstitute();
    }
    if (Role?.role === "Staff") {
      PatternStore.setSelectedItemsPattern({
        selectedName: "Institute",
        props: {
          label: "Institute",
          Title: Role?.instituteName,
          id: Role?.instituteId,
        },
        entityName: Role?.instituteName,
      });
    }
    getAllLanguage();
    getAllPattern();
  }, []);

  const getAllInstitute = async () => {
    const resData = await InstituteServices.getAllInstitute();
    let temp = resData?.institutes?.map((data) => {
      return {
        id: data?.id,
        Title: data?.instituteName,
        label: "Institute",
      };
    });
    setInstitute(temp);
  };

  const getAllLanguage = async () => {
    const res = await QuestionTypeServices.getAllLanguage();
    if (res?.isSuccess) {
      if (res?.data) {
        let language = res?.data.map((item) => {
          return {
            id: item?.value,
            Title: item?.name,
            label: "Language",
          };
        });
        setLanguage(language);
      }
    }
  };

  const getAllPattern = async () => {
    const res = await PatternServices.getAllPattern({
      pageNumber: 0,
      pageSize: 0,
    });
    let patternData = res?.examPatterns?.map((elm) => {
      return {
        id: elm?.id,
        Title: elm?.examPatternName,
        label: "Pattern",
      };
    });
    setExamPatterns(patternData);
  };

  useLayoutEffect(() => {
    CourseServices?.getCourseFilterData({ label: "Exam" });
  }, []);

  const getDataForMockTest = (props, entityName) => {
    if (props?.label === "Course") {
      CourseStore.setSubCourse([]);
      QuestionStore.setSelectedItemsNw({
        selectedName: "Exam",
        props,
        entityName,
      });
    }
    if (props?.label === "SubCourse") {
      QuestionStore.setSelectedItemsNw({
        selectedName: "Course",
        props,
        entityName,
      });
    }
    if (props?.label === "Subject") {
      // CourseStore.setSubCourse([]);
      QuestionStore.setSelectedItemsNw({
        selectedName: "SubCourse",
        props,
        entityName,
      });
    }
    if (props?.label === "Pattern") {
      PatternStore.setSelectedItemsPattern({
        selectedName: "Pattern",
        props,
        entityName,
      });
    }
    if (props?.label === "Institute") {
      PatternStore.setSelectedItemsPattern({
        selectedName: "Institute",
        props,
        entityName,
      });
    }
    if (props?.label === "Language") {
      PatternStore.setSelectedItemsPattern({
        selectedName: "Language",
        props,
        entityName,
      });
    }

    setToggle(!toggle);
    return CourseServices?.getCourseFilterData(props);
  };

  return (
    <div className="card rounded-0 border-0 p-3">
      <div className="row m-0 g-2">
        <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
          <InputLabel>Exam Type</InputLabel>
          <CustomDropdown
            height="48px"
            menu={examList}
            customClass="form-dropdown"
            placeholder="Select Exam"
            handlefunc={getDataForMockTest}
            menuStyle={{ border: "1px solid #E3E9EE" }}
            selectedEntity={QuestionStore.selectedItemsNw.examList.selectedName}
          />
        </div>
        <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
          <InputLabel>Course</InputLabel>
          <CustomDropdown
            height="48px"
            menu={courseList}
            customClass="form-dropdown"
            placeholder="Select Course"
            menuStyle={{ border: "1px solid #E3E9EE" }}
            handlefunc={getDataForMockTest}
            selectedEntity={
              QuestionStore.selectedItemsNw.courseList.selectedName
            }
            disable={!QuestionStore.selectedItemsNw.examList.selectedName}
          />
        </div>
        <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
          <InputLabel>Sub-course</InputLabel>
          <CustomDropdown
            height="48px"
            menu={subcourseList}
            customClass="form-dropdown"
            placeholder="Select SubCourse"
            handlefunc={getDataForMockTest}
            selectedEntity={
              QuestionStore.selectedItemsNw.SubCourseList.selectedName
            }
            disable={!QuestionStore.selectedItemsNw.courseList.selectedName}
            menuStyle={{ border: "1px solid #E3E9EE" }}
          />
        </div>
        <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
          <InputLabel>Exam Pattern</InputLabel>
          <CustomDropdown
            menu={examPatterns}
            height="48px"
            customClass="form-dropdown"
            placeholder="Select Pattern"
            handlefunc={getDataForMockTest}
            menuStyle={{ border: "1px solid #E3E9EE" }}
            selectedEntity={
              PatternStore.selectedItemsPattern.pattern.selectedName
            }
            disable={!QuestionStore.selectedItemsNw.SubCourseList.selectedName}
          />
        </div>
        <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
          <InputLabel>Institue</InputLabel>
          <div className="mt-1">
            <CustomDropdown
              menu={institute}
              height="48px"
              customClass="form-dropdown"
              placeholder="Select Institute"
              handlefunc={getDataForMockTest}
              menuStyle={{ border: "1px solid #E3E9EE" }}
              selectedEntity={
                PatternStore.selectedItemsPattern.Institute.selectedName
              }
              disable={
                !PatternStore.selectedItemsPattern.pattern.selectedName ||
                Role?.role === "Staff"
              }
            />
          </div>
        </div>
        <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
          <InputLabel>Language</InputLabel>
          <div className="mt-1">
            <CustomDropdown
              menu={language}
              height="48px"
              customClass="form-dropdown"
              placeholder="Select Language"
              handlefunc={getDataForMockTest}
              menuStyle={{ border: "1px solid #E3E9EE" }}
              selectedEntity={
                PatternStore.selectedItemsPattern.Language.selectedName
              }
              disable={
                !PatternStore.selectedItemsPattern.Institute.selectedName &&
                !PatternStore.selectedItemsPattern.pattern.selectedName
              }
            />
          </div>
        </div>
        <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12 d-flex align-items-end">
          <Button
            title="Apply"
            width="114px"
            height="48px"
            func={(e) => {
              checkDefault(e);
              applyFunc();
            }}
          />
        </div>
      </div>
    </div>
  );
};

export default MockTestCard;
