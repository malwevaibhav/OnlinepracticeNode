import { observer } from "mobx-react-lite";
import React from "react";
import { ProgressBar, Step } from "react-step-progress-bar";

import MockTestStore from "../../../../../MobX/MockTestStore";
import "./step-bar.css";
const MultiStepProgressBar = () => {
  var stepPercentage = 0;
  if (MockTestStore.currentStep.step === 0) {
    stepPercentage = 0;
  } else if (MockTestStore.currentStep.step === 1) {
    stepPercentage = 33.3;
  } else if (MockTestStore.currentStep.step === 2) {
    stepPercentage = 66.6;
  } else if (MockTestStore.currentStep.step === 3) {
    stepPercentage = 82.5;
  } else {
    stepPercentage = 0;
  }

  return (
    <div className="card rounded-0 border-0 p-3 mb-3">
      <ProgressBar percent={stepPercentage}>
        <Step>
          {({ accomplished, index }) => (
            <div className="f-align">
              <div
                className={`indexedStep ${
                  accomplished ? "accomplished" : null
                }`}
                onClick={() =>
                  MockTestStore.stepCount >= 1 &&
                  MockTestStore.setCurrentStep({
                    step: 1,
                    from: MockTestStore.currentStep?.step,
                  })
                }
              >
                {index + 1}
              </div>
              <div
                className={`stepContent ${
                  accomplished ? "accomplished" : null
                }`}
              >
                Select Mock Test Settings
              </div>
              <div
                className={`stepLine ${accomplished ? "accomplished" : null}`}
              ></div>
            </div>
          )}
        </Step>

        <Step>
          {({ accomplished, index }) => (
            <div className="f-align">
              <div
                className={`indexedStep ${
                  accomplished ? "accomplished" : null
                }`}
                onClick={() =>
                  MockTestStore.stepCount >= 2 &&
                  MockTestStore.setCurrentStep({
                    step: 2,
                    from: MockTestStore.currentStep?.step,
                  })
                }
              >
                {index + 1}
              </div>
              <div
                className={`stepContent ${
                  accomplished ? "accomplished" : null
                }`}
              >
                Create Mock Test
              </div>{" "}
              <div
                className={`stepLine ${accomplished ? "accomplished" : null}`}
              ></div>
            </div>
          )}
        </Step>
        <Step>
          {({ accomplished, index }) => (
            <div className="f-align">
              <div
                className={`indexedStep ${
                  accomplished ? "accomplished" : null
                }`}
                onClick={() =>
                  MockTestStore.stepCount >= 3 &&
                  MockTestStore.setCurrentStep({
                    step: 3,
                    from: MockTestStore.currentStep?.step,
                  })
                }
              >
                {index + 1}
              </div>
              <div
                className={`stepContent ${
                  accomplished ? "accomplished" : null
                }`}
              >
                Preview & Publish
              </div>
            </div>
          )}
        </Step>
      </ProgressBar>
    </div>
  );
};

export default observer(MultiStepProgressBar);
