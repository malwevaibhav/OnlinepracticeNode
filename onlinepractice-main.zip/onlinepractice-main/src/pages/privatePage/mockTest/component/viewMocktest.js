import React, { useRef } from "react";
import { useState } from "react";
import { useLayoutEffect } from "react";
import { useEffect } from "react";
import { useLocation } from "react-router-dom";
import { DocxSvg } from "../../../../assets/svgs/svg";
import Button from "../../../../customcomponents/button/Button";
import { InputLabel } from "../../../../customcomponents/customTextInput/indexCss";
import CustomDropdown from "../../../../customcomponents/custom_Dropdown/CustomDropdown";
import {
  BoldHeading,
  NormalHeading,
  TitleHeading,
} from "../../../../customcomponents/DynamicText/Heading";
import { HeadTitle } from "../../../../customcomponents/headtitle/headTitle";
import MockTestStore from "../../../../MobX/MockTestStore";
import PatternStore from "../../../../MobX/Pattern";
import MocktestServices from "../../../../Services/MockTestService";
import QuestionTypeServices from "../../../../Services/QuestionTypeService";
import { ThemeColors } from "../../../../theme/theme";
import PrintFunction from "../createMockTest/Print/PrintFunction";
import {
  Content,
  Tab,
  Tabs,
} from "./createpage/selectMockTest/manualMockTest/tabpage/tabpagecss";

const tabStyle = {
  borderRadius: "5px 5px 0 0",
  height: "40px",
  width: "120px",
  minWidth: "fit-content",
};

/* eslint-disable */
export default function ViewMocktest() {
  const location = useLocation();
  const mockRef = useRef();
  const [MockTestQuestions, setMockTestQuestions] = useState();
  const [active, setActive] = useState(1);
  const [totalQM, settotalQM] = useState({ questions: 0, marks: 0 });
  const [language, setLanguage] = useState([]);
  const [selectedItems, setSelectedItems] = useState({
    language: { selectedName: "", id: "" },
  });
  const [activeLang, setActiveLang] = useState(
    location?.state?.language.toLowerCase()
  );
  useLayoutEffect(() => {
    getAllLanguage();
  }, []);

  useEffect(() => {
    if (location?.state?.id) {
      // console.log("location=>>>>",location.state?.id)
      mockTestQuestionById(location?.state?.id);
    }
  }, [location?.state?.id]);

  const getAllLanguage = async () => {
    const res = await QuestionTypeServices.getAllLanguage();
    if (res?.isSuccess) {
      if (res?.data) {
        let lang = res?.data.map((item) => {
          return {
            id: item?.value,
            Title: item?.name,
          };
        });
        setLanguage(lang);
      }
    }
  };

  const getLanguageID = async (props) => {
    setSelectedItems({
      ...selectedItems,
      language: { selectedName: props?.Title, id: props?.id },
    });
    setActiveLang(props.Title.toLowerCase());
  };

  const mockTestQuestionById = async (Id) => {
    const resData = await MocktestServices.mockTestQuestionById({
      mockTestSettingId: Id,
    });
    if (resData.isSuccess) {
      setMockTestQuestions(resData.data?.mockTestQuestions);
      MockTestStore.setMockTestArray({ ...resData.data });
      let mark = 0;
      let question = 0;
      resData.data?.mockTestQuestions &&
        resData.data?.mockTestQuestions.map((data) => {
          question += data.totalQuestions;
          return data.sectionDetails.map((obj) => {
            return obj.mockTestQuestions.map((subObj) => {
              return (mark += subObj?.mark);
            });
          });
        });
      settotalQM({ ...totalQM, questions: question, marks: mark });
    }
  };

  const Print = () => {
    mockRef.current.click();
  };

  return (
    <>
      <div>
        <HeadTitle
          text="Preview MockTest"
          
          component1={
            !location.state.toPrint ? 
            <Button
              title="Export Doc"
              width="170px"
              height="48px"
              func={() => Print()}
              icon={<DocxSvg />}
              background={ThemeColors.white}
              textColor={ThemeColors.primary}
              border={"1px solid #0075FF"}
            /> :
            <></>


          }
        />
      </div>
      <div className="position-relative">
        <Tabs style={{ height: "2.2rem" }}>
          <Tab
            onClick={() => setActive(1)}
            active={active === 1}
            id={1}
            style={tabStyle}
          >
            <TitleHeading text={"Mocktest Preview"} />
          </Tab>
          <Tab
            onClick={() => setActive(2)}
            active={active === 2}
            id={2}
            style={tabStyle}
          >
            <TitleHeading text={"General Instructions"} />
          </Tab>
        </Tabs>

        <div
          className="position-absolute d-flex gap-3"
          style={{ right: "0", top: "5px" }}
        >
          <InputLabel style={{ paddingTop: "8px", color: ThemeColors.primary }}>
            Total Questions : {totalQM?.questions}{" "}
          </InputLabel>
          <InputLabel style={{ paddingTop: "8px", color: ThemeColors.primary }}>
            {" "}
            Total Marks : {totalQM?.marks}
          </InputLabel>
          <div className="d-flex align-items-center">
            <small style={{ color: ThemeColors.secondary }}>Language:</small>
            <CustomDropdown
              customClass="QuestionIdDropDown"
              placeholder={
                PatternStore.selectedItemsPattern.Language.selectedName ||
                "English"
              }
              isSelect={true}
              menu={language}
              menuStyle={{ padding: 0, paddingLeft: "5px !important" }}
              handlefunc={getLanguageID}
              selectedEntity={selectedItems?.language?.selectedName}
            />
          </div>
        </div>
        <Content active={active === 1}>
          {MockTestQuestions &&
            MockTestQuestions.map((data, i) => {
              return (
                <div key={i}>
                  <div className="card rounded-0 border-0 p-2">
                    <div className="row m-0 d-flex text-center pt-2">
                      <BoldHeading text={data?.subjectName} />
                    </div>
                  </div>
                  {data.sectionDetails.map((obj, j) => {
                    return (
                      <>
                        <div className="card rounded-0 border-0 p-2" key={j}>
                          <div className="row m-0 d-flex text-center">
                            <NormalHeading text={obj?.sectionName} />
                          </div>
                        </div>
                        {obj.mockTestQuestions.map((subObj, k) => {
                          return (
                            <>
                              <div
                                className="card rounded-0 border-0 border-bottom p-2"
                                key={k}
                              >
                                <div className="row m-0" key={i}>
                                  <div
                                    className="d-flex"
                                    style={{
                                      fontSize: "16px",
                                      fontWeight: "400",
                                    }}
                                  >
                                    {`${k + 1})`}
                                    <label
                                      className="ps-1 m-0 p-0"
                                      dangerouslySetInnerHTML={{
                                        __html:
                                          subObj?.questionTableData[activeLang]
                                            ?.questionText,
                                      }}
                                    />
                                  </div>
                                  <div
                                    className="d-flex"
                                    style={{
                                      fontSize: "16px",
                                      fontWeight: "400",
                                    }}
                                  >
                                    {"A) "}
                                    <label
                                      className="ps-1 m-0 p-0"
                                      dangerouslySetInnerHTML={{
                                        __html:
                                          subObj?.questionTableData[activeLang]
                                            ?.optionA,
                                      }}
                                    />
                                  </div>
                                  <div
                                    className="d-flex"
                                    style={{
                                      fontSize: "16px",
                                      fontWeight: "400",
                                    }}
                                  >
                                    {"B) "}
                                    <label
                                      className="ps-1 m-0 p-0"
                                      dangerouslySetInnerHTML={{
                                        __html:
                                          subObj?.questionTableData[activeLang]
                                            ?.optionB,
                                      }}
                                    />
                                  </div>
                                  <div
                                    className="d-flex"
                                    style={{
                                      fontSize: "16px",
                                      fontWeight: "400",
                                    }}
                                  >
                                    {"C) "}
                                    <label
                                      className="ps-1 m-0 p-0"
                                      dangerouslySetInnerHTML={{
                                        __html:
                                          subObj?.questionTableData[activeLang]
                                            ?.optionC,
                                      }}
                                    />
                                  </div>
                                  <div
                                    className="d-flex"
                                    style={{
                                      fontSize: "16px",
                                      fontWeight: "400",
                                    }}
                                  >
                                    {"D) "}
                                    <label
                                      className="ps-1 m-0 p-0"
                                      dangerouslySetInnerHTML={{
                                        __html:
                                          subObj?.questionTableData[activeLang]
                                            ?.optionD,
                                      }}
                                    />
                                  </div>
                                  <label
                                    className="pb-2"
                                    sstyle={{
                                      fontSize: "16px",
                                      fontWeight: "400",
                                    }}
                                  >
                                    Marks -{subObj?.mark}
                                  </label>
                                </div>
                              </div>
                            </>
                          );
                        })}
                      </>
                    );
                  })}
                </div>
              );
            })}
        </Content>
        <Content active={active === 2}>
          <div className="card border-0 rounded-0 p-4">
          <p
            className="ps-1 m-0 p-0"
            dangerouslySetInnerHTML={{
              __html:MockTestStore?.mockTestArray?.generalInstructions
            }}
          />
          </div>
        </Content>
      </div>
      {!location.state.toPrint && <PrintFunction ref={mockRef} newId={location.state.id} />}
    </>
  );
}
