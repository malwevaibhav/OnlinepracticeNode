import React, { useEffect, useState } from "react";
import MockTestStore from "../../../../../MobX/MockTestStore";
import PatternStore from "../../../../../MobX/Pattern";
import QuestionStore from "../../../../../MobX/Question";
import MocktestServices from "../../../../../Services/MockTestService";
import "./mocktestDetails.css";
import PreviewTabs from "./selectMockTest/manualMockTest/tabpage/PreviewTabs";
import Tabpage from "./selectMockTest/manualMockTest/tabpage/tabpage";

/* eslint-disable */
const ThirdShep = ({ publish, Id }) => {
  const [mockTestQuestions, setMockTestQuestions] = useState([]);
  useEffect(() => {
    if (Id || localStorage.step1Res) {
      mockTestQuestionById(Id);
    }
  }, []);
  const mockTestQuestionById = async (Id) => {
    const resData = await MocktestServices.mockTestQuestionById({
      mockTestSettingId: Id ? Id : localStorage.step1Res,
    });

    if (resData.isSuccess) {
      PatternStore.selectedItemsPattern.SubjectList.id =
        resData?.data?.subjectId;
      PatternStore.selectedItemsPattern.TopicList.id = resData?.data?.topicId;
      PatternStore.selectedItemsPattern.SubTopicList.id =
        resData?.data?.subTopicId;
      PatternStore.selectedItemsPattern.SectionList.id =
        resData?.data?.sectionId;
      QuestionStore.selectedItemsNw.questionType.id =
        resData?.data?.questionType;
      // PatternStore.setSelectedItemsPattern({ selectedName: "Pattern", props, entityName })
      setMockTestQuestions(resData.data?.mockTestQuestions);
      MockTestStore.setMockTestArray({ ...resData.data, IsDraft: true });
    }
  };
  return (
    <div>
      {publish ? (
        <PreviewTabs mockTestQuestions={mockTestQuestions} generalInst={MockTestStore?.mockTestArray?.generalInstructions} />
      ) : (
        <Tabpage mockTestQuestions={mockTestQuestions} />
      )}
    </div>
  );
};

export default ThirdShep;
