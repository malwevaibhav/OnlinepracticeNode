import React, { useState } from "react";
import { TitleHeading } from "../../../../../../../../customcomponents/DynamicText/Heading";
import Accordians from "../../../../Accordians";
import "../../../selectMockTest/selectmocktest.css";
import { Content, Tab, Tabs } from "./tabpagecss";
const tabStyle = {
  borderRadius: "5px 5px 0 0",
  height: "40px",
  width: "120px",
  minWidth: "fit-content",
};

function Tabpage({ mockTestQuestions }) {
  const [active, setActive] = useState(0);
  return (
    <div>
      <Tabs style={{ height: "2.2rem" }}>
        {mockTestQuestions &&
          mockTestQuestions.map((que, i) => {
            return (
              <Tab
                onClick={() => setActive(i)}
                active={active === i}
                id={i}
                style={tabStyle}
                key={i}
              >
                <TitleHeading text={que?.subjectName} />
              </Tab>
            );
          })}
      </Tabs>

      {mockTestQuestions &&
        mockTestQuestions.map((que, i) => {
          return (
            <Content active={active === i}>
              <div className="card rounded-0 border-0 p-3 px-4 d-flex gap-3">
                <Accordians
                  array={que.sectionDetails}
                  subjectId={que.subjectId}
                />
              </div>
            </Content>
          );
        })}
    </div>
  );
}

export default Tabpage;
