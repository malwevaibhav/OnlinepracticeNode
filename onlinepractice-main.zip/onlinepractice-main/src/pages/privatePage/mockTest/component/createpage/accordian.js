import React from "react";
/* eslint-disable */
export default function Accordion(props) {
  const {
    title,
    type,
    icon,
    background = "red",
    textColor = "white",
    func,
    width,
    height = "31px",
    fontSize,
    marginTop,
    border,
    disable,
    funct,
    marginRight,
  } = props;

  return (
    <button
      className="btn rounded-1 d-flex align-items-center  "
      type={type}
      disabled={disable}
      style={{
        fontFamily: "Medium",
        fontWeight: "500",
        marginRight: { marginRight },
        backgroundColor: background,
        color: textColor,
        fontSize: fontSize,
        width: width,
        height: height,
        border: border,
        marginTop: marginTop,
        ...props,
      }}
      onClick={funct}
    >
      {title}
      <span className="ps-2">{icon}</span>
    </button>
  );
}
