import { toJS } from "mobx";
import { observer } from "mobx-react-lite";
import React, { useLayoutEffect, useState, useEffect } from "react";
import Button from "../../../../../../../customcomponents/button/Button";
import { InputLabel } from "../../../../../../../customcomponents/customTextInput/indexCss";
import CustomDropdown from "../../../../../../../customcomponents/custom_Dropdown/CustomDropdown";
import CourseStore from "../../../../../../../MobX/Courses";
import MockTestStore from "../../../../../../../MobX/MockTestStore";
import PatternStore from "../../../../../../../MobX/Pattern";
import QuestionStore from "../../../../../../../MobX/Question";
import CourseServices from "../../../../../../../Services/CourseService";
import MocktestServices from "../../../../../../../Services/MockTestService";
import PatternServices from "../../../../../../../Services/patternService";
import QuestionTypeServices from "../../../../../../../Services/QuestionTypeService";

const ManualMockTestCard = ({ getQuestionFilter, setQueData, Id }) => {
  //#region
  const [examPatterns, setExamPatterns] = useState([]);
  const [questionType, setQuestionType] = useState([]);
  const [toggle, setToggle] = useState(false);

  /* eslint-disable */
  useEffect(() => {
    getAllPattern();
    getAllQuesType();
  }, []);

  useLayoutEffect(() => {
    CourseServices?.getCourseFilterData({ label: "Exam" });
  }, []);

  const examList = toJS(CourseStore?.examList);
  const courseList = toJS(CourseStore?.course);
  const subcourseList = toJS(CourseStore?.subcourse);
  const getAllQuesType = async () => {
    const resData = await QuestionTypeServices.getAllQuestionType();
    let queType = resData?.map((elm) => {
      return {
        id: elm?.value,
        Title: elm?.name,
        label: "QuestionType",
      };
    });
    setQuestionType(queType);
    QuestionStore.setQuestionType(queType);
    CourseStore.setQuestionTypeList(queType);
  };

  const getAllPattern = async () => {
    const res = await PatternServices.getAllPattern({
      pageNumber: 0,
      pageSize: 0,
    });
    let patternData = res?.examPatterns?.map((elm) => {
      return {
        id: elm?.id,
        Title: elm?.examPatternName,
        label: "Pattern",
      };
    });
    setExamPatterns(patternData);
  };

  const getQuestionsDetails = async () => {
    let mainArr = toJS(MockTestStore.mockTestArray);
    mainArr.mockTestQuestions.map((que) => {
      if (
        que.subjectId === PatternStore?.selectedItemsPattern?.SubjectList.id
      ) {
        let secID = que.sectionDetails.find(
          (e) =>
            e.sectionId ===
            PatternStore?.selectedItemsPattern?.SectionList?.props?.id
        );
        if (secID) {
          return;
        } else {
          que.totalQuestions +=
            PatternStore?.selectedItemsPattern?.SectionList?.props?.totalQuestions;
          que.totalAttempt +=
            PatternStore?.selectedItemsPattern?.SectionList?.props?.totalAttempt;
          que.sectionDetails.push({
            sectionId:
              PatternStore?.selectedItemsPattern?.SectionList?.props?.id,
            sectionName:
              PatternStore?.selectedItemsPattern?.SectionList?.props?.Title,
            totalAttempt:
              PatternStore?.selectedItemsPattern?.SectionList?.props
                ?.totalAttempt,
            totalQuestions:
              PatternStore?.selectedItemsPattern?.SectionList?.props
                ?.totalQuestions,
            mockTestQuestions: [],
          });
        }
      }
    });
    let found = mainArr?.mockTestQuestions.find(
      (x) => x.subjectId === PatternStore?.selectedItemsPattern?.SubjectList.id
    );
    if (!found) {
      let a = {
        sectionDetails: [
          {
            sectionId:
              PatternStore?.selectedItemsPattern?.SectionList?.props?.id,
            sectionName:
              PatternStore?.selectedItemsPattern?.SectionList?.props?.Title,
            totalAttempt:
              PatternStore?.selectedItemsPattern?.SectionList?.props
                ?.totalAttempt,
            totalQuestions:
              PatternStore?.selectedItemsPattern?.SectionList?.props
                ?.totalQuestions,
            mockTestQuestions: [],
          },
        ],
        subjectId: PatternStore?.selectedItemsPattern?.SubjectList.id,
        subjectName:
          PatternStore?.selectedItemsPattern?.SubjectList.selectedName,
        totalAttempt:
          PatternStore?.selectedItemsPattern?.SectionList?.props?.totalAttempt,
        totalQuestions:
          PatternStore?.selectedItemsPattern?.SectionList?.props
            ?.totalQuestions,
      };
      mainArr.mockTestQuestions.push(a);
    }
    MockTestStore.setMockTestArray(mainArr);
    getQuestionFilter();
  };
  //#endregion

  const createQueJSON = (data) => {
    let subArr = data?.examPatternSubjects.map((d) => {
      return {
        subjectId: d.subjectId,
        subjectName: d.subjectName,
        totalQuestions: 0,
        totalAttempt: 0,
        sectionDetails: [],
      };
    });
    let mainArr = {
      ...toJS(MockTestStore.mocktestIDs),
      mockTestQuestions: [...subArr],
    };
    MockTestStore.setMockTestArray(mainArr);
  };

  const getDataForMockTest = async (props, entityName) => {
    setQueData("");
    if (props?.label === "Course") {
      CourseStore.setSubCourse([]);
      QuestionStore.setSelectedItemsNw({
        selectedName: "Exam",
        props,
        entityName,
      });
      MockTestStore.setMocktestIDs({ examTypeId: props.id });
      PatternStore.setSelectedItemsPattern({
        selectedName: "Pattern",
        props: {},
        entityName: "",
      });
    }
    if (props?.label === "SubCourse") {
      CourseStore.setSubCourse([]);
      QuestionStore.setSelectedItemsNw({
        selectedName: "Course",
        props,
        entityName,
      });
      MockTestStore.setMocktestIDs({ courseId: props.id });
    }
    if (props?.label === "Subject") {
      QuestionStore.setSelectedItemsNw({
        selectedName: "SubCourse",
        props,
        entityName,
      });
      MockTestStore.setMocktestIDs({ subCourseId: props.id });
    }
    if (props?.label === "QuestionType") {
      QuestionStore.setSelectedItemsNw({
        selectedName: "QuestionType",
        props,
        entityName,
      });
      MockTestStore.setMocktestIDs({ questionType: props.id });
    }
    if (props?.label === "Pattern") {
      PatternStore.setsubject([]);
      PatternStore.setSelectedItemsPattern({
        selectedName: "Pattern",
        props,
        entityName,
      });
      MockTestStore.setMocktestIDs({ examPatternId: props.id });
      let temp = await MocktestServices.getSubjectByPatternId(props?.id);
      createQueJSON(temp);
      return temp;
    }
    if (props?.label === "SubjectPattern") {
      CourseStore.setQuestionTypeList([]);
      PatternStore.setTopics([]);
      PatternStore.setSubTopics([]);
      PatternStore.setSectionList([]);
      PatternStore.setSelectedItemsPattern({
        selectedName: "SubjectPattern",
        props,
        entityName,
      });
      MockTestStore.setMocktestIDs({ subjectId: props.id });
      return MocktestServices.getTopicListbySubjectpattern(props?.id);
    }
    if (props?.label === "TopicPattern") {
      CourseStore.setQuestionTypeList([]);
      PatternStore.setSubTopics([]);
      PatternStore.setSectionList([]);
      PatternStore.setSelectedItemsPattern({
        selectedName: "TopicPattern",
        props,
        entityName,
      });
      MockTestStore.setMocktestIDs({ topicId: props.id });
      return MocktestServices.getSubTopic(props?.id);
    }
    if (props?.label === "SubTopicPattern") {
      CourseStore.setQuestionTypeList([]);
      PatternStore.setSelectedItemsPattern({
        selectedName: "SubTopicPattern",
        props,
        entityName,
      });
      MockTestStore.setMocktestIDs({ subTopicId: props.id });
      return await MocktestServices.getSectionbyPatternId({
        examPatternId: PatternStore.selectedItemsPattern.pattern.id,
        subjectId: PatternStore.selectedItemsPattern.SubjectList.id,
      });
    }
    if (props?.label === "SectionList") {
      CourseStore.setQuestionTypeList([]);
      PatternStore.setSelectedItemsPattern({
        selectedName: "SectionList",
        props,
        entityName,
      });
      MockTestStore.setMocktestIDs({ sectionId: props.id });
    }
    setToggle(!toggle);
    return CourseServices?.getCourseFilterData(props);
  };

  return (
    <>
      <div className="card rounded-0 border-0 p-3 ps-2">
        <div className="row m-0 ">
          <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
            <InputLabel>Exam Type</InputLabel>
            <CustomDropdown
              height="48px"
              menu={examList}
              customClass="form-dropdown"
              placeholder="Select Exam"
              handlefunc={getDataForMockTest}
              menuStyle={{ border: "1px solid #E3E9EE" }}
              selectedEntity={
                QuestionStore.selectedItemsNw.examList.selectedName
              }
              disable={Id}
            />
          </div>
          <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
            <InputLabel>Course</InputLabel>
            <CustomDropdown
              height="48px"
              menu={courseList}
              customClass="form-dropdown"
              placeholder="Select Course"
              menuStyle={{ border: "1px solid #E3E9EE" }}
              handlefunc={getDataForMockTest}
              selectedEntity={
                QuestionStore.selectedItemsNw.courseList.selectedName
              }
              disable={Id || !courseList?.length > 0 ? true : false}
            />
          </div>
          <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
            <InputLabel>Sub-course</InputLabel>
            <CustomDropdown
              height="48px"
              menu={subcourseList}
              customClass="form-dropdown"
              placeholder="Select SubCourse"
              handlefunc={getDataForMockTest}
              selectedEntity={
                QuestionStore.selectedItemsNw.SubCourseList.selectedName
              }
              disable={Id || !subcourseList?.length > 0 ? true : false}
              menuStyle={{ border: "1px solid #E3E9EE" }}
            />
          </div>
          <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
            <InputLabel>Exam Pattern</InputLabel>
            <CustomDropdown
              menu={examPatterns}
              height="48px"
              customClass="form-dropdown"
              placeholder="Select Pattern"
              handlefunc={getDataForMockTest}
              menuStyle={{ border: "1px solid #E3E9EE" }}
              disable={
                Id || !QuestionStore.selectedItemsNw.SubCourseList.selectedName
              }
              selectedEntity={
                PatternStore.selectedItemsPattern.pattern.selectedName
              }
            />
          </div>
        </div>
      </div>

      {/* {PatternStore.selectedItemsPattern.pattern.selectedName && */}
      {(PatternStore.selectedItemsPattern.pattern.selectedName ||
        PatternStore.selectedItemsPattern.pattern.id) && (
        <div className="card rounded-0 border-0 p-3 ps-2 mt-3">
          <div className="row m-0 d-flex align-items-end">
            <div className="col-xl-2 col-lg-2 col-md-6 col-sm-12">
              <InputLabel>Subject</InputLabel>
              <CustomDropdown
                height="48px"
                menu={PatternStore?.subjectList}
                customClass="form-dropdown"
                placeholder="Select Subject"
                handlefunc={getDataForMockTest}
                selectedEntity={
                  PatternStore.selectedItemsPattern.SubjectList.selectedName
                }
                menuStyle={{ border: "1px solid #E3E9EE" }}
              />
            </div>

            <div className="col-xl-2 col-lg-2 col-md-6 col-sm-12">
              <InputLabel>Topic</InputLabel>
              <CustomDropdown
                height="48px"
                menu={PatternStore?.TopicList}
                customClass="form-dropdown"
                placeholder="Select Topic"
                handlefunc={getDataForMockTest}
                selectedEntity={
                  PatternStore.selectedItemsPattern.TopicList.selectedName
                }
                menuStyle={{ border: "1px solid #E3E9EE" }}
              />
            </div>
            <div className="col-xl-2 col-lg-2 col-md-6 col-sm-12">
              <InputLabel>Sub topic</InputLabel>
              <CustomDropdown
                height="48px"
                menu={PatternStore?.SubTopicList}
                customClass="form-dropdown"
                placeholder="Select Sub topic"
                handlefunc={getDataForMockTest}
                selectedEntity={
                  PatternStore.selectedItemsPattern.SubTopicList.selectedName
                }
                menuStyle={{ border: "1px solid #E3E9EE" }}
              />
            </div>

            <div className="col-xl-2 col-lg-2  col-md-6 col-sm-12">
              <InputLabel>Select Section</InputLabel>
              <CustomDropdown
                height="48px"
                menu={PatternStore?.SectionList}
                customClass="form-dropdown"
                placeholder="Select Section"
                handlefunc={getDataForMockTest}
                selectedEntity={
                  PatternStore.selectedItemsPattern.SectionList.selectedName
                }
                menuStyle={{ border: "1px solid #E3E9EE" }}
              />
            </div>
            <div className="col-xl-2 col-lg-2 col-md-6 col-sm-12">
              <InputLabel>Question Type</InputLabel>
              <CustomDropdown
                height="48px"
                menu={questionType}
                customClass="form-dropdown"
                placeholder="Select Question Type"
                handlefunc={getDataForMockTest}
                selectedEntity={
                  QuestionStore.selectedItemsNw.questionType.selectedName
                }
                menuStyle={{ border: "1px solid #E3E9EE" }}
              />
            </div>
            <div className="col-xl-2 col-lg-2 col-md-6 col-sm-12 d-flex justify-content-end">
              <Button
                title="Apply"
                width="114px"
                height="48px"
                marginTop="28px"
                func={getQuestionsDetails}
              />
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default observer(ManualMockTestCard);
