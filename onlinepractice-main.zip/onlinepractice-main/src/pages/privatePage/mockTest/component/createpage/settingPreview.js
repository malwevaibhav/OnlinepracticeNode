import React, { useState } from "react";
import MockTestStore from "../../../../../MobX/MockTestStore";
import { DataNotFound2 } from "../../../../../assets/svgs/svg";
import {
  BoldHeading,
  NormalHeading,
} from "../../../../../customcomponents/DynamicText/Heading";
import Button from "../../../../../customcomponents/button/Button";
import { InputLabel } from "../../../../../customcomponents/customTextInput/indexCss";
import { ThemeColors } from "../../../../../theme/theme";
import "./mocktestDetails.css";

const SettingPreview = ({
  mockTest,
  updateState,
  submitFunc,
  language,
  setType,
  Id,
  
}) => {
  const [lange, setLange] = useState({
    primary: "english",
    secondary: MockTestStore?.mocktest?.secondaryLanguage
  });

  const selectL = (languageSec) => {
     //console.log(" languageSec:", languageSec)
    setLange({ ...lange, secondary: languageSec?.toLowerCase() })
    MockTestStore?.setSecondaryLanguage(languageSec);
    updateState({
      secondaryLanguage: languageSec
    });
    MockTestStore?.setLanglength(Object.keys(lange).length);
    // console.log("lange===============>", Object.keys(lange).length);
  };

   
   

  const isValidNewOption = (inputValue, selectValue) =>
    inputValue.length > 0 && selectValue.length < 2;
  // console.log("PatternStore.selectedItemsPattern.Language", language);
  return (
    <div>
      <div
        className="card rounded-0 border-0 p-3"
        style={{
          backgroundColor: mockTest?.showPreview
            ? ThemeColors.lightBlue
            : ThemeColors.white,
        }}
      >
        <BoldHeading text="Setting Preview" />
        <hr style={{ marginTop: "20px" }} />
        {!mockTest?.showPreview ? (
          <div className="SettingPreviewContainer">
            <DataNotFound2 />
          </div>
        ) : (
          <div className="row m-0 gap-3 mt-3">
            {mockTest?.mockTestName && (
              <div>
                <NormalHeading text="Test Name" />
                <div>{mockTest?.mockTestName}</div>
              </div>
            )}

            {mockTest?.description && (
              <div>
                <NormalHeading text="Description" />
                <div>{mockTest?.description}</div>
              </div>
            )}

            {(mockTest?.timeDurationHours ||
              mockTest?.timeDurationMinutes > 0) && (
                <div>
                  <NormalHeading text="Time Duration" />
                  <div>
                    <div className="f-row gap5">
                      {mockTest?.timeDurationHours > 0 &&
                        ` ${mockTest?.timeDurationHours} Hrs`}
                      <div>{mockTest?.timeDurationMinutes} Mins</div>
                    </div>
                  </div>
                </div>
              )}

            {mockTest?.testAvailability && (
              <div>
                <NormalHeading text="Test Availability" />
                <div>
                  {mockTest?.testAvailability === 2 ? "Always" : "Specific"}
                </div>
                <div>{mockTest?.always}</div>
              </div>
            )}

            <div className="d-flex gap-4">
              <div>
                <NormalHeading text="Allow Reattempts" />
                {mockTest?.isAllowReattempts ? "Yes" : "No"}
              </div>
              {mockTest?.isAllowReattempts && (
                <div>
                  <NormalHeading text="How Many" />
                  {mockTest?.isUnlimitedAttempts
                    ? "Unlimited"
                    : mockTest?.totalAttempts}
                </div>
              )}
            </div>

            <div className="d-flex gap-4">
              <div>
                <NormalHeading text="Allow Test Resume" />
                {mockTest?.isTestResume ? "Yes" : "No"}
              </div>
              {/* {mockTest?.isTestResume && (
                <div>
                  <NormalHeading text="How Many" />
                  {mockTest?.isUnlimitedResume
                    ? "Unlimited"
                    : mockTest?.totalResume}
                </div>
              )} */}
            </div>

            {/* {(mockTest?.backButton) && (
              <div>
                <NormalHeading text="Back Button/ Previous Question" />
                <div>
                  {mockTest?.backButton === 1 ? "Allowed" : "Not-allowed"}
                </div>
              </div>
            )} */}

            {(mockTest?.isMarksResultFormat ||
              mockTest?.isPassFailResultFormat ||
              mockTest?.isRankResultFormat) && (
                <div>
                  <NormalHeading text="Result Format" />
                  <div>{mockTest?.isMarksResultFormat && "Marks"}</div>
                  <div>{mockTest?.isPassFailResultFormat && "Pass/Fail"}</div>
                  <div>{mockTest?.isRankResultFormat && "Rank"}</div>
                </div>
              )}

            {mockTest?.resultDeclaration && (
              <div>
                <NormalHeading text="Result Declaration" />
                <div>
                  {mockTest?.resultDeclaration === 1
                    ? "Show Result After Each Question​"
                    : "Immediately After Test Completion"}
                </div>
              </div>
            )}

            {mockTest?.isShowCorrectAnswer === true && (
              <div>
                <NormalHeading text="Show Correct Answers" />
                <div>{"Yes"}</div>
              </div>
            )}

            {mockTest?.isShowCorrectAnswer === false && (
              <div>
                <NormalHeading text="Show Correct Answers" />
                <div>{"No"}</div>
              </div>
            )}
          </div>
        )}
      </div>

      <div className="card rounded-0 border-0 mt-3 p-3">
        <div>
          <InputLabel>Select Mock Test Type</InputLabel>
          <div className="d-flex gap-4 mt-2">
            <div className="d-flex align-items-center gap-3">
              <input
                value={1}
                checked={mockTest?.mockTestType === 1}
                onChange={(e) => {
                  updateState({ mockTestType: 1 });
                  setType(1);
                }}
                type="radio"
                id="manual"
                disabled={Id && true}
              />{" "}
              <InputLabel htmlFor="manual"> Manual Mock Test</InputLabel>
            </div>
            <div className="d-flex align-items-center gap-3">
              <input
                id="auto"
                type="radio"
                value={2}
                checked={mockTest?.mockTestType === 2}
                onChange={(e) => {
                  updateState({ mockTestType: 2 });
                  setType(2);
                }}
                disabled={Id && true}
              />
              <InputLabel htmlFor="auto">Automatic Mock test</InputLabel>
            </div>
          </div>
        </div>
      </div>
      <div className="card rounded-0 border-0 p-3 mt-3">
        <InputLabel>Select Language (Any two)</InputLabel>
        <div className="row m-0 mt-3">
          <div className="col-xl-5 col-lg-5 col-md-5 col-sm-6 ps-0">
            <div className="d-flex gap-3 ">

              <div className="d-flex gap-2" >
                <button
                  className="langButn"
                  style={{
                    background: "#ffff",
                    border: "1px solid #0075FF",
                    borderRadius: "5PX",
                    padding: "5px",
                    color: '#0075FF'
                  }}
                  isValidNewOption={isValidNewOption}
                  value={language[0]?.label}

                >

                  {language[0]?.label}
                </button>
              </div>
              {language?.map((lang, id) => (

                <>{lang?.label?.toLowerCase() !== "english" && <div className="d-flex gap-2" >
                  <button
                    className={` ${MockTestStore?.mocktest?.secondaryLanguage.toLowerCase() === lang?.Title?.toLowerCase() || lange?.secondary === lang?.Title?.toLowerCase() ? "langActive" : ""}`}

                    style={{

                      border: "1px solid #3A3951",
                      borderRadius: "5PX",
                      padding: "5px",
                    }}
                    isValidNewOption={isValidNewOption}

                    onClick={() => {
                      selectL(lang?.label)

                    }}
                  >

                    {lang?.Title}
                  </button>
                </div>}</>
              ))}

            </div>
            {/* <CustomDropdown
              menu={language}
              customClass="form-dropdown"
              menuStyle={{ border: "1px solid #E5E5E5" }}
              selectedEntity={
                PatternStore.selectedItemsPattern.Language.selectedName
              }
              handlefunc={selectLanguage}
            /> */}
          </div>
        </div>
      </div>
      <div className="Settingbtn mt-25">
        <Button title="Continue" width="137px" func={submitFunc} />
      </div>
    </div>
  );
};
export default SettingPreview;


