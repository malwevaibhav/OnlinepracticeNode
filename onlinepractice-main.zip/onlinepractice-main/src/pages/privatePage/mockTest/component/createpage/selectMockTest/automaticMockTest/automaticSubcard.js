import { observer } from "mobx-react-lite";
import React, { useEffect, useState } from "react";
import { InputLabel } from "../../../../../../../customcomponents/customTextInput/indexCss";
import CustomDropdown from "../../../../../../../customcomponents/custom_Dropdown/CustomDropdown";
import MockTestStore from "../../../../../../../MobX/MockTestStore";
import PatternStore from "../../../../../../../MobX/Pattern";
import QuestionTypeServices from "../../../../../../../Services/QuestionTypeService";

const AutomaticSubcard = observer(
  ({ setautomock, automock, data, sectionId, sectionName }) => {
    const [questionType, setQuestionType] = useState([]);
    const [selectQType, setselectQType] = useState("");

    /* eslint-disable */
    useEffect(() => {
      getAllQuesType();
      //isQtypeseleted && setselectQType("")
    }, []);

    const getAllQuesType = async () => {
      const resData = await QuestionTypeServices.getAllQuestionType();
      let queType = resData?.map((elm) => {
        return {
          id: elm?.value,
          Title: elm?.name,
          label: "QuestionType",
        };
      });
      setQuestionType(queType);
    };

    const getDataForMockTest = async (props, entityName) => {
      PatternStore.setSelectedItemsPattern({
        selectedName: "QuestionType",
        props,
        entityName,
      });
      setselectQType(props?.Title);
      let questsectionDetail = data?.subSection.filter(
        (e) => e.id === sectionId
      );
      let automaticMockArr;
      let newarr;

      if (automock.automaticMockTestQuestionsList.length > 0) {
        const exists1 =
          automock.automaticMockTestQuestionsList(
            (element) => element.subjectId === data.subjectId
          ) > -1;
        if (exists1) {
          automock?.automaticMockTestQuestionsList.map((elm, index) => {
            newarr = {
              subjectId: data?.subjectId,
              sectionDetailss: {
                sectionId: sectionId,
                sectionName: sectionName,
                questionType: props?.id,
              },
            };
            if (elm?.subjectId === data?.subjectId) {
              automock?.automaticMockTestQuestionsList[
                index
              ].sectionDetailss.map((element) => {
                if (element?.sectionId !== sectionId) {
                  automock?.automaticMockTestQuestionsList[
                    index
                  ].sectionDetailss.push(newarr?.sectionDetailss);
                }
              });
            }
          });
        } else {
          newarr = {
            subjectId: data?.subjectId,
            sectionDetailss: [
              {
                sectionId: sectionId,
                sectionName: sectionName,
                questionType: props?.id,
              },
            ],
          };
          automock?.automaticMockTestQuestionsList.push(newarr);
        }
      } else {
        automaticMockArr = {
          subjectId: data?.subjectId,
          sectionDetailss: [
            {
              sectionId: questsectionDetail[0]?.id,
              sectionName: questsectionDetail[0]?.sectionName,
              questionType: props?.id,
            },
          ],
        };
        automock?.automaticMockTestQuestionsList.push(automaticMockArr);
      }
      MockTestStore?.setgenerateMocktest(automock);
    };

    return (
      <div className="col-xl-12 col-lg-12 col-md-6 col-sm-12">
        <InputLabel>Question Type</InputLabel>
        <CustomDropdown
          height="48px"
          menu={questionType}
          handlefunc={getDataForMockTest}
          customClass="form-dropdown"
          placeholder="Select Question Type"
          selectedEntity={selectQType}
          menuStyle={{ border: "1px solid #E3E9EE" }}
        />
      </div>
    );
  }
);
export default AutomaticSubcard;
