import { toJS } from "mobx";
import { observer } from "mobx-react-lite";
import React, { useEffect, useLayoutEffect, useState } from "react";
import Button from "../../../../../../../customcomponents/button/Button";
import { InputLabel } from "../../../../../../../customcomponents/customTextInput/indexCss";
import CustomDropdown from "../../../../../../../customcomponents/custom_Dropdown/CustomDropdown";
import CourseStore from "../../../../../../../MobX/Courses";
import MockTestStore from "../../../../../../../MobX/MockTestStore";
import PatternStore from "../../../../../../../MobX/Pattern";
import QuestionStore from "../../../../../../../MobX/Question";
import CourseServices from "../../../../../../../Services/CourseService";
import PatternServices from "../../../../../../../Services/patternService";
import QuestionTypeServices from "../../../../../../../Services/QuestionTypeService";
import { checkDefault } from "../../../../../../../utils/helper";
const AutomaticMocktestCard = ({ setPattern, setautomatic, setlevelId }) => {
  const [examPatterns, setExamPatterns] = useState([]);
  const [level, setLevel] = useState([]);

  /* eslint-disable */
  useEffect(() => {
    getAllPattern();
    getAllLevel();
  }, []);

  useLayoutEffect(() => {
    CourseServices?.getCourseFilterData({ label: "Exam" });
  }, []);
  
  const examList = toJS(CourseStore?.examList);
  const courseList = toJS(CourseStore?.course);
  const subcourseList = toJS(CourseStore?.subcourse);

  const getAllPattern = async () => {
    const res = await PatternServices.getAllPattern({
      pageNumber: 0,
      pageSize: 0,
    });
    let patternData = res?.examPatterns?.map((elm) => {
      return {
        id: elm?.id,
        Title: elm?.examPatternName,
        label: "Pattern",
      };
    });
    setExamPatterns(patternData);
    // getPatternDetail(!PatternStore.selectedItemsPattern.pattern.id? patternData[0]?.id : PatternStore.selectedItemsPattern.pattern.id)
  };

  const getAllLevel = async () => {
    const res = await QuestionTypeServices.getAllLevel();
    let level = res?.data?.map((elm) => {
      return {
        id: elm?.value,
        Title: elm?.name,
        label: "Level",
      };
    });
    setLevel(level);
    setlevelId(level[0]?.id);
  };

  const getDataForMockTest = async (props, entityName) => {
    if (props?.label === "Course") {
      CourseStore.setSubCourse([]);
      QuestionStore.setSelectedItemsNw({
        selectedName: "Exam",
        props,
        entityName,
      });
      MockTestStore.setMocktestIDs({ examTypeId: props.id });
      PatternStore.setSelectedItemsPattern({
        selectedName: "Pattern",
        props: {},
        entityName: "",
      });
    }
    if (props?.label === "SubCourse") {
      CourseStore.setSubCourse([]);
      QuestionStore.setSelectedItemsNw({
        selectedName: "Course",
        props,
        entityName,
      });
      MockTestStore.setMocktestIDs({ courseId: props.id });
    }
    if (props?.label === "Subject") {
      QuestionStore.setSelectedItemsNw({
        selectedName: "SubCourse",
        props,
        entityName,
      });
      MockTestStore.setMocktestIDs({ subCourseId: props.id });
    }
    if (props?.label === "Level") {
      QuestionStore.setSelectedItemsNw({
        selectedName: "Level",
        props,
        entityName,
      });
      //  MockTestStore.setMocktestIDs({ subCourseId: props.id })
    }

    if (props?.label === "Pattern") {
      PatternStore.setSelectedItemsPattern({
        selectedName: "Pattern",
        props,
        entityName,
      });
      MockTestStore.setMocktestIDs({ examPatternId: props.id });
      // getPatternDetail(props.id)
    }
    return CourseServices?.getCourseFilterData(props);
  };

  const mocktestapply = async (e) => {
    checkDefault(e);
    const res = await PatternServices.getPatternById({
      id: PatternStore.selectedItemsPattern.pattern.id,
    });
    if (res.isSuccess) {
      let temp = 0;
      res?.data?.section.map((x) => {
        if (x.subSection.length > temp) {
          temp = x?.subSection.length;
        }
      });
      setPattern(res.data);
      setautomatic(true);
      setlevelId(QuestionStore.selectedItemsNw.level.id);
    }
  };
  return (
    <div className="card rounded-0 border-0 p-4 ps-2">
      <form className="card px-3 border-0 ">
        <div className="row mt-0  gy-3">
          <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
            <InputLabel>Exam Type</InputLabel>
            <CustomDropdown
              height="48px"
              menu={examList}
              customClass="form-dropdown"
              placeholder="Select Exam"
              handlefunc={getDataForMockTest}
              menuStyle={{ border: "1px solid #E3E9EE" }}
              selectedEntity={
                QuestionStore.selectedItemsNw.examList.selectedName
              }
            />
          </div>
          <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
            <InputLabel>Course</InputLabel>
            <CustomDropdown
              height="48px"
              menu={courseList}
              customClass="form-dropdown"
              placeholder="Select Course"
              menuStyle={{ border: "1px solid #E3E9EE" }}
              handlefunc={getDataForMockTest}
              selectedEntity={
                QuestionStore.selectedItemsNw.courseList.selectedName
              }
            />
          </div>
          <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
            <InputLabel>Sub-course</InputLabel>
            <CustomDropdown
              height="48px"
              menu={subcourseList}
              customClass="form-dropdown"
              placeholder="Select SubCourse"
              handlefunc={getDataForMockTest}
              selectedEntity={
                QuestionStore.selectedItemsNw.SubCourseList.selectedName
              }
              menuStyle={{ border: "1px solid #E3E9EE" }}
            />
          </div>
          <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
            <InputLabel>Exam Pattern</InputLabel>
            <CustomDropdown
              menu={examPatterns}
              height="48px"
              customClass="form-dropdown"
              placeholder="Select Pattern"
              handlefunc={getDataForMockTest}
              menuStyle={{ border: "1px solid #E3E9EE" }}
              selectedEntity={
                PatternStore.selectedItemsPattern.pattern.selectedName
              }
            />
          </div>
          <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
            <InputLabel>Difficulty Level</InputLabel>
            <div className="mt-1">
              <CustomDropdown
                menu={level}
                customClass="form-dropdown"
                placeholder="Select Level"
                name1="instituteId"
                name="institute"
                menuStyle={{ border: "1px solid #E3E9EE" }}
                handlefunc={getDataForMockTest}
                selectedEntity={
                  QuestionStore.selectedItemsNw.level.selectedName
                }
              />
            </div>
          </div>
          <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12 ">
            <Button
              title="Apply"
              width="114px"
              height="48px"
              marginTop="34px"
              func={(e) => {
                mocktestapply(e);
              }}
              disable={!PatternStore.selectedItemsPattern.pattern.selectedName}
            />
          </div>
        </div>
      </form>
    </div>
  );
};
export default observer(AutomaticMocktestCard);
