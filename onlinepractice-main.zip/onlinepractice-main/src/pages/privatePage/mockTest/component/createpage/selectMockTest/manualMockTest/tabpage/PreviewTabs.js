import React, { useEffect, useLayoutEffect, useState } from "react";
import { InputLabel } from "../../../../../../../../customcomponents/customTextInput/indexCss";
import CustomDropdown from "../../../../../../../../customcomponents/custom_Dropdown/CustomDropdown";
import {
  BoldHeading,
  NormalHeading,
  TitleHeading,
} from "../../../../../../../../customcomponents/DynamicText/Heading";
import PatternStore from "../../../../../../../../MobX/Pattern";
import QuestionTypeServices from "../../../../../../../../Services/QuestionTypeService";
import { ThemeColors } from "../../../../../../../../theme/theme";
import "../../../selectMockTest/selectmocktest.css";
import { Content, Tab, Tabs } from "./tabpagecss";
const tabStyle = {
  borderRadius: "5px 5px 0 0",
  height: "50px",
  width: "120px",
  minWidth: "fit-content",
};
function PreviewTabs({ mockTestQuestions, generalInst }) {
  const [active, setActive] = useState(1);
  const [activeLang, setActiveLang] = useState(
    PatternStore.selectedItemsPattern.Language.selectedName.toLowerCase()
  );
  const [totalQM, settotalQM] = useState({ questions: 0, marks: 0 });
  const [language, setLanguage] = useState([]);
  const [selectedItems, setSelectedItems] = useState({
    language: { selectedName: "", id: "" },
  });

  /* eslint-disable */
  useLayoutEffect(() => {
    getAllLanguage();
  }, []);
  useEffect(() => {
    let mark = 0;
    let question = 0;
    mockTestQuestions &&
      mockTestQuestions.map((data) => {
        question += data.totalQuestions;
        return data.sectionDetails.map((obj) => {
          return obj.mockTestQuestions.map((subObj) => {
            return (mark += subObj?.mark);
          });
        });
      });
    settotalQM({ ...totalQM, questions: question, marks: mark });
  }, [mockTestQuestions]);

  const getAllLanguage = async () => {
    const res = await QuestionTypeServices.getAllLanguage();
    if (res?.isSuccess) {
      if (res?.data) {
        let lang = res?.data.map((item) => {
          return {
            id: item?.value,
            Title: item?.name,
          };
        });
        setLanguage(lang);
      }
    }
  };

  const getLanguageID = async (props) => {
    PatternStore.setSelectedItemsPattern({
      selectedName: "Language",
      entityName: props?.Title,
      props: props,
    });
    setSelectedItems({
      ...selectedItems,
      language: { selectedName: props?.Title, id: props?.id },
    });
    setActiveLang(props.Title.toLowerCase());
  };

  return (
    <div className="position-relative">
      <Tabs>
        <Tab
          onClick={() => setActive(1)}
          active={active === 1}
          id={1}
          style={tabStyle}
        >
          <div className="total_Text">
            <TitleHeading text={"Mocktest Preview"} />
          </div>
          <div className="half_text">
            <TitleHeading text={"Mocktest"} />
          </div>
        </Tab>
        <Tab
          onClick={() => setActive(2)}
          active={active === 2}
          id={2}
          style={tabStyle}
        >
          <div className="total_Text">
            <TitleHeading text={"General Instructions"} />
          </div>
          <div className="half_text">
            <TitleHeading text={"Instructions"} />
          </div>
        </Tab>
      </Tabs>

      <div
        className="position-absolute d-flex gap-2 "
        style={{ right: "0", top: "5px", minWidth: "27%" }}
      >
        <InputLabel style={{ paddingTop: "8px", color: ThemeColors.primary }}>
          Total Questions : {totalQM?.questions}{" "}
        </InputLabel>
        <InputLabel style={{ paddingTop: "8px", color: ThemeColors.primary }}>
          {" "}
          Total Marks : {totalQM?.marks}
        </InputLabel>
      
        {/* <InputLabel style={{ paddingTop: "8px", color: ThemeColors.primary }}>
          {" "}
          Language:    
        </InputLabel> */}
        <small style={{ color: ThemeColors.secondary ,marginTop:'4px'}}>Language:</small>
        <CustomDropdown
            customClass="QuestionIdDropDown"
            placeholder={
              PatternStore.selectedItemsPattern.Language.selectedName
            }
            isSelect={true}
            menu={language}
            menuStyle={{ padding: 0, paddingLeft: "5px !important;" }}
            handlefunc={getLanguageID}
            selectedEntity={selectedItems?.language?.selectedName}
          />
       
      </div>
      <Content active={active === 1}>
        {mockTestQuestions &&
          mockTestQuestions.map((data, i) => {
            return (
              <>
                <div className="card rounded-0 border-0 p-2">
                  <div className="row m-0 d-flex text-center pt-2">
                    <BoldHeading text={data?.subjectName} />
                  </div>
                </div>
                {data.sectionDetails.map((obj, j) => {
                  return (
                    <>
                      <div className="card rounded-0 border-0 p-2" key={j}>
                        <div className="row m-0 d-flex text-center">
                          <NormalHeading text={obj?.sectionName} />
                        </div>
                      </div>
                      {obj.mockTestQuestions.map((subObj, k) => {
                        return (
                          <>
                            <div className="card rounded-0 border-0 border-bottom p-2">
                              <div className="row m-0" key={i}>
                                <div
                                  className="d-flex"
                                  style={{
                                    fontSize: "16px",
                                    fontWeight: "400",
                                  }}
                                >
                                  {`${k + 1})`}
                                  <p
                                    className="ps-1 m-0 p-0"
                                    dangerouslySetInnerHTML={{
                                      __html:
                                        subObj?.questionTableData[activeLang]
                                          ?.questionText,
                                    }}
                                  />
                                </div>
                                {subObj?.questionType === 3 ? (
                                  <div className="p-5"></div>
                                ) : (
                                  <>
                                    <div
                                      className="d-flex"
                                      style={{
                                        fontSize: "16px",
                                        fontWeight: "400",
                                      }}
                                    >
                                      {"A) "}
                                      <p
                                        className="ps-1 m-0 p-0"
                                        dangerouslySetInnerHTML={{
                                          __html:
                                            subObj?.questionTableData[
                                              activeLang
                                            ]?.optionA,
                                        }}
                                      />
                                    </div>
                                    <div
                                      className="d-flex"
                                      style={{
                                        fontSize: "16px",
                                        fontWeight: "400",
                                      }}
                                    >
                                      {"B) "}
                                      <p
                                        className="ps-1 m-0 p-0"
                                        dangerouslySetInnerHTML={{
                                          __html:
                                            subObj?.questionTableData[
                                              activeLang
                                            ]?.optionB,
                                        }}
                                      />
                                    </div>
                                    <div
                                      className="d-flex"
                                      style={{
                                        fontSize: "16px",
                                        fontWeight: "400",
                                      }}
                                    >
                                      {"C) "}
                                      <p
                                        className="ps-1 m-0 p-0"
                                        dangerouslySetInnerHTML={{
                                          __html:
                                            subObj?.questionTableData[
                                              activeLang
                                            ]?.optionC,
                                        }}
                                      />
                                    </div>
                                    <div
                                      className="d-flex"
                                      style={{
                                        fontSize: "16px",
                                        fontWeight: "400",
                                      }}
                                    >
                                      {"D) "}
                                      <p
                                        className="ps-1 m-0 p-0"
                                        dangerouslySetInnerHTML={{
                                          __html:
                                            subObj?.questionTableData[
                                              activeLang
                                            ]?.optionD,
                                        }}
                                      />
                                    </div>
                                  </>
                                )}
                                <label
                                  className="pb-2"
                                  sstyle={{
                                    fontSize: "16px",
                                    fontWeight: "400",
                                  }}
                                >
                                  Marks -{subObj?.mark}
                                </label>
                              </div>
                            </div>
                          </>
                        );
                      })}
                    </>
                  );
                })}
              </>
            );
          })}
      </Content>
      <Content active={active === 2}>
        <div className="card border-0 rounded-0 p-4">
          <p
            className="ps-1 m-0 p-0"
            dangerouslySetInnerHTML={{
              __html:generalInst
            }}
          />
        </div>
      </Content>
    </div>
  );
}

export default PreviewTabs;
