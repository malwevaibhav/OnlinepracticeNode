import React, { useState } from "react";
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";
import Button from "../../../../../../../customcomponents/button/Button";
import { CardSubHeading } from "../../../../../../../customcomponents/DynamicText/Heading";
import MockTestStore from "../../../../../../../MobX/MockTestStore";
import PatternStore from "../../../../../../../MobX/Pattern";
import MocktestServices from "../../../../../../../Services/MockTestService";
import "../selectmocktest.css";
import AutomaticMocktestCard from "./automaticMocktestCard";
import AutomaticSubcard from "./automaticSubcard";
import { ClientRoutesConstants } from "../../../../../../../shared/constant";

const AutonaticMockTestPage = ({ Id, setPublish }) => {
  const navigate = useNavigate();
  const [isautomatic, setautomatic] = useState(false);
  const [automaticData, setautomaticData] = useState([]);
  const [automock, setautomock] = useState({
    mockTestSettingId: Id ? Id : localStorage.step1Res,
    examTypeId: "",
    courseId: "",
    subCourseId: "",
    examPatternId: "",
    questionLevel: "",
    language: "",
    automaticMockTestQuestionsList: [],
  });
  const setPattern = (props) => {
    setautomaticData(props?.section);
  };
  const setlevelId = (props) => {
    setautomock({
      ...automock,
      questionLevel: props,
      examTypeId: MockTestStore.mocktestIDs.examTypeId,
      courseId: MockTestStore.mocktestIDs.courseId,
      subCourseId: MockTestStore.mocktestIDs.subCourseId,
      examPatternId: MockTestStore.mocktestIDs.examPatternId,
      language: PatternStore.selectedItemsPattern.Language.selectedName,
    });
  };

  const generateAutomock = async () => {
    const res = await MocktestServices?.generateAutoMockTest(
      MockTestStore.generateMocktest
    );
    if (res?.isSuccess) {
      localStorage.setItem("step1Res", res?.data?.mockTestSettingId);
      MockTestStore?.setCurrentStep({ step: 3, from: 2 });
      setPublish(true);
    } else {
      toast.error(res?.messages);
      navigate(ClientRoutesConstants?.mocktest);
    }
  };
  return (
    <div>
      <AutomaticMocktestCard
        setPattern={setPattern}
        setautomatic={setautomatic}
        setlevelId={setlevelId}
      />
      {isautomatic && (
        <>
          <div className="mt-3 mb-3">
            <CardSubHeading text="Section Setting" />
          </div>
          {automaticData &&
            automaticData.map((data, i) => {
              return (
                <div className="card rounded-0 p-3 mt-3" key={i}>
                  <div className="f-between ">
                    <div>{data?.subjectName}</div>
                    <div>Total Question : {data?.totalSectionQuestions}</div>
                  </div>
                  <hr />
                  <div className="row">
                    <div className="row">
                      {data?.subSection &&
                        data?.subSection.map((elm, j) => {
                          return (
                            <div className="col-xl-4 col-lg-4" key={j}>
                              <div className="sectionHeading">
                                {elm?.sectionName}
                              </div>
                              <div
                                className="rounded-0 card py-3 p-3"
                                style={{
                                  background: "#ECF5FF",
                                  border: "1px solid #E3E9EE",
                                }}
                              >
                                <AutomaticSubcard
                                  setautomock={setautomock}
                                  automock={automock}
                                  data={data}
                                  sectionId={elm?.id}
                                  sectionName={elm?.sectionName}
                                />
                              </div>
                            </div>
                          );
                        })}
                    </div>
                  </div>
                </div>
              );
            })}
          <div className="row mt-3 pull-right ms-1">
            <Button title="Generate" width="137px" func={generateAutomock} />
          </div>
        </>
      )}
    </div>
  );
};

export default AutonaticMockTestPage;
