import { toJS } from "mobx";
import { observer } from "mobx-react-lite";
import React, { useEffect, useState } from "react";
import { toast } from "react-toastify";
import {
  DataNotFound2,
  DownArrowIcon,
  GreenDownArrowIcon,
} from "../../../../../../../assets/svgs/svg";
import Button from "../../../../../../../customcomponents/button/Button";
import { InputLabel } from "../../../../../../../customcomponents/customTextInput/indexCss";
import Pagination from "../../../../../../../customcomponents/pagination/Pagination";
import MockTestStore from "../../../../../../../MobX/MockTestStore";
import PatternStore from "../../../../../../../MobX/Pattern";
import QuestionStore from "../../../../../../../MobX/Question";
import MocktestServices from "../../../../../../../Services/MockTestService";
import { ThemeColors } from "../../../../../../../theme/theme";
import QuestionSet from "../../../QuestionSet";
import Accordion from "../../accordian";
import "../selectmocktest.css";
import ManualMockTestCard from "./manualMockTestCard";

const ManualMockTestPage = ({ Id, setPublish }) => {
  const [queData, setQueData] = useState({});
  const [toggle, setToggle] = useState(false);
  const [explaination, setExplaination] = useState("");
  const [option, setOption] = useState("");
  const [patternLength, setPatternLength] = useState();
  const [pageNoSize, setPageNoSize] = useState({ no: 1, size: 10 });
  const languageSelected =
    PatternStore?.selectedItemsPattern?.Language?.selectedName.toLowerCase();

  /* eslint-disable */
  useEffect(() => {
    // if (Id && (MockTestStore.currentStep.from === 1)) {
    if (Id || localStorage.step1Res) {
      mockTestQuestionById(Id || localStorage.step1Res);
    }
    if (
      PatternStore.selectedItemsPattern.SubjectList.id &&
      PatternStore.selectedItemsPattern.TopicList.id &&
      PatternStore.selectedItemsPattern.SubTopicList.id &&
      // QuestionStore.selectedItemsNw.SubCourseList.id &&
      QuestionStore.selectedItemsNw.questionType.id
    ) {
      getQuestionFilter();
    }
    if (
      MockTestStore.currentStep.from === 3 &&
      MockTestStore.currentStep.step === 2
    ) {
      setPublish(false);
    }
  }, []);

  const mockTestQuestionById = async (Id) => {
    const resData = await MocktestServices.mockTestQuestionById({
      mockTestSettingId: Id,
    });
    if (resData?.isSuccess) {
      let ids = {
        courseId: resData?.data?.courseId,
        mocktestSettingId: resData?.data?.mockTestSettingId,
        examTypeId: resData?.data?.examTypeId,
        subCourseId: resData?.data?.subCourseId,
        examPatternId: resData?.data?.examPatternId,
        subjectId:
          MockTestStore.currentStep.from === 1
            ? resData?.data?.subjectId
            : PatternStore.selectedItemsPattern.SubjectList.id,
        topicId:
          MockTestStore.currentStep.from === 1
            ? resData?.data?.topicId
            : PatternStore.selectedItemsPattern.TopicList.id,
        subTopicId:
          MockTestStore.currentStep.from === 1
            ? resData?.data?.subTopicId
            : PatternStore.selectedItemsPattern.SubTopicList.id,
        sectionId:
          MockTestStore.currentStep.from === 1
            ? resData?.data?.sectionId
            : PatternStore.selectedItemsPattern.SectionList.id,
        questionType:
          MockTestStore.currentStep.from === 1
            ? resData?.data?.questionType
            : QuestionStore.selectedItemsNw.questionType.id,
        isDraft: true,
      };
      MockTestStore.setMocktestIDs(ids);
      QuestionStore.selectedItemsNw.SubCourseList.id =
        resData?.data?.subCourseId;
      if (MockTestStore.currentStep.from === 1) {
        MockTestStore.setMockTestArray(resData.data);

        PatternStore.selectedItemsPattern.SubjectList.id =
          resData?.data?.subjectId;
        PatternStore.selectedItemsPattern.pattern.id =
          resData?.data?.examPatternId;
        QuestionStore.selectedItemsNw.courseList.id = resData?.data?.courseId;
        QuestionStore.selectedItemsNw.examList.id = resData?.data?.examTypeId;
        PatternStore.selectedItemsPattern.TopicList.id = resData?.data?.topicId;
        PatternStore.selectedItemsPattern.SubTopicList.id =
          resData?.data?.subTopicId;
        PatternStore.selectedItemsPattern.SectionList.id =
          resData?.data?.sectionId;
        QuestionStore.selectedItemsNw.questionType.id =
          resData?.data?.questionType;
      }

      let subjectRes = await MocktestServices.getSubjectByPatternId(
        resData?.data?.examPatternId
      );
      subjectRes?.examPatternSubjects.map((sub) => {
        if (ids?.subjectId === sub.subjectId) {
          PatternStore.setSelectedItemsPattern({
            selectedName: "SubjectPattern",
            props: {
              id: sub.subjectId,
              Title: sub.subjectName,
              label: "SubjectPattern",
            },
            entityName: sub.subjectName,
          });
        }
      });

      // QuestionStore.selectedItemsNw.SubCourseList.id = resData?.data?.subCourseId
      let topicRes = await MocktestServices.getTopicListbySubjectpattern(
        ids?.subjectId
      );
      topicRes?.topic.map((topic) => {
        if (ids?.topicId === topic.id) {
          PatternStore.setSelectedItemsPattern({
            selectedName: "TopicPattern",
            props: { id: topic.id, Title: topic.topicName },
            entityName: topic.topicName,
          });
        }
      });

      let subTopicRes = await MocktestServices.getSubTopic(ids?.topicId);
      subTopicRes.map((subTopic) => {
        if (ids?.subTopicId === subTopic.id) {
          PatternStore.setSelectedItemsPattern({
            selectedName: "SubTopicPattern",
            props: { id: subTopic.id, Title: subTopic.subTopicName },
            entityName: subTopic.subTopicName,
          });
        }
      });

      let sectionRes = await MocktestServices.getSectionbyPatternId({
        examPatternId: resData?.data?.examPatternId,
        subjectId: ids?.subjectId,
      });
      sectionRes.map((section) => {
        if (ids?.sectionId === section.id) {
          PatternStore.setSelectedItemsPattern({
            selectedName: "SectionList",
            props: { ...section, id: section.id, Title: section.sectionName },
            entityName: section.sectionName,
          });
        }
      });

      QuestionStore?.questionType.map((qType) => {
        if (qType.id === ids?.questionType) {
          QuestionStore.setSelectedItemsNw({
            selectedName: "QuestionType",
            props: qType,
            entityName: qType?.Title,
          });
        }
      });

      getQuestionFilter();
    }
  };

  const optionfunction = (index) => {
    setExplaination("");
    if (option === index) {
      setOption("");
    } else {
      setOption(index);
    }
  };

  const explaFunction = (index) => {
    setOption("");
    if (explaination === index) {
      setExplaination("");
    } else {
      setExplaination(index);
    }
  };

  const AddFunction = (data) => {
    let copyArr = { ...toJS(MockTestStore.mockTestArray) };
    let arrInd = toJS(
      MockTestStore.mockTestArray?.mockTestQuestions?.findIndex(
        (x) => x.subjectId === PatternStore.selectedItemsPattern.SubjectList.id
      )
    );
    let subArrInd = toJS(
      MockTestStore.mockTestArray?.mockTestQuestions[arrInd]
    )?.sectionDetails?.findIndex(
      (x) => x.sectionId === PatternStore.selectedItemsPattern.SectionList.id
    );
    if (!MockTestStore.mockTestArray.mockTestQuestions[arrInd]?.noOfQue) {
      copyArr.mockTestQuestions[arrInd].sectionDetails[
        subArrInd
      ].mockTestQuestions.push({
        questionRefId: data.questionRefId,
        questionType: data.questionType,
        questionLevel: data.questionLevel,
        mark: data.mark,
        negativeMark: data.negativeMark,
      });
    } else if (
      MockTestStore.mockTestArray.mockTestQuestions[arrInd]?.sectionDetails[
        subArrInd
      ]?.totalQuestions >
      MockTestStore.mockTestArray?.mockTestQuestions[arrInd]?.sectionDetails[
        subArrInd
      ]?.mockTestQuestions?.length
    ) {
      copyArr.mockTestQuestions[arrInd].sectionDetails[
        subArrInd
      ].mockTestQuestions.push({
        questionRefId: data.questionRefId,
        questionType: data.questionType,
        questionLevel: data.questionLevel,
        mark: data.mark,
        negativeMark: data.negativeMark,
      });
    } else {
      toast.error(
        `You Exceed max limit of questions in ${PatternStore.selectedItemsPattern.SubjectList.selectedName} subject OR Apply for New Section`
      );
      // toast.error(`You Exceed max limit of questions in ${PatternStore.selectedItemsPattern.SubjectList.selectedName} subject of ${PatternStore.selectedItemsPattern.SectionList.selectedName}`)
    }

    MockTestStore.setMockTestArray(copyArr);
    checkQuesLength(PatternStore.selectedItemsPattern.SubjectList.id);
    setToggle(!toggle);
  };

  const removeFunction = (refId) => {
    let copyArr1 = { ...toJS(MockTestStore.mockTestArray) };
    copyArr1?.mockTestQuestions.map((data, i) => {
      data?.sectionDetails.map((obj, j) => {
        obj?.mockTestQuestions.map((subObj, k) => {
          if (subObj.questionRefId === refId) {
            copyArr1?.mockTestQuestions[i]?.sectionDetails[
              j
            ]?.mockTestQuestions.splice(k, 1);
          }
        });
      });
    });
    MockTestStore.setMockTestArray(copyArr1);
    checkQuesLength(PatternStore.selectedItemsPattern.SubjectList.id);
    setToggle(!toggle);
  };

  const checkQue = (refId) => {
    let arrObj = toJS(
      MockTestStore?.mockTestArray?.mockTestQuestions.find(
        (x) =>
          x.subjectId === PatternStore?.selectedItemsPattern?.SubjectList.id
      )
    );
    let isAdded;
    arrObj?.sectionDetails.map((obj) => {
      obj?.mockTestQuestions.map((subObj) => {
        if (subObj?.questionRefId === refId) {
          isAdded = true;
        }
      });
    });
    return isAdded;
  };

  const getQuestionFilter = async (no = 1, size = 10) => {
    let postData = {
      subCourseId: QuestionStore.selectedItemsNw.SubCourseList.id,
      // subjectId: PatternStore.selectedItemsPattern.SubjectList.id,
      subjectId: PatternStore.selectedItemsPattern.SubjectList.props.id,
      topicId: PatternStore.selectedItemsPattern.TopicList.id,
      subTopicId: PatternStore.selectedItemsPattern.SubTopicList.id,
      questionType: QuestionStore.selectedItemsNw.questionType.id,
      language: languageSelected,
      pageNumber: no,
      pageSize: size,
    };
    const resp = await MocktestServices.getQuestionByFilter(postData);
    if (resp?.isSuccess) {
      setQueData(resp.data);
      setPatternLength(resp.data?.totalRecords);
    } else {
      setQueData(resp.data);
    }
  };

  return (
    <div>
      <ManualMockTestCard
        getQuestionFilter={getQuestionFilter}
        setQueData={setQueData}
        Id={Id}
      />
      <div className="card border-0 mt-3">
        <div className="row m-0 g-0">
          <div className="col-xl-9">
            {queData?.mockTestQuestions ? (
              <>
                <div
                  className="card overflow-auto  border-0"
                  style={{ maxHeight: "800px" }}
                >
                  <div className="mt-3 ps-3 pe-3">
                    {queData?.mockTestQuestions.map((data, index) => (
                      <div key={index}>
                        <div className="f-row-align-between">
                          <InputLabel
                            style={{
                              color: ThemeColors.primary,
                              fontSize: "16px",
                            }}
                          >
                            Question-{index + 1}
                          </InputLabel>
                          <div>
                            <Button
                              title={data?.questionLevel}
                              width="fit-content"
                              height="29px"
                              background={
                                data?.questionLevel === "Hard"
                                  ? ThemeColors.bgHard
                                  : data?.questionLevel === "Medium"
                                  ? ThemeColors.bgMedium
                                  : ThemeColors.bgEasy
                              }
                              textColor={
                                data?.questionLevel === "Hard"
                                  ? ThemeColors.danger
                                  : data?.questionLevel === "Medium"
                                  ? ThemeColors.txtMedium
                                  : ThemeColors.txtEasy
                              }
                              fontSize="14px"
                            />
                          </div>
                        </div>
                        <div className="f-row mt-1">
                          {/* <MathJax> */}
                          <p
                            className="mt-1"
                            dangerouslySetInnerHTML={{
                              __html:
                                data?.questionTableData[languageSelected]
                                  ?.questionText,
                            }}
                          />

                          {/* </MathJax> */}
                        </div>
                        <div className="f-row">
                          <Accordion
                            width="106px"
                            border="1px solid #0075FF"
                            title="Options"
                            background="#ECF5FF"
                            textColor=" #0075FF"
                            fontSize="16px"
                            funct={(d) => {
                              optionfunction(index);
                            }}
                            marginRight="10px"
                            icon={<DownArrowIcon />}
                          ></Accordion>
                          <Accordion
                            width="138px"
                            border="1px solid #30924B"
                            title="Explanation"
                            background="#EAFFF0"
                            textColor="#30924B"
                            funct={(d) => {
                              explaFunction(index);
                            }}
                            icon={<GreenDownArrowIcon />}
                          ></Accordion>
                        </div>

                        {option === index && (
                          <div className=" accordianContent ">
                            <div className="OptionContainer gap10">
                              <div className="mockTestOption">
                                <span>
                                  <input
                                    type="checkbox"
                                    name="option1"
                                    className="optionn"
                                    checked={
                                      data?.questionTableData[languageSelected]
                                        ?.isCorrectA
                                    }
                                  />
                                </span>
                                Option 1
                              </div>
                              {/* <MathJax> */}
                              <span
                                className="mt-1 aligns-items-center"
                                dangerouslySetInnerHTML={{
                                  __html:
                                    data?.questionTableData[languageSelected]
                                      ?.optionA,
                                }}
                              />
                              {/* </MathJax> */}

                              <div className="gap10"> </div>
                            </div>

                            <div className="OptionContainer gap10">
                              <div className="mockTestOption">
                                <span>
                                  <input
                                    type="checkbox"
                                    name="option1"
                                    className="optionn"
                                    checked={
                                      data?.questionTableData[languageSelected]
                                        ?.isCorrectB
                                    }
                                  />
                                </span>
                                Option 2
                              </div>
                              {/* <MathJax> */}
                              <span
                                className="mt-1 aligns-items-center"
                                dangerouslySetInnerHTML={{
                                  __html:
                                    data?.questionTableData[languageSelected]
                                      ?.optionB,
                                }}
                              />
                              {/* </MathJax> */}
                              <div className="gap10"> </div>
                            </div>

                            <div className="OptionContainer gap10">
                              <div className="mockTestOption">
                                <span>
                                  <input
                                    type="checkbox"
                                    name="option1"
                                    className="optionn"
                                    checked={
                                      data?.questionTableData[languageSelected]
                                        ?.isCorrectC
                                    }
                                  />
                                </span>
                                Option 3
                              </div>
                              {/* <MathJax> */}
                              <span
                                className="mt-1 aligns-items-center"
                                dangerouslySetInnerHTML={{
                                  __html:
                                    data?.questionTableData[languageSelected]
                                      ?.optionC,
                                }}
                              />
                              {/* </MathJax> */}
                              <div className="gap10"> </div>
                            </div>

                            <div className="OptionContainer gap10">
                              <div className="mockTestOption">
                                <span>
                                  <input
                                    type="checkbox"
                                    name="option1"
                                    className="optionn"
                                    checked={
                                      data?.questionTableData[languageSelected]
                                        ?.isCorrectD
                                    }
                                  />
                                </span>
                                Option 4
                              </div>
                              {/* <MathJax> */}
                              <span
                                className="mt-1 aligns-items-center"
                                dangerouslySetInnerHTML={{
                                  __html:
                                    data?.questionTableData[languageSelected]
                                      ?.optionD,
                                }}
                              />
                              {/* </MathJax> */}
                              <div className="gap10"> </div>
                            </div>
                          </div>
                        )}

                        {explaination === index && (
                          <div className=" accordianContent">
                            <div className="OptionContainer gap10">
                              <div className="gap10">
                                {/* <MathJax> */}
                                <p
                                  className="ms-3 mt-1"
                                  dangerouslySetInnerHTML={{
                                    __html:
                                      data?.questionTableData[languageSelected]
                                        ?.explanation,
                                  }}
                                />
                                {/* </MathJax> */}
                              </div>
                            </div>
                          </div>
                        )}

                        <hr className="setMarkLine" />
                        <div className="f-row-between ">
                          <div className="f-a-row  gap10">
                            <div className="setMark">Set Marks</div>
                            <div className="MarksFeild">{data?.mark}</div>

                            <div className="setMark">Negative Marks</div>

                            <div className="MarksFeild">
                              {data?.negativeMark}
                            </div>
                          </div>
                          <div>
                            {checkQue(data?.questionRefId) ? (
                              <Button
                                title="Remove"
                                background={ThemeColors.danger}
                                fontSize="14px"
                                width="69px"
                                height="35px"
                                func={() => removeFunction(data?.questionRefId)}
                              />
                            ) : (
                              <Button
                                title="Add"
                                background={ThemeColors.primary}
                                fontSize="14px"
                                width="46px"
                                height="35px"
                                disable={
                                  !data?.questionTableData[languageSelected]
                                    ?.isAvailable
                                }
                                func={() => AddFunction(data)}
                              />
                            )}
                          </div>
                        </div>
                        <hr className="setMarkLine" />
                      </div>
                    ))}
                  </div>
                </div>
              </>
            ) : (
              <div className="card rounded-0 border-0 p-5  mt-3 d-flex align-items-center">
                <DataNotFound2 />
              </div>
            )}
          </div>
          {queData?.mockTestQuestions && (
            <div className="col-xl-3">
              <QuestionSet setPublish={setPublish} />
            </div>
          )}
        </div>
      </div>
      {queData?.mockTestQuestions && (
        <div className="row mt-3">
          <div className="col-9">
            <Pagination
              getFunction={getQuestionFilter}
              totalLength={patternLength}
              setPageNoSize={setPageNoSize}
              pageNoSize={pageNoSize}
              length={queData?.mockTestQuestions?.length}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default observer(ManualMockTestPage);

export const checkQuesLength = (subjectId) => {
  let copyArr1 = { ...toJS(MockTestStore.mockTestArray) };
  let arrInd1 = toJS(
    MockTestStore.mockTestArray?.mockTestQuestions?.findIndex(
      (x) => x.subjectId === subjectId
    )
  );
  let count = 0;
  for (
    let i = 0;
    i < copyArr1.mockTestQuestions[arrInd1].sectionDetails.length;
    i++
  ) {
    count +=
      copyArr1.mockTestQuestions[arrInd1].sectionDetails[i].mockTestQuestions
        .length;
  }
  copyArr1.mockTestQuestions[arrInd1].noOfQue = count;
  copyArr1.mockTestQuestions[arrInd1] = {
    ...copyArr1.mockTestQuestions[arrInd1],
    noOfQue: count,
  };
  MockTestStore.setMockTestArray(copyArr1);
};
