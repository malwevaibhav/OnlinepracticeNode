import React from "react";
import AutonaticMockTestPage from "./selectMockTest/automaticMockTest/autonaticMockTestPage";
import ManualMockTestPage from "./selectMockTest/manualMockTest/manualMockTestPage";
const SecondShep = ({ Id, typeMocktest, setPublish }) => {
  return (
    <div>
      {typeMocktest === 1 ? (
        <div>
          <ManualMockTestPage Id={Id} setPublish={setPublish} />
        </div>
      ) : (
        <div>
          <AutonaticMockTestPage Id={Id} setPublish={setPublish} />
        </div>
      )}
      <div></div>
    </div>
  );
};

export default SecondShep;
