import React, { useEffect, useState } from "react";
import MockTestStore from "../../../../../../../MobX/MockTestStore";
import MocktestServices from "../../../../../../../Services/MockTestService";
import PreviewTabs from "./tabpage/PreviewTabs";
import Tabpage from "./tabpage/tabpage";

const ManualPreviewPage = ({ publish, Id }) => {
  const [mockTestQuestions, setMockTestQuestions] = useState([]);

  /* eslint-disable */
  useEffect(() => {
    if (Id || localStorage.step1Res) {
      mockTestQuestionById(Id);
    }
  }, []);
  const mockTestQuestionById = async (Id) => {
    const resData = await MocktestServices.mockTestQuestionById({
      mockTestSettingId: Id ? Id : localStorage.step1Res,
    });
    if (resData.isSuccess) {
      setMockTestQuestions(resData.data?.mockTestQuestions);
      MockTestStore.setMockTestArray(resData.data);
    }
  };
  return (
    <div>
      {publish ? (
        <PreviewTabs mockTestQuestions={mockTestQuestions} />
      ) : (
        <Tabpage mockTestQuestions={mockTestQuestions} />
      )}
    </div>
  );
};

export default ManualPreviewPage;
