import { toJS } from "mobx";
import { observer } from "mobx-react-lite";
import React, { useRef, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import {
  DocxSvg,
  EditIcon,
  ExclamationIcon,
} from "../../../../assets/svgs/svg";
import Button from "../../../../customcomponents/button/Button";
import { HeadTitle } from "../../../../customcomponents/headtitle/headTitle";
import Modal from "../../../../customcomponents/modalPopup/CustomModal";
import MockTestStore from "../../../../MobX/MockTestStore";
import MocktestServices from "../../../../Services/MockTestService";
import { ClientRoutesConstants } from "../../../../shared/constant";
import { ThemeColors } from "../../../../theme/theme";
import SecondShep from "../component/createpage/SecondShep";
import ThirdShep from "../component/createpage/ThirdShep";
import MultiStepProgressBar from "../component/step-bar/stepBar";
import "../MocktestPage.css";
import PrintFunction from "./Print/PrintFunction";
import Step1 from "./step1/Step1";
function MockTestCreate() {
  const location = useLocation();
  const navigate = useNavigate();
  const mockRef = useRef();
  const [modal, setModal] = useState("");
  const [publish, setPublish] = useState(location?.state?.publish);
  const [editDetail, seteditDetail] = useState(location?.state?.publish);
  const [typeMocktest, setTypeMockTest] = useState(1);
  MockTestStore.setStepCount(location?.state?.id ? 3 : MockTestStore.stepCount);

  const publishMockTest = async () => {
    let mainArr = [...toJS(MockTestStore.mockTestArray?.mockTestQuestions)];
    let obj = mainArr.find(
      (arr) => arr?.sectionCount > arr?.sectionDetails?.length
    );
    if (obj) {
      toast.error(`Please complete all sections in ${obj.subjectName} Subject`);
    } else {
      const res = await MocktestServices.publishMockTest({
        mockTestSettingId: location?.state?.id
          ? location?.state?.id
          : localStorage.step1Res,
      });
      if (res.isSuccess) {
        localStorage.removeItem("step1Res");
        toast.success(res.messages);
        navigate(ClientRoutesConstants.mocktest);
      } else {
        toast.error(res.messages);
      }
    }
  };

  const checkMockTest = () => {
    let mainArr = [...toJS(MockTestStore.mockTestArray?.mockTestQuestions)];
    let found = mainArr.find(
      (x) =>
        x?.noOfQue !== x?.totalQuestions ||
        x?.sectionCount > x?.sectionDetails?.length
    );
    if (!found) {
      setPublish(true);
      seteditDetail(false);
    } else {
      toast.error(`Please fill questions in ${found?.subjectName} subject`);
    }
  };

  const saveDraft = async () => {
    let postData = { ...toJS(MockTestStore.mockTestArray), IsDraft: true };
    const res = await MocktestServices.updatemocktestquestions(postData);
    if (res.isSuccess) {
      localStorage.removeItem("step1Res");
      toast.success(res.messages);
      navigate(ClientRoutesConstants.mocktest);
    }
  };

  const discard = async () => {
    const deleteData = await MocktestServices.deleteMockTest({
      id: localStorage.step1Res,
    });
    if (deleteData?.isSuccess) {
      toast.info("Mock Test Discard");
      localStorage.removeItem("step1Res");
      navigate(ClientRoutesConstants.mocktest);
    } else {
      toast.error(deleteData?.messages);
    }
  };

  const editDetails = () => {
    setPublish(false);
  };

  const setType = (props) => {
    setTypeMockTest(props);
  };

  const Print = () => {
    mockRef.current.click();
  };
  return (
    <>
      {MockTestStore.currentStep.step === 3 && !publish ? (
        <HeadTitle
          text={`${location?.state?.id ? "Edit" : "Create"} Mock Test`}
          component1={
            <Button
              title="Save & Draft"
              width="161px"
              height="48px"
              border="1px solid #0075FF"
              background={ThemeColors.lightBlue}
              color={ThemeColors.primary}
              func={saveDraft}
            />
          }
          component2={
            <Button
              title="Preview Mocktest"
              width="196px"
              height="48px"
              func={() => {
                checkMockTest();
              }}
            />
          }
        />
      ) : MockTestStore.currentStep.step === 3 ? (
        <HeadTitle
          text={`Preview Mock Test`}
          component1={
            <Button
              title="Cancel"
              width="96px"
              height="48px"
              background={ThemeColors.secondary}
              func={() => {
                setModal("cancel");
              }}
            />
          }
          component2={
            editDetail ? (
              <Button
                title="Edit Details"
                width="154px"
                height="48px"
                icon={<EditIcon />}
                func={() => {
                  editDetails();
                }}
              />
            ) : (
              <Button
                title="Publish"
                width="126px"
                height="48px"
                func={() => {
                  setModal("publish");
                }}
              />
            )
          }
          component3={
            <Button
              title="Export Doc"
              width="170px"
              height="48px"
              func={() => Print()}
              icon={<DocxSvg />}
              background={ThemeColors.white}
              textColor={ThemeColors.primary}
              border={"1px solid #0075FF"}
            />
          }
        />
      ) : (
        <HeadTitle
          text={`${location?.state?.id ? "Edit" : "Create"} Mock Test`}
          component1={<div className="mb-5"></div>}
        />
      )}
      <MultiStepProgressBar />
      {
        {
          1: <Step1 Id={location?.state?.id} setType={setType} />,
          2: (
            <SecondShep
              Id={location?.state?.id}
              typeMocktest={typeMocktest}
              setPublish={setPublish}
            />
          ),
          3: <ThirdShep publish={publish} Id={location?.state?.id} />,
        }[MockTestStore.currentStep.step]
      }

      {modal === "cancel" && (
        <Modal closeBtn={false} noFooter={false} maxModalWidth="600px">
          <div className="row m-0 p-2">
            <p
              className="px-0 "
              style={{ fontSize: "20px", fontWeight: "400" }}
            >
              Are you sure you want to discard this mocktest? You can’t undo
              this action.
            </p>
            <div className="d-flex justify-content-end mt-3 gap-3">
              {!location?.state?.id && (
                <Button
                  title="Discard"
                  background={ThemeColors.danger}
                  width="127px"
                  func={discard}
                />
              )}

              <Button
                title="Save & Draft"
                color={ThemeColors.primary}
                background={ThemeColors.lightBlue}
                border="1px solid #0075FF"
                width="161px"
                func={saveDraft}
              />
              <Button
                title="Cancel"
                background={ThemeColors.secondary}
                width="122px"
                func={() => {
                  setModal("");
                }}
              />
            </div>
          </div>
        </Modal>
      )}

      {modal === "publish" && (
        <Modal closeBtn={false} noFooter={false} maxModalWidth="432px">
          <div className="row m-0 text-center gap-3 p-2">
            <ExclamationIcon />
            <p className="m-0" style={{ fontSize: "20px", fontWeight: "400" }}>
              You are about to <strong>publish</strong> the mocktest
            </p>
            <div className="d-flex justify-content-center gap-3">
              <Button
                title="Publish now"
                width="159px"
                func={publishMockTest}
              />
              <Button
                title="Cancel"
                background={ThemeColors.secondary}
                width="122px"
                func={() => {
                  setModal("");
                }}
              />
            </div>
          </div>
        </Modal>
      )}
      {MockTestStore.currentStep.step === 3 && <PrintFunction ref={mockRef} />}
    </>
  );
}

export default observer(MockTestCreate);
