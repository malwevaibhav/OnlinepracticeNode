import React from "react";
import { useLocation } from "react-router-dom";
import CustomInput from "../../../../../customcomponents/customTextInput";
import { InputLabel } from "../../../../../customcomponents/customTextInput/indexCss";
import CustomDropdown from "../../../../../customcomponents/custom_Dropdown/CustomDropdown";
import { TitleHeading } from "../../../../../customcomponents/DynamicText/Heading";
import AuthStore from "../../../../../MobX/Auth";
import PatternStore from "../../../../../MobX/Pattern";
import { ThemeColors } from "../../../../../theme/theme";
export default function MockTestDetail({
  institutes,
  mockTest,
  updateState,
  error,
  setMockError,
}) {
  const Role = AuthStore?.user?.user;
  const location = useLocation()
  const Institutetarget = (props, entityName) => {
    setMockError({ ...error, instituteName: false });
    updateState({
      instituteName: entityName,
      showPreview: true,
      instituteId: props.id,
    });
    PatternStore.setSelectedItemsPattern({
      selectedName: "Institute",
      props,
      entityName,
    });
  };
  return (
    <div className="card rounded-0 border-0 p-3">
      <TitleHeading text="Mock Test Details" />
      <hr className="mt-4" style={{ border: "1px solid #E3E9EE" }} />
      <CustomInput
        height="48px"
        label="Test Name"
        marginBottom="10px"
        marginTop="10px"
        value={mockTest?.mockTestName}
        onChange={(e) => {
          setMockError({ ...error, testName: false });
          updateState({
            mockTestName: e.target.value,
            showPreview: true,
          });
        }}
      />
      {error?.testName && (
        <div className="input-feedback">Mock test name is required</div>
      )}
      <InputLabel className="mt-3">Description</InputLabel>
      <textarea
        className="input-field inputField form-control mt-2"
        style={{ background: ThemeColors.bg }}
        value={mockTest?.description}
        placeholder="Description"
        onChange={(e) => {
          updateState({
            description: e.target.value,
            showPreview: true,
          });
        }}
      ></textarea>

      <div className="mt-3">
        <InputLabel>Select Institute</InputLabel>
        <CustomDropdown
          menu={institutes}
          customClass="form-dropdown"
          placeholder="Select Institute"
          menuStyle={{ border: "1px solid #E5E5E5", marginTop: "10px" }}
          selectedEntity={mockTest?.instituteName}
          handlefunc={Institutetarget}
          disable={Role?.role === 'Staff'}
        />
      </div>
      {error?.instituteName && (
        <div className="input-feedback">Institute is required</div>
      )}
      <div className="col-xl-12 col-lg-12  col-md-12 col-sm-12 f-align-row gap50 mt-3">
        <InputLabel> Pricing</InputLabel>
    
        <div className="f-row gap-5">
          <div>
            <input
              type="radio"
              className="MockradioType "
              name="Price"
              id="free"
              label="Value 13"
              checked={mockTest?.isFree}
              onChange={(e) => {
                setMockError({ ...error, price: false });
                updateState({ isFree: true, price: 0, showPreview: true });
              }}
              disabled={Role?.role==="Staff" && location?.state?.id}
            />{" "}
            <InputLabel htmlFor="free">Free</InputLabel>
          </div>
          <div>
            <input
              type="radio"
              className="MockradioType "
              name="Price"
              id="price"
              label="Value 22"
              checked={!mockTest?.isFree}
              onChange={(e) => {
                setMockError({ ...error, price: false });
                updateState({
                  isFree: false,
                  showPreview: true,
                });
              }}
              disabled={Role?.role==="Staff" && location?.state?.id}
            />
            <InputLabel htmlFor="price"> Price</InputLabel>
          </div>
        </div>

        {mockTest?.isFree === false && (
          <input
            type="number"
            className="input-field inputField form-control"
            style={{ background: "#F4F6F8", marginTop: "5px" }}
            value={mockTest?.price}
            onChange={(e) => {
              setMockError({ ...error, price: false });
              updateState({
                price: parseInt(e.target.value),
                showPreview: true,
              });
            }}
            disabled={Role?.role==="Staff" && location?.state?.id}
          
          />
        )}
        {error?.price && (
          <div className="input-feedback">
            Price should be greater than ZERO
          </div>
        )}
      </div>
    </div>
  );
}
