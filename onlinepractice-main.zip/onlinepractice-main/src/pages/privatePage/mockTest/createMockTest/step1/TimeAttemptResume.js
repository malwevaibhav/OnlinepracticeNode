import React from "react";
import Checkbox from "../../../../../customcomponents/checkbox/Checkbox";
import CustomInput from "../../../../../customcomponents/customTextInput";
import { InputLabel } from "../../../../../customcomponents/customTextInput/indexCss";
import { TitleHeading } from "../../../../../customcomponents/DynamicText/Heading";
import MockTestStore from "../../../../../MobX/MockTestStore";
import { ThemeColors } from "../../../../../theme/theme";

export default function TimeAttempResume({
  updateState,
  mockTest,
  error,
  setMockError,
}) {
  const date = new Date();
  function formatDate(date) {
    var d = new Date(date),
      month = "" + (d.getMonth() + 1),
      day = "" + d.getDate(),
      year = d.getFullYear();

    if (month.length < 2) month = "0" + month;
    if (day.length < 2) day = "0" + day;

    return [year, month, day].join("-");
  }
  return (
    <>
      <div className="card border-0 mt-3 rounded-0 p-3">
        <TitleHeading text="Time Setting" />
        <hr style={{ border: "1px solid #E3E9EE" }} />
        <div className="row m-0 ">
          <div className="col-3 d-flex py-3 align-items-center">
            <InputLabel>Time Duration</InputLabel>
          </div>
          <div className="col-9 d-flex align-items-center gap-3">
            <InputLabel>Hrs</InputLabel>
            <div className="me-2" style={{ width: "55px" }}>
              <CustomInput
                height="40px"
                type="number"
                value={mockTest?.timeDurationHours}
                onChange={(e) => {
                  setMockError({ ...error, timeDuration: "" });
                  updateState({
                    timeDurationHours: parseInt(e.target.value),
                    showPreview: true,
                  });
                }}
              />
            </div>
            <InputLabel> Min</InputLabel>
            <div style={{ width: "55px" }}>
              <CustomInput
                height="40px"
                type="number"
                value={mockTest?.timeDurationMinutes}
                onChange={(e) => {
                  setMockError({ ...error, timeDuration: "" });
                  updateState({
                    timeDurationMinutes: parseInt(e.target.value),
                    showPreview: true,
                  });
                }}
              />
            </div>
          </div>
          {error?.timeDuration && (
            <div className="input-feedback col-10 text-start">
              {error?.timeDuration}
            </div>
          )}
          <div className="col-3 d-flex py-3 align-items-center">
            <InputLabel>Test Availability</InputLabel>
          </div>
          <div className="col-9 d-flex align-items-center gap-3">
            <div className="d-flex gap-3 me-3">
              <input
                type="radio"
                name="testAvailablity"
                id="always"
                checked={mockTest?.testAvailability === 2}
                value={2}
                onChange={(e) => {
                  updateState({
                    testAvailability: parseInt(e.target.value),
                    showPreview: true,
                    testSpecificToDate: null,
                    testSpecificFromDate: null,
                    testStartTime: null,
                  });
                }}
              />
              <InputLabel htmlFor="always" style={{ paddingLeft: "10px" }}>
                Always
              </InputLabel>
            </div>
            <div className="d-flex gap-3">
              <input
                type="radio"
                name="testAvailablity"
                id="specific"
                value={1}
                checked={mockTest?.testAvailability === 1}
                onChange={(e) => {
                  updateState({
                    testAvailability: parseInt(e.target.value),
                    showPreview: true,
                  });
                }}
              />
              <InputLabel htmlFor="specific" style={{ paddingLeft: "10px" }}>
                Specific
              </InputLabel>
            </div>
          </div>
          {mockTest?.testAvailability === 1 && (
            <>
              <div className="col-3 d-flex py-3 align-items-center">
                <InputLabel>Date</InputLabel>
              </div>
              <div className="col-9 d-flex align-items-center gap-3">
                <InputLabel>From</InputLabel>
                <div className="me-2" style={{ width: "125px" }}>
                  <CustomInput
                    type="date"
                    min={formatDate(date)}
                    height="40px"
                    value={mockTest?.testSpecificFromDate}
                    onChange={(e) => {
                      // console.log("dbdhfdh",e.target.value + "T" +MockTestStore.mocktest?.testStartTime)
                      setMockError({ ...error, specificDate: false });
                      updateState({
                        testSpecificFromDate: e.target.value,
                        showPreview: true,
                        testUpdatedTime:
                          e.target.value +
                          "T" +
                          MockTestStore.mocktest?.testStartTime,
                      });
                    }}
                  />
                </div>
                <InputLabel> To</InputLabel>
                <div style={{ width: "125px" }}>
                  <CustomInput
                    type="date"
                    min={formatDate(date)}
                    height="40px"
                    value={mockTest?.testSpecificToDate}
                    onChange={(e) => {
                      setMockError({ ...error, specificDate: false });
                      updateState({
                        testSpecificToDate: e.target.value,
                        showPreview: true,
                      });
                    }}
                  />
                </div>
              </div>
              {error?.specificDate && (
                <div className="input-feedback col-10 text-start">
                  From Or To Date is required
                </div>
              )}

              <div className="col-3  mt-2 d-flex py-3 align-items-center">
                <InputLabel>Time</InputLabel>
              </div>
              <div className="col-9  mt-2 d-flex align-items-center gap-3">
                <InputLabel>Start Time</InputLabel>
                <CustomInput
                  type="time"
                  height="40px"
                  value={mockTest?.testStartTime}
                  onChange={(e) => {
                    // console.log(("nfhhfh",toJS(MockTestStore.mocktest?.testSpecificFromDate + "T" +e.target.value)));
                    setMockError({ ...error, specificTime: false });
                    updateState({
                      testStartTime: e.target.value,
                      showPreview: true,
                      testUpdatedTime:
                        MockTestStore.mocktest?.testSpecificFromDate +
                        "T" +
                        e.target.value,
                    });
                  }}
                />
              </div>
              {error?.specificTime && (
                <div className="input-feedback col-10 text-start">
                  Time is required
                </div>
              )}
            </>
          )}
        </div>
      </div>

      <div className="card border-0 mt-3 rounded-0 p-3">
        <TitleHeading text="Attempt Setting" />
        <hr style={{ border: "1px solid #E3E9EE" }} />
        <div className="row m-0 ">
          <div className="col-3 d-flex py-3 align-items-center">
            <InputLabel>Allow Reattempts</InputLabel>
          </div>
          <div className="col-9 d-flex align-items-center ">
            <div className="d-flex gap-3 me-1">
              <input
                type="radio"
                name="exampleRadios"
                id="yes"
                checked={mockTest?.isAllowReattempts}
                onChange={(e) => {
                  updateState({
                    isAllowReattempts: true,
                    totalAttempts: parseInt("3"),
                    showPreview: true,
                  });
                }}
              />
              <InputLabel htmlFor="yes" style={{ marginTop: "5px" }}>
                Yes
              </InputLabel>

              {mockTest?.isAllowReattempts && (
                <div>
                  <InputLabel style={{ color: "#787F86" }}>
                    (3 Times Only)
                  </InputLabel>
                </div>
              )}

              {/* {error?.noOfReattempt && (
                <div className="input-feedback col-10 text-start">
                  No. of Attempts is required
                </div>
              )} */}
            </div>
            <div className="d-flex gap-3 ms-5">
              <input
                type="radio"
                name="exampleRadios"
                id="no"
                checked={!mockTest?.isAllowReattempts}
                onChange={(e) => {
                  updateState({
                    isAllowReattempts: false,
                    totalAttempts: 0,
                    // reattemptsDays: 0,
                    // reattemptsHours: 0,
                    // reattemptsMinutes: 0,
                    showPreview: true,
                  });
                }}
              />
              <InputLabel htmlFor="no" style={{ paddingLeft: "10px" }}>
                No
              </InputLabel>
            </div>
          </div>
          {/* {mockTest?.isAllowReattempts && (
            <>
              <div className="col-3 d-flex py-3 align-items-center">
                <InputLabel>How Many</InputLabel>
              </div>
              <div className="col-9 d-flex align-items-center gap-3">
                <div className="d-flex gap-3 me-1">
                  <Checkbox
                    isChecked={mockTest?.isUnlimitedAttempts}
                    handleClick={(e) => {
                      setMockError({ ...error, noOfReattempt: false });
                      updateState({
                        isUnlimitedAttempts: e.target.checked,
                        totalAttempts: 0,
                        showPreview: true,
                      });
                    }}
                  />
                  <></>
                  <InputLabel>Unlimited</InputLabel>
                </div>
                {!mockTest?.isUnlimitedAttempts && (
                  <div style={{ width: "56px" }}>
                    <CustomInput
                      height="40px"
                      type="number"
                      value={mockTest?.totalAttempts}
                      onChange={(e) => {
                        setMockError({ ...error, noOfReattempt: false });
                        updateState({
                          totalAttempts: parseInt(e.target.value),
                          showPreview: true,
                        });
                      }}
                    />
                  </div>
                )}
              </div>
              {error?.noOfReattempt && (
                <div className="input-feedback col-10 text-start">
                  No. of Attempts is required
                </div>
              )}
              <div className="col-3 d-flex py-3 align-items-center">
                <InputLabel>Gap Between Reattempts</InputLabel>
              </div>
              <div className="col-9 d-flex align-items-center gap-3">
                <InputLabel>Days</InputLabel>
                <div style={{ width: "56px", marginRight: "15px" }}>
                  <CustomInput
                    height="40px"
                    type="number"
                    value={mockTest?.reattemptsDays}
                    onChange={(e) => {
                      setMockError({ ...error, gapReattempt: false });
                      updateState({
                        reattemptsDays: parseInt(e.target.value),
                        showPreview: true,
                      });
                    }}
                  />
                </div>
                <InputLabel> Hrs</InputLabel>
                <div style={{ width: "56px", marginRight: "10px" }}>
                  <CustomInput
                    height="40px"
                    type="number"
                    value={mockTest?.reattemptsHours}
                    onChange={(e) => {
                      setMockError({ ...error, gapReattempt: false });
                      updateState({
                        reattemptsHours: parseInt(e.target.value),
                        showPreview: true,
                      });
                    }}
                  />
                </div>
                <InputLabel> Min</InputLabel>
                <div style={{ width: "56px" }}>
                  <CustomInput
                    height="40px"
                    type="number"
                    value={mockTest?.reattemptsMinutes}
                    onChange={(e) => {
                      setMockError({ ...error, gapReattempt: false });
                      updateState({
                        reattemptsMinutes: parseInt(e.target.value),
                        showPreview: true,
                      });
                    }}
                  />
                </div>
              </div>
              {error?.gapReattempt && (
                <div className="input-feedback col-10 text-start">
                  Gap Between Reattempts is required
                </div>
              )}
              {mockTest?.reattemptsHours > 23 && (
                <div className="input-feedback col-12 text-center">
                  Hours should not be greater than 23
                </div>
              )}
              {mockTest?.reattemptsMinutes > 59 && (
                <div className="input-feedback col-12 text-center">
                  Minutes should not be greater than 59
                </div>
              )}
            </>
          )} */}
        </div>
      </div>

      <div className="card border-0 mt-3 rounded-0 p-3">
        <TitleHeading text="Resume Setting" />
        <hr style={{ border: "1px solid #E3E9EE" }} />
        <div className="row m-0 ">
          <div className="col-3 d-flex py-3 align-items-center">
            <InputLabel>Allow Test Resume</InputLabel>
          </div>
          <div className="col-9 d-flex align-items-center">
            <div className="d-flex gap-3 me-1">
              <input
                type="radio"
                name="resume"
                id="resumeYes"
                checked={mockTest?.isTestResume}
                onChange={(e) => {
                  setMockError({ ...error, noOfTestResume: false });
                  updateState({
                    isTestResume: true,
                    showPreview: true,
                  });
                }}
              />
              <InputLabel htmlFor="resumeYes" style={{ paddingLeft: "10px" }}>
                Yes
              </InputLabel>
            </div>
            <div className="d-flex gap-3 ms-5">
              <input
                type="radio"
                name="resume"
                id="resumeNo"
                checked={!mockTest?.isTestResume}
                onChange={(e) => {
                  setMockError({ ...error, noOfTestResume: false });
                  updateState({
                    isTestResume: false,
                    showPreview: true,
                  });
                }}
              />
              <InputLabel htmlFor="resumeNo" style={{ paddingLeft: "10px" }}>
                No
              </InputLabel>
            </div>
          </div>
          {/* {mockTest?.isTestResume && (
            <>
              <div className="col-10 d-flex align-items-center gap-3">
                <small
                  style={{ color: ThemeColors.secondary, fontSize: "12px" }}
                >
                  ( Users can restart the test from the same point where they
                  stopped test in case of Power Cut-off, System Crash etc. due
                  to unexpected circumstances )
                </small>
              </div>
              <div className="col-3 d-flex py-3 align-items-center">
                <InputLabel>How Many</InputLabel>
              </div>
              <div className="col-9 d-flex align-items-center gap-3">
                <div className="d-flex gap-3 ">
                  <Checkbox
                    isChecked={mockTest?.isUnlimitedResume}
                    handleClick={(e) => {
                      setMockError({ ...error, noOfTestResume: false });
                      updateState({
                        isUnlimitedResume: e.target.checked,
                        totalResume: 0,
                        showPreview: true,
                      });
                    }}
                  />
                  <InputLabel>Unlimited</InputLabel>
                </div>
                {!mockTest?.isUnlimitedResume && (
                  <div style={{ width: "56px" }}>
                    <CustomInput
                      height="40px"
                      type="number"
                      value={mockTest?.totalResume}
                      onChange={(e) => {
                        updateState({
                          totalResume: parseInt(e.target.value),
                          showPreview: true,
                        });
                      }}
                    />
                  </div>
                )}
              </div>
              {error?.noOfTestResume && (
                <div className="input-feedback col-10 text-start">
                  No. of Test Resume is required
                </div>
              )}
            </>
          )} */}
        </div>
      </div>

      {/* <div className="card border-0 mt-3 rounded-0 p-3">
        <TitleHeading text="Appearance" />
        <hr style={{ border: "1px solid #E3E9EE" }} />
        <div className="row m-0 ">
          <div className="col-3 d-flex py-2 align-items-center">
            <InputLabel>Back Button​/Previous Question</InputLabel>
          </div>
          <div className="col-9 d-flex align-items-center">
            <div className="d-flex gap-3 ">
              <input
                type="radio"
                name="backBtn"
                id="allow"
                value={1}
                checked={mockTest?.backButton === 1}
                onChange={(e) => {
                  updateState({
                    backButton: 1,
                    showPreview: true,
                  });
                }}
              />
              <InputLabel htmlFor="allow" style={{ paddingLeft: "10px" }}>
                Allowed
              </InputLabel>
            </div>
            <div className="d-flex gap-3 ms-4">
              <input
                type="radio"
                name="backBtn"
                id="notAllow"
                value={2}
                checked={mockTest?.backButton === 2}
                onChange={(e) => {
                  updateState({
                    backButton: 2,
                    showPreview: true,
                  });
                }}
              />
              <InputLabel htmlFor="notAllow" style={{ paddingLeft: "10px" }}>
                Not-allowed
              </InputLabel>
            </div>
          </div>
          <div className="col-10 d-flex align-items-center gap-3">
            <small style={{ color: ThemeColors.secondary, fontSize: "12px" }}>
              ( Users can go to previous questions and can change the answer )
            </small>
          </div>
        </div>
      </div> */}
    </>
  );
}
