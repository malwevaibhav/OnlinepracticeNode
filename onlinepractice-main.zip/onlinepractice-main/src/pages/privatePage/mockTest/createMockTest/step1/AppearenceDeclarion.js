import React from "react";
import Checkbox from "../../../../../customcomponents/checkbox/Checkbox";
import { InputLabel } from "../../../../../customcomponents/customTextInput/indexCss";
import { TitleHeading } from "../../../../../customcomponents/DynamicText/Heading";
export default function AppearenceDeclarion({ updateState, mockTest }) {
  return (
    <>
      <div className="card rounded-0 border-0 mt-3 p-3">
        <TitleHeading text="Result Declaration Option" />
        <hr style={{ border: "1px solid #E3E9EE" }} />
        <div className="row m-0 ">
          <div className="col-3 d-flex py-3 align-items-start">
            <InputLabel>Result Format</InputLabel>
          </div>
          <div className="col-9 d-flex py-3 align-items-start flex-column gap-3">
            <div className="d-flex gap-3">
              <Checkbox
                isChecked={mockTest?.isMarksResultFormat}
                handleClick={(e) => {
                  updateState({
                    isMarksResultFormat: e.target.checked,
                    showPreview: true,
                  });
                }}
              />
              <InputLabel>Marks</InputLabel>
            </div>
            {/* <div className="d-flex gap-3">
              <Checkbox
                isChecked={mockTest?.isPassFailResultFormat}
                handleClick={(e) => {
                  updateState({
                    isPassFailResultFormat: e.target.checked,
                    showPreview: true,
                  });
                }}
              />
              <InputLabel>Pass/Fail</InputLabel>
            </div> */}
            {/* <div className="d-flex gap-3">
              <Checkbox
                isChecked={mockTest?.isRankResultFormat}
                handleClick={(e) => {
                  updateState({
                    isRankResultFormat: e.target.checked,
                    showPreview: true,
                  });
                }}
              />
              <InputLabel>Rank</InputLabel>
            </div> */}
          </div>
          <div className="col-3 d-flex py-3 align-items-start">
            <InputLabel>Result Declaration</InputLabel>
          </div>
          <div className="col-9 d-flex py-3 align-items-start flex-column gap-3">
            <div className="d-flex gap-3 ">
              <input
                type="radio"
                name="Declaration"
                id="perQuestion"
                value={1}
                checked={mockTest?.resultDeclaration === 1}
                onChange={(e) => {
                  updateState({
                    resultDeclaration: 1,
                    showPreview: true,
                    isShowCorrectAnswer: true,
                  });
                }}
              />
              <InputLabel htmlFor="perQuestion">
                Show Result After Each Question
              </InputLabel>
            </div>
            <div className="d-flex gap-3 ">
              <input
                type="radio"
                name="Declaration"
                id="testComp"
                value={2}
                checked={mockTest?.resultDeclaration === 2}
                onChange={(e) => {
                  updateState({
                    resultDeclaration: 2,
                    showPreview: true,
                    isShowCorrectAnswer: false,
                  });
                }}
              />
              <InputLabel htmlFor="testComp">
                Immediately After Test Completion
              </InputLabel>
            </div>
          </div>
          <div className="col-3 d-flex py-3 align-items-center">
            <InputLabel>Show Correct Answers</InputLabel>
          </div>
          <div className="col-9 d-flex py-3 align-items-center ">
            <div className="d-flex gap-3 me-1">
              <input
                type="radio"
                name="correctAns"
                id="perQuestion"
                value={1}
                checked={mockTest?.resultDeclaration === 1}
                // onChange={(e) => {
                //   updateState({
                //     isShowCorrectAnswer: true,
                //     showPreview: true,
                //   });
                // }}
              />
              <InputLabel htmlFor="ansYes">Yes</InputLabel>
            </div>
            <div className="d-flex gap-3 ms-5">
              <input
                type="radio"
                name="correctAns"
                id="testComp"
                checked={mockTest?.resultDeclaration === 2}
                // onChange={(e) => {
                //   updateState({
                //     isShowCorrectAnswer: false,
                //     showPreview: true,
                //   });
                // }}
              />
              <InputLabel htmlFor="ansNo">No</InputLabel>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
