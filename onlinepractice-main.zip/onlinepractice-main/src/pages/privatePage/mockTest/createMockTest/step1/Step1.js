import React, { useEffect, useState } from "react";
import { toast } from "react-toastify";
import AuthStore from "../../../../../MobX/Auth";
import MockTestStore from "../../../../../MobX/MockTestStore";
import PatternStore from "../../../../../MobX/Pattern";
import QuestionStore from "../../../../../MobX/Question";

import InstituteServices from "../../../../../Services/InstituteService";
import MocktestServices from "../../../../../Services/MockTestService";
import QuestionTypeServices from "../../../../../Services/QuestionTypeService";
import { removeExtraSpace } from "../../../../../utils/helper";
import SettingPreview from "../../component/createpage/settingPreview";
import AppearenceDeclarion from "./AppearenceDeclarion";
import MockTestDetail from "./MockTestDetail";
import TimeAttempResume from "./TimeAttemptResume";

/* eslint-disable */
export default function Step1({ Id, setType }) {
  const [institutes, setInstitute] = useState([]);
  const [toggle, settoggle] = useState(false);
  const [language, setLanguage] = useState([]);
  const [mockError, setMockError] = useState({
    testName: false,
    instituteName: false,
    price: false,
    timeDuration: false,
    specificDate: false,
    specificTime: false,
    noOfReattempt: false,
    gapReattempt: false,
    noOfTestResume: false,
  });
  const Role = AuthStore?.user?.user;
  useEffect(() => {
    settoggle(true);
    if (Role?.role === "Admin") {
      getAllInstitute();
    }
    getAllLanguage();
    if (Id) {
      mockTestById(Id);
    } else if (localStorage?.step1Res) {
      mockTestById(localStorage.step1Res);
    }
    settoggle(false);
    if (Role?.role === "Staff") {
      MockTestStore.setmocktest({
        instituteName: Role?.instituteName,
        showPreview: true,
        instituteId: Role?.instituteId,
      });
    }
  }, [Id]);

  const getAllInstitute = async () => {
    const resData = await InstituteServices.getAllInstitute();
    let temp = resData?.institutes?.map((data, i) => {
      return (resData[i] = {
        ...resData?.institutes[i],
        Title: data.instituteName,
      });
    });
    setInstitute(temp);
  };

  const getAllLanguage = async () => {
    const res = await QuestionTypeServices.getAllLanguage();
    if (res?.isSuccess) {
      if (res?.data) {
        let lang = res?.data.map((item) => {
          return {
            id: item?.value,
            Title: item?.name,

            value: item?.value,
            label: item?.name,
          };
        });
        setLanguage(lang);
        PatternStore.setSelectedItemsPattern({
          selectedName: "Language",
          props: lang[0],
          entityName: lang[0]?.Title,
        });
        MockTestStore.setmocktest({ language: lang[0]?.Title });
      }
    }
  };

  const mockTestById = async (id) => {
    const resData = await MocktestServices.getMockTestById({ id: id });
    if (resData?.isSuccess) {
      if (resData?.data?.testAvailability === 1) {
        updateState({
          ...resData?.data,
          showPreview: true,
          testStartTime: resData?.data?.testStartTime.split("T")?.[1],
          testUpdatedTime: resData?.data?.testStartTime,
          testSpecificFromDate:
            resData?.data?.testSpecificFromDate.split("T")?.[0],
          testSpecificToDate: resData?.data?.testSpecificToDate.split("T")?.[0],
        });
      } else {
        updateState({
          ...resData?.data,
          showPreview: true,
        });
      }
      settoggle(false);
    }
  };

  const updateState = (data) => {
    MockTestStore.setmocktest(data);
    if (data?.language) {
      PatternStore.setSelectedItemsPattern({
        selectedName: "Language",
        props: {},
        entityName: data?.language,
      });
    }
    settoggle(!toggle);
  };

  const checkTestSetting = () => {

    //  console.log(" ",MockTestStore?.langlength);

    MockTestStore.setmocktest({
      mockTestName: removeExtraSpace(MockTestStore.mocktest?.mockTestName),
    });
 
    if(MockTestStore?.langlength < 2){
      return toast.error("please select atmost two languages");
    }

    if (removeExtraSpace(MockTestStore.mocktest?.mockTestName) === "") {
      return setMockError({ ...mockError, testName: true });
    }

    if (!MockTestStore.mocktest?.instituteId && Role?.role === "Admin") {
      return setMockError({ ...mockError, instituteName: true });
    }

    if (!MockTestStore.mocktest?.isFree && !MockTestStore.mocktest?.price) {
      return setMockError({ ...mockError, price: true });
    }

    if (
      !MockTestStore.mocktest?.timeDurationHours &&
      !MockTestStore.mocktest?.timeDurationMinutes
    ) {
      return setMockError({
        ...mockError,
        timeDuration: "Time-Duration is required",
      });
    }
    if (
      MockTestStore.mocktest?.timeDurationMinutes > 59 ||
      MockTestStore.mocktest?.timeDurationHours > 23
    ) {
      return setMockError({
        ...mockError,
        timeDuration:
          "Minutes should be less than to 60 and Hours should less than 24 ",
      });
    }
    if (
      MockTestStore.mocktest?.testAvailability === 1 &&
      (!MockTestStore.mocktest?.testSpecificToDate ||
        !MockTestStore.mocktest?.testSpecificFromDate)
    ) {
      return setMockError({ ...mockError, specificDate: true });
    }
    if (
      MockTestStore.mocktest?.testAvailability === 1 &&
      !MockTestStore.mocktest?.testStartTime
    ) {
      return setMockError({ ...mockError, specificTime: true });
    }
    // if (
    //   MockTestStore.mocktest?.isAllowReattempts &&
    //   !MockTestStore.mocktest?.isUnlimitedAttempts &&
    //   !MockTestStore.mocktest?.totalAttempts
    // ) {

    //return setMockError({ ...mockError, noOfReattempt: true });
    // }
    // if (
    //   (MockTestStore.mocktest?.isAllowReattempts &&
    //     !MockTestStore.mocktest?.reattemptsMinutes &&
    //     !MockTestStore.mocktest?.reattemptsHours &&
    //     !MockTestStore.mocktest?.reattemptsDays) ||
    //   MockTestStore.mocktest?.reattemptsHours > 23 ||
    //   MockTestStore.mocktest?.reattemptsDays > 59
    // ) {

    // return setMockError({ ...mockError, gapReattempt: true });
    // }
    // if (
    //   MockTestStore.mocktest?.isTestResume &&
    //   !MockTestStore.mocktest?.isUnlimitedResume &&
    //   !MockTestStore.mocktest?.totalResume
    // ) {
    //   return setMockError({ ...mockError, noOfTestResume: true });
    // }
    if (
      !MockTestStore.mocktest?.isMarksResultFormat &&
      !MockTestStore.mocktest?.isPassFailResultFormat &&
      !MockTestStore.mocktest?.isRankResultFormat
    ) {
      return toast.error("Select at least one Result Format");
    }
    submitTestSetting(MockTestStore.mocktest);
  };

  const submitTestSetting = async (data) => {
    let payload = {
      ...data,
      testStartTime: data?.testUpdatedTime,
    };
    if (localStorage?.step1Res || Id) {
      payload.id = Id ? Id : localStorage.step1Res;
      payload = { ...payload, id: Id ? Id : localStorage.step1Res };
      let res = await MocktestServices.updateMockTest(payload);
      if (res.isSuccess) {
        MockTestStore.setMocktestIDs({ mocktestSettingId: res.data?.id });
        MockTestStore.setCurrentStep({ step: 2, from: 1 });
        MockTestStore.setStepCount(2);
      } else {
        toast.error(res.messages);
      }
    } else {
      let res = await MocktestServices.createMockTest(payload);
      if (res.isSuccess) {
        MockTestStore.setMockTestArray({});
        QuestionStore.setSelectedItemsNw({
          selectedName: "Exam",
          props: {},
          entityName: "",
        });
        localStorage.setItem("step1Res", res.data?.id);
        MockTestStore.setMocktestIDs({ mocktestSettingId: res.data.id });
        MockTestStore.setCurrentStep({ step: 2, from: 1 });
        MockTestStore.setStepCount(2);
        PatternStore.setSelectedItemsPattern({
          selectedName: "Pattern",
          props: {},
          entityName: "",
        });
      } else {
        toast.error(res.messages);
      }
    }
  };

  return (
    <div className="row ">
      <div className="col-xl-6 col-lg-12 col-md-12 col-sm-12 mb-3">
        <MockTestDetail
          institutes={institutes}
          mockTest={MockTestStore?.mocktest}
          updateState={updateState}
          error={mockError}
          setMockError={setMockError}
        />
        <TimeAttempResume
          updateState={updateState}
          mockTest={MockTestStore?.mocktest}
          error={mockError}
          setMockError={setMockError}
        />
        <AppearenceDeclarion
          updateState={updateState}
          mockTest={MockTestStore?.mocktest}
        />
      </div>
      <div className="col-xl-6 col-lg-12 col-md-12 col-sm-12">
        <SettingPreview
          language={language}
          updateState={updateState}
          mockTest={MockTestStore?.mocktest}
          institutes={institutes}
          submitFunc={checkTestSetting}
          setType={setType}
          Id={Id}
        />
      </div>
    </div>
  );
}
