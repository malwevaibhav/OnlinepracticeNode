import { observer } from "mobx-react";
import * as React from "react";
import { useState } from "react";
import ReactToPrint from "react-to-print";
import { toast } from "react-toastify";
import PatternStore from "../../../../../MobX/Pattern";
import MocktestServices from "../../../../../Services/MockTestService";
import { PrintComponent } from "./PrintComponent";

/* eslint-disable */
const PrintFunction = React.forwardRef((props,ref,newId) => {
  const language =
    PatternStore.selectedItemsPattern.Language.selectedName.toLowerCase();
  const [pdfData, setPdfData] = useState();
  const componentRef = React.useRef(null);
  const onBeforeGetContentResolve = React.useRef(null);

  React.useImperativeHandle(ref, () => ({
    click() {
      document.getElementById("print-button").click();
    },
  }));

  React.useEffect(() => {
    getExportData();
    if (typeof onBeforeGetContentResolve.current === "function") {
      onBeforeGetContentResolve.current();
    }
  }, [onBeforeGetContentResolve.current]);

  const handleAfterPrint = React.useCallback(() => {
    // console.log("`onAfterPrint` called");
  }, []);

  const handleBeforePrint = React.useCallback(() => {
    // getExportData()
    // console.log("`onBeforePrint` called");
  }, []);

  const handleOnBeforeGetContent = React.useCallback(() => {
    // console.log("`onBeforeGetContent` called");
    return new Promise((resolve) => {
      onBeforeGetContentResolve.current = resolve;
      resolve();
    });
  }, []);

  const reactToPrintContent = React.useCallback(() => {
    return componentRef.current;
  }, [componentRef.current]);

  const reactToPrintTrigger = React.useCallback(() => {
    // var currentdate = new Date();
    // datetime = currentdate.getDate() + "" + (currentdate.getMonth() + 1) + "" + currentdate.getFullYear() + "" + currentdate.getHours() + "" + currentdate.getMinutes() + "" + currentdate.getSeconds();
    // NOTE: could just as easily return <SomeComponent />. Do NOT pass an `onClick` prop
    // to the root node of the returned component as it will be overwritten.

    // Bad: the `onClick` here will be overwritten by `react-to-print`
    // return <button onClick={() => alert('This will not work')}>Print this out!</button>;

    // Good
    return (
      <button id="print-button" style={{ display: "none" }}>
        Print using a Functional Component
      </button>
    );
  }, []);

  const getExportData = async () => {
      //  console.log("newId",newId)
    const res = await MocktestServices.MockTestPdf({
      mockTestSettingId: localStorage.step1Res||newId,
    });
    if (res.isSuccess) {
      setPdfData(res?.data);
    } else {
      toast.error(res.messages);
    }
  };

  const currentTime = () => {
    var currentdate = new Date();
    return (
      currentdate.getDate() +
      "" +
      (currentdate.getMonth() + 1) +
      "" +
      currentdate.getFullYear() +
      "" +
      currentdate.getHours() +
      "" +
      currentdate.getMinutes() +
      "" +
      currentdate.getSeconds()
    );
  };

  return (
    <div>
      <ReactToPrint
        content={reactToPrintContent}
        documentTitle={"mockTest_" + currentTime()}
        onAfterPrint={handleAfterPrint}
        onBeforeGetContent={handleOnBeforeGetContent}
        onBeforePrint={handleBeforePrint}
        removeAfterPrint
        trigger={reactToPrintTrigger}
      />
      <PrintComponent
        ref={componentRef}
        pdfData={pdfData}
        language={language}
      />
    </div>
  );
});

export default observer(PrintFunction);
