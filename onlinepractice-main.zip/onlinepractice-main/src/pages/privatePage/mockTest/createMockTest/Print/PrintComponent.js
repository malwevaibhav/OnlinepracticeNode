import * as React from "react";

export class PrintComponent extends React.PureComponent {
  render() {
    const { pdfData, language } = this.props;
    return (
      <>
        <div className="p-3 print-source">
          <div className="d-flex justify-content-between align-items-center gap-3 pb-2">
            <img
              src={pdfData?.instituteLogo}
              alt="Institute logo"
              style={{
                width: "200px",
                height: "50px",
                objectFit: "fill",
                borderRadius: "5px",
                maxWidth: "200px",
                maxHeight: "100px",
              }}
            />
            <p>{pdfData?.examPatternName}</p>
            <p className="d-flex gap-3">
              Subjects:
              {pdfData?.mockTestQuestions?.map((data, key) => {
                return <div key={key}>{data?.subjectName}</div>;
              })}
            </p>
          </div>
          <div className="d-flex justify-content-between bg-dark p-2 mb-2">
            <h6 className="text-white p-0 m-0">
              Time : - {pdfData?.timeDurationHours}:
              {pdfData?.timeDurationMinutes}
            </h6>
            <h6 className="text-white p-0 m-0">
              Test Name : - {pdfData?.mockTestName}
            </h6>
            <h6 className="text-white p-0 m-0">
              Total Marks : - {pdfData?.totalMarks}
            </h6>
          </div>
          <div>
            <p
              className="ps-1 m-0 p-0"
              style={{ pageBreakAfter: "always" }}
              dangerouslySetInnerHTML={{
                __html: pdfData?.generalInstructions,
              }}
            />
          </div>
          {pdfData?.mockTestQuestions?.map((data, key) => {
            return (
              <div className="text-center" key={key}>
                <h4>{data?.subjectName}</h4>
                {data?.sectionDetails.map((secData, subI) => {
                  return (
                    <div key={subI} style={{ pageBreakAfter: "always" }}>
                      <hr />
                      <h5>{secData?.sectionName}</h5>
                      {secData?.mockTestQuestions?.map((mockData, i) => {
                        return (
                          <div className="row m-0 text-start pt-4" key={i}>
                            <div
                              className="d-flex col-12"
                              style={{ fontSize: "16px", fontWeight: "400" }}
                            >
                              <div style={{ minWidth: "fit-content" }}>
                                {" "}
                                {`Q ${i + 1})`}
                              </div>
                              <p
                                className="ps-1 m-0 p-0"
                                dangerouslySetInnerHTML={{
                                  __html:
                                    mockData?.questionTableData[language]
                                      ?.questionText,
                                }}
                              />
                            </div>
                            {mockData?.questionType === 3 ? (
                              <div className="p-5"></div>
                            ) : (
                              <>
                                <div
                                  className="d-flex col-6"
                                  style={{
                                    fontSize: "16px",
                                    fontWeight: "400",
                                  }}
                                >
                                  {"A) "}
                                  <p
                                    style={{
                                      maxHeight: "200px",
                                      maxWidth: "200px",
                                    }}
                                    className="ps-1 m-0 p-0"
                                    dangerouslySetInnerHTML={{
                                      __html:
                                        mockData?.questionTableData[language]
                                          ?.optionA,
                                    }}
                                  />
                                </div>
                                <div
                                  className="d-flex col-6"
                                  style={{
                                    fontSize: "16px",
                                    fontWeight: "400",
                                  }}
                                >
                                  {"B) "}
                                  <p
                                    style={{
                                      maxHeight: "200px",
                                      maxWidth: "200px",
                                    }}
                                    className="ps-1 m-0 p-0"
                                    dangerouslySetInnerHTML={{
                                      __html:
                                        mockData?.questionTableData[language]
                                          ?.optionB,
                                    }}
                                  />
                                </div>
                                <div
                                  className="d-flex col-6"
                                  style={{
                                    fontSize: "16px",
                                    fontWeight: "400",
                                  }}
                                >
                                  {"C) "}
                                  <p
                                    style={{
                                      maxHeight: "200px",
                                      maxWidth: "200px",
                                    }}
                                    className="ps-1 m-0 p-0"
                                    dangerouslySetInnerHTML={{
                                      __html:
                                        mockData?.questionTableData[language]
                                          ?.optionC,
                                    }}
                                  />
                                </div>
                                <div
                                  className="d-flex col-6"
                                  style={{
                                    fontSize: "16px",
                                    fontWeight: "400",
                                  }}
                                >
                                  {"D) "}
                                  <p
                                    style={{
                                      maxHeight: "200px",
                                      maxWidth: "200px",
                                    }}
                                    className="ps-1 m-0 p-0"
                                    dangerouslySetInnerHTML={{
                                      __html:
                                        mockData?.questionTableData[language]
                                          ?.optionD,
                                    }}
                                  />
                                </div>
                                {/* <div className='' style={{ width: '100%', height: '15px', borderBottom: '1px solid black', textAlign: 'center' }}>
                                                                <span style={{ fontSize: "20px", backgroundColor: "#F3F5F6", padding: "0 10px" }}>
                                                                    SPACE FOR ROUGH WORK
                                                                </span>
                                                            </div> */}
                              </>
                            )}
                            {(i + 1) % 2 === 0 && (
                              <p
                                className=""
                                style={{ pageBreakAfter: "always" }}
                              />
                            )}
                          </div>
                        );
                      })}
                    </div>
                  );
                })}
              </div>
            );
          })}
          <div
            className=""
            style={{
              width: "100%",
              height: "15px",
              borderBottom: "1px solid black",
              textAlign: "center",
              pageBreakBefore: "always",
            }}
          >
            <span
              style={{
                fontSize: "20px",
                backgroundColor: "#F3F5F6",
                padding: "0 10px",
              }}
            >
              SPACE FOR ROUGH WORK
            </span>
          </div>
          <div
            className=""
            style={{
              width: "100%",
              height: "15px",
              borderBottom: "1px solid black",
              textAlign: "center",
              pageBreakBefore: "always",
            }}
          >
            <span
              style={{
                fontSize: "20px",
                backgroundColor: "#F3F5F6",
                padding: "0 10px",
              }}
            >
              SPACE FOR ROUGH WORK
            </span>
          </div>
          <footer>
            <div className="">Keep working, you will get your Dreams</div>
          </footer>
        </div>
      </>
    );
  }
}

export const FunctionalComponentToPrint = React.forwardRef((props, ref) => {
  // eslint-disable-line max-len
  return <PrintComponent ref={ref} text={props.text} />;
});
