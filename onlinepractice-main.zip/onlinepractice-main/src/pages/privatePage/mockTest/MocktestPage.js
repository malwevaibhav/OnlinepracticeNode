import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { PlusIcon } from "../../../assets/svgs/svg";
import DataExtractor from "../../../component/hooks/dataExtractor";
import Button from "../../../customcomponents/button/Button";
import { HeadTitle } from "../../../customcomponents/headtitle/headTitle";
import Pagination from "../../../customcomponents/pagination/Pagination";
import MockTable from "../../../customcomponents/table/mockTable";
import AuthStore from "../../../MobX/Auth";
import MockTestStore from "../../../MobX/MockTestStore";
import PatternStore from "../../../MobX/Pattern";
import QuestionStore from "../../../MobX/Question";
import MocktestServices from "../../../Services/MockTestService";
import { ClientRoutesConstants } from "../../../shared/constant";
import MockTestCard from "./component/mockTestcard";

const tableHead = [
  "Title",
  "Added By",
  "Institute ",
  "Date & Time ",
  "Status",
  "Language",
  "Type",
  "action",
];

/* eslint-disable */
const MocktestPage = () => {
  const navigate = useNavigate();
  const [pageNoSize, setPageNoSize] = useState({ no: 1, size: 10 });
  const [allMockTest, setallMockTest] = useState([]);
  const [mockTestLength, setMockTestLength] = useState("");
  const Role = AuthStore?.user?.user
  
  useEffect(() => {
    if (
      QuestionStore.selectedItemsNw.examList.id &&
      QuestionStore.selectedItemsNw.courseList.id &&
      QuestionStore.selectedItemsNw.SubCourseList.id &&
      PatternStore.selectedItemsPattern.Institute.id &&
      PatternStore.selectedItemsPattern.pattern.id &&
      PatternStore.selectedItemsPattern.Language.selectedName
    ) {
      getAllMockTest();
    }
  }, []);

  const getAllMockTest = async (no = 1, size = 10) => {
    setPageNoSize({ no: 1, size: 10 });
    let post = {
      examTypeId: QuestionStore.selectedItemsNw.examList.id,
      courseId: QuestionStore.selectedItemsNw.courseList.id,
      subCourseId: QuestionStore.selectedItemsNw.SubCourseList.id,
      instituteId: PatternStore.selectedItemsPattern.Institute.id,
      examPatternId: PatternStore.selectedItemsPattern.pattern.id,
      language: PatternStore.selectedItemsPattern.Language.selectedName,
      pageNumber: no,
      pageSize: size,
    };
    if (Role === "Staff") {
      post.instituteId = Role.instituteId
    }
    const res = await MocktestServices.getAllMockTest(post);
   // console.log("gfdgdfg+=>>>",res)
    if (res?.isSuccess) {

     // console.log("gfdgdfg+=>>>",res)
      setMockTestLength(res?.data?.totalRecords);
      let extracted = DataExtractor(res?.data?.getAllMocktests, [
        "lastModifiedDate",
      ]);
      let list = extracted?.map((elm) => {
        return {
          ...elm,
          action: true,
        };
      });
      setallMockTest(list);
      return extracted.length;
    }
    if (!res?.isSuccess) {

      //console.log("gfdgdfg+=>>>",res)
      setallMockTest([]);
    }
    if (!res?.data?.getAllMocktests) {
      setPageNoSize({ ...pageNoSize, no: pageNoSize.no - 1 });
      if (pageNoSize.no - 1 <= 0) {
        setallMockTest([]);
        setMockTestLength();
        return false;
      } else {
        return getAllMockTest(pageNoSize?.no - 1, pageNoSize?.size);
      }
    }
  };

  const addMockTes = () => {
    MockTestStore.clear()
    localStorage.removeItem("step1Res");
    // MockTestStore.setMockTestArray({});
    // MockTestStore.setCurrentStep({ step: 1, from: 0 });
    // MockTestStore.setStepCount(1);
    // let initalMocktest = {
    //   mockTestName: "",
    //   description: "",
    //   instituteId: "",
    //   instituteName: "",
    //   isFree: true,
    //   price: 0,
    //   timeDurationHours: 0,
    //   timeDurationMinutes: 0,
    //   testAvailability: 2,
    //   testSpecificToDate: null,
    //   testSpecificFromDate: null,
    //   isAllowReattempts: false,
    //   isUnlimitedAttempts: null,
    //   totalAttempts: 0,
    //   reattemptsDays: 0,
    //   reattemptsHours: 0,
    //   reattemptsMinutes: 0,
    //   isTestResume: false,
    //   isUnlimitedResume: false,
    //   totalResume: false,
    //   backButton: 1,
    //   isMarksResultFormat: true,
    //   isPassFailResultFormat: false,
    //   isRankResultFormat: false,
    //   resultDeclaration: 2,
    //   isShowCorrectAnswer: false,
    //   mockTestType: 1,
    //   mocktestLogoUrl: "xyz",
    //   headerTitle: "xyz",
    //   isDraft: true,
    //   language: "",
    // };
    // MockTestStore.setmocktest(initalMocktest);
    navigate("/create-Mocktest");
  };

  const editMockTest = (data) => {
    localStorage.setItem("step1Res", data?.id);
    MockTestStore.setStepCount(3);
    MockTestStore.setCurrentStep({ step: 1, from: 0 });
    navigate(ClientRoutesConstants.createMockTest, { state: { id: data?.id } });
  };

  const viewMockTest = (data) => {

    localStorage.setItem("step1Res", data?.id);
    if (data?.mockTestType[0] === "Automatic" || (Role?.role === "Staff" && Role?.userId !== data?.creationUserId)) {
      navigate(ClientRoutesConstants.viewMockAutomatic, {
        state: { id: data?.id, language: data?.languages[0] },
      });
    } else {
      MockTestStore.setStepCount(3);
      MockTestStore.setCurrentStep({ step: 3, from: 0 });
      navigate(ClientRoutesConstants.createMockTest, {
        state: {
          id: data?.id,
          publish: data.status === "Pending" ? false : true,
        },
      });
    }
  };

  const deleteFunc = async (id) => {
    const deleteData = await MocktestServices.deleteMockTest({ id: id });
    if (deleteData?.isSuccess) {
      toast.success(deleteData?.messages);
      getAllMockTest(pageNoSize?.no, pageNoSize?.size);
    } else {
      toast.error(deleteData?.messages);
    }
  };

  return (
    <div>
      <HeadTitle
        text="Mock Test"
        component2={
          <Button
            title="Add Mock Test"
            width="170px"
            height="48px"
            icon={<PlusIcon />}
            func={() => {
              addMockTes();
            }}
          />
        }
      />
      <MockTestCard applyFunc={getAllMockTest} />
      <div className="row mt-3 ">
        <div className="d-grid">
          <MockTable
            tableData={allMockTest}
            tableHead={tableHead}
            toggleEditModal={(data) => {
              editMockTest(data);
            }}
            deleteData={deleteFunc}
            viewDetail={viewMockTest}
            action={false}
            actionShowHide={{
              keyName: "mockTestType",
              index: 0,
              value: "Automatic",
            }}
          />
          {mockTestLength > 0 && (
            <Pagination
              getFunction={getAllMockTest}
              totalLength={mockTestLength}
              setPageNoSize={setPageNoSize}
              pageNoSize={pageNoSize}
              length={allMockTest.length}
            />
          )}
        </div>
      </div>
    </div>
  );
};

export default MocktestPage;
