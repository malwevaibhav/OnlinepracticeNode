import React from 'react'
import { PlusIcon } from '../../../assets/svgs/svg'
import Button from '../../../customcomponents/button/Button'
import { HeadTitle } from '../../../customcomponents/headtitle/headTitle'

export default function Subject() {
  return (
    <div>
      <HeadTitle 
       text="Subjects"
       component1={
        <Button
          title="Add Subject"
          icon={<PlusIcon />}
          width="154px"
          height="48px"  
        />
      }/>
    </div>
  )
}
