import { Formik } from 'formik';
import React, { useLayoutEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from "react-toastify";
import { EditStaffSchema } from '../../../assets/regex/schema';
import CardTitle from '../../../customcomponents/CardTitle/CardTitle';
import Checkbox from '../../../customcomponents/checkbox/Checkbox';
import CustomInput from '../../../customcomponents/customTextInput';
import { InputLabel } from '../../../customcomponents/customTextInput/indexCss';
import CustomDropdown from '../../../customcomponents/custom_Dropdown/CustomDropdown';
import Modal from '../../../customcomponents/modalPopup/CustomModal';
import InstituteServices from '../../../Services/InstituteService';
import StaffServices from '../../../Services/StaffService';
import { ThemeColors } from '../../../theme/theme';
import { removeExtraSpace } from '../../../utils/helper';
 /* eslint-disable */
export function Staffmodal(props) {
  const { dataid, setShowmodal, getAllStaffList, pageNoSize, getStaffDetail } = props;

  const [staffDetail, setStaffDetail] = useState({});
  const [permissionModule, setPermissionModules] = useState([]);
  const [Selectedmodules, setSelectedModules] = useState([]);
  const [permissionError, setPermissionError] = useState(false);
  const [institute, setInstitute] = useState([])
  const navigate = useNavigate()
 /* eslint-disable */
  useLayoutEffect(() => {
    if (dataid) {
      getStaffData(dataid);
    }
    getAllInstitute()
  }, [dataid])



  const getAllInstitute = async () => {
    const resData = await InstituteServices.getAllInstitute();
    let temp = resData?.institutes.map((data, i) => {
      return (
        resData[i] = { ...resData?.institutes[i], Title: data.instituteName }
      )
    })
    setInstitute([...temp]);
  }
  const getStaffData = async (id) => {
    const res = await StaffServices.getStaffById({
      id: id,
    });

    if (res?.isSuccess && res?.responseCode === 200) {
      setStaffDetail(res?.data);
      getPermissionModule(res?.data);

    } else {
      toast.error(res?.messages);
      navigate("/staff-list");
    }
  };

  const getPermissionModule = async (data) => {
    const modules12 = await StaffServices.getAllModules();
    let mData = [];
    modules12?.map((d) => {
      let findData = data?.modules?.findIndex(
        (el) => d.moduleId === el.moduleId
      );
      return mData.push({ ...d, isSelected: findData > -1 ? true : false });
    });
    setPermissionModules(mData);
    setSelectedModules(mData);
  };

  const changePermission = ({ index, data }) => {
    let module = { ...Selectedmodules };
    module[index].isSelected = data;
    setSelectedModules(module);

    let d = permissionModule?.findIndex((el) => el.isSelected === true);
    if (d < 0) {
      setPermissionError(true);
    } else {
      setPermissionError(false);
    }
  };


  const editStaff = async (values) => {
    // upadte data as per permission
    let permissionData = [];
    permissionModule.map((elm) => {
      return (permissionData.push({
        moduleId: elm.moduleId,
        value: elm.isSelected,
      }))
    });

    let editStaff_formated = {
      id: dataid,
      email: values?.email,
      mobileNumber: values?.mobileNumber,
      fullName: removeExtraSpace(values?.fullName),
      instituteId: values?.instituteId,
      permission: {
        modules: permissionData,
      },
    };
    if (!permissionError) {
      const res = await StaffServices.editStaff(editStaff_formated);
      if (res?.isSuccess) {
        toast.success(res?.messages);
        setShowmodal('');
        if (getStaffDetail) { return getStaffDetail() }
        getAllStaffList(pageNoSize?.no, pageNoSize?.size);
      } else {
        toast.error(res?.messages);
      }
    }
  };


  return (
    <Modal
      onRequestClose={() => setShowmodal('')}
      closeBtn={false}
      backgroundColor={ThemeColors.primary}
    >
      <Formik
        enableReinitialize
        initialValues={{
          fullName: staffDetail?.name,
          email: staffDetail?.email,
          mobileNumber: staffDetail?.mobileNumber,
          instituteId: staffDetail?.instituteId,
          instituteName: staffDetail?.instituteName,
          permission: [],
        }}
        validationSchema={EditStaffSchema()}
        onSubmit={(values) => {
          editStaff(values);
        }}

      >
        {(props) => {
          const { values, touched, errors, handleChange, handleSubmit, setFieldValue } =
            props;
          return (
            <form onSubmit={handleSubmit}>
              <div className="row m-0">
                <div className="col-12 mb-0 m-0 p">
                  <CardTitle title="Edit Personal Details" />
                </div>
                <div className="col-sm-6  m-0">
                  <CustomInput
                    name="fullName"
                    id="fullName"
                    onChange={handleChange}
                    placeholder="Ex. Rahul Sharma"
                    type="text"
                    label="Full Name"
                    value={values?.fullName}
                    height="49px"
                  />
                  {errors.fullName && touched.fullName && (
                    <div className="input-feedback">
                      {errors.fullName}
                    </div>
                  )}
                </div>
                <div className="col-sm-6 ">
                  <CustomInput
                    name="email"
                    id="email"
                    onChange={handleChange}
                    placeholder="Ex. abcd@gmail.com"
                    type="email"
                    label="Email Address"
                    value={values?.email}
                    isDisabled={true}
                    height="49px"
                  />
                  {errors.email && touched.email && (
                    <div className="input-feedback">{errors.email}</div>
                  )}
                </div>
                <div className="col-sm-6 ">
                  <CustomInput
                    name="mobileNumber"
                    id="mobileNumber"
                    onChange={handleChange}
                    placeholder="Ex. 9876543210"
                    type="text"
                    label="Mobile Number"
                    value={values?.mobileNumber}
                    height="49px"
                  />
                  {errors.mobileNumber && touched.mobileNumber && (
                    <div className="input-feedback">
                      {errors.mobileNumber}
                    </div>
                  )}
                </div>
                <div className="col-sm-6 mt-3">
                  <InputLabel>Institute</InputLabel>
                  <div className='mt-2'>
                    <CustomDropdown
                      menu={institute}
                      customClass="form-dropdown"
                      placeholder="Institute"
                      name1="instituteId"
                      name="instituteName"
                      handlefunc={() => { }}
                      setFieldValue={setFieldValue}
                      selectedEntity={values?.instituteName}
                      menuStyle={{ border: '1px solid #E3E9EE' }}
                    />
                  </div>
                  {errors.instituteId && touched.instituteId && (
                    <div className="input-feedback">{errors.instituteId}</div>
                  )}
                </div>

                <div>
                  <hr className="text-muted mt-4 mb-4" />
                </div>
                <div className="col-12  mb-4">
                  <CardTitle title="Edit Permission" />
                </div>
                <div
                  className="row m-0 d-flex flex-direction-row align-items-center"
                  style={{ columnGap: "3.1rem" }}
                >
                  {permissionModule.length > 0 &&
                    permissionModule?.map((data, ind) => {
                      return (
                        <div className="col-sm-5 d-flex align-items-center p-0 ps-1 mb-4" key={ind}>
                          <Checkbox
                            id={ind}
                            handleClick={(e) => {
                              changePermission({
                                index: ind,
                                data: e.target.checked,
                              });
                            }}
                            isChecked={data?.isSelected}
                          />{" "}
                          <label className="ms-2 pt-1" style={{ fontSize: '18px', fontFamily: 'Medium' }}>
                            {data?.moduleName}
                          </label>
                        </div>
                      );
                    })}
                  {permissionError && (
                    <div className="input-feedback">
                      {"Permission field must have at least 1 items"}
                    </div>
                  )}
                </div>
              </div>
              <div className="modal-footer mt-4 pe-2">
                <button
                  type="submit"
                  className="btn btn-primary rounded-1 me-3 ps-4 pe-4"
                  style={{ width: "122px", height: "48px" }}
                >
                  Update
                </button>
                <button
                  type="button"
                  className="btn btn-secondary rounded-1 border-0 ps-4 pe-4"
                  style={{ background: ThemeColors.secondary, width: "122px", height: "48px" }}
                  onClick={() => {
                    getPermissionModule(staffDetail);
                    setPermissionError(false);
                    setShowmodal('');
                  }}
                >
                  Cancel
                </button>
              </div>
            </form>
          );
        }}
      </Formik>
    </Modal>
  )
}


