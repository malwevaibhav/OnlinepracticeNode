import { Formik } from "formik";
import React, { useEffect, useState } from "react";
import CardTitle from "../../../customcomponents/CardTitle/CardTitle";
import CustomInput from "../../../customcomponents/customTextInput";
import Modal from "../../../customcomponents/modalPopup/CustomModal";
import { ThemeColors } from "../../../theme/theme"; /* eslint-disable */
import { StudentSchema } from "../../../assets/regex/schema";
import Button from "../../../customcomponents/button/Button";
import StudentServices from "../../../Services/StudentService";
import { removeExtraSpace } from "../../../utils/helper";
import { toast } from "react-toastify";
export function StudentModal(props) {

  const {studentId,setIsShow,getStudentList,pageNoSize} = props
  const  [studentDetail,setstudentDetail] = useState({})
   useEffect(()=>{
    getStudentDetail(studentId)
   },[studentId])


  const getStudentDetail = async(Id)=>{
    const res =  await StudentServices?.getStudentById(Id)
    if(res?.isSuccess){
     setstudentDetail(res?.data)
    }  
  }

  const editValues = async (values) => {
    let formatted_Data = {
      id:`${values?.id}`,
      email: `${values?.email}`,
      mobileNumber: `${values?.mobileNumber}`,
      password:`${values?.password}` ,
      fullName: removeExtraSpace(values?.fullName),
    };
    
    const studentRes = await StudentServices.updateStudent(formatted_Data);
    // console.log("studentRes",studentRes);
    if (studentRes?.isSuccess && studentRes?.responseCode === 200) {
      toast.success(studentRes?.messages);
      setIsShow("")
      getStudentList(pageNoSize?.no, pageNoSize?.size);
    } else {
      toast.error(studentRes?.messages);
      setIsShow("")
       getStudentList(pageNoSize?.no, pageNoSize?.size);
    }
  };
  /* eslint-disable */
  return (
    <Modal
      onRequestClose={() => setIsShow("")}
      closeBtn={false}
      backgroundColor={ThemeColors.primary}
    >
      <div className="card rounded-2 border-0 mt-2 p-3">
        <Formik
        enableReinitialize
          initialValues={{
            id:studentDetail?.id,
            email: studentDetail?.email,
            mobileNumber: studentDetail?.mobileNumber,
            password: studentDetail?.password,
            fullName: studentDetail?.name
          }}
          onSubmit={(values) => {
            editValues(values);
          }}
          validationSchema={StudentSchema()}
        >
          {(props) => {
            const { touched, errors, handleChange, handleSubmit ,values} = props;
            return (
              <form onSubmit={handleSubmit}>
                <div className="row m-0">
                  <div className="col-12 mb-0 m-0 p">
                    <CardTitle title="Edit Details" />
                  </div>
                  <div className="row m-0">
                  <div className="col-sm-6 col-md-6 col-lg-6 m-0">
                    <CustomInput
                      name="fullName"
                      id="fullName"
                      placeholder="Ex. Rahul Sharma"
                      type="text"
                      label="Full Name"
                      height="48px"
                      onChange={handleChange}
                      value={values?.fullName}
                    />
                    {errors.fullName && touched.fullName && (
                      <div className="input-feedback">{errors.fullName}</div>
                    )}
                  </div>
                  <div className="col-sm-6 col-md-6 col-lg-6">
                    <CustomInput
                      name="email"
                      id="email"
                      placeholder="Ex. abcd@gmail.com"
                      type="email"
                      label="Email Address"
                      height="48px"
                      value={values?.email}
                      onChange={handleChange}
                    />
                    {errors.email && touched.email && (
                      <div className="input-feedback">{errors.email}</div>
                    )}
                  </div>
                  </div>
                  <div className="row m-0">
                  <div className="col-sm-6 col-md-6 col-lg-6">
                    <CustomInput
                      name="password"
                      id="password"
                      placeholder="Ex.ABC123@"
                      type="password"
                      label="Password"
                      value={values?.password}
                      height="48px"
                      onChange={handleChange}
                    />
                    {errors.password && touched.password && (
                      <div className="input-feedback">{errors.password}</div>
                    )}
                  </div>
                  <div className="col-sm-6 col-md-6 col-lg-6">
                    <CustomInput
                      name="mobileNumber"
                      id="mobileNumber"
                      placeholder="Ex. 9876543210"
                      type="text"
                      label="Mobile Number"
                      height="48px"
                      value={values?.mobileNumber}
                      onChange={handleChange}
                    />
                    {errors.mobileNumber && touched.mobileNumber && (
                      <div className="input-feedback">
                        {errors.mobileNumber}
                      </div>
                    )}
                  </div>
                  </div>
                  <div className="modal-footer mt-4 pe-2">
                  <button
                  type="submit"
                  className="btn btn-primary rounded-1 me-3 ps-4 pe-4"
                  style={{ width: "122px", height: "48px" }}
                 
                >Update
                </button>
                <button
                  type="button"
                  className="btn btn-secondary rounded-1 border-0 ps-4 pe-4"
                  style={{ background: ThemeColors.secondary, width: "122px", height: "48px" }}
                  onClick={() => {
                    setIsShow('');
                  }}
                >
                  Cancel
                </button>
                  </div>
                </div>
              </form>
            );
          }}
        </Formik>
      </div>
    </Modal>
  );
}
