import { Formik } from "formik";
import React, { useEffect, useState } from "react";
import { toast } from "react-toastify";

import {
  EditInstituteSchema,
  InstituteSchema
} from "../../../assets/regex/schema";
import CustomInput from "../../../customcomponents/customTextInput";
import { InputLabel } from "../../../customcomponents/customTextInput/indexCss";
import { Heading } from "../../../customcomponents/DynamicText/Heading";
import Modal from "../../../customcomponents/modalPopup/CustomModal";
import InstituteServices from "../../../Services/InstituteService";
import { ThemeColors } from "../../../theme/theme";
import { removeExtraSpace } from "../../../utils/helper";
import { CustomUpload } from "../institute/components/Upload";

export default function InstituteModal(props) {
  const { instituteId, onRequestClose, pageNoSize, getAllInstitute } = props;
  const [instituteDetail, setInstituteDetail] = useState({ id: instituteId });
  useEffect(() => {
    if (instituteId) {
      getInstituteById(instituteId);
    }
  }, [instituteId]);

  const getInstituteById = async (id) => {
    const getbyid = await InstituteServices.getInstituteById({ id: id });
    setInstituteDetail(getbyid);
  };

  const PostIntitute = async (values) => {
    let payload = {
     
      instituteCode: values?.instituteCode,
      instituteName: removeExtraSpace(values?.instituteName),
      instituteContactNo: values?.instituteContactNo,
      instituteContactPerson: removeExtraSpace(values?.instituteContactPerson),
      instituteEmail: values?.instituteEmail,
      instituteCity: removeExtraSpace(values?.instituteCity),
      instituteAddress: values?.instituteAddress,
      instituteLogo: values?.instituteLogo,
    };
    // // if (values?.instituteContactNo?.length < 12) {
    //   payload.instituteContactNo = `${values?.instituteContactNo}`;
    // }
    if(instituteId){
    payload.id=instituteId
    }


    if (instituteId) {
      if (values.instituteLogo !== instituteDetail.instituteLogo) {
        const formData = new FormData();
        formData.append("Image", values.instituteLogo);
        const uploadImgRes = await InstituteServices.UploadImage(formData);
        if (uploadImgRes?.isSuccess) {
          toast.success(uploadImgRes?.messages);
          payload.instituteLogo = uploadImgRes.data;
          const updateRes = await InstituteServices.updateInstitute(payload);
          if (updateRes?.isSuccess) {
            onRequestClose();
            toast.success(updateRes?.messages);
            getAllInstitute(pageNoSize?.no, pageNoSize?.size)
            // window.location.reload();
          } else {
            toast.error(updateRes?.messages);
          }
        } else {
          toast.error(uploadImgRes?.messages);
        }
      } else {
        const updateRes = await InstituteServices.updateInstitute(payload);
        if (updateRes?.isSuccess) {
          onRequestClose();
          toast.success(updateRes?.messages);
          getAllInstitute(pageNoSize?.no, pageNoSize?.size)

        } else {
          toast.error(updateRes?.messages);
        }
      }
    } else {
      const formData = new FormData();
      formData.append("Image", values.instituteLogo);
      const uploadImgRes = await InstituteServices.UploadImage(formData);
      if (uploadImgRes?.isSuccess) {
        toast.success(uploadImgRes?.messages);
        payload.instituteLogo = uploadImgRes.data;
        const postResp = await InstituteServices.createInstitute(payload);
        if (postResp?.isSuccess) {
          onRequestClose();
          toast.success(postResp?.messages);
          getAllInstitute(pageNoSize?.no, pageNoSize?.size)
          // window.location.reload();
        } else {
          toast.error(postResp?.messages);
        }
      } else {
        toast.error(uploadImgRes?.messages);
      }
    }
  };
  
  return (
    <Formik
      enableReinitialize
      initialValues={{
        instituteCode: instituteDetail?.instituteCode,
        instituteName: instituteDetail?.instituteName,
        instituteContactNo: instituteDetail?.instituteContactNo,
        instituteContactPerson: instituteDetail?.instituteContactPerson,
        instituteEmail: instituteDetail?.instituteEmail,
        instituteCity: instituteDetail?.instituteCity,
        instituteAddress: instituteDetail?.instituteAddress,
        instituteLogo: instituteDetail?.instituteLogo,
      }}
      onSubmit={(values) => {
        PostIntitute({ ...values, id: instituteId });
      }}
      validationSchema={instituteId ? EditInstituteSchema() : InstituteSchema()}
    >
      {(props) => {
        const {
          touched,
          errors,
          values,
          handleChange,
          handleSubmit,
          setFieldValue,
        } = props;
        return (
          <form onSubmit={handleSubmit}>
            <Modal
              onRequestClose={onRequestClose}
              dynButton={instituteId ? "Update" : "Create"}
              dynBtnSize="120px"
              width="70vw"
              maxModalWidth="null"
              backgroundColor={ThemeColors.primary}
              me=""
            >
              <div className="row m-0 p-3 pb-0 mb-0 pe-0">
                <Heading
                  text={
                    !instituteId
                      ? "Add New Institute"
                      : "Edit Institute Details"
                  }
                />
                <div>
                  <hr />
                </div>
              </div>
              <div
                className="row m-0 p-3 pt-0 pe-0 gap-2"
                style={{ height: "625px", overflowY: "auto" }}
              >
                <div className="position-relative">
                  <CustomInput
                    name="instituteCode"
                    value={values?.instituteCode}
                    label="Institute Code"
                    placeholder="Institute Code"
                    onChange={handleChange}
                  />
                  {errors.instituteCode && touched.instituteCode && (
                    <div className="input-feedback position-absolute">
                      {errors.instituteCode}
                    </div>
                  )}
                </div>
                <div className="position-relative">
                  <CustomInput
                    name="instituteName"
                    value={values?.instituteName}
                    label="Institute Name"
                    placeholder="Institute Name"
                    onChange={handleChange}
                  />
                  {errors.instituteName && touched.instituteName && (
                    <div className="input-feedback position-absolute">
                      {errors.instituteName}
                    </div>
                  )}
                </div>
                <div className="position-relative">
                  <CustomInput
                    name="instituteAddress"
                    value={values?.instituteAddress}
                    label="Address"
                    placeholder="Address"
                    onChange={handleChange}
                  />
                  {errors.instituteAddress && touched.instituteAddress && (
                    <div className="input-feedback position-absolute">
                      {errors.instituteAddress}
                    </div>
                  )}
                </div>
                <div className="position-relative">
                  <CustomInput
                    name="instituteContactNo"
                    value={values?.instituteContactNo}
                    label="Mobile Number"
                    placeholder="Ex. 91 9876543210"
                    onChange={handleChange}
                  />
                  {errors.instituteContactNo && touched.instituteContactNo && (
                    <div className="input-feedback position-absolute">
                      {errors.instituteContactNo}
                    </div>
                  )}
                </div>
                <div className="position-relative">
                  <CustomInput
                    name="instituteEmail"
                    value={values?.instituteEmail}
                    label="Email Address"
                    placeholder="Email Address"
                    onChange={handleChange}
                  />
                  {errors.instituteEmail && touched.instituteEmail && (
                    <div className="input-feedback position-absolute">
                      {errors.instituteEmail}
                    </div>
                  )}
                </div>
                <div className="position-relative">
                  <CustomInput
                    name="instituteCity"
                    value={values?.instituteCity}
                    label="City"
                    placeholder="Enter city name"
                    onChange={handleChange}
                  />
                  {errors.instituteCity && touched.instituteCity && (
                    <div className="input-feedback position-absolute">
                      {errors.instituteCity}
                    </div>
                  )}
                </div>
                <div className="position-relative ">
                  <CustomInput
                    name="instituteContactPerson"
                    value={values?.instituteContactPerson}
                    label="Contact Person"
                    placeholder="Contact Person"
                    onChange={handleChange}
                  />
                  {errors.instituteContactPerson &&
                    touched.instituteContactPerson && (
                      <div className="input-feedback position-absolute">
                        {errors.instituteContactPerson}
                      </div>
                    )}
                </div>
                <div className="position-relative mt-3">
                  <InputLabel>Upload Logo</InputLabel>
                  <CustomUpload
                    name="instituteLogo"
                    setFieldValue={setFieldValue}
                    imgSrc={values.instituteLogo}
                    handleChange={handleChange}
                  />
                  {errors.instituteLogo && touched.instituteLogo && (
                    <div className="input-feedback position-absolute">
                      {errors.instituteLogo}
                    </div>
                  )}
                </div>
              </div>
            </Modal>
          </form>
        );
      }}
    </Formik>
  );
}
