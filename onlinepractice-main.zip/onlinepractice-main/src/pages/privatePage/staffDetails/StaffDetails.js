import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { DeleteIcon, EditIcon } from "../../../assets/svgs/svg";
import Button from "../../../customcomponents/button/Button";
import CardTitle from "../../../customcomponents/CardTitle/CardTitle";
import Checkbox from "../../../customcomponents/checkbox/Checkbox";
import CardSubHeading from "../../../customcomponents/DynamicText/cardSubHeading";
import { SubHeading } from "../../../customcomponents/DynamicText/Heading";
import { HeadTitle } from "../../../customcomponents/headtitle/headTitle";
import Modal from "../../../customcomponents/modalPopup/CustomModal";
import DeleteModal from "../../../customcomponents/modalPopup/deleteModal/DeleteModal";
import Table from "../../../customcomponents/table/Table";
import Tabs from "../../../customcomponents/Tabs/Tabs";
import AuthServices from "../../../Services/AuthService";
import StaffServices from "../../../Services/StaffService";
import { ThemeColors } from "../../../theme/theme";
import { Staffmodal } from "../custommodals/custommodal";
const tHead = ["Heading", "Description", "Category", "Last Update (Date & Time)"]
/* eslint-disable */
export default function StaffDetails() {
  const [showModal, setShowModal] = useState('');
  const [staffDetail, setStaffDetail] = useState({});
  const [tabData, setTabData] = useState([]);
  const { state } = useLocation();
  const navigate = useNavigate();
   /* eslint-disable */
  useEffect(() => {
    const getAll = () => {
      if (state?.id) {
        getStaffData();
      } else {
        navigate("/staff-list");
      }
    };
    getAll();
  }, [state?.id]);

  const getStaffData = async () => {
    const res = await StaffServices.getStaffById({
      id: state?.id,
    });
    if (res?.isSuccess && res?.responseCode === 200) {
      setStaffDetail(res?.data);
      createTabData(res?.data?.modules)
    } else {
      toast.error(res?.messages);
      navigate("/staff-list");
    }
  };

  const deleteStaffData = async () => {
    const res = await StaffServices.deleteStaff({
      id: staffDetail?.id,
    });
    if (res?.isSuccess && res?.responseCode === 200) {
      toast.success(res?.messages);
      navigate("/staff-list");
    } else {
      toast.error(res?.messages);
    }
  };

  // Resend password
  const resendPassword = async (email) => {
    const res = await AuthServices.resendPassword({
      email: email,
    });
    if (res?.isSuccess) {
      toast.success(res?.messages);
    } else {
      toast.error(res?.messages);
    }
  };

  const createTabData = (moduleData) => {
     //console.log("moduleData",moduleData);
    moduleData.map((data) => {
      if (data?.moduleName === "MockTest") {
        data.body = <Table tableHead={tHead} tableData={data?.moduleData} action={false}/>
      }
      if (data?.moduleName === "Videos") {
        data.body = <Table tableHead={tHead} tableData={data?.moduleData} action={false}/>
      }
      if (data?.moduleName === "Ebook") {
        data.body = <Table tableHead={tHead} tableData={data?.moduleData} action={false}/>
      }
      if (data?.moduleName === "Previous Year Paper") {
        data.body = <Table tableHead={["Heading", "Description", "Category", "Last Update (Date & Time)"]} tableData={data?.moduleData} action={false} />
      }
      if (data?.moduleName === "Live Classes") {
        data.body = <Table tableHead={tHead} tableData={data?.moduleData} action={false}/>
      }
    })
    setTabData(moduleData)
  }

  return (
    <div className="row m-0">
      <HeadTitle
        text="Staff Details"
        component1={
          <Button
            title="Delete Staff"
            icon={<DeleteIcon />}
            background={ThemeColors.danger}
            width="158px"
            height="48px"
            func={() => setShowModal("delete")}
          />
        }
        component2={
          <Button
            title="Edit Details"
            icon={<EditIcon />}
            width="154px"
            height="48px"
            func={() => setShowModal("edit")}
          />
        }
      />
      {staffDetail && (
        <div className="card rounded-0 border-0 p-3 mb-3">
          <div className="row m-0">
            <div className="col-12 mb-3">
              <CardTitle title="About Staff" />
            </div>
            <div
              className="col-xl-2 col-lg-3 col-md-4 col-sm-6 mb-3"
              style={{ minWidth: "fit-content" }}
            >
              <small className="m-0 text-muted">{"Staff Name"}</small>
              <CardSubHeading text={staffDetail?.name} />
            </div>
            <div
              className="col-xl-2 col-lg-3 col-md-4 col-sm-6 mb-3"
              style={{ minWidth: "fit-content" }}
            >
              <small className="m-0 text-muted">{"Email ID"}</small>
              <CardSubHeading text={staffDetail?.email} />
            </div>
            <div
              className="col-xl-2 col-lg-3 col-md-4 col-sm-6 mb-3"
              style={{ minWidth: "fit-content" }}
            >
              <small className="m-0 text-muted">{"Mobile Number"}</small>
              <CardSubHeading text={staffDetail?.mobileNumber} />
            </div>
            <div
              className="col-xl-2 col-lg-3 col-md-4 col-sm-6 mb-3"
              style={{ minWidth: "fit-content" }}
            >
              <small className="m-0 text-muted">{"Institute"}</small>
              <CardSubHeading text={staffDetail?.instituteName} />
            </div>
            <div
              className="col-xl-2 col-lg-3 col-md-4 col-sm-6 mb-3 d-flex align-items-end"
              style={{ minWidth: "fit-content" }}
            >
              <Button
                title="Resend Password"
                width="199px"
                height="48px"
                func={() => {
                  setShowModal("resendPassword");
                }}
              />
            </div>
            <div>
              <hr className="mt-3 mb-4 text-muted" />
            </div>
            <div className="col-12 mb-0 mt-1 mb-3">
              <CardTitle title="Permission" />
            </div>
            <div className="row m-0 d-flex flex-direction-row gap-5 mb-3 ">
              {staffDetail?.modules?.map((data, i) => (
                <div key={i}
                  className="col-xl-2 col-lg-4 col-md-4  col-sm-5 d-flex align-items-center p-0 ps-1 mt-2"
                  style={{ minWidth: "max-content" }}
                >
                  <Checkbox isChecked={true} />
                  <label
                    className="ms-3 pt-1"
                    style={{ fontSize: "18px", fontFamily: "Medium" }}
                  >
                    {data?.moduleName}
                  </label>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
      <HeadTitle text="Activity" />
      <div className="mt-3 ps-0">
        <Tabs data={staffDetail?.modules} getFunction={getStaffData} />
      </div>

      {showModal === "edit" && (
        <Staffmodal dataid={state?.id} setShowmodal={setShowModal} getStaffDetail={getStaffData} />
      )}

      {showModal === "delete" && (
        <DeleteModal
          onRequestClose={() => {
            setShowModal("");
          }}
          onPress={() => {
            setShowModal("");
            deleteStaffData();
          }}
          name={staffDetail?.name}
        />
      )}

      {showModal === "resendPassword" && (
        <Modal
          onRequestClose={() => setShowModal("")}
          dynButton="Send"
          dynBtnSize={"109px"}
          onPress={() => {
            setShowModal("");
            resendPassword(staffDetail?.email);
          }}
          backgroundColor={ThemeColors.primary}
        >
          <div className="row m-0">
            <SubHeading text="Resend Password" />
            <p className="mb-0 mt-3" style={{ fontFamily: "Regular" }}>
              Are you sure you want to send <strong>New password?</strong>
            </p>
          </div>
        </Modal>
      )}
    </div>
  );
}
// end of the staff
