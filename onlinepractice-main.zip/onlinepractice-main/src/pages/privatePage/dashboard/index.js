import React, { useEffect, useState } from "react";
import DashboardServices from "../../../Services/DashboradService";
import { EnrollmentIcon, SalesIcon } from "../../../assets/svgs/svg";
import BarChart from "../../../customcomponents/Chart/BarChart";
import LineChart from "../../../customcomponents/Chart/LineChart";
import {
  CardData,
  CardSubHeading,
  SubHeading,
  TileHeading,
} from "../../../customcomponents/DynamicText/Heading";
import CustomDropdown from "../../../customcomponents/custom_Dropdown/CustomDropdown";
import Carddynamic from "../../../customcomponents/dashboradcard/CardDynamic";
import { HeadTitle } from "../../../customcomponents/headtitle/headTitle";
import Table from "../../../customcomponents/table/Table";
import { ThemeColors } from "../../../theme/theme";
import DashboardStore from "../../../MobX/Dashboard";
import { ClientRoutesConstants } from "../../../shared/constant";
import { useNavigate } from "react-router-dom";
import { action } from "mobx";

const Dashboard = () => {
  const [selectedItems, setSelectedItems] = useState({
    sales: { selectedName:"Monthly", id: 3 },
    enrollment: { selectedName:"Monthly", id: 3 },
    totalSales: { selectedName:"This month", id: 3},
    studentEnrollment: { selectedName:"This month", id: 3},
    instituteCount:{ selectedName:"This month", id: 3}
  })

  const navigate= useNavigate()
   useEffect(()=>{
    // 
    getTotalSales();
    getTotalEnrollment();
    getInstituteStudent();
    getTransactionTimeline();
    getSalesGraph();
    getEnrollmentGraph()
   },[])

  const menuStyle = {
    color: ThemeColors.link,
    backgroundColor: ThemeColors.selectButton,
    border: '1px solid #C7E1FF',
    minWidth: "130px",
    fontFamily: "Medium",
    transform: "translate(0px, 83px) !important",
  };
  const menuStyle1 = {
    color: ThemeColors.link,
    backgroundColor: ThemeColors.white,
    fontFamily: "Medium",
  };

//     public enum DurationFilter
//     {
//         Today = 1,
//         Week = 2,
//         Month = 3,

//     }

  const [datasales, setDatasales] =useState({})
  const [dataenrol, setDataenrollment] =useState({})
  const [dataIns, setDataInst] =useState({})
  const [TransactionTimeline, setTransactionTimeline] =useState("")
  const [salesgraph, setSalesGraph] =useState([])
  const [Enrolment, setEnrolement] =useState([])


  const menu = [
    { Title: "Monthly" ,id:3},
    { Title: "Weekly", id:2 },
    { Title: "Today", id:1 },
  ];
  const menu1 = [
    { Title: "This month", id:3 },
    { Title: "This week", id:2 },
    { Title: "Today", id:1},
  ];

  const analysisStyle = {
    backgroundColor: ThemeColors.white,
    padding: "1rem",
    height: "4rem",
    marginBlock: "1.5rem",
  };

  const setData = async (props, entityName,data) => {
    if(data==="sales"){
      DashboardStore?.selectedsales({selectedName: entityName, id: props?.id})
      // setSelectedItems({...selectedItems,sales: { selectedName: entityName, id: props?.id }})
      getTotalSales(props?.id)
    } 
 
    if(data==="InstituteEnrollment"){
      DashboardStore?.selectedinstituteCount({selectedName: entityName, id: props?.id})
     // setSelectedItems({...selectedItems,instituteCount: { selectedName: entityName, id: props?.id }})
      getInstituteStudent(props?.id)
    }
    if(data==="enrollment"){
      DashboardStore?.selectedenrollment({selectedName: entityName, id: props?.id})
     // setSelectedItems({...selectedItems,enrollment: { selectedName: entityName, id: props?.id }})
      getTotalEnrollment(props?.id)
    }
 
  }


  const setsalesGraph=async(props, entityName,data)=>{
    if(data==="totalsales"){
      DashboardStore?.selectedtotalSales({selectedName: entityName, id: props?.id})
      //setSelectedItems({...selectedItems,totalSales: { selectedName: entityName, id: props?.id }})
      getSalesGraph(props?.id)
    }

  }

  const setEnrollGraph=async(props, entityName,data)=>{
    if(data==="studentsEnrollent"){
      DashboardStore?.selectedstudentEnrollment({selectedName: entityName, id: props?.id})
     // setSelectedItems({...selectedItems,studentEnrollment: { selectedName: entityName, id: props?.id }})
      getEnrollmentGraph(props?.id)
    }
 
  }
  
  const getTotalSales= async(Id)=>{
    const res = await DashboardServices?.getSales(!Id ? DashboardStore?.sales?.id : Id);
    if(res){
      setDatasales(res)
    }
  }


  const getTotalEnrollment= async(Id)=>{
    const res =await DashboardServices?.getTotalEnrollment(!Id ? DashboardStore?.enrollment?.id : Id);
    if(res)
    {
      setDataenrollment(res)
    }
  }

  const getInstituteStudent= async(Id)=>{
    const res =await DashboardServices?.getInstituteStudent(!Id? DashboardStore?.instituteCount?.id : Id );
    if(res)
    {
   let insData= res?.instituteStudentCourses.map((item)=>{
      return{
        instituteName: item?.instituteName,
        studentCount: item?.studentCount,
        action:true
      }
     })
     setDataInst(insData)

    }
  }

  const getTransactionTimeline= async()=>{
    const res =await DashboardServices?.getTransactionTimeline();
    if(res)
    {
      let data1=res.recentTransactions.map(item=>{return {...item,action:true}})
      let data2=res.timeLines.map(item=>{return {...item,action:true}})
     // console.log("res=>>>>",res,)

     setTransactionTimeline({...res,recentTransactions:data1,timeLines:data2})
  }
}
  const getSalesGraph= async(Id)=>{
    const res =await DashboardServices?.getSalesGraph( !Id? DashboardStore?.totalSales?.id : Id);
    if(res)
    {
      setSalesGraph(res)
      // console.log("object",res);
  }
}
  const getEnrollmentGraph= async(Id)=>{
    const res =await DashboardServices?.getEnrollmentGraph(!Id ? DashboardStore?.studentEnrollment?.id : Id);
    if(res)
    {
      setEnrolement(res)
    // console.log("object1",res);
  }
}
const getPath=(type)=>{
  
  let path
  switch (type) {
    case "MockTest":
      path=ClientRoutesConstants.viewMockAutomatic
      break;
    case "eBook":
      path=ClientRoutesConstants.purchaseEbook
      break;
    case "Video":
      path=ClientRoutesConstants.videoPurchase
      break;
    case "Paper":
      path=ClientRoutesConstants.PYPDetail
      break;
  
    default: path=''
      break;
  }
  return path
}
const viewDetail=(dataObj,title)=>{
  if (title==="Recently Added"){
    return  navigate(getPath(dataObj.type[0]),{state: { id: dataObj?.id,language:"English",toPrint:true }})
   }
   if(title==="Recent Transaction"){
     return  navigate("/translation-details",{state:{orderId:dataObj?.orderId}})
   }
}

  const Overview = [
    {
      icon: <SalesIcon />,
      title: <TileHeading text="Today's Sale" />,
      detail: <CardData text={`₹${datasales?.sale}`} />,
      dropdown: (
        <CustomDropdown
          menu={menu}
          selectoption={true}
          menuStyle={menuStyle1}
          placeholder="Monthly"
          handlefunc={setData}
          entityName="sales"
          selectedEntity={DashboardStore?.sales?.selectedName}                                            
        />
      ),
    },
    {
      icon: <SalesIcon />,
      title: <TileHeading text="Total Sale" />,
      detail: <CardData text={`₹${datasales?.totalSale}`} />,
      dropdown: "",
    },
    {
      icon: <EnrollmentIcon />,
      title: <TileHeading text="Today's Enrollment" />,
      detail: <CardData text={dataenrol?.enrollment}  />,
      dropdown: (
        <CustomDropdown
          menu={menu}
          selectoption={true}
          menuStyle={menuStyle1}
          placeholder="Monthly"
          handlefunc={setData}
          entityName="enrollment"
          selectedEntity={DashboardStore?.enrollment?.selectedName}
        />
      ),
    },
    {
      icon: <EnrollmentIcon />,
      title: <TileHeading text="Total Enrollment" />,
      detail: <CardData text={dataenrol?.totalEnrollment}  />,
      dropdown: "",
    },
  ];
  ///
  const SalesChart = {
      title: <CardSubHeading text="Total Sales" />,
      subTitle: "(Last 30 days sale)",
      detail: <LineChart salesgraph={salesgraph} id={DashboardStore?.totalSales?.id}/>,
      dropdown: (
        <CustomDropdown
          menu={menu1}
          menuStyle={menuStyle}
          selectoption={true}
          placeholder="This month"
            handlefunc={setsalesGraph}
          entityName="totalsales"
          selectedEntity={DashboardStore?.totalSales?.selectedName}
        />
      ),
      }
      const EnrollChart = {
      title: <CardSubHeading text="Students Enrollment" />,
      subTitle: "(Last 30 days students)",
      detail: <BarChart Enrolment={Enrolment} id={DashboardStore?.studentEnrollment?.id } />,
      dropdown: (
        <CustomDropdown
          menu={menu1}
          menuStyle={menuStyle}
          selectoption={true}
          placeholder="This month"
          handlefunc={setEnrollGraph}
          entityName="studentsEnrollent"
          selectedEntity={DashboardStore?.studentEnrollment?.selectedName}
        />
      ),
    }

  const tableHeadIns= ["Institute Name", "Student Count"];
  const tableHead = ["Student Name", "Date", "Amount"];
  const tableHead1 = ["Document Name", "Date", "Type"];

 
  const TableCard = [
    {
      dataTitle:"Recent Transaction",
      title: <SubHeading text="Recent Transaction" />,
      subTitle: "",
      tableHead: tableHead,
      tableData:TransactionTimeline?.recentTransactions
    },
    {
      dataTitle:"Recently Added",
      title: <SubHeading text="Recently Added" />,
      subTitle: "(Newly Added mock-test, eBook, video & previous year paper list)",
      tableHead: tableHead1,
      tableData:TransactionTimeline?.timeLines
    },
  ];

  return (
    <>
      {/* Card  */}
      <HeadTitle text="Overview" component="" />
      <div className="card-container mt-3">
        {Overview.map((item, i) => (
          <div className="cards  border-0"  key={i}>
            <Carddynamic
              key={i}
              title={item.title}
              detail={item.detail}
              icon={item.icon}
              dropdown={item.dropdown}
              height="100%"
            />
          </div>
        ))}
      </div>
      <div style={analysisStyle}>
        <SubHeading text="Analysis" />
      </div>
      <div style={{ marginBlock: "1.5rem" }} className="chart-container">
        {/* {ChartCard && ChartCard.map((data, j) => ( */}
          <div className="card border-0" key={"graph1"}>
            <Carddynamic
              key={"graph11"}
              title={SalesChart.title}
              subTitle={SalesChart.subTitle}
              detail={SalesChart.detail}
              dropdown={SalesChart.dropdown}
            />
          </div>
          <div className="card border-0" key={"graph2"}>
            <Carddynamic
              key={"graph21"}
              title={EnrollChart.title}
              subTitle={EnrollChart.subTitle}
              detail={EnrollChart.detail}
              dropdown={EnrollChart.dropdown}
            />
          </div>
        {/* ))} */}
      <div className="card border-0">
           <Carddynamic
               title= {<SubHeading text="Institute Student Counts "/>}
               subTitle="(Student enrollment by institute)"
               dropdown={
                <CustomDropdown
                menu={menu1}
                menuStyle={menuStyle}
                selectoption={true}
                placeholder="This month"
                  handlefunc={setData}
                entityName="InstituteEnrollment"
                selectedEntity={DashboardStore?.instituteCount?.selectedName}
              />}
              detail={
                <Table
                del={false}
                edit={false}
                action={false}
                tableHead={tableHeadIns}
                tableData={dataIns}
                checkbox={false}
                tHeadBackgoundColor={ThemeColors.tableHead}
                tHeadPadding="py-3 ps-2"
              />
              }
            />
           
      </div>
      </div>
   
      <div className="transaction-container mt-4">
        {TableCard.map((data, j) => (
          <div className="card-new  border-0"  key={j}>
            <Carddynamic
              key={j}
              title={data.title}
              subTitle={data.subTitle}
              link={data.dropdown}
              menuStyle={menuStyle.color}
            />
            <Table
              del={false}
              edit={false}
              tableHead={data?.tableHead}
              tableData={data?.tableData}
              dataTitle={data?.dataTitle}
              checkbox={false}
              viewDetail={viewDetail}
              tHeadBackgoundColor={ThemeColors.tableHead}
              tHeadPadding="py-3 ps-2"
            />
          </div>
        ))}
      </div>
    </>
  );
};

export default Dashboard;
