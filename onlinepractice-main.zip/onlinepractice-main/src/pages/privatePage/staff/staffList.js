import React, { useEffect, useState } from "react";
import DataExtractor from "../../../component/hooks/dataExtractor";
import Button from "../../../customcomponents/button/Button";
import MultiLevelDropDown from "../../../customcomponents/custom_Dropdown/MultiLevelDropDown";
import { HeadTitle } from "../../../customcomponents/headtitle/headTitle";
import Table from "../../../customcomponents/table/Table";
import FormCard from "./staffComp/FormCard";
import "./staffList.css";
import StaffServices from "../../../Services/StaffService";
import { PlusIcon } from "../../../assets/svgs/svg";
import { Staffmodal } from "../custommodals/custommodal";
import {
  sortArrayAlphabatically,
  sortArrayByDate,
} from "../../../utils/Arraysorting";
import { toast } from "react-toastify";
import Pagination from "../../../customcomponents/pagination/Pagination";

export const dropDown = [
  { title: "Date", tooltip: "link", active: false },
  { title: "Name", tooltip: "link", active: false },
  { title: "Institute", tooltip: "link", active: false },
];

const myStyle = {
  backgroundColor: "white",
  width: "max-content",
  display: "flex",
  height: "46px",
  padding: "9px 13px",
  paddingLeft: "18px",
};

export default function StaffList() {
  const [show, setShow] = useState(false);
  const [toggleModal, setToggleModal] = useState(false);
  const [modules, setModules] = useState([]);
  const [staffList, setStaffList] = useState([]);
  const [staffId, setStaffId] = useState();
  const [staffListLength, setStaffListLength] = useState();
  const [pageNoSize, setPageNoSize] = useState({ no: 1, size: 10 });

  const showCard = () => setShow(!show);

  /* eslint-disable */
  useEffect(() => {
    const getModules = async () => {
      const modules = await StaffServices.getAllModules();
      setModules([...modules]);
    };
    getModules();
    getAllStaffList();
  }, []);

  const getAllStaffList = async (no = 1, size = 10) => {
    if (no <= 0) {
      no = 1;
    }
    const resData = await StaffServices.getAllStaff({
      pageNumber: no,
      pageSize: size,
    });
    if (resData?.totalRecords === 1) {
      setPageNoSize({ ...pageNoSize, no: 1 })
    }
    if (!resData?.data?.staffList) {
      if ((pageNoSize.no - 1) <= 0) {
        setStaffList([])
        setStaffListLength()
        return false
      }
      else {
        setPageNoSize({ ...pageNoSize, no: pageNoSize.no - 1 })
        return getAllStaffList(pageNoSize?.no, pageNoSize?.size)
      }
    }
    if (resData?.isSuccess && resData?.responseCode === 200) {
      let td = [];
      setStaffListLength(resData?.data?.totalRecords);
      resData?.data?.staffList.map((T) => {
        let module = [];
        T?.modules?.map((n) => {
          return module.push(n?.moduleName);
        });
      
        return td.push({
          id: T?.id,
          Name: T?.name,
          Mobile: T?.mobileNumber,
          Permission: module.sort(),
          Institute: T?.instituteName,
          CreationDate: T?.creationDate,
          // CreationDate: T?.creationDate + "z",
          isSelected: false,
          action:true
        });
      
      });

      const sorted = sortArrayByDate(td, "CreationDate");
      const extracted = DataExtractor(sorted, ["isSelected"]);
      setStaffList(extracted);
    }
  };

  const onSortData = (type) => {
    if (type === "Date") {
      const sorted = sortArrayByDate(staffList, "CreationDate");
      const extracted = DataExtractor(sorted, ["isSelected"]);
      setStaffList(extracted);
    } else if (type === "Name") {
      const sorted = sortArrayAlphabatically(staffList, "Name");
      const extracted = DataExtractor(sorted, ["isSelected"]);
      setStaffList(extracted);
    } else if (type === "Institute") {
      const sorted = sortArrayAlphabatically(staffList, "Institute");
      const extracted = DataExtractor(sorted, ["isSelected"]);
      setStaffList(extracted);
    }
  };


  const deleteStaffData = async (props) => {
    const res = await StaffServices.deleteStaff({
      id: props,
    });
    if (res?.isSuccess && res?.responseCode === 200) {
      toast.success(res?.messages);
      getAllStaffList(pageNoSize?.no, pageNoSize?.size);
    } else {
      toast.error(res?.messages);
    }
  };

  return (
    <div className="mt-2">
      <div className="d-grid mb-4">
        <HeadTitle
          text="Staff List"
          component2={
            <Button
              title="Add Staff"
              width="135px"
              height="45px"
              func={showCard}
              icon={<PlusIcon />}
            />
          }
          component1={
            <MultiLevelDropDown
              menu={dropDown}
              preText="Sort By : "
              menuStyle={myStyle}
              onSort={(e) => onSortData(e)}
            />
          }
        />
        {show && (
          <div className="col-12 mb-4">
            <FormCard data={modules.sort()} getAllStaffList={getAllStaffList} pageNoSize={pageNoSize} setShow={setShow} />
          </div>
        )}

        <Table
          tableData={staffList}
          tableHead={tableHead}
          navigateTo="staff-details"
          toggleEditModal={() => {
            setToggleModal(!toggleModal);
          }}
          setId={setStaffId}
          deleteData={deleteStaffData}
        />
        {staffListLength && (
          <Pagination
            getFunction={getAllStaffList}
            totalLength={staffListLength}
            setPageNoSize={setPageNoSize}
            pageNoSize={pageNoSize}
            length={staffList.length}
          />
        )}

      </div>
      {toggleModal && (
        <Staffmodal dataid={staffId} setShowmodal={setToggleModal} getAllStaffList={getAllStaffList} pageNoSize={pageNoSize} />
      )}
    </div>
  );
}

const tableHead = [
  "Staff Name",
  "Contact",
  "Permission",
  "Institute",
  "Created At",
];
