import { Formik } from "formik";
import React, { useEffect, useState } from "react";
import { toast } from "react-toastify";
import InitValue from "../../../../assets/regex/initialValues";
import { StaffSchema } from "../../../../assets/regex/schema";
import Button from "../../../../customcomponents/button/Button";
import CardTitle from "../../../../customcomponents/CardTitle/CardTitle";
import Checkbox from "../../../../customcomponents/checkbox/Checkbox";
import CustomInput from "../../../../customcomponents/customTextInput";
import { InputLabel } from "../../../../customcomponents/customTextInput/indexCss";
import CustomDropdown from "../../../../customcomponents/custom_Dropdown/CustomDropdown";
import InstituteServices from "../../../../Services/InstituteService";
import StaffServices from "../../../../Services/StaffService";
import { removeExtraSpace } from "../../../../utils/helper";
export default function FormCard({ data, getAllStaffList, pageNoSize, setShow }) {
  const [institute, setInstitute] = useState([])

  const formatData = async (values) => {
    let m = [];
    values?.permission.map((p) => {
      return (
        m.push({
          moduleId: p,
        })
      )
    });
    let formatted_Data = {
      email: `${values?.email}`,
      mobileNumber: `${values?.mobileNumber}`,
      password: `Staff@123`,
      fullName: removeExtraSpace(values?.fullName),
      instituteId: `${values?.instituteId}`,
      permission: {
        modules: m,
      },
    };

    const staffRes = await StaffServices.createStaff(formatted_Data);
    if (staffRes?.isSuccess && staffRes?.responseCode === 200) {
      toast.success(staffRes?.messages);
      getAllStaffList(pageNoSize?.no, pageNoSize?.size);
      setShow(false)
      // window.location.reload();
    } else {
      toast.error(staffRes?.messages);
    }
  };

  useEffect(() => {
    getAllInstitute();
  }, [])

  const getAllInstitute = async () => {
    const resData = await InstituteServices.getAllInstitute();
    let temp = resData?.institutes?.map((data, i) => {
      return (
        resData[i] = { ...resData?.institutes[i], Title: data.instituteName }
      )
    })
    setInstitute(temp);

  }
  return (
    <div className="card rounded-0 border-0 p-4 ps-2">
      <Formik
        initialValues={InitValue.StaffList}
        onSubmit={(values) => {
          formatData(values);
        }}
        validationSchema={StaffSchema()}
      >
        {(props) => {
          const { touched, errors, handleChange, handleSubmit, setFieldValue, values } = props;
          return (
            <form onSubmit={handleSubmit}>
              <div className="row m-0">
                <div className="col-12 mb-0 m-0 p">
                  <CardTitle number="1" title="Create Staff" />
                </div>
                <div className="col-sm-6 col-md-6 col-lg-3 m-0">
                  <CustomInput
                    name="fullName"
                    id="fullName"
                    onChange={handleChange}
                    placeholder="Ex. Rahul Sharma"
                    type="text"
                    label="Full Name"
                    height="48px"
                  />
                  {errors.fullName && touched.fullName && (
                    <div className="input-feedback">{errors.fullName}</div>
                  )}
                </div>
                <div className="col-sm-6 col-md-6 col-lg-3">
                  <CustomInput
                    name="email"
                    id="email"
                    onChange={handleChange}
                    placeholder="Ex. abcd@gmail.com"
                    type="email"
                    label="Email Address"
                    height="48px"
                  />
                  {errors.email && touched.email && (
                    <div className="input-feedback">{errors.email}</div>
                  )}
                </div>
                <div className="col-sm-6 col-md-6 col-lg-3">
                  <CustomInput
                    name="mobileNumber"
                    id="mobileNumber"
                    onChange={handleChange}
                    placeholder="Ex. 9876543210"
                    type="text"
                    label="Mobile Number"
                    height="48px"
                  />
                  {errors.mobileNumber && touched.mobileNumber && (
                    <div className="input-feedback">{errors.mobileNumber}</div>
                  )}
                </div>
                <div className="col-sm-6 col-md-6 col-lg-3 mt-3">
                  <InputLabel>Institue</InputLabel>

                  <div className="mt-1">
                    <CustomDropdown
                      menu={institute}
                      customClass="form-dropdown"
                      placeholder="Institute"
                      name1="instituteId"
                      name="institute"
                      handlefunc={(data) => { setFieldValue("instituteId", data.id);setFieldValue("institute", data.Title) }}
                      // setFieldValue={setFieldValue}
                      selectedEntity={values?.institute}
                      menuStyle={{ border: '1px solid #E3E9EE' }}

                    />
                  </div>
                  {errors.institute && touched.institute && (
                    <div className="input-feedback">{errors.institute}</div>
                  )}
                </div>
                <div className="col-12 mt-4">
                  <CardTitle number="2" title="Permission" />
                </div>
                <div className="row m-0 d-flex flex-direction-row gap-2 mb-3 align-items-center">
                  {data?.map((module, i) => (
                    <div className="col-xl-2 col-lg-4 col-md-4  col-sm-5 d-flex align-items-center p-0 pt-1 ps-1 mt-2" style={{ minWidth: "max-content" }} key={i}>
                      <Checkbox
                        id={i}

                        name={"permission"}
                        handleClick={handleChange}
                        value={module?.moduleId}
                      />{" "}
                      <label className="ms-4 pt-1" style={{ fontSize: '18px', fontFamily: 'Medium' }}>
                        {module?.moduleName}
                      </label>
                    </div>
                  ))}
                  {errors.permission && touched.permission && (
                    <div className="input-feedback ps-1 p-0">
                      {errors.permission}
                    </div>
                  )}
                  <div className="col-sm-5 col-md-2 d-flex align-items-center p-0 ps-1 mt-3">
                    <Button
                      type="submit"
                      title="Save"
                      width="108px"
                    />
                  </div>
                </div>
              </div>
            </form>
          );
        }}
      </Formik>
    </div>
  );
}
