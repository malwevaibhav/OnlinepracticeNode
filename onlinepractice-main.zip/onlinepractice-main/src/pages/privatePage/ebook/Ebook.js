import React, { useEffect, useState } from "react";
import { pdfjs } from "react-pdf";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { PlusIcon } from "../../../assets/svgs/svg";
import Button from "../../../customcomponents/button/Button";
import MultiLevelDropDown from "../../../customcomponents/custom_Dropdown/MultiLevelDropDown";
import { HeadTitle } from "../../../customcomponents/headtitle/headTitle";
import Pagination from "../../../customcomponents/pagination/Pagination";
import EbookTable from "../../../customcomponents/table/ebookTable";
import AuthStore from "../../../MobX/Auth";
import EbookStore from "../../../MobX/Ebook";
import QuestionStore from "../../../MobX/Question";
import EbookServices from "../../../Services/EbookService";
import { sortArrayAlphabatically } from "../../../utils/Arraysorting";
import EbookCard from "../ebook/component/ebookCard";
export const dropDown = [
  { title: "Title", tooltip: "link", active: false },
];
const tableHead = [
  "Ebook Title",
  "Subject",
  "Topic ",
  "Author ",
  "Price",
  "Institute",
];
 /* eslint-disable */
const Ebook = () => {
  const Role= AuthStore?.user?.user;
  const [Errorcard, setErrorcard] = useState({
    examType: false,
    courseType: false,
    subCourseType: false,
    subjectType: false,
    instituteType: false,
    writerType: false
  })

  pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.js`;
  const navigate = useNavigate();
  const [pageNoSize, setPageNoSize] = useState({ no: 1, size: 10 });
  const [allEbookList, setallEbookList] = useState([]);
  const [Ebooklength, setEbooklength] = useState("");
  const [Ebookshowlength, setEbookshowlength] = useState("");
  const [show,] = useState(false);
  const [toggle, setToggle] = useState(false);

  const myStyle = {
    backgroundColor: "white",
    width: "max-content",
    display: "flex",
    height: "46px",
    padding: "9px 13px",
    paddingLeft: "18px",
  };

  useEffect(() => {
    if (EbookStore?.ebookselectedids.subjectCategory &&
      EbookStore?.ebookselectedids.instituteId || Role?.instituteId &&
      EbookStore?.ebookselectedids.writer
      ) {
      getAllEbook()
    }
  }, [])

  const addEbook = () => {
    navigate("/add-newbook");
  };


  const getAllEbook = async (no = 1, size = 10) => {
    setPageNoSize({ no: 1, size: 10 })
    let postdata = {
      subjectCategoryId: EbookStore?.ebookselectedids.subjectCategory,
      topicId: EbookStore?.ebookselectedids.topicId || "00000000-0000-0000-0000-000000000000",
      instituteId: EbookStore?.ebookselectedids.instituteId || Role?.instituteId,
      writerName: QuestionStore?.selectedItemsNw.Writerlist?.selectedName,
      pageNumber: no,
      pageSize: size
    }
    const resData = await EbookServices.getAllEbook(postdata);
    if (resData?.isSuccess) {
      let list = resData?.data?.ebooks?.map((elm, i) => (
        !!elm?.ebookPdfUrl &&
        {
          id: elm?.id,
          ebookTitle: elm?.ebookTitle,
          subject: elm?.subjectName,
          topic: elm?.topicName,
          author: elm?.authorName,
          price: elm?.price,
          institute: elm?.instituteName,
          creatorUserId:elm?.creatorUserId
        }


      ));
      setallEbookList(list);
      setEbookshowlength(list.length);
      setEbooklength(resData?.data?.totalRecords);
      return list.length
    }
    if(!resData?.isSuccess){
      setallEbookList([]);
      setEbookshowlength(0);
    }
    if (!resData?.data?.ebooks) {

      setPageNoSize({ ...pageNoSize, no: pageNoSize.no - 1 })
      if ((pageNoSize.no - 1) <= 0) {
        setPageNoSize({ ...pageNoSize, no: pageNoSize.no - 1 })
        setallEbookList([])
        setEbooklength()
        return false
      }
      else {
        setPageNoSize({ ...pageNoSize, no: pageNoSize.no - 1 })
        return getAllEbook(pageNoSize?.no - 1, pageNoSize?.size)
      }
    }
  }

  const deleteFunc = async (id) => {
    const deleteData = await EbookServices.deleteEbook({ id: id });
    if (deleteData?.isSuccess) {
      toast.success(deleteData?.messages);
      getAllEbook(pageNoSize?.no, pageNoSize?.size);
    } else {
      toast.error(deleteData?.messages);
    }

  };

  const editEbookDetail = async (data) => {
    navigate("/add-newbook", { state: { id: data?.id } });
  }

  const onSortData = (type) => {
    // need to check
    if (type === "Title") {
      const sorted = sortArrayAlphabatically(allEbookList, "ebookTitle");
      setallEbookList(sorted)
    }
    setToggle(!toggle)
  }
  return (
    <div>
      <HeadTitle
        text="Ebook"
        component3={
          <Button
            title="Add Ebook"
            width="135px"
            height="45px"
            func={addEbook}
            icon={<PlusIcon />}
          />
        }
        component1={
          <MultiLevelDropDown
            menu={dropDown}
            preText="Sort By :"
            menuStyle={myStyle}
            onSort={(e) => onSortData(e)}
          />
        }
      />
      <EbookCard show={show} getAllEbook={getAllEbook} Errorcard={Errorcard} setErrorcard={setErrorcard} />
      <div className="row mt-3">

        <div className="d-grid">
            <EbookTable
              tableData={allEbookList}
              tableHead={tableHead}
              navigateTo="purchase-Ebook"
              deleteData={deleteFunc}
              toggleEditModal={(data) => {
                editEbookDetail(data)
              }}
            />
          {Ebooklength > 0 && (
            <Pagination
              getFunction={getAllEbook}
              totalLength={Ebooklength}
              setPageNoSize={setPageNoSize}
              pageNoSize={pageNoSize}
              length={Ebookshowlength}
            />
          )}
        </div>
      </div>

    </div>
  );
};

export default Ebook;







