import { toJS } from "mobx";
import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import Button from "../../../../customcomponents/button/Button";
import { InputLabel } from "../../../../customcomponents/customTextInput/indexCss";
import CustomDropdown from "../../../../customcomponents/custom_Dropdown/CustomDropdown";
import AuthStore from "../../../../MobX/Auth";
import CourseStore from "../../../../MobX/Courses";
import EbookStore from "../../../../MobX/Ebook";
import PatternStore from "../../../../MobX/Pattern";
import QuestionStore from "../../../../MobX/Question";
import EbookServices from "../../../../Services/EbookService";
import InstituteServices from "../../../../Services/InstituteService";
import { checkDefault } from "../../../../utils/helper";
const EbookCard = ({ show, getAllEbook, Errorcard, setErrorcard, setDisable }) => {
  const Role = AuthStore?.user?.user;
  const [toggle, setToggle] = useState(false);
  const [institute, setInstitute] = useState([]);
  const location = useLocation()
  /* eslint-disable */

  let tempList = toJS(CourseStore?.topicList);
  tempList.push({
    id: "00000000-0000-0000-0000-000000000000",
    Title: "None",
    label: "SubTopic",
  });
  const topicList = tempList;

  useEffect(() => {
    if(Role?.role==="Admin"){
      getAllInstitute();
    }
    EbookServices.getCourseFilterData({ label: "Exam" });
  }, []);
  {
    /* new code updated error  */
  }

  const getAllInstitute = async () => {
    const resData = await InstituteServices.getAllInstitute();
    let temp = resData?.institutes?.map((data) => {
      return {
        id: data?.id,
        Title: data?.instituteName,
        label: "Institute",
      };
    });
    setInstitute(temp);
  };

 

  const checkValidate = () => {
    if (!EbookStore.ebookselectedids.examTypeId) {
      return setErrorcard({ ...Errorcard, examType: true });
    }
    if (!EbookStore.ebookselectedids.courseId) {
      return setErrorcard({ ...Errorcard, courseType: true });
    }
    if (!EbookStore.ebookselectedids.subCourseId) {
      return setErrorcard({ ...Errorcard, subCourseType: true });
    }
    if (!EbookStore.ebookselectedids.subjectCategory) {
      return setErrorcard({ ...Errorcard, subjectType: true });
    }
    if (!EbookStore.ebookselectedids.instituteId && Role?.role === "Admin") {
      return setErrorcard({ ...Errorcard, instituteType: true });
    }
    if (!EbookStore.ebookselectedids.writer) {
      return setErrorcard({ ...Errorcard, writerType: true });
    }
  };
  const getDropdownEbook = async (props, entityName) => {
    if (props?.label === "Course") {
      CourseStore.setSubCourse([]);
      QuestionStore.setSelectedItemsNw({
        selectedName: "Exam",
        props,
        entityName,
      });
      EbookStore.setEbookSelectedid({ examTypeId: props?.id });
      setErrorcard && setErrorcard({ ...Errorcard, examType: false });
    }
    if (props?.label === "SubCourse") {
      QuestionStore.setSelectedItemsNw({
        selectedName: "Course",
        props,
        entityName,
      });
      EbookStore.setEbookSelectedid({ courseId: props?.id });
      setErrorcard && setErrorcard({ ...Errorcard, courseType: false });
    }
    if (props?.label === "Subject") {
      QuestionStore.setSelectedItemsNw({
        selectedName: "SubCourse",
        props,
        entityName,
      });
      EbookStore.setEbookSelectedid({ subCourseId: props?.id });
      setErrorcard && setErrorcard({ ...Errorcard, subCourseType: false });
    }
    if (props?.label === "Topic") {
      QuestionStore.setSelectedItemsNw({
        selectedName: "Subject",
        props,
        entityName,
      });
      EbookStore.setEbookSelectedid({ subjectCategory: props?.id });
      setErrorcard && setErrorcard({ ...Errorcard, subjectType: false });
    }
    if (props?.label === "SubTopic") {
      QuestionStore.setSelectedItemsNw({
        selectedName: "Topic",
        props,
        entityName,
      });
      EbookStore.setEbookSelectedid({ topicId: props?.id });
      setDisable && setDisable(false)
    }
    if (props?.label === "Institute") {

      PatternStore.setSelectedItemsPattern({
        selectedName: "Institute",
        props,
        entityName,
      });
      EbookStore?.setEbookSelectedid({ instituteId: props.id });
      setErrorcard && setErrorcard({ ...Errorcard, instituteType: false });
      await EbookServices?.getAllauthor({
        subjectCategoryId: QuestionStore?.selectedItemsNw?.SubjectList?.id,
        topicId: QuestionStore?.selectedItemsNw?.TopicList?.id || "00000000-0000-0000-0000-000000000000",
      });
    }
    Role?.role === "Staff" &&
      QuestionStore?.selectedItemsNw?.SubjectList?.id &&
      (await EbookServices?.getAllauthor({
        subjectCategoryId: QuestionStore?.selectedItemsNw?.SubjectList?.id,
        topicId:
          QuestionStore?.selectedItemsNw?.TopicList?.id ||
          "00000000-0000-0000-0000-000000000000",
      }));
    if (props?.label === "Writer") {
      QuestionStore.setSelectedItemsNw({
        selectedName: "Writer",
        props,
        entityName,
      });
      EbookStore?.setEbookSelectedid({ writer: entityName });
      setErrorcard && setErrorcard({ ...Errorcard, writerType: false });
    }
    setToggle(!toggle);
    return EbookServices?.getCourseFilterData(props);
  };
  
  return (
    <div>
      <form className="card px-3 pb-4 border-0 mt-3">
        <div className="row m-0 gy-3">
          <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
            <InputLabel>Exam Type</InputLabel>
            <CustomDropdown
              menuStyle={{ border: "1px solid #E3E9EE" }}
              customClass="form-dropdown"
              placeholder="Select Exam"
              handlefunc={getDropdownEbook}
              menu={CourseStore?.examList}
              selectedEntity={
                QuestionStore.selectedItemsNw.examList.selectedName
              }
              disable={location?.state?.id}
            />
            {Errorcard?.examType && (
              <span className=" ms-2 input-feedback">
                Exam Type is required{" "}
              </span>
            )}
          </div>
          <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
            <InputLabel>Course</InputLabel>
            <CustomDropdown
              menuStyle={{ border: "1px solid #E3E9EE" }}
              customClass="form-dropdown"
              placeholder="Select Course"
              isSelect={true}
              handlefunc={getDropdownEbook}
              menu={CourseStore?.course}
              selectedEntity={
                QuestionStore.selectedItemsNw.courseList.selectedName
              }
              disable={location?.state?.id}
            />
            {Errorcard?.courseType && (
              <span className="ms-2  input-feedback">Course is required </span>
            )}
          </div>
          <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
            <InputLabel>Sub-course</InputLabel>
            <CustomDropdown
              menuStyle={{ border: "1px solid #E3E9EE" }}
              customClass="form-dropdown"
              placeholder="Select SubCourse"
              isSelect={true}
              handlefunc={getDropdownEbook}
              menu={CourseStore?.subcourse}
              selectedEntity={
                QuestionStore.selectedItemsNw.SubCourseList.selectedName
              }
              disable={location?.state?.id}
            />
            {Errorcard?.subCourseType && (
              <span className=" ms-2  input-feedback">
                SubCourse is required{" "}
              </span>
            )}
          </div>
          <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
            <InputLabel>Subject</InputLabel>
            <CustomDropdown
              menuStyle={{ border: "1px solid #E3E9EE" }}
              customClass="form-dropdown"
              placeholder="Select Subject"
              isSelect={true}
              handlefunc={getDropdownEbook}
              menu={CourseStore?.subjectList}
              selectedEntity={
                QuestionStore.selectedItemsNw.SubjectList.selectedName
              }
              disable={location?.state?.id}
            />
            {Errorcard?.subjectType && (
              <span className="ms-2 input-feedback">Subject is required </span>
            )}
          </div>

          <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
            <InputLabel>
              Topic <span>(optional)</span>{" "}
            </InputLabel>
            <CustomDropdown
              menuStyle={{ border: "1px solid #E3E9EE" }}
              customClass="form-dropdown"
              placeholder="Select Topic"
              isSelect={true}
              handlefunc={getDropdownEbook}
              menu={topicList}
              selectedEntity={
                QuestionStore.selectedItemsNw.TopicList.selectedName
              }
            />
          </div>

          {!show && (
            <>
              <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
                <InputLabel>Institute</InputLabel>
                <CustomDropdown
                  menuStyle={{ border: "1px solid #E3E9EE" }}
                  isSelect={true}
                  menu={institute}
                  customClass="form-dropdown"
                  placeholder="Select Institute"
                  handlefunc={getDropdownEbook}
                  selectedEntity={
                    Role?.role == "Admin"
                      ? PatternStore.selectedItemsPattern.Institute.selectedName
                      : Role?.instituteName
                  }
                  disable={Role?.role === "Staff" || location?.state?.id}
                />
                {Errorcard?.instituteType && (
                  <span className="ms-2 input-feedback">
                    Institute is required{" "}
                  </span>
                )}
              </div>
              <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
                <InputLabel>Writer</InputLabel>
                <CustomDropdown
                  menuStyle={{ border: "1px solid #E3E9EE" }}
                  isSelect={true}
                  menu={EbookStore?.writer}
                  customClass="form-dropdown"
                  placeholder="Select Writer"
                  handlefunc={getDropdownEbook}
                  selectedEntity={
                    QuestionStore.selectedItemsNw.Writerlist.selectedName
                  }
                  disable={location?.state?.id}
                />
                {Errorcard?.writerType && (
                  <span className="ms-2 input-feedback">
                    Writer is required{" "}
                  </span>
                )}
              </div>
              <div className="w-25">
                <Button
                  title="Apply"
                  width="114px"
                  height="48px"
                  marginTop="25px"
                  func={(e) => {
                    checkDefault(e);
                    getAllEbook();
                    checkValidate();
                  }}
                />
              </div>
            </>
          )}
        </div>
      </form>
    </div>
  );
};

export default EbookCard;
