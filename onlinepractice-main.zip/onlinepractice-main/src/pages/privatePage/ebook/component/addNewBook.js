import React, { useState } from 'react'
import { HeadTitle } from '../../../../customcomponents/headtitle/headTitle'
import "../ebook.css"
import BookDetails from './bookDetails'
import EbookCard from './ebookCard'
const AddNewBook = () => {
    const [show,] = useState(true);
    const [disable, setDisable] = useState(true)
   
    const [Errorcard, setErrorcard] = useState({
        examType: false,
        courseType: false,
        subCourseType: false,
        subjectType: false
    })
    return (
        <div>
            <HeadTitle
                text="Add New Ebook" />
            <div className="mb-3">
                {/* new code updated error  */}
                <EbookCard show={show} Errorcard={Errorcard} setErrorcard={setErrorcard}  setDisable={setDisable}/>
            </div>

            <div>
                {/* new code updated error  */}
                <BookDetails Errorcard={Errorcard} setErrorcard={setErrorcard} disable={disable} setDisable={setDisable}/>
            </div>
        </div>
    )
}

export default AddNewBook