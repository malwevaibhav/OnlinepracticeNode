import React, { useEffect, useRef, useState } from "react";
import { UploadIcon } from "../../../../assets/svgs/svg";
import Button from "../../../../customcomponents/button/Button";
import { CardData } from "../../../../customcomponents/DynamicText/Heading";

function removeItems(arr, item) {
    for (var i = 0; i < item; i++) {
        arr.pop();
    }
}

function useFiles({ initialState = [], maxFiles }) {
    const [state, setstate] = useState(initialState);
    function withBlobs(files) {
        const destructured = [...files];
        if (destructured.length > maxFiles) {
            const difference = destructured.length - maxFiles;
            removeItems(destructured, difference);
        }
        const blobs = destructured
            .map(file => {
                if (file.type.includes("image")) {
                    file.preview = URL.createObjectURL(file);
                    return file;
                }
                return null;
            })
            .filter(elem => elem !== null);

        setstate(blobs);
    }
    return [state, withBlobs];
}

function Upload({ onDrop, maxFiles = 1 }) {
    const [isFile, setIsFile] = useState(true);
    const [over, setover] = useState(false);
    const [files, setfiles] = useFiles({ maxFiles });
    const $input = useRef(null);
    useEffect(() => {
        if (onDrop) {
            onDrop(files);
        }

    }, [files, onDrop]);
    const reset = () => {
        setIsFile(true)
        setfiles('');
    }
    return (
        <>
            <div className="row m-0 text-center ps-5 pe-5">
                <CardData text="Upload" />
                {isFile &&
                    <div className="card border-0">
                        <div style={{ margin: '10px' }} className="mb-2 mt-4"
                            onClick={() => {
                                $input.current.click();

                            }}
                            onDrop={e => {
                                e.preventDefault();
                                e.persist();
                                // setfiles(e.dataTransfer.files);
                                setIsFile(false);
                                setover(false);
                            }}
                            onDragOver={e => {
                                e.preventDefault();
                                setover(true);
                            }}
                            onDragLeave={e => {
                                e.preventDefault();
                                setover(false);
                            }}

                        >
                            <div className={over ? "upload-container over" : "upload-container"}>
                                <UploadIcon />
                                <h5 className="SemiBold mt-3 mb-3">Drag and drop your file here</h5>
                                <h5 className="SemiBold mt-3 mb-3">Or</h5>
                                <input
                                    style={{ display: "none" }}
                                    type="file"
                                    accept="image/*"
                                    ref={$input}
                                    onChange={e => {
                                        setfiles(e.target.files);
                                        setIsFile(false);
                                    }}
                                    multiple={maxFiles > 1}
                                />
                                <div className="d-flex justify-content-center">
                                    <Button title="Browse File" width="152px"  />
                                </div>
                            </div>
                        </div>
                    </div>
                }
                {!isFile && files.map(file => (
                    <>
                        <div className="blob-container">
                            <img key={file.name + "file"} src={file.preview} alt="your file" width={"60%"} />
                        </div>
                        <div className="blob-buttons mt-3 d-flex justify-content-center">
                            <Button title="Save" width="20%" />
                            <button type="reset" className="btn btn-secondary rounded-1 ms-2" onClick={reset} > Reset</button >
                        </div>
                    </>
                ))}
            </div>


        </>
    );
}

export { Upload };

