import React, { useEffect, useRef, useState } from "react";
import { toast } from "react-toastify";
import { UploadIcon } from "../../../../assets/svgs/svg";
import "../ebook.css";
function UploadThumbnail({
    onDrop,
    maxFiles = 1,
    name,
    setFieldValue,
    setfiles,
    setPdfSrc,
    files,
    isEdit,
    accept,
    PDFImage,
    setError,
    Error,
    updateState,
    setDisable
}) {
    const [over, setover] = useState(false);
    const [extension, setextension] = useState("")
    const $input = useRef(null);
    useEffect(() => {
        if (onDrop) {
            onDrop(files);
        }
    }, [onDrop, files]);

    const ImgUpload = async (file) => {
        if (accept === "application/pdf") {
            if (
                file[0]?.type === "image/png" ||
                file[0]?.type === "image/jpg" ||
                file[0]?.type === "image/jpeg" ||
                file[0]?.type === "image/bmp" ||
                file[0]?.type === ".mp4"
            ) {
                toast.error("file format is not valid");
            }
            setextension(file[0]?.type);
            setFieldValue(file[0]);
            setPdfSrc(URL.createObjectURL(file[0]));
            updateState({ PdfPreview: file[0]?.name });
            setError({ ...Error, PdfPreview: false })
        } else if (accept === "image/png, image/jpeg, image/jpg, image/bmp,.mp4") {
            if (file[0]?.type === "application/pdf") {
                toast.error("file format is not valid");
            }
            setextension(file[0]?.type);
            setFieldValue(file[0]);
            setfiles(URL.createObjectURL(file[0]));
        }
    };
    return (
        <>
            <div className="row m-0 mt-2">
                {!isEdit && (
                    PDFImage ?
                        <>
                            <div className="blob-container d-flex align-items-center ps-0 mt-2">

                                {extension === "application/pdf" &&
                                    <embed
                                        src={PDFImage}
                                        width="200"
                                        height="200" />
                                }
                                <div
                                    className="ms-4"
                                    onClick={() => {
                                        $input.current.click();
                                    }}
                                >
                                    <input
                                        name={name}
                                        onChange={(e) => {
                                            ImgUpload(e.target.files);
                                        }}
                                        multiple={maxFiles > 1}
                                        style={{ display: "none" }}
                                        type="file"
                                        accept={accept}
                                        ref={$input}
                                    />

                                    <div className="BrouseFiel">
                                        <div className="d-flex justify-content-center mt-2 me-5" >
                                            <u>Change</u>
                                        </div>
                                    </div>


                                </div>
                                {/* <div className=" mt-1">
                                    <u style={{ color: ThemeColors.secondary, fontSize: '14px' }} onClick={(e) => { checkDefault(e); setPDFImage(null); updateState({ PdfPreview: "" }); setError({ ...Error, PdfPreview: true }) }}>Cancel</u>
                                </div> */}
                            </div>
                            {Error?.PdfPreview && <span className="input-feedback">Pdf is required </span>}
                        </>
                        :
                        <>
                            <div
                                className="card rounded-3 text-center"
                                style={{
                                    backgroundColor: "#ECF5FF", border: "1px dashed #ABB6C0"
                                }}
                            >
                                <div
                                    onClick={() => {
                                        $input.current.click();
                                    }}
                                    onDrop={(e) => {
                                        e.preventDefault();
                                        e.persist();
                                        ImgUpload(e.dataTransfer.files);
                                        setover(false);
                                    }}
                                    onDragOver={(e) => {
                                        e.preventDefault();
                                        setover(true);
                                    }}
                                    onDragLeave={(e) => {
                                        e.preventDefault();
                                        setover(false);
                                    }}
                                >
                                    <div
                                        className={`${over ? "upload-container over" : "upload-container"
                                            } mt-4`}
                                    >
                                        <UploadIcon width="35" height="25" />
                                        <h6 className="SemiBold mt-2 d-flex justify-content-center">
                                            Drag and drop your file here or &nbsp;
                                            <p className="text-primary pointer">Browse</p>
                                        </h6>
                                        <input
                                            name={name}
                                            style={{ display: "none" }}
                                            type="file"
                                            accept={accept}
                                            ref={$input}
                                            onChange={(e) => {
                                                ImgUpload(e.target.files);
                                                setDisable && setDisable(false)
                                            }}
                                            multiple={maxFiles > 1}
                                        />

                                    </div>
                                </div>

                            </div>
                            {Error?.PdfPreview && <span className="input-feedback">Pdf is required </span>}
                        </>
                )}
                {isEdit === true && (
                    <div className="blob-container d-flex align-items-center ps-0 mt-2">
                        <img
                            src={PDFImage}
                            width="200"
                            height="200"
                            alt="" />

                        <div
                            className="ms-4"
                            onClick={() => {
                                $input.current.click();
                            }}
                        >
                            <input
                                name={name}
                                onChange={(e) => {
                                    ImgUpload(e.target.files);
                                    setDisable(false)
                                }}
                                multiple={maxFiles > 1}
                                style={{ display: "none" }}
                                type="file"
                                accept={accept}
                                ref={$input}
                            />
                            <div className="BrouseFiel d-flex mt-1" >
                                <u>Change</u>
                            </div>
                        </div>

                     

                    </div>
                )}
            </div>
        </>
    );
}

export { UploadThumbnail };

