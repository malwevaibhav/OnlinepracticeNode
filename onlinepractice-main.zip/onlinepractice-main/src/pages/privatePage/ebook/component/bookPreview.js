import React from "react";
import { useNavigate } from "react-router-dom";
import { DataNotFound2 } from "../../../../assets/svgs/svg";
import Button from "../../../../customcomponents/button/Button";
import PatternStore from "../../../../MobX/Pattern";
import { ClientRoutesConstants } from "../../../../shared/constant";
import '../ebook.css';
const BookPreview = ({ disable, bookDetails, files, saveData, isEdit, updateData, isDetailView, PDFImage }) => {
    
    const navigate = useNavigate();
    const languageBox = {
        padding: '2px 10px',
        width: 'min-content',
        height: '29px',
        borderRadius: '3px',
        color: '#0075ff',
        margin: "0",
        background: '#ecf5ff',
        border: '1px solid #d0e6ff',
    }
    
    return (
        <div>
            {" "}
            <div>
                <div className="card  border-0  mt-25 " style={{
                    backgroundColor: isDetailView ? '#ECF5FF' : '#FFFFFF',
                }}>
                    <div className="pt-30 ps-4 videoHead">Ebook Preview</div>

                    {!isDetailView ? (
                        <>
                            <hr></hr>
                            <div className="SettingPreviewContainer">
                                <DataNotFound2 />
                            </div>
                        </>
                    ) : (
                        <>
                            <div className="p-30">
                                <hr></hr>

                                {PDFImage && (
                                    <div>

                                        <img
                                            style={{
                                                width: "200px",
                                                objectFit: "contain",
                                                borderRadius: "5px",
                                            }}
                                            accept="image/png, image/jpeg, image/jpg, image/bmp"
                                            key={files + "file"}
                                            src={PDFImage}
                                            alt="your file"
                                        />
                                    </div>

                                )}
                                {bookDetails.EbookTitle !== "" && (
                                    <div className="mt-2">
                                        <div className="ebookprevewhead pt-2">Test Name</div>
                                        <div className="ebookPrevewText pb-4 mt-2">
                                            {bookDetails.EbookTitle}
                                        </div>
                                    </div>
                                )}

                                {bookDetails.Description !== "" && (
                                    <div>
                                        <div className="ebookprevewhead ">Description</div>
                                        <div className="ebookPrevewText pb-4  mt-2">
                                            {bookDetails.Description}
                                        </div>
                                    </div>
                                )}
                                {(bookDetails.Institute !== "" || PatternStore.selectedItemsPattern.Institute.selectedName) && (
                                    <div>
                                        <div className="ebookprevewhead "> Institute</div>
                                        <div className="ebookPrevewText pb-4  mt-2">
                                            {bookDetails.Institute || PatternStore.selectedItemsPattern.Institute.selectedName}
                                        </div>
                                    </div>
                                )}
                                {bookDetails.AuthorName !== "" && (
                                    <div>
                                        <div className="ebookprevewhead ">Author</div>
                                        <div className="ebookPrevewText pb-4  mt-2">
                                            {bookDetails.AuthorName}
                                        </div>
                                    </div>
                                )}
                                {bookDetails.Language !== "" && (
                                    <div>
                                        <div className="ebookprevewhead">Language</div>
                                        <div className="pb-4  mt-2" style={languageBox}>
                                            {bookDetails.Language}
                                        </div>
                                    </div>
                                )}

                                {/* {bookDetails.PriceSetting !== "" && ( */}
                                    <div className="mt-3">
                                        <div className="ebookprevewhead "> Price</div>
                                        <div className="ebookPrevewText pb-4  mt-2">
                                            &#x20b9; {bookDetails.PriceSetting || 0}
                                        </div>
                                    </div>
                                {/* )} */}
                            </div>
                        </>
                    )}
                </div>

                <div className="f gap16  f-flexEnd mt-3">
                    <div className="Settingbtn ">
                        <Button
                            background="rgb(171, 182, 192)"
                            title="Cancel"
                            width="137px"
                            type="submit"
                            func={(e) => {
                                e.preventDefault();
                                navigate(ClientRoutesConstants.ebook);
                            }}
                        /></div>
                    {
                        isEdit ?
                            <Button title="Update" width="162px" height="48px" func={updateData} disable={disable}/> :
                            <Button title="Continue" width="162px" height="48px" func={saveData} />

                    }

                </div>
            </div>

        </div>

    );
};

export default BookPreview;
