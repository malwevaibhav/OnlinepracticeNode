import React, { useEffect, useState } from "react";
import { pdfjs } from "react-pdf";
import { useLocation, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { DeleteIcon, EditIcon } from "../../../../assets/svgs/svg";
import { downloadpdf } from "../../../../component/hooks/downloadPDF";
import Button from "../../../../customcomponents/button/Button";
import CustomInput from "../../../../customcomponents/customTextInput";
import { InputLabel } from "../../../../customcomponents/customTextInput/indexCss";
import CustomDropdown from "../../../../customcomponents/custom_Dropdown/CustomDropdown";
import { HeadTitle } from "../../../../customcomponents/headtitle/headTitle";
import DeleteModal from "../../../../customcomponents/modalPopup/deleteModal/DeleteModal";
import AuthStore from "../../../../MobX/Auth";
import EbookServices from "../../../../Services/EbookService";
import { ClientRoutesConstants } from "../../../../shared/constant";
import { ThemeColors } from "../../../../theme/theme";
import { checkDefault } from "../../../../utils/helper";
import "../ebook.css";
/* eslint-disable */
const PurchaseEbook = () => {
    const Role = AuthStore?.user?.user;
    pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.js`;
    const navigate = useNavigate()
    const [viewDetail, setviewDetail] = useState({})
    const [category, setCategory] = useState("")
    const location = useLocation()
    const [showModal, setShowmodal] = useState('');
    const [PDFImage, setPDFImage] = useState(null);
    const menuStyle = {
        marginTop: "10px",
        marginBottom: "20px",
    };
    let Pdf = {};
    useEffect(() => {
        getById(location?.state?.id)
    }, [location?.state?.id])

    const getById = async (Id) => {
        const res = await EbookServices?.getEbookById(Id);
        if (res?.isSuccess) {
            if (res?.data?.ebookPdfUrl) {
                pdfjs.getDocument(res?.data?.ebookPdfUrl).promise.then((pdf) => {
                    // const pages = [];
                    Pdf = pdf;
                    getPage(1).then((result) => {
                        // console.log("result---",result)
                        setPDFImage(result);
                    });
                });
            }
            setviewDetail(res?.data)
            setCategory(`${res?.data?.examTypeName} > ${res?.data?.courseName} ${res?.data?.subCourseName} > ${res?.data?.subjectName} >${res?.data?.topicName}`)
        }
    }
    const download = (e, viewDetail) => {
        checkDefault(e);
        downloadpdf(viewDetail?.ebookPdfUrl, "sample")

    }
    const deleteEbook = async () => {
        const deleteData = await EbookServices.deleteEbook({ id: location?.state?.id });
        if (deleteData?.isSuccess) {
            toast.success(deleteData?.messages);
            navigate(ClientRoutesConstants?.ebook)
        } else {
            toast.error(deleteData?.messages);
        }

    };

    const getPage = (num) => {
        return new Promise((resolve, reject) => {
            Pdf.getPage(num).then((page) => {
                const scale = "1.5";
                const viewport = page.getViewport({
                    scale: scale,
                });
                const canvas = document.createElement("canvas");
                const canvasContext = canvas.getContext("2d");
                canvas.height =
                    viewport.height || viewport.viewBox[3]; /* viewport.height is NaN */
                canvas.width =
                    viewport.width ||
                    viewport.viewBox[2]; /* viewport.width is also NaN */
                page
                    .render({
                        canvasContext,
                        viewport,
                    })
                    .promise.then((res) => {
                        resolve(canvas.toDataURL());
                    });
            });
        });
    };
    return (
        <div>
            <HeadTitle
                text={viewDetail?.ebookTitle}
                component1={<div className="totalPurchase">Total Purchase : {viewDetail?.totalPurchase}</div>}
                component2={
                    (viewDetail?.creatorUserId === Role?.userId || (Role.role === "Admin")) &&
                    <Button
                        icon={<DeleteIcon />}
                        background={ThemeColors.danger}
                        title="Delete"
                        height="42px"
                        width="121px"
                        func={() => setShowmodal("delete")}

                    />
                }
                component3={(viewDetail?.creatorUserId === Role?.userId || (Role.role === "Admin")) && <Button func={() => navigate('/add-newbook', { state: { id: location?.state?.id } })} icon={<EditIcon />} title="Edit Details" width="154px" height="42px" />}
            />
            <div>
                {" "}
                <form className="card px-3 pb-4 border-0 mt-3">
                    <div className="row m-0 gy-3">
                        <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
                            <img style={{ height: "250px", width: "250px" }} src={PDFImage} alt="ebook" />
                            {
                                (Role.role === "Admin") &&
                                <div className="mt-3 ms-5">
                                    <Button
                                        background={ThemeColors.primary}
                                        title="Preview"
                                        height="48px"
                                        width="122px"
                                        func={(e) => download(e, viewDetail)}
                                    />
                                </div>
                            }
                        </div>
                        <div className="col-xl-4 col-lg-4  col-md-6 col-sm-12">
                            <InputLabel>Ebook Title</InputLabel>
                            <CustomInput
                                backgroundColor="#F4F6F8"
                                marginBottom="15px"
                                marginTop="10px"
                                value={viewDetail?.ebookTitle}
                                isDisabled={true}
                            />
                            <InputLabel>Description</InputLabel>
                            <CustomInput
                                backgroundColor="#F4F6F8"
                                marginBottom="15px"
                                marginTop="10px"
                                value={viewDetail?.description}
                                isDisabled={true}
                            />
                            <InputLabel>Category</InputLabel>
                            <CustomInput
                                backgroundColor="#F4F6F8"
                                marginBottom="15px"
                                marginTop="10px"
                                isDisabled={true}
                                value={category}
                            />

                        </div>
                        <div className="col-xl-4 col-lg-4  col-md-6 col-sm-12">
                            <InputLabel>Author</InputLabel>
                            <CustomInput
                                backgroundColor="#F4F6F8"
                                marginBottom="15px"
                                marginTop="10px"
                                value={viewDetail?.authorName}
                                isDisabled={true}
                            />

                            <InputLabel>Price</InputLabel>
                            <CustomInput
                                backgroundColor="#F4F6F8"
                                marginBottom="15px"
                                marginTop="10px"
                                value={`₹${viewDetail?.price}`}
                                isDisabled={true}
                            />
                            <InputLabel>Language</InputLabel>
                            <CustomDropdown
                                customClass="form-dropdown"
                                selectedEntity={viewDetail?.language}
                                menuStyle={menuStyle}
                                disable={true}
                            />
                        </div>
                    </div>
                </form>
            </div>
            {
                showModal === "delete" && (
                    <DeleteModal
                        onRequestClose={() => {
                            setShowmodal('');
                        }}
                        onPress={() => {
                            setShowmodal('');
                            deleteEbook()
                        }}
                        name={viewDetail?.ebookTitle}
                    />
                )
            }
        </div>
    );
};

export default PurchaseEbook;
