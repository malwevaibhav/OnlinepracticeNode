import React, { useEffect, useState } from "react";
import { pdfjs } from "react-pdf";
import { useLocation, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { numberdecimalOnly } from "../../../../assets/regex";
import CustomInput from "../../../../customcomponents/customTextInput";
import { InputLabel } from "../../../../customcomponents/customTextInput/indexCss";
import CustomDropdown from "../../../../customcomponents/custom_Dropdown/CustomDropdown";
import { NormalHeading } from "../../../../customcomponents/DynamicText/Heading";
import AuthStore from "../../../../MobX/Auth";
import EbookStore from "../../../../MobX/Ebook";
import PatternStore from "../../../../MobX/Pattern";
import QuestionStore from "../../../../MobX/Question";
import EbookServices from "../../../../Services/EbookService";
import InstituteServices from "../../../../Services/InstituteService";
import QuestionTypeServices from "../../../../Services/QuestionTypeService";
import { ClientRoutesConstants } from "../../../../shared/constant";
import BookPreview from "./bookPreview";
import { UploadThumbnail } from "./uploadThumbnail";
let Pdf = {};
const BookDetails = ({ Errorcard, setErrorcard, disable, setDisable }) => {
    const Role = AuthStore?.user?.user;
    //console.log("auth", toJS(AuthStore?.user?.user));
    //new code updated error
    pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.js`;
    const location = useLocation()
    const [isDetailView, setIsDetailView] = useState(false)
    const [PDFImage, setPDFImage] = useState(null);
    const [pdf, setPdf] = useState()
    const [editAutorErr,] = useState(false);
    const [files, setfiles] = useState();
    const [pdfSrc, setPdfSrc] = useState();
    const [institute, setInstitute] = useState([]);
    const [language, setLanguage] = useState([]);
    const [isEdit, setIsEdit] = useState(false)
    // const [disable, setDisable] = useState(true)
    const [bookDetails, setBookDetails] = useState({
        EbookTitle: "",
        Description: "",
        Institute: PatternStore.selectedItemsPattern.Institute.selectedName,
        AuthorName: "",
        Language: PatternStore.selectedItemsPattern.Language.selectedName ? PatternStore.selectedItemsPattern.Language.selectedName : "",
        PriceSetting: "",
        PdfPreview: "",
        examType: EbookStore.ebookselectedids.examTypeId,
        courseType: EbookStore.ebookselectedids.courseId,
        subcourseType: EbookStore.ebookselectedids.subCourseId,
        subjectType: EbookStore.ebookselectedids.subjectCategory
    });
    const [Error, setError] = useState({
        EbookTitle: false,
        Institute: false,
        PriceSetting: false,
        AuthorName: false,
        Language: false,
        PdfPreview: false,
        examType: false,
        courseType: false,
        subCourseType: false,
        subjectType: false
    });
    const [previousImage, setpreviousImage] = useState(null)
    const navigate = useNavigate();

    /* eslint-disable */
    useEffect(() => {
        if (Role?.role === "Admin") {
            getAllInstitute();
        }

        getAllLanguage();
        if (location?.state?.id) {
            getById()
        }
        if (Role?.role === "Staff") {
            setIsDetailView(true)
            PatternStore.setSelectedItemsPattern({
                selectedName: "Institute",
                props: {
                    label: "Institute",
                    Title: Role?.instituteName,
                    id: Role?.instituteId,
                },
                entityName: Role?.instituteName,
            });
        }


    }, []);

    useEffect(() => {
        if (pdfSrc) {
            pdfjs.getDocument(pdfSrc).promise.then((pdf) => {
                Pdf = pdf;
                getPage(1).then((result) => {
                    setPDFImage(result);
              
                });
            });
        }

    }, [pdfSrc])

    const getById = async () => {
        const res = await EbookServices?.getEbookById(location?.state?.id);
        if (res?.isSuccess) {
            setBookDetails((bookDetails) => ({
                ...bookDetails,
                EbookTitle: res?.data?.ebookTitle,
                Description: res?.data?.description,
                AuthorName: res?.data?.authorName,
                Language: res?.data?.language,
                PriceSetting: res?.data?.price,
                PdfPreview: res?.data?.ebookPdfUrl
            }));
            setPdfSrc(res?.data?.ebookPdfUrl);

            QuestionStore.setSelectedItemsNw({
                selectedName: "Exam",
                props: { id: res?.data?.examTypeId, entityName: res?.data?.examTypeName },
                entityName: res?.data?.examTypeName,
            });
            EbookStore.setEbookSelectedid({ examTypeId: res?.data?.examTypeId });
            setErrorcard && setErrorcard({ ...Errorcard, examType: false });

            QuestionStore.setSelectedItemsNw({
                selectedName: "Course",
                props: { id: res?.data?.courseId, entityName: res?.data?.courseName },
                entityName: res?.data?.courseName,
            });
            EbookStore.setEbookSelectedid({ courseId: res?.data?.courseId });
            setErrorcard && setErrorcard({ ...Errorcard, courseType: false });

            QuestionStore.setSelectedItemsNw({
                selectedName: "SubCourse",
                props: { id: res?.data?.subCourseId, entityName: res?.data?.subCourseName },
                entityName: res?.data?.subCourseName,
            });
            EbookStore.setEbookSelectedid({ subCourseId: res?.data?.subCourseId });
            setErrorcard && setErrorcard({ ...Errorcard, subCourseType: false });

            QuestionStore.setSelectedItemsNw({
                selectedName: "Subject",
                props: { id: res?.data?.subjectCategoryId, entityName: res?.data?.subjectName },
                entityName: res?.data?.subjectName,
            });
            EbookStore.setEbookSelectedid({ subjectCategory: res?.data?.subjectCategoryId });
            setErrorcard && setErrorcard({ ...Errorcard, subjectType: false });
            QuestionStore.setSelectedItemsNw({
                selectedName: "Topic", props: {
                    id: res?.data?.topicId,
                    Title: res?.data?.topicName,
                    label: "SubTopic"

                }, entityName: res?.data?.topicName
            })
            EbookStore.setEbookSelectedid({ topicId: res?.data?.topicId });

            QuestionStore.setSelectedItemsNw({
                selectedName: "Writer",
                props:{},
                entityName: res?.data?.authorName,
            });
            EbookStore?.setEbookSelectedid({ writer: res?.data?.authorName });
            setErrorcard && setErrorcard({ ...Errorcard, writerType: false });

            if (res?.data?.ebookPdfUrl) {
                pdfjs.getDocument(res?.data?.ebookPdfUrl).promise.then((pdf) => {
                    Pdf = pdf;
                    getPage(1).then((result) => {
                        setPDFImage(result);
                        setpreviousImage(result)
                    });
                });
            }

            setfiles(res?.data?.ebookThumbnail)
            setIsEdit(true);
            setIsDetailView(true)

            EbookServices?.getCourseFilterData({id:res?.data?.subjectCategoryId,label:"Topic"});
        }

    }

    const updateState = (data) => {
        if (data) {
            setIsDetailView(true)
        }
        setBookDetails((bookDetails) => ({ ...bookDetails, ...data }));
    };

    const getAllInstitute = async () => {
        const resData = await InstituteServices.getAllInstitute();
        let temp = resData?.institutes?.map((data) => {
            return {
                id: data?.id,
                Title: data?.instituteName,
                label: 'Institute',
            };
        });
        setInstitute(temp);
    };

    const getAllLanguage = async () => {
        const res = await QuestionTypeServices.getAllLanguage();
        if (res?.isSuccess) {
            if (res?.data) {
                let language = res?.data.map((item) => {
                    return {
                        id: item?.value,
                        Title: item?.name,
                        label: 'Language'
                    };
                });
                setLanguage(language);
            }
        }
    };

    const getDropdownEbook = (props, entityName) => {
        if (props?.label === "Institute") {

            PatternStore.setSelectedItemsPattern({ selectedName: "Institute", props, entityName })
            setBookDetails((bookDetails) => ({ ...bookDetails, Institute: entityName }));
            EbookStore?.setEbookSelectedid({ instituteId: props.id })
            setError({ ...Error, Institute: false })
        }
        if (props?.label === "Language") {
            PatternStore.setSelectedItemsPattern({ selectedName: "Language", props, entityName })
            setBookDetails((bookDetails) => ({ ...bookDetails, Language: entityName }));
            setError({ ...Error, Language: false })
            setDisable(false)
        }


    };

    const checkValidate = async () => {
        if (!EbookStore.ebookselectedids.examTypeId) {
            return setErrorcard({ ...Errorcard, examType: true })
        }
        if (!EbookStore.ebookselectedids.courseId) {
            return setErrorcard({ ...Errorcard, courseType: true })
        }
        if (!EbookStore.ebookselectedids.subCourseId) {
            return setErrorcard({ ...Errorcard, subCourseType: true })
        }
        if (!EbookStore.ebookselectedids.subjectCategory) {
            return setErrorcard({ ...Errorcard, subjectType: true })
        }
        if (bookDetails?.EbookTitle === "") {
            return setError({ ...Error, EbookTitle: true })
        }

        if (bookDetails?.Institute === "" && Role?.role === "Admin") {
            return setError({ ...Error, Institute: true })
        }
        if (bookDetails?.AuthorName === "") {
            return setError({ ...Error, AuthorName: true })
        }
        if (bookDetails?.Language === "") {
            return setError({ ...Error, Language: true })
        }
        if (bookDetails?.PdfPreview === "") {
            return setError({ ...Error, PdfPreview: true })
        }

        const formDatapdf = new FormData();
        formDatapdf.append("PdfUrl", pdf);
        const uploadPdf = await EbookServices.UploadEbookPdf(formDatapdf);
        if (uploadPdf?.isSuccess) {
            let payload = {
                examTypeId: EbookStore?.ebookselectedids?.examTypeId,
                courseId: EbookStore?.ebookselectedids.courseId,
                subCourseId: EbookStore?.ebookselectedids.subCourseId,
                subjectCategory: EbookStore?.ebookselectedids.subjectCategory,
                topicId: EbookStore?.ebookselectedids.topicId || "00000000-0000-0000-0000-000000000000",
                ebookTitle: bookDetails?.EbookTitle,
                description: bookDetails?.Description,
                instituteId: EbookStore?.ebookselectedids?.instituteId || Role?.instituteId,
                authorName: bookDetails?.AuthorName,
                language: bookDetails?.Language,
                ebookPdfUrl: uploadPdf?.data,
                ebookThumbnail: PDFImage,
                price: bookDetails?.PriceSetting || 0

            }
            const postResp = await EbookServices.createNewebook(payload);
            if (postResp?.isSuccess) {
                EbookStore?.setEbookSelectedid({ writer: postResp?.data?.authorName })
                QuestionStore.setSelectedItemsNw({ selectedName: "Writer", props: { entityName: postResp?.data?.authorName }, entityName: postResp?.data?.authorName })
                toast.success(postResp?.messages);
                navigate(ClientRoutesConstants?.ebook)
            }
        }

    };

    const saveData = async () => {
        const str = numberdecimalOnly.test(bookDetails?.PriceSetting) ? false : true;
        if (str) {
            return toast.error("Please enter valid price")
        }
        checkValidate();
    };

    const updateData = async () => {
        const str = numberdecimalOnly.test(bookDetails?.PriceSetting) ? false : true;
        if (str) {
            toast.error("Please enter valid price")
        }
        if (bookDetails?.EbookTitle === "") {
            return setError({ ...Error, EbookTitle: true })
        }
        if (bookDetails?.Institute === "" && Role?.role === "Admin") {
            return setError({ ...Error, Institute: true })
        }
        if (bookDetails?.AuthorName === "") {
            return setError({ ...Error, AuthorName: true })
        }
        if (bookDetails?.Language === "") {
            return setError({ ...Error, Language: true })
        }
        if (bookDetails?.PdfPreview === "") {
            return setError({ ...Error, PdfPreview: true })
        }

        if (pdf) {
            const formDatapdf = new FormData();
            formDatapdf.append("PdfUrl", pdf);
            const uploadPdf = await EbookServices.UploadEbookPdf(formDatapdf);
            if (uploadPdf?.isSuccess) {
                let payload = {
                    examTypeId: EbookStore?.ebookselectedids?.examTypeId,
                    courseId: EbookStore?.ebookselectedids.courseId,
                    subCourseId: EbookStore?.ebookselectedids.subCourseId,
                    subjectCategory: EbookStore?.ebookselectedids.subjectCategory,
                    topicId: EbookStore?.ebookselectedids.topicId,
                    ebookTitle: bookDetails?.EbookTitle,
                    description: bookDetails?.Description,
                    instituteId: EbookStore?.ebookselectedids?.instituteId || Role?.instituteId,
                    authorName: bookDetails?.AuthorName,
                    language: bookDetails?.Language,
                    ebookPdfUrl: uploadPdf?.data,
                    ebookThumbnail: PDFImage,
                    price: bookDetails?.PriceSetting || 0,
                    id: location?.state?.id

                }
                const postResp = await EbookServices.updateNewebook(payload);
                if (postResp?.isSuccess) {
                    toast.success(postResp?.messages);
                    navigate(ClientRoutesConstants?.ebook)
                }
            }

        } else {

            let payload = {
                examTypeId: EbookStore?.ebookselectedids?.examTypeId,
                courseId: EbookStore?.ebookselectedids.courseId,
                subCourseId: EbookStore?.ebookselectedids.subCourseId,
                subjectCategory: EbookStore?.ebookselectedids.subjectCategory,
                topicId: EbookStore?.ebookselectedids.topicId,
                ebookTitle: bookDetails?.EbookTitle,
                description: bookDetails?.Description,
                instituteId: EbookStore?.ebookselectedids?.instituteId || Role?.instituteId,
                authorName: bookDetails?.AuthorName,
                language: bookDetails?.Language,
                ebookPdfUrl: pdfSrc,
                ebookThumbnail: PDFImage,
                price: bookDetails?.PriceSetting || 0,
                id: location?.state?.id

            }
            const postResp = await EbookServices.updateNewebook(payload);
            if (postResp?.isSuccess) {
                toast.success(postResp?.messages);
                navigate(ClientRoutesConstants?.ebook)
            }


        }

    };

    const getPage = (num) => {
        return new Promise((resolve, reject) => {
            Pdf.getPage(num).then((page) => {
                const scale = "1.5";
                const viewport = page.getViewport({
                    scale: scale,
                });
                const canvas = document.createElement("canvas");
                const canvasContext = canvas.getContext("2d");
                canvas.height =
                    viewport.height || viewport.viewBox[3]; /* viewport.height is NaN */
                canvas.width =
                    viewport.width ||
                    viewport.viewBox[2]; /* viewport.width is also NaN */
                page
                    .render({
                        canvasContext,
                        viewport,
                    })
                    .promise.then((res) => {
                        resolve(canvas.toDataURL());
                    });
            });
        });
    };

    return (
        <div>
            <div className="transaction-container">
                <div>
                    <div className="card  border-0 p-30 mt-25">
                        <NormalHeading text="Ebook Basic Details"></NormalHeading>
                        {/* <div className="CardLabel pb-2"></div> */}
                        <div className="mt-3 mb-3">
                            <InputLabel>Ebook Title</InputLabel>
                            <CustomInput
                                backgroundColor="#F4F6F8"
                                marginBottom="15px"
                                marginTop="10px"
                                value={bookDetails.EbookTitle}
                                onChange={(e) => {
                                    setDisable(false)
                                    setError({ ...Error, EbookTitle: false })
                                    updateState({
                                        EbookTitle: e.target.value,
                                    });
                                }}
                            />
                            {Error?.EbookTitle && <span className="input-feedback">Ebook Title is required </span>}
                        </div>

                        <InputLabel>Description</InputLabel>
                        <textarea
                            className="textareaMocktest mt-2"
                            placeholder="Description"
                            value={bookDetails.Description}
                            onChange={(e) => {
                                setDisable(false)
                                updateState({
                                    Description: e.target.value,
                                });
                            }}
                        >
                        </textarea>
                        <div className="mb-3 mt-3">
                            <InputLabel>Select Institute</InputLabel>
                            <CustomDropdown
                                isSelect={true}
                                menu={institute}
                                customClass="form-dropdown"
                                placeholder="Select Institute"
                                value={bookDetails.Institute}
                                onChange={(e) => {
                                    updateState({
                                        Institute: e.target.value,
                                    });
                                }}
                                handlefunc={getDropdownEbook}
                                selectedEntity={
                                    PatternStore.selectedItemsPattern.Institute.selectedName
                                }
                                disable={Role?.role === 'Staff'}
                            />
                            {Error?.Institute && <span className="input-feedback">Institute Title is required </span>}
                        </div>

                        <div className="mt-2">
                            <InputLabel>Author Name</InputLabel>
                            <CustomInput
                                backgroundColor="#F4F6F8"
                                marginBottom="10px"
                                marginTop="10px"
                                value={bookDetails.AuthorName}

                                onChange={(e) => {
                                    setDisable(false)
                                    setError({ ...Error, AuthorName: false })
                                    updateState({
                                        AuthorName: e.target.value.replace(/\d+|^\s+$/g, ''),
                                    });
                                }}
                            />
                            {editAutorErr && <p>Your email is invalid</p>}
                            {Error?.AuthorName && <span className="input-feedback">Author Name is required </span>}

                        </div>

                        <div className="mt-3">
                            <InputLabel>Language</InputLabel>
                            <CustomDropdown
                                isSelect={true}
                                menu={language}
                                customClass="form-dropdown"
                                placeholder="Select Language"
                                value={bookDetails.Language}
                                onChange={(e) => {
                                    setDisable(false)
                                    updateState({
                                        Language: e.target.value,
                                    });
                                }}
                                handlefunc={getDropdownEbook}
                                selectedEntity={
                                    isEdit ? bookDetails.Language :
                                        PatternStore.selectedItemsPattern.Language.selectedName
                                }

                            />
                            {Error?.Language && <span className="input-feedback">Language is required </span>}
                        </div>
                    </div>

                    <div className="card  border-0 p-30 mt-25">
                        <div className="">Upload ebook(PDF format)</div>
                        <UploadThumbnail
                            name="ebookpdf"
                            setFieldValue={setPdf}
                            pdfSrc={pdfSrc}
                            setPdfSrc={setPdfSrc}
                            PDFImage={PDFImage}
                            setPDFImage={setPDFImage}
                            isEdit={isEdit}
                            bookDetails={bookDetails}
                            updateState={updateState}
                            accept="application/pdf"
                            setError={setError}
                            Error={Error}
                            previousImage={previousImage}
                            setDisable={setDisable}
                        />
                    </div>
                    <div className="card  border-0 p-30 mt-25">
                        <NormalHeading text="Price Setting"></NormalHeading>
                        <hr></hr>
                        <InputLabel>Price</InputLabel>
                        <div className="f f-a-row gap10 pt-2">
                            <div className="RupeyBox mt-2" style={{ color: '#FFFFFF' }}>&#x20b9;</div>
                            <div className="price">
                                <CustomInput
                                    backgroundColor="#F4F6F8"
                                    height="48px"
                                    placeholder="00"
                                    width="800px !important"
                                    value={bookDetails.PriceSetting}
                                    onChange={(e) => {
                                        setDisable(false)
                                        setError({ ...Error, PriceSetting: false })
                                        updateState({
                                            PriceSetting: e.target.value,
                                        });
                                    }}
                                    isDisabled={isEdit && Role?.role === "Staff"}
                                />
                            </div>
                        </div>
                    </div>
                </div>
                <BookPreview disable={disable} bookDetails={bookDetails} saveData={saveData} updateData={updateData} files={files} setfiles={setfiles} setBookDetails={setBookDetails} isEdit={isEdit} isDetailView={isDetailView} PDFImage={PDFImage} />
            </div>
        </div>
    );
};

export default BookDetails;
