import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import StudentServices from "../../../Services/StudentService";
import {
  SubHeading
} from "../../../customcomponents/DynamicText/Heading";
import Carddynamic from "../../../customcomponents/dashboradcard/CardDynamic";
import { HeadTitle } from "../../../customcomponents/headtitle/headTitle";
import Table from "../../../customcomponents/table/Table";
import { ThemeColors } from "../../../theme/theme";
import "../dashboard/dashboard.css";
import StudentCard from "./component/studentCard";
import "./studentCard.css";
export default function StudentDetails() {

  const location = useLocation()

  const  [studentDetail,setstudentDetail] = useState({})

  useEffect(()=>{
  getStudentDetail(location?.state?.id);
  },[location?.state?.id])


   const getStudentDetail = async(Id)=>{
     const res =  await StudentServices?.getStudentById(Id)
     if(res?.isSuccess){
      setstudentDetail(res?.data)
     }  
   }

  const menuStyle = {
    color: ThemeColors.link,
    backgroundColor: ThemeColors.selectButton,
    minWidth: "130px",
  };

  const tableHead = ["Item Name", "Type", "Date", "Amount"];
  const tableHead1 = ["Amount", "Date", "status"];
 
 
  return (
    <>
      <HeadTitle text="Student Details" />
      <div className="my-3">
        {" "}
        <StudentCard studentDetail={studentDetail} />
      </div>
      <div className="my-4">
        <div className="transaction-container">
          <div className="card  border-0">
            <Carddynamic
              title={<SubHeading text="Purchase Items" />}
              link={`Total Item:  ${studentDetail?.totalItems}`}
              menuStyle={menuStyle.color}
            />
            <Table
              tableHead={tableHead}
              tableData={studentDetail?.purchaseItems}
              checkbox={false}
              action={false}
              tHeadBackgoundColor={ThemeColors.tableHead}
              tHeadPadding="py-3 ps-2"
            />
          </div>
          <div className="card  border-0 ">
            <Carddynamic
              title={<SubHeading text="Wallet transaction" />}
              link={`Available Amount: ${studentDetail?.balance}`}
              menuStyle={menuStyle.color}
            />
            <Table
              tableHead={tableHead1}
              tableData={studentDetail?.walletTransactions}
              checkbox={false}
              action={false}
              tHeadBackgoundColor={ThemeColors.tableHead}
              tHeadPadding="py-3 ps-2"
            />
          </div>
        </div>
      </div>
    
    </>
  );
}
