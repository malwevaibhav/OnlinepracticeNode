import React, { useEffect, useState } from "react";
import { toast } from "react-toastify";
import AuthStore from "../../../MobX/Auth";
import EbookStore from "../../../MobX/Ebook";
import StudentServices from "../../../Services/StudentService";
import { FolderUploadIcon, PlusIcon } from "../../../assets/svgs/svg";
import Button from "../../../customcomponents/button/Button";
import { HeadTitle } from "../../../customcomponents/headtitle/headTitle";
import Modal from "../../../customcomponents/modalPopup/CustomModal";
import Pagination from "../../../customcomponents/pagination/Pagination";
import Table from "../../../customcomponents/table/Table";
import { StudentModal } from "../custommodals/studentmodal";
import ResultCard from "../result/customcomponent/resultCard";
import AddStudentCard from "./component/AddStudentCard";
import Upload from "./component/upload";

const tableHead = [
  "Name",
  "Course",
  "Sub-course",
  "Enrollment Date ",
  "Institute",
];
export default function StudentList() {
  const Role = AuthStore?.user?.user; 
  const [isShow, setIsShow] = useState(false);
  const [showStudent, setshowStudent] = useState(false);
  const [upload, setUpload] = useState(false);
  const [pageNoSize, setPageNoSize] = useState({ no: 1, size: 10 });
  const [studentLength, setStudentLength] = useState("");
  const [allStudent, setAllStudent] = useState("");
  const [studentId, setstudentId] = useState("");

useEffect(()=>{
  if (
    (EbookStore?.ebookselectedids.subCourseId || "00000000-0000-0000-0000-000000000000" &&
      EbookStore?.ebookselectedids.instituteId) || Role?.instituteId || "00000000-0000-0000-0000-000000000000"
  ) {
  getStudentList();
  }
},[])


  const getStudentList = async (no = 1, size = 10) => {
    setPageNoSize({ no: 1, size: 10 });
    let payload = {
      subCourseId: EbookStore?.ebookselectedids.subCourseId || "00000000-0000-0000-0000-000000000000",
      instituteId:EbookStore?.ebookselectedids.instituteId || Role?.instituteId || "00000000-0000-0000-0000-000000000000",
      pageNumber: no,
      pageSize: size,
    };
    const resData = await StudentServices.getAllStudentlist(payload)
    if (resData?.isSuccess) {
      setStudentLength(resData?.data.totalRecords);
     let list = resData?.data?.studentDetails?.map((elm) => {
        return {
          id:elm?.studentId,
          studentName: elm?.studentName,
          courseName: elm?.courseName,
          subCourseName: elm?.subCourseName,
          enrollmentDate: elm?.enrollmentDate,
          instituteName: elm?.instituteName,
          action:true
        };
      });
      setAllStudent(list);
      return list.length;
    }

    }

    const getSampleReport=async()=>{
      const resData = await StudentServices.getSampleReport();
      if(resData?.isSuccess){
          var link = document.createElement("a");
          link.download = "Sample";
          link.href = resData?.data;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);

      }

    }

    const deleteStudent = async (props) => {
      const res = await StudentServices.deleteStudent(props);
      if (res?.isSuccess && res?.responseCode === 200) {
        toast.success(res?.messages);
        getStudentList(pageNoSize?.no, pageNoSize?.size);
      } else {
        toast.error(res?.messages);
      }
    };
  

  return (
    <>
      <HeadTitle
        text="Student List"
        component1={
          <Button
            title="Bulk Upload"
            icon={<FolderUploadIcon />}
            width="159px"
            func={()=>setUpload(true)}
          />
        }
        component2={
          <Button title="Add Student" icon={<PlusIcon />} width="154px" func={()=>setshowStudent(true)} />
        }
        component3={
          <Button title="Sample Download"  icon={<FolderUploadIcon />}  width="190px"  func={getSampleReport} />
        }
      />
      
      <ResultCard getResult={getStudentList}  student={true}/>
      {
        showStudent && 
        <AddStudentCard getStudentList={getStudentList}  pageNoSize={pageNoSize} setshowStudent={setshowStudent} showStudent={showStudent}  />
      }
  <div className="row mt-3 ">
  <div className="d-grid">
        <Table
          tableData={allStudent}
          tableHead={tableHead}
          navigateTo="student-details"
          toggleEditModal={() => {
            setIsShow(!isShow)     
          }}
          setId={setstudentId}
          tHeadPadding="py-3 ps-2"
          deleteData={deleteStudent}
        />
        <Pagination
          getFunction={getStudentList}
          totalLength={studentLength}
          setPageNoSize={setPageNoSize}
          pageNoSize={pageNoSize}
          length={allStudent.length}
        />
      </div>
  </div>
    
      {isShow && (
      <StudentModal studentId={studentId}  setIsShow={setIsShow} getStudentList={getStudentList}  pageNoSize={pageNoSize}/>
      )}

      {
        upload && 
        <Upload  getStudentList={getStudentList}  pageNoSize={pageNoSize} setUpload={setUpload} upload={upload} />
      }


    </>
  );
}

