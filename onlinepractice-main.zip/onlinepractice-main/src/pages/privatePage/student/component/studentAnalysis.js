import React from 'react'
import LineChart from '../../../../customcomponents/Chart/LineChart'

export default function StudentAnalysis() {
  return (
   <div className='py-4 ps-2 ms-4 me-4'>
    <LineChart/>
   </div>
  )
}
