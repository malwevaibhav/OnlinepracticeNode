import React from "react";
import { CardSubHeading } from "../../../../customcomponents/DynamicText/Heading";
import "../../dashboard/dashboard.css";
import im from "../../../../assets/Images/blankProfile.png";

export default function StudentCard(props) {
  /* eslint-disable */
  const { studentDetail } = props;
  return (
    <div className="card p-3 border-0">
      <div className="d-flex">
        <div className="flex-shrink-0" >
          {/* <div className="col-lg-2 col-md-4 col-sm-12 col-xs-12"> */}
          <img
            src={studentDetail?.profileImage? studentDetail?.profileImage : im}
            width= "140"
            height= "140"
            style={{ borderRadius: "100px" }}
          />
        </div>

        <div className="flex-grow-1 ps-4" >
          {/* <div className="col-lg-10 col-md-8 col-sm-12 col-xs-12"> */}
          <div className="row m-0" style={{ rowGap: "1rem" }}>
            <div className="col-lg-3 col-md-6 col-sm-6">
              <small className="m-0 text-muted">Student Name</small>
              <CardSubHeading text={studentDetail?.name} />
            </div>
            
            <div className="col-lg-3 col-md-6 col-sm-6">
              <small className="m-0 text-muted">Email ID</small>
              <CardSubHeading text={studentDetail?.email} />
            </div>

            <div className="col-lg-3 col-md-6 col-sm-6">
              <small className="m-0 text-muted">Mobile Number</small>
              <CardSubHeading text={studentDetail?.mobileNumber} />
            </div>
            <div className="col-lg-3 col-md-6 col-sm-6">
              <small className="m-0 text-muted">Institute</small>
              <CardSubHeading text={studentDetail?.instituteName} />
            </div>
            <div className="col-lg-3 col-md-6 col-sm-6">
              <small className="m-0 text-muted">Course</small>
              <CardSubHeading text={studentDetail?.courseName} />
            </div>
           
          </div>
        </div>
      </div>
    </div>
    // <Table />
  );
}
