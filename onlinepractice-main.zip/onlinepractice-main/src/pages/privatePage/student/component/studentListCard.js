import React from "react";
import Button from "../../../../customcomponents/button/Button";
import CustomDropdown from "../../../../customcomponents/custom_Dropdown/CustomDropdown";

export default function StudentListCard() {
  const courseOptions = [
    { Title: "Engineering" },
    { Title: "Medical" },
    { Title: "Defence" },
  ];
  const subcourseOptions = [
    { Title: "JEE Mains" },
    { Title: "JEE Advance" },
    { Title: "Neet" },
  ];
  const Institute = ["Allen", { Title: "Catelyser" }, { Title: "kautilya" }];
  return (
    <div className="card p-4 border-0">
      <form>
        <div className="student-container ms-2 me-2">
          <div>
            <CustomDropdown
              menu={courseOptions}
              customClass="form-dropdown"
              placeholder="Select Course"
              name="courseId"
              handlefunc={() => {}}
              // selectedEntity={values?.instituteName}
              menuStyle={{ border: "1px solid #E3E9EE" }}
            />
          </div>
          <div>
            <CustomDropdown
              menu={subcourseOptions}
              customClass="form-dropdown"
              placeholder="Select Sub-course"
              name="subcourseId"
              handlefunc={() => {}}
              // selectedEntity={values?.instituteName}
              menuStyle={{ border: "1px solid #E3E9EE" }}
            />
          </div>
          <div>
            <CustomDropdown
              menu={Institute}
              customClass="form-dropdown"
              placeholder="Select Institute"
              name="instituteId"
              handlefunc={() => {}}
              // selectedEntity={values?.instituteName}
              menuStyle={{ border: "1px solid #E3E9EE" }}
            />
          </div>
          <div className="w-25">
            <Button title="Apply" width="114px" />
          </div>
        </div>
      </form>
    </div>
  );
}
