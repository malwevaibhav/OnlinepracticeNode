import React from "react";
import CardTitle from "../../../../customcomponents/CardTitle/CardTitle";
import Button from "../../../../customcomponents/button/Button";
import CustomInput from "../../../../customcomponents/customTextInput";
import { ThemeColors } from "../../../../theme/theme";
import { Formik } from "formik";
import InitValue from "../../../../assets/regex/initialValues";
import { StudentSchema } from "../../../../assets/regex/schema";
import { toast } from "react-toastify";
import StudentServices from "../../../../Services/StudentService";
import { removeExtraSpace } from "../../../../utils/helper";

export default function AddStudentCard({getStudentList,pageNoSize ,setshowStudent ,showStudent}) {

  const addValues = async (values) => {
    let formatted_Data = {
      email: `${values?.email}`,
      mobileNumber: `${values?.mobileNumber}`,
      password:`${values?.password}` ,
      fullName: removeExtraSpace(values?.fullName),
    };
    
    const studentRes = await StudentServices.createStudent(formatted_Data);
    if (studentRes?.isSuccess && studentRes?.responseCode === 200) {
      toast.success(studentRes?.messages);
       getStudentList(pageNoSize?.no, pageNoSize?.size);
       setshowStudent(!showStudent)
    } else {
      toast.error(studentRes?.messages);
        getStudentList(pageNoSize?.no, pageNoSize?.size);
        setshowStudent(!showStudent)
    }
  };

  return (
    <div className="card rounded-2 border-0 mt-2 p-3">
      <Formik
        initialValues={InitValue?.StudentList}
        onSubmit={(values) => {
          addValues(values);
        }}
        validationSchema={StudentSchema()}
      >
        {(props) => {
          const {
            touched,
            errors,
            handleChange,
            handleSubmit,
          } = props;
          return (
            <form onSubmit={handleSubmit}>
              <div className="row m-0">
                <div className="col-12 mb-0 m-0 p">
                  <CardTitle title="Add Student " />
                </div>
                <div className="col-sm-6 col-md-6 col-lg-3 m-0">
                  <CustomInput
                    name="fullName"
                    id="fullName"
                    placeholder="Ex. Rahul Sharma"
                    type="text"
                    label="Full Name"
                    height="48px"
                    onChange={handleChange}
                  />
                   {errors.fullName && touched.fullName && (
                    <div className="input-feedback">{errors.fullName}</div>
                  )}
                </div>
                <div className="col-sm-6 col-md-6 col-lg-3">
                  <CustomInput
                    name="email"
                    id="email"
                    placeholder="Ex. abcd@gmail.com"
                    type="email"
                    label="Email Address"
                    height="48px"
                    onChange={handleChange}
                  />
                    {errors.email && touched.email && (
                    <div className="input-feedback">{errors.email}</div>
                  )}
                </div>
                <div className="col-sm-6 col-md-6 col-lg-3">
                  <CustomInput
                   name="password"
                   id="password"
                    placeholder="Ex.ABC123@"
                    type="password"
                    label="Password"
                    height="48px"
                    onChange={handleChange}
                  />
                  {errors.password && touched.password && (
                  <div className="input-feedback">{errors.password}</div>
                )}
                </div>
                <div className="col-sm-6 col-md-6 col-lg-3">
                  <CustomInput
                    name="mobileNumber"
                    id="mobileNumber"
                    placeholder="Ex. 9876543210"
                    type="text"
                    label="Mobile Number"
                    height="48px"
                    onChange={handleChange}
                  />
                   {errors.mobileNumber && touched.mobileNumber && (
                    <div className="input-feedback">{errors.mobileNumber}</div>
                  )}
                </div>
                <div className="col-sm-5 col-md-2 d-flex align-items-center p-0 ps-1 mt-3 gap-4">
                  <Button type="submit" title="Save" width="108px" />
                  <Button
                    type="reset"
                    title="Cancel"
                    width="108px"
                    background={ThemeColors?.secondary}
                    onChange={handleChange}
                  />
                </div>
              </div>
            </form>
          );
        }}
      </Formik>
    </div>
  );
}
