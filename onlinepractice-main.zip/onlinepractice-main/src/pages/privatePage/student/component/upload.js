import { useEffect, useRef, useState } from "react";
import { UploadIcon } from "../../../../assets/svgs/svg";
import { SubHeading } from "../../../../customcomponents/DynamicText/Heading";
import Button from "../../../../customcomponents/button/Button";
import StudentServices from "../../../../Services/StudentService";
import Modal from "../../../../customcomponents/modalPopup/CustomModal";
import { toast } from "react-toastify";

export default function Upload({ onDrop, maxFiles = 1,getStudentList, pageNoSize ,upload ,setUpload}) {
  const $input = useRef(null);
  const [, setover] = useState(false);
  const [files,] = useState();
  const [, setItems] = useState();
  const [filename,setfilename]=useState("")

    const readExcel = async (file) => {
      const formData = new FormData();
      formData.append("file", file);
      const uploadexcel = await StudentServices.UploadExcel(formData);
  
      if (uploadexcel?.isSuccess) {
        toast.success(uploadexcel?.messages)
        getStudentList(pageNoSize?.no, pageNoSize?.size);
        setUpload(!upload)
      }
      else{
        toast.error(uploadexcel?.messages)
        setUpload(!upload)
      }
      // const promise = new Promise((resolve, reject) => {
      //   const fileReader = new FileReader();
        //fileReader.readAsArrayBuffer(file);
        // fileReader.onload = (e) => {
        //   const bufferArray = e.target.result;
        //   const wb = XLSX.read(bufferArray, { type: "buffer" });
        //   const wsname = wb.SheetNames[0];
        //  const ws = wb.Sheets[wsname];
        //   const data = XLSX.utils.sheet_to_json(ws);
        //   console.log("object",data);
        //   resolve(data);
        // };
        // fileReader.onerror = (error) => {
        //   reject(error);
        // };
      // });
      // promise.then((d) => {
      //   setItems(d);
      // });
    };

  useEffect(() => {
    if (onDrop) {
        onDrop(files);
    }
}, [onDrop,files]);

  return (
    <Modal onRequestClose={() => setUpload(false)} closeBtn={false} toggle={() => setUpload(!upload)} width="30vw">
      <div
        onClick={() => {
          $input.current.click();
        }}
        onDrop={(e) => {
          e.preventDefault();
          e.persist();
          setover(false);
          readExcel(e.dataTransfer.files[0]);
          setfilename(e.dataTransfer.files[0]?.name)
        }}
        onDragOver={(e) => {
          e.preventDefault();
          setover(true);
        }}
        onDragLeave={(e) => {
          e.preventDefault();
          setover(false);
        }}
      >
        <div className="d-flex align-items-center flex-column mt-2">
          <SubHeading text={"Upload"} />
          <UploadIcon />
          <h6 className="SemiBold mt-2 d-flex justify-content-center mt-4">
            Drag and drop your file here
          </h6>
          <p>or</p>
          <Button title="Browse file" width="152px"/>
        </div>
        <input
                                            name={"name"}
                                            style={{ display: "none" }}
                                            type="file"
                                            accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel"
                                            ref={$input}
                                            onChange={(e) => {
                                              const file = e.target.files[0];
                                              readExcel(file);
                                              setfilename(file?.name)
                                            }}
                                            multiple={maxFiles > 1}
                                        />
                                        <p className="text-center mt-2">{filename}</p>
      </div>
      </Modal>
  );
}
  