import React from "react";

const PublicRoute = ({ component: Component, restricted, ...props }) => {
  return (
    <>
    
      <Component />
    </>
  );
};

export default PublicRoute;
