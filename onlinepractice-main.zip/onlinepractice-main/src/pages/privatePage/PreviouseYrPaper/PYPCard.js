import { toJS } from "mobx";
import { observer } from "mobx-react-lite";
import React, { useEffect, useState } from "react";
import Button from "../../../customcomponents/button/Button";
import { InputLabel } from "../../../customcomponents/customTextInput/indexCss";
import CustomDropdown from "../../../customcomponents/custom_Dropdown/CustomDropdown";
import AuthStore from "../../../MobX/Auth";
import PYPStores from "../../../MobX/PYPStore";
import InstituteServices from "../../../Services/InstituteService";
import PYPServices from "../../../Services/PYPService";
import QuestionTypeServices from "../../../Services/QuestionTypeService";

const PYPCard = (props) => {
  const {
    show = true,
    setFieldValue,
    errors,
    touched,
    applyFunc,
    disabled,
    setDisable
  } = props;
  const [toggle, setToggle] = useState(false);
  const examList = toJS(PYPStores?.examList);
  const courseList = toJS(PYPStores?.course);
  const subcourseList = toJS(PYPStores?.subcourse);
  const [institutes, setInstitute] = useState();
  const [addedBY, setAddedBY] = useState([]);
  const [yearList, setYearList] = useState([]);
  /* eslint-disable */
  const Role = AuthStore?.user?.user;
  useEffect(() => {
    getExamType();
    getAllInstitute();
    getAllYear();
    if (show) {
      getAllAddedBy();
    }
  }, []);

  const getExamType = async () => {
    let exam = await PYPServices?.getPYPFilterData({ label: "Exam" });
    PYPStores.setexamList(exam);
  };

  const getAllInstitute = async () => {
    let data = await InstituteServices?.getAllInstitute();
    if (data?.institutes) {
      let inst = data.institutes?.map((elm) => {
        return {
          id: elm?.id,
          Title: elm?.instituteName,
          label: "Institute",
        };
      });
      setInstitute(inst);
    }
  };

  const getAllAddedBy = async () => {
    const resData = await QuestionTypeServices.getAllAddedBy();
    let addedby = resData?.staffList?.map((elm) => {
      return {
        id: elm?.id,
        Title: elm?.name,
        label: "AddedBy",
      };
    });
    setAddedBY(addedby);
  };

  const getAllYear = async () => {
    const resData = await PYPServices.getYearList();
    let list = resData?.years?.map((elm) => {
      return {
        id: elm,
        Title: elm,
        label: "Year",
      };
    });
    setYearList(list);
  };

  const getDataForPYPCard = async (props, entityName) => {
    if (props?.label === "Course") {
      PYPStores.setSelectedItemsNw({ selectedName: "Exam", props, entityName });
      let course = await PYPServices?.getPYPFilterData(props);
      PYPStores.setCourse(course);
    }
    if (props?.label === "SubCourse") {
      PYPStores.setSelectedItemsNw({
        selectedName: "Course",
        props,
        entityName,
      });
      let subCourse = await PYPServices?.getPYPFilterData(props);
      PYPStores.setSubCourse(subCourse);
    }
    if (props?.label === "Subject") {
      PYPStores.setSelectedItemsNw({
        selectedName: "SubCourse",
        props,
        entityName,
      });
    }
    if (props?.label === "Institute") {
      PYPStores.setSelectedItemsNw({
        selectedName: "Institute",
        props,
        entityName,
      });
    }
    if (props?.label === "Year") {
      PYPStores.setSelectedItemsNw({ selectedName: "Year", props, entityName });
    }
    if (props?.label === "AddedBy") {
      PYPStores.setSelectedItemsNw({
        selectedName: "AddedBy",
        props,
        entityName,
      });
    }
    setDisable && setDisable(false)
    setToggle(!toggle);
  };
  return (
    <>
      <div className="card rounded-0 border-0 px-3 pb-3 py-1 mb-3">
        <div className="row m-0 g-2">
          <div className="col-xl-3 col-lg-4 col-md-6 col-sm-12 pb-2">
            <InputLabel>Exam Type</InputLabel>
            <CustomDropdown
              customClass="form-dropdown"
              placeholder="Select Exam"
              height="48px"
              menu={examList}
              handlefunc={(data) => {
                setFieldValue("examTypeId", data?.id);
                getDataForPYPCard(data, data?.Title);
              }}
              menuStyle={{ border: "1px solid #E3E9EE" }}
              selectedEntity={
                PYPStores?.selectedItemsNw?.examList?.selectedName
              }
              disable={disabled}
            />
            {errors?.examTypeId && touched?.examTypeId && (
              <div className="input-feedback position-absolute">
                {errors?.examTypeId}
              </div>
            )}
          </div>
          <div className="col-xl-3 col-lg-4 col-md-6 col-sm-12 pb-2">
            <InputLabel>Course</InputLabel>
            <CustomDropdown
              customClass="form-dropdown"
              placeholder="Select Course"
              height="48px"
              menu={courseList}
              handlefunc={(data) => {
                setFieldValue("courseId", data?.id);
                getDataForPYPCard(data, data?.Title);
              }}
              menuStyle={{ border: "1px solid #E3E9EE" }}
              selectedEntity={
                PYPStores?.selectedItemsNw?.courseList?.selectedName
              }
              disable={disabled || !PYPStores?.selectedItemsNw?.examList?.id}
            />
            {errors?.courseId && touched.courseId && (
              <div className="input-feedback position-absolute">
                {errors?.courseId}
              </div>
            )}
          </div>
          <div className="col-xl-3 col-lg-4 col-md-6 col-sm-12 pb-2">
            <InputLabel>Sub-course</InputLabel>
            <CustomDropdown
              customClass="form-dropdown"
              placeholder="Select SubCourse"
              height="48px"
              handlefunc={(data) => {
                setFieldValue("subCourseId", data?.id);
                getDataForPYPCard(data, data?.Title);
              }}
              menu={subcourseList}
              menuStyle={{ border: "1px solid #E3E9EE" }}
              selectedEntity={
                PYPStores?.selectedItemsNw?.SubCourseList?.selectedName
              }
              disable={disabled || !PYPStores?.selectedItemsNw?.courseList?.id}
            />
            {errors?.subCourseId && touched.subCourseId && (
              <div className="input-feedback position-absolute">
                {errors?.subCourseId}
              </div>
            )}
          </div>
          <div className="col-xl-3 col-lg-4 col-md-6 col-sm-12 pb-2">
            <InputLabel>Year</InputLabel>
            <CustomDropdown
              customClass="form-dropdown"
              placeholder="Select Year"
              height="48px"
              handlefunc={(data) => {
                setFieldValue("year", data?.Title);
                getDataForPYPCard(data, data?.Title);
              }}
              menu={yearList}
              menuStyle={{ border: "1px solid #E3E9EE" }}
              selectedEntity={
                PYPStores?.selectedItemsNw?.YearList?.selectedName
              }
              disable={!PYPStores?.selectedItemsNw?.SubCourseList?.id}
            />
            {errors?.year && touched.year && (
              <div className="input-feedback position-absolute">
                {errors?.year}
              </div>
            )}
          </div>
          <div className="col-xl-3 col-lg-4 col-md-6 col-sm-12 pb-2">
            <InputLabel>Institute</InputLabel>
            <CustomDropdown
              customClass="form-dropdown"
              placeholder="Select Institute"
              height="48px"
              menu={institutes}
              handlefunc={(data) => {
                setFieldValue("instituteId", data?.id);
                getDataForPYPCard(data, data?.Title);
              }}
              menuStyle={{ border: "1px solid #E3E9EE" }}
              selectedEntity={
                Role?.role == "Admin"
                  ? PYPStores?.selectedItemsNw?.InstituteList?.selectedName
                  : Role?.instituteName
              }
              disable={Role?.role === "Staff"}
            />
            {errors?.instituteId && touched.instituteId && (
              <div className="input-feedback position-absolute">
                {errors?.instituteId}
              </div>
            )}
          </div>

          {show && Role?.role === "Admin" && (
            <>
              <div className="col-xl-3 col-lg-4 col-md-6 col-sm-12 pb-2">
                <InputLabel>Added By</InputLabel>
                <CustomDropdown
                  customClass="form-dropdown"
                  placeholder="Select Added By"
                  height="48px"
                  menu={addedBY}
                  handlefunc={(data) => {
                    getDataForPYPCard(data, data?.Title);
                  }}
                  selectedEntity={
                    PYPStores?.selectedItemsNw?.addedByList?.selectedName
                  }
                  disable={!PYPStores?.selectedItemsNw?.InstituteList?.id}
                  menuStyle={{ border: "1px solid #E3E9EE" }}
                />
              </div>
              <div className="col-xl-3 col-lg-4 col-md-6 col-sm-12 pb-2 d-flex align-items-end">
                <Button
                  title="Apply"
                  width="114px"
                  height="48px"
                  disable={!PYPStores?.selectedItemsNw?.addedByList?.id}
                  func={(e) => {
                    e.preventDefault();
                    applyFunc();
                  }}
                />
              </div>
            </>
          )}

          {show && Role?.role === "Staff" && (
            <div className="col-xl-3 col-lg-4 col-md-6 col-sm-12 pb-2 d-flex align-items-end">
              <Button
                title="Apply"
                width="114px"
                height="48px"
                disable={!Role?.instituteName && Role?.userId}
                func={(e) => {
                  e.preventDefault();
                  applyFunc();
                }}
              />
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default observer(PYPCard);
