import React from 'react'
import { useState } from 'react';
import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import { PlusIcon } from '../../../assets/svgs/svg'
import DataExtractor from '../../../component/hooks/dataExtractor';
import Button from '../../../customcomponents/button/Button'
import { HeadTitle } from '../../../customcomponents/headtitle/headTitle'
import Pagination from '../../../customcomponents/pagination/Pagination';
import Table from '../../../customcomponents/table/Table';
import AuthStore from '../../../MobX/Auth';
import PYPStores from '../../../MobX/PYPStore';
import PYPServices from '../../../Services/PYPService';
import { ClientRoutesConstants } from '../../../shared/constant';
import PYPCard from './PYPCard';
const tableHead = [
    "Name",
    "Year",
    "Institute",
    "Added By ",
    "Language",
];

/* eslint-disable */
const PYP = () => {
    const Role = AuthStore?.user?.user;
    const navigate = useNavigate()
    const [feildValue, setFieldValue] = useState({})
    const [allPapers, setAllPappers] = useState([])
    const [paperLength, setPaperLength] = useState()
    const [pageNoSize, setPageNoSize] = useState({ no: 1, size: 10 });

    useEffect(() => {
        if (Role?.role === "Staff") {
            if (PYPStores?.selectedItemsNw?.SubCourseList?.id &&
                PYPStores?.selectedItemsNw?.YearList?.selectedName &&
                Role?.instituteId &&
                "00000000-0000-0000-0000-000000000000") {
                getAllPapers()
            }
        } else {
            if (PYPStores?.selectedItemsNw?.SubCourseList?.id &&
                PYPStores?.selectedItemsNw?.YearList?.selectedName &&
                PYPStores?.selectedItemsNw?.InstituteList?.id &&
                PYPStores?.selectedItemsNw?.addedByList?.id) {
                getAllPapers()
            }
        }
    }, [])

    const getAllPapers = async (no = 1, size = 10) => {
        setPageNoSize({ no: 1, size: 10 })
        let post = {
            subCourseId: PYPStores?.selectedItemsNw?.SubCourseList?.id,
            year: PYPStores?.selectedItemsNw?.YearList?.selectedName,
            instituteId: PYPStores?.selectedItemsNw?.InstituteList?.id || Role?.instituteId,
            creationUserId: PYPStores?.selectedItemsNw?.addedByList?.id,
            pageNumber: no,
            pageSize: size
        };
        if (Role?.role === "Staff") {
            post.creationUserId = "00000000-0000-0000-0000-000000000000"
            // post.creationUserId = Role?.userid
        }
        const res = await PYPServices.getAllPaper(post);
        if (!res?.data?.previousYearPapers) {
            setPageNoSize({ ...pageNoSize, no: pageNoSize.no - 1 })
            if ((pageNoSize.no - 1) <= 0) {
                setAllPappers([])
                setPaperLength()
                return false;
            }
            else {
                return getAllPapers(pageNoSize?.no - 1, pageNoSize?.size)
            }
        }
        setPaperLength(res.data.totalRecords)
        const data= res.data.previousYearPapers.map((emp)=>
        {return {...emp, action:true}}
      )
        const extracted = DataExtractor(data, ["subCourseId", "creationDateTime"]);
        setAllPappers(extracted)
        return extracted.length
    };

    const setvalues = (name, value) => {
        setFieldValue({ ...feildValue, [name]: value })
    }

    const addFunction = () => {
        PYPStores.setSelectedItems({})
        navigate(ClientRoutesConstants.addUpdatePYP)
    }

    const editFunct = (data) => {
        navigate(ClientRoutesConstants.addUpdatePYP, {
            state: { id: data?.id },
        })
    };

    const deleteFunc = async (id) => {
        const del = await PYPServices.deletePaper({ id: id });
        if (del?.isSuccess) {
            toast.success(del?.messages);
            getAllPapers(pageNoSize?.no, pageNoSize?.size);
        } else {
            toast.error(del?.messages);
        }

    };

    return (
        <div>
            <HeadTitle
                text="Previous Year Paper"
                component1={
                    <Button
                        title="Add Previous Year Paper"
                        width="235px"
                        height="45px"
                        func={addFunction}
                        icon={<PlusIcon />}
                    />
                }

            />
            <div>
                <PYPCard applyFunc={getAllPapers} setFieldValue={setvalues} />
            </div>
            <div className='d-grid'>
                <Table
                    tableHead={tableHead}
                    tableData={allPapers}
                    navigateTo="paper-detail"
                    deleteData={deleteFunc}
                    toggleEditModal={editFunct}
                />
                {paperLength && (
                    <Pagination
                        getFunction={getAllPapers}
                        totalLength={paperLength}
                        setPageNoSize={setPageNoSize}
                        pageNoSize={pageNoSize}
                        length={allPapers?.length}
                    />
                )}
            </div>
        </div>
    )
}

export default PYP
