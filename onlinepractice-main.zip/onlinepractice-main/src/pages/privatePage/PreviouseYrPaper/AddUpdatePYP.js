import { Formik } from "formik";
import React, { useLayoutEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { pypSchema } from "../../../assets/regex/schema";
import { DataNotFound2, RupeeIcon } from "../../../assets/svgs/svg";
import Button from "../../../customcomponents/button/Button";
import CustomInput from "../../../customcomponents/customTextInput";
import { InputLabel } from "../../../customcomponents/customTextInput/indexCss";
import CustomDropdown from "../../../customcomponents/custom_Dropdown/CustomDropdown";
import {
  BoldHeading,
  TitleHeading,
} from "../../../customcomponents/DynamicText/Heading";
import { HeadTitle } from "../../../customcomponents/headtitle/headTitle";
import { DocUpload } from "../../../customcomponents/pdfUpload/DocUpload";
import AuthStore from "../../../MobX/Auth";
import PYPStores from "../../../MobX/PYPStore";
import PYPServices from "../../../Services/PYPService";
import QuestionTypeServices from "../../../Services/QuestionTypeService";
import { ClientRoutesConstants } from "../../../shared/constant";
import { ThemeColors } from "../../../theme/theme";
import PYPCard from "./PYPCard";

/* eslint-disable */
const AddUpdatePYP = () => {

  const Role = AuthStore?.user?.user;
  const location = useLocation();
  const navigate = useNavigate();
  const [language, setLanguage] = useState([]);
  const [veiwPDF, setveiwPDF] = useState("");
  const [PYPDetail, setPYPDetail] = useState({ id: location?.state?.id });
  const [disable, setDisable] = useState(true)
  useLayoutEffect(() => {
    getAllLanguage();
    if (location?.state?.id) {
      getPaperById();
    }
  }, []);

  const getAllLanguage = async () => {
    const res = await QuestionTypeServices.getAllLanguage();
    if (res?.isSuccess) {
      if (res?.data) {
        let language = res?.data.map((item) => {
          return {
            id: item?.value,
            Title: item?.name,
            label: "Language",
          };
        });
        setLanguage(language);
      }
    }
  };

  const getPaperById = async () => {
    const res = await PYPServices.getPaperById({ id: location?.state?.id });
    if (res?.isSuccess) {
      setPYPDetail(res?.data);
      setveiwPDF(res?.data?.paperPdfUrl);
      PYPStores.setSelectedItemsNw({
        selectedName: "Exam",
        props: { id: res?.data?.examTypeId, Title: res?.data?.examTypeName },
        entityName: res?.data?.examTypeName,
      });
      PYPStores.setSelectedItemsNw({
        selectedName: "Course",
        props: { id: res?.data?.courseId, Title: res?.data?.courseName },
        entityName: res?.data?.courseName,
      });
      PYPStores.setSelectedItemsNw({
        selectedName: "SubCourse",
        props: { id: res?.data?.subCourseId, Title: res?.data?.subCourseName },
        entityName: res?.data?.subCourseName,
      });
      PYPStores.setSelectedItemsNw({
        selectedName: "Institute",
        props: { id: res?.data?.instituteId, Title: res?.data?.instituteName },
        entityName: res?.data?.instituteName,
      });
      PYPStores.setSelectedItemsNw({
        selectedName: "Year",
        props: { id: res?.data?.year, Title: res?.data?.year },
        entityName: res?.data?.year,
      });
    }
  };

  const submitFunction = async (values) => {
    if (location?.state?.id) {
      if (values.paperPdfUrl !== PYPDetail.paperPdfUrl) {
        const formData = new FormData();
        formData.append("PdfUrl", values.paperPdfUrl);
        const uploadFile = await PYPServices.uploadFile(formData);
        if (uploadFile?.isSuccess) {
          toast.success(uploadFile?.messages);
          values.paperPdfUrl = uploadFile.data;
        } else {
          return toast.error(uploadFile?.messages);
        }
      }
      const putResp = await PYPServices.updatePaper(values);
      if (putResp?.isSuccess) {
        toast.success(putResp?.messages);
        navigate(ClientRoutesConstants.previousYearPaper);
      } else {
        toast.error(putResp?.messages);
      }
    } else {
      const formData = new FormData();
      formData.append("PdfUrl", values.paperPdfUrl);
      const uploadFile = await PYPServices.uploadFile(formData);
      if (uploadFile?.isSuccess) {
        toast.success(uploadFile?.messages);
        values.paperPdfUrl = uploadFile.data;
        const postResp = await PYPServices.createPaper(values);
        if (postResp?.isSuccess) {
          PYPStores.setSelectedItemsNw({
            selectedName: "AddedBy",
            props: { id: postResp?.data },
            entityName: "",
          });
          toast.success(postResp?.messages);
          navigate(ClientRoutesConstants.previousYearPaper);
        } else {
          toast.error(postResp?.messages);
        }
      } else {
        toast.error(uploadFile?.messages);
      }
    }
  };

  return (
    <Formik
      enableReinitialize
      initialValues={{
        id: PYPDetail?.id,
        examTypeId: PYPDetail?.examTypeId,
        courseId: PYPDetail?.courseId,
        subCourseId: PYPDetail?.subCourseId,
        instituteId: PYPDetail?.instituteId || Role?.instituteId,
        year: PYPDetail?.year,
        paperTitle: PYPDetail?.paperTitle,
        language: PYPDetail?.language,
        price: PYPDetail?.price,
        paperPdfUrl: PYPDetail?.paperPdfUrl,
        description: PYPDetail?.description,
      }}
      onSubmit={(values) => {
        submitFunction(values);
      }}
      validationSchema={pypSchema()}
    >
      {(props) => {
        const {
          touched,
          errors,
          values,
          setFieldValue,
          handleSubmit,
        } = props;
        return (
          <form onSubmit={handleSubmit}>
            <div className="mb-3">
              <HeadTitle
                text={`${location?.state?.id ? "Update" : "Add New"} Paper`}
              />
            </div>
            <div>
              <PYPCard
                show={false}
                setFieldValue={setFieldValue}
                errors={errors}
                touched={touched}
                values={values}
                disabled={location?.state?.id}
                setDisable={setDisable}
              />
            </div>
            <div className="row ">
              <div className="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                <div className="card p-3 border-0 rounded-0 mb-3">
                  <TitleHeading text="Basic Details" />
                  <div className="position-relative pb-2">
                    <CustomInput
                      height="48px"
                      label="Title"
                      marginBottom="10px"
                      marginTop="10px"
                      name="paperTitle"
                      id="paperTitle"
                      value={values?.paperTitle}
                      onChange={(e) => { setFieldValue("paperTitle", e.target.value); setDisable && setDisable(false) }}
                    />
                    {errors.paperTitle && touched.paperTitle && (
                      <div className="input-feedback position-absolute">
                        {errors.paperTitle}
                      </div>
                    )}
                  </div>
                  <div className="py-2">
                    <InputLabel className="pb-2">Language</InputLabel>
                    <CustomDropdown
                      customClass="form-dropdown"
                      placeholder="Select Language"
                      name="language"
                      menu={language}
                      selectedEntity={values?.language}
                      handlefunc={(data) => {
                        setFieldValue("language", data?.Title);
                        setDisable && setDisable(false)
                      }}
                      menuStyle={{ border: "1px solid #E3E9EE" }}
                    />
                    {errors.language && touched.language && (
                      <div className="input-feedback position-absolute">
                        {errors.language}
                      </div>
                    )}
                  </div>
                </div>
                <div className="card p-3 border-0 rounded-0 mb-3">
                  <TitleHeading text="Upload File" />
                  <hr />
                  <DocUpload
                    name="paperPdfUrl"
                    name2="description"
                    setFieldValue={setFieldValue}
                    orgFileSrc={PYPDetail?.paperPdfUrl}
                    fileSrc={values?.paperPdfUrl}
                    orgFileName={PYPDetail?.description}
                    fileName={values?.description}

                    setDisable={setDisable}
                    accept="application/pdf"
                    set={setveiwPDF}
                    touched={touched}
                  />
                  {errors.paperPdfUrl && touched.paperPdfUrl && (
                    <div className="input-feedback">{errors.paperPdfUrl}</div>
                  )}
                </div>

                <div className="card border-0 rounded-0 p-3 ">
                  <TitleHeading text="Price Setting" />
                  <hr />
                  <InputLabel>Price</InputLabel>
                  <div className="f f-a-row gap10">
                    <div className="RupeyBox" style={{ marginTop: "8px" }}>
                      <RupeeIcon />
                    </div>
                    <div className="price">
                      <CustomInput
                        height="48px"
                        marginBottom="10px"
                        marginTop="10px"
                        placeholder="00"
                        name="price"
                        value={values?.price}
                        onChange={(e) => { setFieldValue("price", e.target.value); setDisable && setDisable(false) }}
                        isDisabled={location?.state?.id && Role?.role === "Staff"}
                      />
                      {errors.price && touched.price && (
                        <div className="input-feedback position-absolute">
                          {errors.price}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                <div
                  className="card rounded-0 border-0 p-3"
                  style={{
                    backgroundColor: veiwPDF
                      ? ThemeColors.lightBlue
                      : ThemeColors.white,
                  }}
                >
                  <BoldHeading text="Previous Year Paper Preview" />
                  <hr style={{ marginTop: "6px" }} />
                  <div className="text-center">
                    {veiwPDF ? (
                      <iframe
                        title="pdf"
                        src={veiwPDF + "#toolbar=0&scrollbar=0"}
                        width="400"
                        height="515"
                      />
                    ) : (
                      <DataNotFound2 />
                    )}
                  </div>
                </div>
                <div className="f gap16 f-justify-end ">
                  <div className="Settingbtn mt-25">
                    <Button
                      background="rgb(171, 182, 192)"
                      title="Cancel"
                      width="137px"
                      type="submit"
                      func={(e) => {
                        e.preventDefault();

                        previousYearPaper: "/previous-year-paper",
                          navigate(ClientRoutesConstants.previousYearPaper);
                      }}
                    /></div>
                  <div className="Settingbtn mt-25">
                    <Button
                      title={location?.state?.id ? "Update" : "Continue"}
                      width="137px"
                      type="submit"
                      func={handleSubmit}

                      disable={location?.state?.id ? disable : false}

                    />
                  </div>
                </div>
              </div>
            </div>
          </form>
        );
      }}
    </Formik>
  );
};

export default AddUpdatePYP;