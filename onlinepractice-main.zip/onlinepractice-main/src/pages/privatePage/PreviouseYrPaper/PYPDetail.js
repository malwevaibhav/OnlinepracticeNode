import React, { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'
import { DeleteIcon, EditIcon, FullPdfSvg } from '../../../assets/svgs/svg'
import { downloadpdf } from '../../../component/hooks/downloadPDF'
import Button from '../../../customcomponents/button/Button'
import CustomInput from '../../../customcomponents/customTextInput'
import { InputLabel } from '../../../customcomponents/customTextInput/indexCss'
import CustomDropdown from '../../../customcomponents/custom_Dropdown/CustomDropdown'
import { HeadTitle } from '../../../customcomponents/headtitle/headTitle'
import AuthStore from '../../../MobX/Auth'
import PYPServices from '../../../Services/PYPService'
import { ClientRoutesConstants } from '../../../shared/constant'
import { ThemeColors } from '../../../theme/theme'

const PYPDetail = () => {
    const navigate = useNavigate()
    const location = useLocation()
    const [PYPDetail, setPYPDetail] = useState({});
/* eslint-disable */

const Role=AuthStore?.user?.user;
    useEffect(() => {
        getPaperById()
    }, [])

    const getPaperById = async () => {
        const res = await PYPServices.getPaperById({ id: location?.state?.id });
        if (res?.isSuccess) {
            setPYPDetail(res?.data)
      }
    };

    const deleteFunc = async (id) => {
        const del = await PYPServices.deletePaper({ id: id });
        if (del?.isSuccess) {
            toast.success(del?.messages);
            navigate(ClientRoutesConstants.previousYearPaper)
        } else {
            toast.error(del?.messages);
        }

    };
    const download = () => {
        // checkDefault(e);
        downloadpdf(PYPDetail?.paperPdfUrl,"sample")
      
    }
    return (
        <div>
            <HeadTitle
                text={PYPDetail?.paperTitle}
                component1={<InputLabel className='d-flex align-items-center' style={{ color: ThemeColors.primary }}>Total Purchase : {PYPDetail?.totalPurchase}</InputLabel>
                }
                component2={
                    (PYPDetail?.creatorUserId === Role?.userId || (Role.role === "Admin")) &&
                    <Button
                        icon={<DeleteIcon />}
                        background={ThemeColors.danger}
                        title="Delete"
                        height="42px"
                        width="121px"
                        func={() => { deleteFunc(location?.state?.id) }}

                    />
                }
                component3={ (PYPDetail?.creatorUserId === Role?.userId || (Role.role === "Admin")) &&
                <Button   func={() => { navigate(ClientRoutesConstants.addUpdatePYP, { state: { id: location?.state?.id } }) }} icon={<EditIcon />} title="Edit Details" width="154px" height="42px" />}
            />
            <div className="card py-3 border-0 rounded-0">
                <div className="row m-0 px-5 ">
                    <div className="col-xl-2 col-lg-2 col-md-4 d-grid gap-3 justify-content-center">
                        <div className='d-flex justify-content-center ps-2'>
                            <FullPdfSvg />
                        </div>
                        {
                            Role?.role==="Admin" &&
                        <div>
                            <Button
                                title="Preview"
                                width="143px"
                                func={()=>{download()}}
                            />
                        </div>
                        }
                    </div>
                    <div className="col-xl-10 col-lg-10 col-md-8">
                        <div className="row">
                            <div className="col-xl-6 col-md-12 col-sm-12">
                                <CustomInput
                                    name="ebookTitle"
                                    label="Ebook Title"
                                    placeholder="Ebook Title"
                                    value={PYPDetail?.paperTitle}
                                    isDisabled={true}
                                />
                            </div>
                            <div className="col-xl-6 col-md-12 col-sm-12" style={{ paddingTop: "20px" }}>
                                <InputLabel >Language</InputLabel>
                                <CustomDropdown
                                    customClass="form-dropdown"
                                    placeholder="Select Language"
                                    name="language"
                                    selectedEntity={PYPDetail?.language}
                                    handlefunc={() => {
                                    }}
                                    menuStyle={{ border: '1px solid #E3E9EE' }}
                                    disable={true}
                                    height="56px"
                                />
                            </div>
                            <div className="col-xl-6 col-md-12 col-sm-12">
                                <CustomInput
                                    name="category"
                                    label="Category"
                                    placeholder="Category"
                                    isDisabled={true}
                                    value={`${PYPDetail?.examTypeName} > ${PYPDetail?.courseName} > ${PYPDetail?.subCourseName}`}

                                />
                            </div>
                            <div className="col-xl-6 col-md-12 col-sm-12">
                                <CustomInput
                                    name="price"
                                    label="Price"
                                    placeholder="Price"
                                    isDisabled={true}
                                    value={` ₹${PYPDetail?.price}`}

                                />
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    )
}

export default PYPDetail
