import { Formik } from "formik";
import React, { useLayoutEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { EditInstituteSchema } from "../../../../assets/regex/schema";
import {
  BlueEditIcon,
  DataNotFound2,
  DeleteIcon,
  EnrollmentIcon,
  SalesIcon,
} from "../../../../assets/svgs/svg";
import Button from "../../../../customcomponents/button/Button";
import CustomInput from "../../../../customcomponents/customTextInput";
import CustomDropdown from "../../../../customcomponents/custom_Dropdown/CustomDropdown";
import Carddynamic from "../../../../customcomponents/dashboradcard/CardDynamic";
import {
  CardData,
  TileHeading,
} from "../../../../customcomponents/DynamicText/Heading";
import { HeadTitle } from "../../../../customcomponents/headtitle/headTitle";
import DeleteModal from "../../../../customcomponents/modalPopup/deleteModal/DeleteModal";
import Table from "../../../../customcomponents/table/Table";
import Tabs from "../../../../customcomponents/Tabs/Tabs";
import InstituteServices from "../../../../Services/InstituteService";
import { ClientRoutesConstants } from "../../../../shared/constant";
import { ThemeColors } from "../../../../theme/theme";
import InstituteModal from "../../custommodals/instituteModal";
import "../institute.css";
export default function InstituteDetail() {
  const navigate = useNavigate();
  const location = useLocation();
  const [instituteDetail, setInstituteDetail] = useState({});
  const [isEdit, setIsEdit] = useState(false);
  const [toggleModal, settoggleModal] = useState(false);
  const tableHead = [
    "Heading",
    "Description",
    "Category",
    "Last Update (Date & Time)",
  ];
  const data = [
    {
      heading: "Ebook",
      body: <Table tableHead={tableHead} />,
    },
    {
      heading: "Mock test",
      body: <Table tableHead={tableHead} />,
    },
    {
      heading: "Video",
      body: <Table tableHead={tableHead} />,
    },
    {
      heading: "Previous Year Paper",
      body: <Table tableHead={tableHead} />,
    },
  ];
  const data1 = [
    {
      heading: "Overall Transactions",
      body: (
        <div className="card border-0 rounded-1 d-flex align-items-center">
          <DataNotFound2 />
        </div>
      ),
    },
    {
      heading: "Modules",
      body: (
        <div className="card border-0 rounded-1 d-flex align-items-center">
          <DataNotFound2 />
        </div>
      ),
    },
  ];
  const menu1 = [
    { Title: "This month" },
    { Title: "This year" },
    { Title: "This week" },
    { Title: "Today" },
  ];
  const menuStyle = {
    color: ThemeColors.link,
    backgroundColor: ThemeColors.selectButton,
    border: "1px solid #C7E1FF",
    minWidth: "130px",
    fontFamily: "Medium",
    transform: "translate(0px, 83px) !important",
  };
  useLayoutEffect(() => {
    getInstituteById(location?.state?.id);
  }, [location?.state?.id, toggleModal]);

  const getInstituteById = async (id) => {
    const getbyid = await InstituteServices.getInstituteById({ id: id });
    setInstituteDetail(getbyid);
  };

  const UpdateIntitute = async (values) => {
    if (location?.state?.id) {
      const updateRes = await InstituteServices.updateInstitute(values);
      if (updateRes?.isSuccess) {
        toast.success(updateRes?.messages);
      } else {
        toast.error(updateRes?.messages);
      }
    }
  };
  const deleteFunc = async (id) => {
    const deleteData = await InstituteServices.deleteInstitute({ id: id });
    if (deleteData?.isSuccess) {
      navigate(ClientRoutesConstants?.institute);
      toast.success(deleteData?.messages);
    } else {
      toast.error(deleteData?.messages);
    }
  };
  return (
    <>
      <div className="d-grid ps-1 pe-2">
        <HeadTitle
          text="Institute Details"
          component1={
            <Button
              background={ThemeColors.danger}
              title="Delete"
              func={() => {
                settoggleModal("delete");
              }}
              width="121px"
              // icon={<DeleteIcon />}
            />
          }
        />
      </div>
 <div className="d-flex gap-5">
 <div className="mb-3">
              <div className="card  border-0 rounded-1">
                <Carddynamic
                  title={<TileHeading text="TOTAL STUDENTS" />}
                  icon={<EnrollmentIcon />}
                  detail={<CardData text={instituteDetail?.totalStudent} />}
                  height="100%"
                />
              </div>
       </div>
            <div className="mb-3">
              <div className="card border-0 rounded-1 ">
                <Carddynamic
                  title={<TileHeading text="TOTAL STAFF" />}
                  icon={<EnrollmentIcon />}
                  detail={<CardData text={instituteDetail?.totalStaff} />}
                  height="100%"
                />
              </div>
        
          </div>
 </div>
      
      <div className="row">
        <div className="new-class-1 mb-3 pe-2">
          <div className="card border-0 rounded-1 p-3 py-4">
            <Formik
              enableReinitialize
              initialValues={{
                instituteCode: instituteDetail?.instituteCode,
                instituteName: instituteDetail?.instituteName,
                instituteContactNo: instituteDetail?.instituteContactNo,
                instituteContactPerson: instituteDetail?.instituteContactPerson,
                instituteEmail: instituteDetail?.instituteEmail,
                instituteCity: instituteDetail?.instituteCity,
                instituteAddress: instituteDetail?.instituteAddress,
                instituteLogo: instituteDetail?.instituteLogo,
              }}
              onSubmit={(values) => {
                UpdateIntitute({ ...values, id: location?.state?.id });
                setIsEdit(false);
              }}
              validationSchema={EditInstituteSchema()}
            >
              {(props) => {
                const { touched, errors, handleChange, values, handleSubmit } =
                  props;
                return (
                  <form onSubmit={handleSubmit}>
                    <div className="row m-0 mb-2">
                      <div className="col-6 mb-2" style={{ height: "80px" }}>
                        <img
                          src={values?.instituteLogo}
                          alt="Institute logo"
                          style={{
                            width: "100px",
                            height: "100px",
                            objectFit: "fill",
                            borderRadius: "5px",
                            maxWidth: "100px",
                            maxHeight: "100px",
                          }}
                        />
                      </div>
                      <div className="col-6 d-flex justify-content-end">
                        {!isEdit ? (
                          <Button
                            title="Edit"
                            icon={<BlueEditIcon />}
                            textColor="#0075FF"
                            background="#DCEEFF"
                            width="108px"
                            height="34px"
                            func={(e) => {
                              settoggleModal("update");
                              e.preventDefault();
                            }}
                          />
                        ) : (
                          // <Button title="Edit" icon={<BlueEditIcon />} textColor="#0075FF" background="#DCEEFF" width="108px" height="34px" func={(e) => { setIsEdit(!isEdit); e.preventDefault() }} />
                          <Button
                            title="Update"
                            width="108px"
                            height="34px"
                            type="submit"
                          />
                        )}
                      </div>
                    </div>
                    <div className="row m-0 gap-3">
                      <div className="position-relative">
                        <CustomInput
                          height="48px"
                          name="instituteCode"
                          label="Institute Code"
                          value={values?.instituteCode}
                          placeholder="Enter institute code"
                          onChange={handleChange}
                          isDisabled={!isEdit}
                        />
                        {errors.instituteCode && touched.instituteCode && (
                          <div className="input-feedback position-absolute">
                            {errors.instituteCode}
                          </div>
                        )}
                      </div>
                      <div className="position-relative">
                        <CustomInput
                          height="48px"
                          name="instituteName"
                          label="Institute Name"
                          value={values?.instituteName}
                          placeholder="Institute Name"
                          onChange={handleChange}
                          isDisabled={!isEdit}
                        />
                        {errors.instituteName && touched.instituteName && (
                          <div className="input-feedback position-absolute">
                            {errors.instituteName}
                          </div>
                        )}
                      </div>

                      <div className="position-relative">
                        <CustomInput
                          height="48px"
                          name="instituteCity"
                          value={values?.instituteCity}
                          label="City"
                          placeholder="Enter city name"
                          onChange={handleChange}
                        />
                        {errors.instituteCity && touched.instituteCity && (
                          <div className="input-feedback position-absolute">
                            {errors.instituteCity}
                          </div>
                        )}
                      </div>
                      <div className="position-relative">
                        <CustomInput
                          height="48px"
                          name="instituteEmail"
                          label="Email Address"
                          value={values?.instituteEmail}
                          placeholder="Email Address"
                          onChange={handleChange}
                          isDisabled={!isEdit}
                        />
                        {errors.instituteEmail && touched.instituteEmail && (
                          <div className="input-feedback position-absolute">
                            {errors.instituteEmail}
                          </div>
                        )}
                      </div>

                      <div className="position-relative">
                        <CustomInput
                          height="48px"
                          name="instituteContactNo"
                          label="Mobile Number"
                          value={values?.instituteContactNo}
                          placeholder="Ex. 91 9876543210"
                          onChange={handleChange}
                          isDisabled={!isEdit}
                        />
                        {errors.instituteContactNo &&
                          touched.instituteContactNo && (
                            <div className="input-feedback position-absolute">
                              {errors.instituteContactNo}
                            </div>
                          )}
                      </div>

                      <div className="position-relative">
                        <CustomInput
                          height="48px"
                          name="instituteContactPerson"
                          label="Contact Person"
                          value={values?.instituteContactPerson}
                          placeholder="Contact Person"
                          onChange={handleChange}
                          isDisabled={!isEdit}
                        />
                        {errors.instituteContactPerson &&
                          touched.instituteContactPerson && (
                            <div className="input-feedback position-absolute">
                              {errors.instituteContactPerson}
                            </div>
                          )}
                      </div>

                      <div className="position-relative">
                        <CustomInput
                          height="48px"
                          name="instituteAddress"
                          label="Address"
                          value={values?.instituteAddress}
                          placeholder="Address"
                          onChange={handleChange}
                          isDisabled={!isEdit}
                        />
                        {errors.instituteAddress &&
                          touched.instituteAddress && (
                            <div className="input-feedback position-absolute">
                              {errors.instituteAddress}
                            </div>
                          )}
                      </div>
                    </div>
                  </form>
                );
              }}
            </Formik>
          </div>
        </div>
      </div>
    
      {toggleModal === "delete" && (
        <DeleteModal
          onRequestClose={() => {
            settoggleModal("");
          }}
          name={instituteDetail.instituteName}
          onPress={() => {
            deleteFunc(location?.state?.id);
          }}
        />
      )}
      {toggleModal === "update" && (
        <InstituteModal
          onRequestClose={() => settoggleModal("")}
          isEdit={isEdit}
          instituteId={location?.state?.id}
        />
      )}






        {/* remove  for ui for now  */}
      {/* <div className="d-grid  ps-1 pe-2 ">
        <HeadTitle text="Study Material" />
      </div> */}
      {/* <div className="mt-2 ps-1">
        <Tabs data={data} />
      </div> */}
    </>
  );
}
