import React, { useEffect, useState } from "react";
import { toast } from "react-toastify";
import { InstituteIcon } from "../../../assets/svgs/svg";
import DataExtractor from "../../../component/hooks/dataExtractor";
import { CardSubHeading } from "../../../customcomponents/DynamicText/Heading";
import { HeadTitle } from "../../../customcomponents/headtitle/headTitle";
import Pagination from "../../../customcomponents/pagination/Pagination";
import Table from "../../../customcomponents/table/Table";
import InstituteServices from "../../../Services/InstituteService";
import InstituteModal from "../custommodals/instituteModal";

export default function Institute() {
  const [toggleModal, setToggleModal] = useState(false);
  const [institute, setInstitute] = useState([]);
  const [instituteLength, setInstituteLength] = useState();
  const [isEdit, setIsEdit] = useState(false);
  const [instituteId, setInstituteId] = useState();
  const [pageNoSize, setPageNoSize] = useState({ no: 1, size: 10 });
  const tHead = [
    "Institute Name",
    "Contact Number",
    "Contact Person",
    "Email Address",
    "City",
  ];
  /* eslint-disable */
  useEffect(() => {
    getAllInstitute();
  }, []);

  const getAllInstitute = async (no = 1, size = 10) => {
    const resData = await InstituteServices.getAllInstitute({
      pageNumber: no,
      pageSize: size,
    });
    if (!resData?.institutes) {
      setPageNoSize({ ...pageNoSize, no: pageNoSize.no - 1 })
      if ((pageNoSize.no - 1) <= 0) {
        setInstitute([])
        setInstituteLength()
        return false
      }
      else {
        return getAllInstitute(pageNoSize?.no, pageNoSize?.size)
      }
    }
    if(resData?.totalRecords===1){
      setPageNoSize({ ...pageNoSize, no:  1 })
    }
    setInstituteLength(resData?.totalRecords);
    const data=  resData?.institutes.map((emp)=>
    {return {...emp, action:true}}
  )
    const extracted = DataExtractor(data, [
      "creationDate",
      "lastModifiedDate",
      "instituteLogo",
      "instituteCode",
      "instituteAddress",
    ]);

    setInstitute(extracted);
    return extracted.length
  };

  const deleteFunc = async (id) => {
    const deleteData = await InstituteServices.deleteInstitute({ id: id });
    if (deleteData?.isSuccess) {
      toast.success(deleteData?.messages);
      getAllInstitute(pageNoSize?.no, pageNoSize?.size);
    } else {
      toast.error(deleteData?.messages);
    }

  };

  return (
    <div className="">
      <div className="d-grid mb-2">
        <HeadTitle text="Institute" />
      </div>
      <div className="row m-0">
        <div className="col-md-3 col-sm-6 p-0 ">
          <div
            className="card d-flex align-items-center p-4  spCard"
            onClick={() => {
              setIsEdit(false);
              setToggleModal(!toggleModal);
              setInstituteId(null);
            }}
          >
            <InstituteIcon />
            <CardSubHeading text="Add New Institute" />
          </div>
        </div>
      </div>
      <div className="d-grid mt-3">
        <Table
          tableHead={tHead}
          tableData={institute}
          toggleEditModal={() => {
            setIsEdit(true);
            setToggleModal(!toggleModal);
          }}
          setId={setInstituteId}
          navigateTo="institute-detail"
          deleteData={deleteFunc}
          
        />
        {instituteLength && (
          <Pagination
            getFunction={getAllInstitute}
            totalLength={instituteLength}
            setPageNoSize={setPageNoSize}
            pageNoSize={pageNoSize}
            length={institute.length}
          />
        )}
      </div>
      {toggleModal && (
        <InstituteModal
          onRequestClose={() => setToggleModal(!toggleModal)}
          isEdit={isEdit}
          instituteId={instituteId}
          pageNoSize={pageNoSize}
          getAllInstitute={getAllInstitute}
        />
      )}
    </div>
  );
}
