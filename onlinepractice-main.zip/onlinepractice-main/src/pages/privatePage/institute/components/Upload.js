import React, { useEffect, useRef, useState } from "react";
import { toast } from "react-toastify";
import { UploadIcon } from "../../../../assets/svgs/svg";
import Button from "../../../../customcomponents/button/Button";

function CustomUpload({
  onDrop,
  maxFiles = 1,
  name,
  setFieldValue,
  imgSrc,
  accept,
}) {
  const [isFile, setIsFile] = useState(true);
  const [over, setover] = useState(false);
  const [files, setfiles] = useState();
  const $input = useRef(null);

  useEffect(() => {
    if (imgSrc && files === undefined) {
      setIsFile(false);
      setfiles(imgSrc);
    }
    if (onDrop) {
      onDrop(files);
    }
  }, [files, onDrop, imgSrc]);

  const ImgUpload = async (file) => {
    if (
      file[0]?.type === "image/png" ||
      file[0]?.type === "image/jpg" ||
      file[0]?.type === "image/jpeg" ||
      file[0]?.type === "image/bmp" ||
      file[0]?.type === "application/pdf"
    ) {
      setFieldValue(name, file[0]);
      // setFieldValue("instituteLogo", file[0]);
      setIsFile(false);
      setfiles(URL.createObjectURL(file[0]));
    } else {
      toast.error("file format is not valid");
    }
  };
  return (
    <>
      <div className="row m-0 mt-2">
        {isFile && (
          <div
            className="card  rounded-3 text-center"
            style={{ backgroundColor: "#ECF5FF", border: "1px dashed #ABB6C0" }}
          >
            <div
              onClick={() => {
                $input.current.click();
              }}
              onDrop={(e) => {
                e.preventDefault();
                e.persist();
                ImgUpload(e.dataTransfer.files);
                setIsFile(false);
                setover(false);
              }}
              onDragOver={(e) => {
                e.preventDefault();
                setover(true);
              }}
              onDragLeave={(e) => {
                e.preventDefault();
                setover(false);
              }}
            >
              <div
                className={`${
                  over ? "upload-container over" : "upload-container"
                } mt-4`}
              >
                <UploadIcon width="35" height="25" />
                <h6 className="SemiBold mt-2 d-flex justify-content-center">
                  Drag and drop your file here or &nbsp;
                  <p className="text-primary pointer">Browse</p>
                </h6>
                <input
                  name={name}
                  style={{ display: "none" }}
                  type="file"
                  accept={`image/png, image/jpeg, image/jpg, image/bmp ${accept}`}
                  ref={$input}
                  onChange={(e) => {
                    ImgUpload(e.target.files);
                  }}
                  multiple={maxFiles > 1}
                />
              </div>
            </div>
          </div>
        )}
        {
          !isFile && (
            // files.map((file) => (
            //   <>
            <div className="blob-container d-flex align-items-center ps-0 mt-2">
              <div>
                <img
                  style={{
                    width: "150px",
                    height: "150px",
                    objectFit: "contain",
                    borderRadius: "5px",
                  }}
                  accept={`image/png, image/jpeg, image/jpg, image/bmp ${accept}`}
                  key={files + "file"}
                  src={files}
                  alt="your file"
                />
              </div>
              <div
                className="ms-4"
                onClick={() => {
                  $input.current.click();
                }}
              >
                <input
                  name={name}
                  onChange={(e) => {
                    ImgUpload(e.target.files);
                  }}
                  multiple={maxFiles > 1}
                  style={{ display: "none" }}
                  type="file"
                  accept="image/*"
                  ref={$input}
                />
                <Button
                  title="Change Logo"
                  width="166px"
                  func={(e) => e.preventDefault()}
                />
              </div>
            </div>
          )
          //   </>
          // ))
        }
      </div>
    </>
  );
}

export { CustomUpload };
