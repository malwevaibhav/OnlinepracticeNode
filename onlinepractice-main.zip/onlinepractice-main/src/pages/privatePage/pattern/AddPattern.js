import { FieldArray, Form, Formik } from "formik";
import { toJS } from "mobx";
import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import * as Yup from "yup";

import { BluePlusIcon, DeleteRedIcon } from "../../../assets/svgs/svg";
import Button from "../../../customcomponents/button/Button";
import CustomInput from "../../../customcomponents/customTextInput";
import { InputLabel } from "../../../customcomponents/customTextInput/indexCss";
import CustomDropdown from "../../../customcomponents/custom_Dropdown/CustomDropdown";
import { TitleHeading } from "../../../customcomponents/DynamicText/Heading";
import { HeadTitle } from "../../../customcomponents/headtitle/headTitle";
import CourseStore from "../../../MobX/Courses";
import CourseServices from "../../../Services/CourseService";
import PatternServices from "../../../Services/patternService";
import { ClientRoutesConstants } from "../../../shared/constant";
import { ThemeColors } from "../../../theme/theme";
import "./pattern.css";

export default function AddPattern() {
  const navigate = useNavigate();
  const location = useLocation();
  const [initValue, setInitValue] = useState({
    id: location?.state?.id,
    examPatternName: "",
    generalInstruction: "",
    section: [
      {
        subjectId: "",
        subjectName: "",
        subSection: [
          {
            totalQuestions: "",
            totalAttempt: "",
          },
        ],
      },
    ],
  });

  useEffect(() => {
    CourseServices.getNewAllSubject();
    if (location?.state?.id) {
      getPatternDetail(location?.state?.id);
    }
  }, [location?.state?.id]);

  const schema = Yup.object().shape({
    examPatternName: Yup.string().required("Exam Pattern Name is required"),
    section: Yup.array().of(
      Yup.object().shape({
        subjectName: Yup.string().required("Subject is required"),
        subjectId: Yup.string(),
        subSection: Yup.array().of(
          Yup.object().shape({
            totalQuestions: Yup.number()
              .moreThan(
                0,
                `Total question should not be zero or less than zero`
              )
              .required("Total number of question is required"),
            // totalAttempt: Yup.number().lessThan(Yup.ref("totalQuestions"), "Total attempt should not be more than Total questions").moreThan(-1, `Total attempt should not be  less than zero`).required('Total attempt is required'),
            totalAttempt: Yup.number()
              .moreThan(0, `Total attempt should not be  less than zero`)
              .max(
                Yup.ref("totalQuestions"),
                "Total attempt should not be more than Total questions"
              )
              .required("Total attempt is required"),
          })
        ),
      })
    ),
  });

  const submitPattern = async (value) => {
    let res;
    if (location?.state?.id) {
      res = await PatternServices.updatePattern(value);
      if (res.isSuccess) {
        toast.success(res.messages);
        navigate(ClientRoutesConstants.pattern);
      } else {
        toast.error(res.messages);
      }
    } else {
      res = await PatternServices.createPattern(value);
      if (res.isSuccess) {
        toast.success(res.messages);
        navigate(ClientRoutesConstants.generalInstruction, {
          state: { id: res?.data, examPatternName: value.examPatternName },
        });
      } else {
        toast.error(res.messages);
      }
    }
  };

  const getPatternDetail = async (id) => {
    const res = await PatternServices.getPatternById({ id: id });
    setInitValue(res);
    if (res.isSuccess) {
      setInitValue(res.data);
    } else {
      toast.error(res.messages);
    }
  };

  return (
    <>
      <div>
        <HeadTitle
          text="Pattern"
          component1={
            location?.state?.id && (
              <Button
                title={`${
                  initValue.generalInstruction ? "Edit" : "Add"
                } General Instruction`}
                width="230px"
                height="48px"
                func={() => {
                  navigate(ClientRoutesConstants.generalInstruction, {
                    state: {
                      id: initValue?.id,
                      generalInstruction: initValue?.generalInstruction,
                      examPatternName: initValue?.examPatternName,
                    },
                  });
                }}
              />
            )
          }
        />
      </div>

      <Formik
        enableReinitialize
        initialValues={initValue}
        validationSchema={schema}
        onSubmit={(values) => {
          submitPattern(values);
        }}
      >
        {(props) => {
          const { values, errors, touched, handleChange, setFieldValue } =
            props;
          return (
            <Form>
              <FieldArray name="section">
                {({ remove, push }) => (
                  <>
                    <div className="row m-0 gap-3 mt-2">
                      <div className="card py-3 px-4 border-0">
                        <div className="ps-0 pb-1">
                          <InputLabel>Pattern Name</InputLabel>
                        </div>
                        <CustomInput
                          height="48px"
                          placeholder="Enter pattern name"
                          name="examPatternName"
                          onChange={handleChange}
                          value={values?.examPatternName}
                        />
                        {errors?.examPatternName &&
                          touched?.examPatternName && (
                            <div className="input-feedback ">
                              {errors?.examPatternName}
                            </div>
                          )}
                      </div>

                      {values?.section?.length > 0 &&
                        values.section.map((sec, index) => {
                          return (
                            <div
                              className="card py-3 pt-0 px-4 border-0"
                              key={index}
                            >
                              <div className="ps-0 py-3">
                                <TitleHeading text="Select Subject" />
                              </div>
                              <div className="col-xl-3 col-lg-4 col-md-5 col-sm-12">
                                <CustomDropdown
                                  menu={toJS(CourseStore?.allSubjectList)}
                                  customClass="form-dropdown"
                                  handlefunc={() => {}}
                                  setFieldValue={setFieldValue}
                                  selectedEntity={sec?.subjectName}
                                  placeholder="Select Subject"
                                  name={`section[${index}].subjectName`}
                                  name1={`section[${index}].subjectId`}
                                />
                                {errors &&
                                  errors?.section &&
                                  errors?.section[index]?.subjectName &&
                                  touched &&
                                  touched?.section &&
                                  touched?.section[index]?.subjectName && (
                                    <div className="input-feedback ">
                                      {errors?.section[index]?.subjectName}
                                    </div>
                                  )}
                              </div>
                              <div
                                className="d-flex justify-content-end position-absolute"
                                style={{ right: 0, padding: "12px 25px 0 0" }}
                              >
                                <div
                                  className="rounded-1 bg-white  border border-1"
                                  style={{ padding: "3px 0px 3px 10px" }}
                                  onClick={() => remove(index)}
                                >
                                  <DeleteRedIcon />
                                </div>
                              </div>
                              {/* <FieldArray name={`section.${index}.subSection`}> */}
                              <FieldArray name={`section[${index}].subSection`}>
                                {({ remove, push }) => (
                                  <>
                                    {sec.subSection.map((subSec, subIndex) => {
                                      return (
                                        <div
                                          className="card border-0 py-3 px-3 mt-3"
                                          style={{ background: "#ECF5FF" }}
                                          key={subIndex}
                                        >
                                          <div className="row m-0">
                                            <div className="d-flex justify-content-between align-items-end">
                                              <TitleHeading
                                                text={`Section ${subIndex + 1}`}
                                              />
                                              <div
                                                className="rounded-1 bg-white border border-1"
                                                style={{
                                                  padding: "4px 2px 5px 12px",
                                                }}
                                                onClick={() => remove(subIndex)}
                                              >
                                                <DeleteRedIcon />
                                              </div>
                                            </div>
                                            <div>
                                              <hr className="mb-2 " />
                                            </div>
                                            <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12 ">
                                              <CustomInput
                                                height="48px"
                                                background="white"
                                                name={`section[${index}].subSection[${subIndex}].totalQuestions`}
                                                // name={`section.${index}.subSection.${subIndex}.totalQuestions`}
                                                onChange={handleChange}
                                                placeholder="Enter no. of question"
                                                type="number"
                                                value={subSec?.totalQuestions}
                                                label="Total Number of questions"
                                              />
                                              {errors &&
                                                errors?.section &&
                                                errors?.section[index]
                                                  ?.subSection &&
                                                errors?.section[index]
                                                  ?.subSection[subIndex]
                                                  ?.totalQuestions &&
                                                touched &&
                                                touched?.section &&
                                                touched?.section[index]
                                                  ?.subSection &&
                                                touched?.section[index]
                                                  ?.subSection[subIndex]
                                                  ?.totalQuestions && (
                                                  <div className="input-feedback ">
                                                    {
                                                      errors?.section[index]
                                                        ?.subSection[subIndex]
                                                        ?.totalQuestions
                                                    }
                                                  </div>
                                                )}
                                            </div>
                                            <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12 ">
                                              <CustomInput
                                                height="48px"
                                                background="white"
                                                name={`section[${index}].subSection[${subIndex}].totalAttempt`}
                                                // name={`section.${index}.subSection.${subIndex}.totalAttempt`}
                                                placeholder="Enter no. of attempt"
                                                type="number"
                                                onChange={handleChange}
                                                value={subSec.totalAttempt}
                                                label="Total Attempt"
                                              />

                                              {errors &&
                                                errors?.section &&
                                                errors?.section[index]
                                                  ?.subSection &&
                                                errors?.section[index]
                                                  ?.subSection[subIndex]
                                                  ?.totalAttempt &&
                                                touched &&
                                                touched?.section &&
                                                touched?.section[index]
                                                  ?.subSection &&
                                                touched?.section[index]
                                                  ?.subSection[subIndex]
                                                  ?.totalAttempt && (
                                                  <div className="input-feedback ">
                                                    {
                                                      errors?.section[index]
                                                        ?.subSection[subIndex]
                                                        ?.totalAttempt
                                                    }
                                                  </div>
                                                )}
                                              {/* {ErrorView(errors,touched,index,subIndex)} */}
                                            </div>
                                          </div>
                                        </div>
                                      );
                                    })}

                                    <div className="mt-3">
                                      <Button
                                        title="Add New"
                                        width="132px"
                                        height="42px"
                                        icon={<BluePlusIcon />}
                                        func={() =>
                                          push({
                                            totalQuestions: "",
                                            totalAttempt: "",
                                          })
                                        }
                                        type="button"
                                        color={ThemeColors.primary}
                                        background="white"
                                        border="1px solid #E3E9EE"
                                      />
                                    </div>
                                  </>
                                )}
                              </FieldArray>
                            </div>
                          );
                        })}
                    </div>
                    <div className="mt-3 d-flex justify-content-between">
                      <Button
                        title="Add New Section"
                        width="186px"
                        height="42px"
                        icon={<BluePlusIcon />}
                        type="button"
                        color={ThemeColors.primary}
                        background="white"
                        border="1px solid #E3E9EE"
                        func={() => {
                          push({
                            subjectName: "",
                            subjectId: "",
                            subSection: [
                              {
                                totalQuestions: "",
                                totalAttempt: "",
                              },
                            ],
                          });
                        }}
                      />
                      <Button
                        title={location?.state?.id ? "Update" : "Save"}
                        width="108px"
                        type="submit"
                      />
                    </div>
                  </>
                )}
              </FieldArray>
            </Form>
          );
        }}
      </Formik>
    </>
  );
}
