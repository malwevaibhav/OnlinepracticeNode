import { MathJax } from "better-react-mathjax";
import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

import { EditIcon } from "../../../assets/svgs/svg";
import EditorCK from "../../../component/CKEditor/EditorCK";
import Button from "../../../customcomponents/button/Button";
import { TitleHeading } from "../../../customcomponents/DynamicText/Heading";
import { HeadTitle } from "../../../customcomponents/headtitle/headTitle";
import PatternServices from "../../../Services/patternService";
import { ClientRoutesConstants } from "../../../shared/constant";
import { ThemeColors } from "../../../theme/theme";

export default function GeneralInstruction() {
  const location = useLocation();
  const [value, setValue] = useState(location?.state?.generalInstruction);
  const [view, setView] = useState(location?.state?.view);
  const navigate = useNavigate();
  const submitGeneralIns = async () => {
    let res;
    res = await PatternServices.editInstruction({
      id: location?.state?.id,
      generalInstruction: value,
    });
    if (res?.isSuccess) {
      toast.success(res.messages);
      navigate(ClientRoutesConstants.pattern);
    } else {
      toast.success(res.messages);
    }
  };

  return (
    <div style={{ flexShrink: 1, width: "98.9%" }}>
      <div>
        <HeadTitle
          text="General Instructions"
          component1={
            view && (
              <Button
                title="Edit Details"
                icon={<EditIcon />}
                width="154px"
                height="48px"
                func={() => setView(false)}
              />
            )
          }
        />
      </div>
      <div className="mt-3">
        <div
          style={{
            backgroundColor: ThemeColors.darkSecondary,
            padding: "10px 10px 10px 20px",
          }}
        >
          <TitleHeading text={location?.state?.examPatternName} />
        </div>
        {view ? (
          <div className="card rounded-0 p-3">
            <MathJax>
              <p dangerouslySetInnerHTML={{ __html: value }} />
            </MathJax>
          </div>
        ) : (
          <EditorCK value={value} setValue={setValue} />
        )}
      </div>
      <div className="modal-footer mt-4 gap-3">
        {!view && (
          <Button title="Save" width="110px" func={submitGeneralIns}></Button>
        )}
      </div>
    </div>
  );
}
