import React from "react";
import { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { EditIcon } from "../../../assets/svgs/svg";
import Button from "../../../customcomponents/button/Button";
import { TitleHeading } from "../../../customcomponents/DynamicText/Heading";
import { HeadTitle } from "../../../customcomponents/headtitle/headTitle";
import PatternServices from "../../../Services/patternService";
import { ClientRoutesConstants } from "../../../shared/constant";
import { ThemeColors } from "../../../theme/theme";

/* eslint-disable */
export default function PatternDetails() {
  const location = useLocation();
  const navigate = useNavigate();
  const [pattern, setPattern] = useState([]);
  const [count, setCount] = useState(0);
  useEffect(() => {
    getPatternDetail(location?.state?.id);
  }, []);

  const getPatternDetail = async (id) => {
    const res = await PatternServices.getPatternById({ id: id });
    if (res.isSuccess) {
      let temp = 0;
      res?.data?.section.map((x) => {
        if (x.subSection.length > temp) {
          temp = x?.subSection.length;
        }
      });
      setCount(temp);
      setPattern(res.data);
    }
  };
  return (
    <>
      <div>
        <HeadTitle
          text="Pattern Detail"
          component2={
            <Button
              title="Edit Details"
              icon={<EditIcon />}
              width="154px"
              height="48px"
              func={() =>
                navigate(ClientRoutesConstants.addPattern, {
                  state: { id: location?.state?.id },
                })
              }
            />
          }
          component1={
            <Button
              title={`${
                pattern.generalInstruction ? "View" : "Add"
              } General Instruction`}
              width="215px"
              height="48px"
              func={() =>
                navigate(ClientRoutesConstants.generalInstruction, {
                  state: {
                    id: location?.state?.id,
                    examPatternName: pattern.examPatternName,
                    generalInstruction: pattern.generalInstruction,
                    view: pattern.generalInstruction ? true : false,
                  },
                })
              }
            />
          }
        />
      </div>
      <div
        style={{
          backgroundColor: ThemeColors.darkSecondary,
          padding: "10px 10px 10px 20px",
        }}
      >
        <TitleHeading text={pattern.examPatternName} />
      </div>
      <div className="card p-3 rounded-0 border-0">
        <div className="col-xl-10 col-lg-10 col-md-10 col-sm-12">
          <div className="table-responsive">
            <table className="table table-bordered">
              <thead>
                <tr
                  className="text-center text-white"
                  style={{ backgroundColor: ThemeColors.primary }}
                >
                  <td>Subject</td>
                  <td colSpan="100" scope="row">
                    Maximum Question and Type
                  </td>
                </tr>
              </thead>
              <tbody>
                <tr className="text-center">
                  <td></td>
                  {count > 0 &&
                    [...Array(count)].map((_, index) => {
                      return (
                        <td
                          key={index}
                          style={{
                            paddingBlock: "1rem",
                          }}
                        >
                          Section {index + 1} (No of Question)
                        </td>
                      );
                    })}
                </tr>
                {pattern?.section &&
                  pattern?.section.map((data, key) => {
                    return (
                      <tr className="text-center" key={key}>
                        <td
                          style={{
                            paddingBlock: "1rem",
                          }}
                        >
                          {data?.subjectName}
                        </td>
                        {data?.subSection.map((sub, key) => {
                          return (
                            <td
                              style={{
                                paddingBlock: "1rem",
                              }}
                              key={key}
                            >
                              {sub?.totalAttempt} out of {sub?.totalQuestions}
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
        </div>
        <Button
          title={`Total Question : ${pattern?.totalQuestion}`}
          background={ThemeColors.lightBlue}
          textColor={ThemeColors.primary}
          width="175px"
          height="39px"
          border="1px solid #E3E9EE"
          fontSize="16px"
        />
      </div>
    </>
  );
}
