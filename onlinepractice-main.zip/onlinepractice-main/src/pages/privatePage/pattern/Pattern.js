import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

import { PlusIcon } from "../../../assets/svgs/svg";
import DataExtractor from "../../../component/hooks/dataExtractor";
import Button from "../../../customcomponents/button/Button";
import { HeadTitle } from "../../../customcomponents/headtitle/headTitle";
import Pagination from "../../../customcomponents/pagination/Pagination";
import Table from "../../../customcomponents/table/Table";
import PatternServices from "../../../Services/patternService";
import { ClientRoutesConstants } from "../../../shared/constant";

/* eslint-disable */
export default function Pattern() {
  const navigate = useNavigate();
  const [allPattern, setAllPattern] = useState([]);
  const [patternLength, setPatternLength] = useState();
  const [pageNoSize, setPageNoSize] = useState({ no: 1, size: 10 });
  useEffect(() => {
    getAllPattern();
  }, []);
  const getAllPattern = async (no = 1, size = 10) => {
    const res = await PatternServices.getAllPattern({
      pageNumber: no,
      pageSize: size,
    });
    if (!res?.examPatterns) {
      setPageNoSize({ ...pageNoSize, no: pageNoSize.no - 1 });
      if (pageNoSize.no - 1 <= 0) {
        setAllPattern([]);
        setPatternLength();
        return false;
      } else {
        return getAllPattern(pageNoSize?.no - 1, pageNoSize?.size);
      }
    }
    setPatternLength(res?.totalRecords);
    //  let  pattern= {...res?.examPatterns}
      // console.log("object",pattern);
    const data=  res?.examPatterns.map((emp)=>
        {return {...emp, action:true}}
      )
    const extracted = DataExtractor(data, [
      "creationDate",
      "lastModifiedDate",
    ]);
    setAllPattern(extracted);
    return extracted.length;
  };

  const editFunct = (data) => {
    navigate(ClientRoutesConstants.addPattern, {
      state: { id: data?.id },
    });
  };

  const deleteFunc = async (id) => {
    const del = await PatternServices.deletePattern({ id: id });
    if (del?.isSuccess) {
      toast.success(del?.messages);
      getAllPattern(pageNoSize?.no, pageNoSize?.size);
    } else {
      toast.error(del?.messages);
    }
  };
  return (
    <div>
      <div>
        <HeadTitle
          text="Pattern"
          component1={
            <Button
              title="Add Pattern"
              icon={<PlusIcon />}
              width="154px"
              height="48px"
              func={() => {
                navigate(ClientRoutesConstants.addPattern);
              }}
            />
          }
        />
      </div>
      <div>
        <Table
          tableData={allPattern}
          tableHead={tHead}
          SerialNumbers={true}
          navigateTo="pattern-details"
          deleteData={deleteFunc}
          toggleEditModal={editFunct}
        />
        {patternLength >0 && 
        
        (
          <Pagination
            getFunction={getAllPattern}
            totalLength={patternLength}
            setPageNoSize={setPageNoSize}
            pageNoSize={pageNoSize}
            length={allPattern?.length}
          />
        )
        }
      </div>
    </div>
  );
}
const tHead = ["S. Number", "Exam Pattern Name"];
