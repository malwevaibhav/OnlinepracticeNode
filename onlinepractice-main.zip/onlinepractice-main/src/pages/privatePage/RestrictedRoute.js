import { toJS } from "mobx";
import React from "react";
import { Navigate } from "react-router-dom";
import AuthStore from "../../MobX/Auth";
import { ClientRoutesConstants } from "../../shared/constant";
const auth = toJS(AuthStore?.user?.user);
const RestrictedRoute = ({
  component: Component,
  checkedroles,
  userrole,
  ...props
}) => {
  // console.log(
  //   auth
  //     ? checkedroles?.includes(auth?.role)
  //       ? "roles"
  //       : "no-roles"
  //     : "no-auth",
  //   auth
  // );

  return (
    <>
      {checkedroles?.includes(userrole) ? (
        <Component {...props} />
      ) : (
        <Navigate to={ClientRoutesConstants?.mocktest} />
      )}
    </>
  );
};

export default RestrictedRoute;
