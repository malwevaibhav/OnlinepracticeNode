import React from "react";
export default function SubjectCard() {
  return (
    <>
      <div className="mt-4">
        <HeadTitle text="Select Subjects" />
      </div>
      <div className="card p-4 ps-2 border-0 rounded-1 mt-3">
        <div className="d-flex m-0 flex-wrap">
          {subjectList?.map(
            (sub, key) =>
              sub?.title && (
                <div className="checkbox mb-4" key={key}>
                  <label className="d-flex pe-2">
                    <input
                      type="checkbox"
                      className="checkbox-input"
                      onChange={(e) => selectSubject(e.target.checked, sub)}
                      checked={sub?.isSelected}
                    />
                    <span className="checkbox-tile">
                      <i className="bx bxl-twitter"></i>
                      <span>{sub.title}</span>
                    </span>
                  </label>
                </div>
              )
          )}
          <div className="ps-3">
            <Button
              title="Add New Subject"
              icon={<PlusIcon />}
              height="50px"
              func={(e) => {
                checkDefault(e);
                setAddSubject(!addSubject);
              }}
            />
          </div>

          {addSubject && (
            <div className="card p-4 mt-4 border-0 rounded-1">

              <CreateEntity
                lable="Add New Subject"
                placeholder="Ex. Physics"
                onChange={(e) => setNewSub(e.target.value)}
                func={(e) => {
                  checkDefault(e);
                  setSubject((subject) => [
                    ...subject,
                    { id: subjectList.length + 1, title: newSub },
                  ]);
                  createSubject(newSub);
                }}
              />
            </div>
          )}
        </div>
      </div>
    </>
  );
}
