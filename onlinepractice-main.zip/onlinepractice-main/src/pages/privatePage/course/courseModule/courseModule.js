import { Formik } from "formik";
import { toJS } from "mobx";
import { observer } from "mobx-react";
import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { createCourseSchema } from "../../../../assets/regex/schema";
import { DataNotFound2, PlusIcon } from "../../../../assets/svgs/svg";
import Button from "../../../../customcomponents/button/Button";
import { HeadTitle } from "../../../../customcomponents/headtitle/headTitle";
import CourseStore from "../../../../MobX/Courses";
import CourseServices from "../../../../Services/CourseService";
import SubjectServices from "../../../../Services/SubjectService";
import { ThemeColors } from "../../../../theme/theme";
import { removeExtraSpace } from "../../../../utils/helper";
import CreateEntity from "../courseComp/createEntity";
import ExistingCourseCard from "../courseComp/existingCourseCard";
import NewCourseCard from "../courseComp/newCourseCard";
import "./courseModule.css";


const CourseModule = () => {
  const [isEdit, setIsEdit] = useState(false);
  const [toggle, setToggle] = useState(false);
  const [addSubject, setAddSubject] = useState(false);
  const [isSubCourseSelected, setIsSubCourseSelected] = useState(false);
  const [newSub, setNewSub] = useState({ value: '', error: '' });
  const [subCourseId, setsubCourseId] = useState([]);
  // const [toggle,setToggle]= useState(false)
  const location = useLocation();
  const navigate = useNavigate();

  /* eslint-disable */
  useEffect(() => {
    if (location?.state?.isExisting) {
      setIsEdit(true);
    } else {
      getAllSubject();
      setIsSubCourseSelected(true);
    }
  }, []);

  const getInitialValues = () => {
    let editInitialValues = {
      subCourseId: "",
      subjectIds: [],
    }
    let addInitialValues = {
      examTypeName: "",
      courseName: "",
      subCourseName: "",
      subjectName: [],
    }
    if (isEdit) {
      return editInitialValues
    }
    else {
      return addInitialValues
    }
  }


  const getAllSubject = async () => {
    setIsSubCourseSelected(true);
    const res = await SubjectServices.getAllSubject();
    let sujectList = res?.subjects?.map((elm) => {
      return {
        id: elm?.id,
        title: elm?.subjectName,
        isSelected: false,
      };
    });
    CourseStore?.setAllSubject([...sujectList]);
    return true;
  };

  const createCourseModule = async (values) => {
    let subId = CourseStore.selectedSubjectList.map((elm) => {
      return {
        subjectId: elm?.id,
      };
    });
    let addCourse = {
      examTypeName: removeExtraSpace(values?.examTypeName),
      courseName: removeExtraSpace(values?.courseName),
      subCourseName: removeExtraSpace(values?.subCourseName),
      subjectIds: subId,
    };
    const res = await CourseServices.createCourseModule(addCourse);
    if (res) {
      navigate("/courses");
    }
  };

  const updateCourseModule = async () => {
    let subId = CourseStore.selectedSubjectList.map((elm) => {
      return {
        id: elm?.id,
        value: true
      };
    });

    let updateCourse = {
      subCourseId,
      subjectIds: subId,
    };
    const res = await CourseServices.updateCourseModule(updateCourse);

    if (res) {
      navigate("/courses");
    }
  };

  const checkDefault = async (e) => {
    e.preventDefault();
  };

  const getSubjectById = async (data) => {
    // setIsSubCourseSelected()
    const selectedSubjectList = await CourseServices?.getSubjectById(data);
    let updatedsubjectlist = selectedSubjectList?.subjects?.map((elm) => {
      return {
        id: elm?.id,
        title: elm?.subjectName,
        isSelected: true,
      };
    });
    CourseStore.setSubjectSelected([...updatedsubjectlist]);
    compareArr(updatedsubjectlist);
  };

  const compareArr = (updatedsubjectlist) => {
    let CopyArr = [...CourseStore?.allSubjectList];
    CopyArr = CopyArr?.map((mainitem) => {
      let resp = updatedsubjectlist.find((item) => item?.id === mainitem?.id);
      if (resp) {
        mainitem.isSelected = true;
        return toJS(mainitem);
      } else {
        return toJS(mainitem);
      }
    });

    CourseStore?.setAllSubject(CopyArr);
    setToggle(!toggle)
  };

  const createSubject = async (value) => {

    if (!value.value) {
      setNewSub({ ...newSub, error: 'Subject name is required' })
    } else {
      setNewSub({ ...newSub, error: '' })
      let createSubject = { subjectName: removeExtraSpace(value.value) };
      const res = await SubjectServices.createSubject(createSubject);
      if (res?.isSuccess) {
        toast.success(res?.messages);
        subCourseId ? handleSubjects(subCourseId) : getAllSubject();
        setAddSubject(false)
      } else {
        toast.error(res?.messages);
      }
    }
  };

  const handleSubjects = async (subCourseId) => {
    setsubCourseId(subCourseId)
    const resp = await getAllSubject();
    if (resp) {
      getSubjectById(subCourseId);
    }
  };

  const handleAddSubj = (ind) => {
    let CourseCopy = [...CourseStore?.allSubjectList];
    if (CourseCopy[ind].isSelected) {
      CourseCopy[ind].isSelected = false;
    } else {
      CourseCopy[ind].isSelected = true;
    }
    let selectedSubject = CourseCopy.filter((subj) => toJS(subj?.isSelected))

    CourseStore.setSubjectSelected([...selectedSubject])
    CourseStore.setAllSubject([...CourseCopy]);
    setToggle(!toggle)
  };
  return (
    <div className="mt-3">
      <>
        <HeadTitle text={isEdit ? "Edit Course" : "Create New Course"} width="181px" />
        <Formik
          initialValues={getInitialValues()}
          onSubmit={(values) => {
            isEdit ? updateCourseModule() : createCourseModule(values);;
          }}
          validationSchema={!isEdit && createCourseSchema()}
        >
          {(props) => {
            const { handleSubmit, resetForm } = props;
            return (
              <form onSubmit={handleSubmit} onReset={resetForm}>
                {isEdit ? (<div className="card p-3  border-0 rounded-1 mt-3">
                  <ExistingCourseCard handleSubjects={handleSubjects} setIsSubCourseSelected={setIsSubCourseSelected} />
                </div>) :
                  (<div className="card p-3  border-0 rounded-1 mt-3">
                    <NewCourseCard props={props} />
                  </div>)
                }
                <div className="my-2">
                  <HeadTitle text="Select Subjects" />
                </div>

                <div className="card border-0 rounded-1 mt-3" style={{ padding: "34px", paddingInline: "" }} >
                  {isSubCourseSelected ? (
                    <div style={{ rowGap: "20px", columnGap: "36px" }} className="d-flex m-0  flex-wrap">
                      {CourseStore?.allSubjectList?.map((sub, key) => (
                        <div
                          onClick={() => handleAddSubj(key)}
                          className={`${sub?.isSelected && "selectedbg"}`}
                        >
                          <span className="checkbox-tile pe-2">
                            <i className="bx bxl-twitter"></i>
                            <span>{sub.title}</span>
                          </span>
                        </div>
                      ))}
                      <div >

                        <Button
                          title="Add New Subject"
                          icon={<PlusIcon />}
                          height="50px"
                          func={(e) => {
                            checkDefault(e);
                            setAddSubject(!addSubject);
                          }}
                        />
                      </div>
                    </div>
                  )
                    :
                    <div className="text-center p-5">
                      <DataNotFound2 />
                    </div>
                  }
                </div>
                {addSubject && (
                  <div className="card p-4 mt-4 border-0 rounded-1">
                    <CreateEntity
                      lable="Add New Subject"
                      placeholder="Ex. Physics"
                      onChange={(e) => setNewSub({ ...newSub, value: e.target.value, error: '' })}
                      func={(e) => {
                        checkDefault(e);
                        createSubject(newSub);
                      }}
                    />
                    {newSub?.error && (
                      <div className="input-feedback">{newSub?.error}</div>
                    )}
                  </div>
                )}

                <div className="modal-footer mt-4 gap-3">
                  <Button title={isEdit ? "Update" : "Create"} width="120px" />
                  <Button
                    title="Cancel"
                    width="122px"
                    type="reset"
                    background={ThemeColors.secondary}
                  />
                </div>
              </form>
            );
          }}
        </Formik>
      </>
    </div>
  );
};
export default observer(CourseModule);
