import React from 'react'
import Button from '../../../../customcomponents/button/Button';
import CustomInput from '../../../../customcomponents/customTextInput';

export default function CreateEntity({ lable, placeholder, value, onChange, func}) {
    return (

        <div >
            <div className="d-flex">
                <label htmlFor="" className='p-0' style={{ fontSize: "14px", fontFamily: 'Medium' }}>{lable}</label>
            </div>
            <div className="d-flex flex-sm-wrap flex-wrap  align-items-center gap-3">
                <div style={{ minWidth: ' 9rem', maxWidth: '20rem', width: '20rem' }}>
                    <CustomInput
                        name="subject"
                        id="subject"
                        placeholder={placeholder}
                        type="text"
                        height="48px"
                        value={value}
                        onChange={onChange}
                    />
                </div>
                <div className='pt-2' >
                    <Button
                        title="Save"
                        height="48px"
                        width="108px"
                        func={func}
                    />
                </div>
            </div>
        </div >
    )
}

