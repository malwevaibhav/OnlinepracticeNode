import React from 'react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

import Cardbg from "../../../../assets/Images/Cardbg.png";
import ActionButton from '../../../../customcomponents/actionbutton/ActionButton';
import Button from '../../../../customcomponents/button/Button';
import { NormalHeading } from '../../../../customcomponents/DynamicText/Heading';
import DeleteModal from '../../../../customcomponents/modalPopup/deleteModal/DeleteModal';
import '../course.css';


export default function SubCard({ text, data, setcourseId, setDelete, isAction = true, navigateTo }) {
    const navigate = useNavigate()
    const [modal, setModal] = useState("")
    const setdata = (data) => {
        setcourseId(data)
    }

    return (
        <><div className='subCard p-4 pt-2 py-5 mb-1 position-relative' style={{ backgroundImage: `url(${Cardbg})` }}>
            <span className='position-absolute' style={{ marginLeft: '8rem',top:"10px",zIndex:"1" }}>{isAction && <ActionButton eye={false} editfunction={() => setdata(data?.obj?.id)} deletefunction={() => setModal('delete')} />}</span>
            <div className="ps-0 mt-2 pt-2 mb-0 text-center position-absolute ">  <NormalHeading text={text} /> </div>
            <div className='mt-2 position-absolute' style={{bottom:"15px"}}> <Button title="Choose" width="103px" fontSize="15px" height="38px" func={() => navigate(navigateTo, { state: { title: data?.title, examId: data?.examId, obj: data?.obj } })} /> </div>
        </div>
            {
                modal === "delete" && <DeleteModal
                    onRequestClose={() => {
                        setModal('');
                    }}
                    onPress={() => {
                        setModal(''); setDelete(data?.obj?.id);
                    }}
                    name={text}
                />
            }
        </>
    )
}
