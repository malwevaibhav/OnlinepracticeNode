import React from 'react'
import CustomInput from '../../../../customcomponents/customTextInput'

export default function NewCourseCard(props) {
    const { handleChange, errors, touched } = props?.props;
    return (
        <div className="row m-0 p-0 d-flex align-items-baseline">
            <div className="col-xl-2 col-lg-3 col-md-4 col-sm-4 ps-4 pe-0 d-flex justify-content-start align-items-start mb-0"
                style={{ marginTop: "30px" }} >
                <label>Exam Type</label>
            </div>
            <div className="col-xl-10 col-lg-9 col-md-8 col-sm-8 ms-0 " style={{ paddingLeft: "25px" }}>
                <CustomInput placeholder="Enter exam type" type="text" height="40px" name="examTypeName" id="examTypeName" onChange={handleChange} />
                {errors.examTypeName && touched.examTypeName && (
                    <div className="input-feedback position-absolute">{errors.examTypeName}</div>
                )}
            </div>
            <div className="col-xl-2 col-lg-3 col-md-4 col-sm-4  ps-4 pe-0 d-flex justify-content-start align-items-start mb-0"
                style={{ marginTop: "30px" }} >
                <label>Course Name</label>
            </div>
            <div className="col-xl-10 col-lg-9 col-md-8 col-sm-8 ps-4 ps-2 ms-0 ">
                <CustomInput placeholder="Enter course name" type="text" height="40px" id="courseName" name="courseName" onChange={handleChange} />
                {errors.courseName && touched.courseName && (
                    <div className="input-feedback position-absolute">{errors.courseName}</div>
                )}
            </div>
            <div className="col-xl-2 col-lg-3 col-md-4 col-sm-4  ps-4 pe-0 d-flex justify-content-start align-items-start mb-0"
                style={{ marginTop: "30px" }}
            >
                <label>Sub-course Name</label>
            </div>
            <div className="col-xl-10 col-lg-9 col-md-8 col-sm-8 ps-4 ps-2 ms-0 ">
                <CustomInput placeholder="Enter sub course name" type="text" height="40px" id="subCourseName" name="subCourseName" onChange={handleChange} />

                {errors.subCourseName && touched.subCourseName && (
                    <div className="input-feedback position-absolute">{errors.subCourseName}</div>
                )}</div>
        </div>
    )
}
