import React, { useState } from 'react'
import { toast } from 'react-toastify'

import { DeleteRedIcon } from '../../../../assets/svgs/svg'
import ActionButton from '../../../../customcomponents/actionbutton/ActionButton'
import Button from '../../../../customcomponents/button/Button'
import { SubHeading } from '../../../../customcomponents/DynamicText/Heading'
import ExamDeleteModal from '../../../../customcomponents/modalPopup/ExamDeleteModal/ExamDeleteModal'
import CourseServices from '../../../../Services/CourseService'
import { ClientRoutesConstants } from '../../../../shared/constant'
import { ThemeColors } from '../../../../theme/theme'
import SubCard from './subCard'

export default function CourseCard({ cardHeading = "", cardArray = [], examId, setcourseId, setDelete, setExamModal, exammodal, getAllCourses }) {
    const [deleteToggle, setDeleteToggle] = useState(false)
    const deletefunction = async () => {
        const res = await CourseServices.deleteExam(examId)
        if (res?.isSuccess) {
            toast.success(res?.messages)
            getAllCourses()
            setDeleteToggle(false)
        } else {
            toast.error(res?.messages)
        }
    }
    return (
        <div className="card border-0 p-3" >
            <div className='d-flex align-items-center justify-content-between gap-3 flex-wrap'>
                <div className='d-flex align-items-center gap-3' >
                    <SubHeading text={cardHeading} />
                    <ActionButton eye={false} del={false} editfunction={() => { setExamModal({ ...exammodal, popup: true, modalTitle: "Exam Type", examId, examName: cardHeading }) }} />
                </div>
                <div>
                    <Button title="Delete Category" fontSize="15px" textColor={ThemeColors.danger} width="161px" height="38px" background="white" icon={<DeleteRedIcon />} func={() => setDeleteToggle(true)} />
                </div>
            </div>
            <div className='mt-3 d-flex flex-direction-row gap-3 flex-wrap'>
                {cardArray.map((obj, i) => (
                    <div key={i}>
                        <SubCard icon={obj?.icon} navigateTo={ClientRoutesConstants.courseTopic} text={obj?.courseName} data={{ title: cardHeading, examId: examId, obj: obj }} setcourseId={setcourseId} setDelete={setDelete} />
                    </div>
                ))}
            </div>
            {deleteToggle && (
                <ExamDeleteModal
                    onRequestClose={() => setDeleteToggle(false)}
                    name={cardHeading}
                    onPress={deletefunction}
                    dynBtnSize="119px"
                />
            )}
        </div>
    )
}
