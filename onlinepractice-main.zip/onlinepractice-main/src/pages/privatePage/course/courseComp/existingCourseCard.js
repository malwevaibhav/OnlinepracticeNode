import { observer } from "mobx-react-lite";
import React, { useEffect, useState } from "react";
import { toast } from "react-toastify";
import { PlusIcon } from "../../../../assets/svgs/svg";
import Button from "../../../../customcomponents/button/Button";
import CustomDropdown from "../../../../customcomponents/custom_Dropdown/CustomDropdown";
import CourseStore from "../../../../MobX/Courses";
import CourseServices from "../../../../Services/CourseService";
import { removeExtraSpace } from "../../../../utils/helper";
import CreateEntity from "./createEntity";

const ExistingCourseCard = ({ handleSubjects, setIsSubCourseSelected }) => {
  const [course, setCourse] = useState(false);
  const [subCourse, setSubCourse] = useState(false);
  const [courseValue, setCourseValue] = useState({});
  const [selectedItems, setSelectedItems] = useState({
    Examtype: { selectedName: "", id: "" },
    Coursetype: { selectedName: "", id: "" },
    SubCoursetype: { selectedName: "", id: "" }
  })
  useEffect(() => {
    CourseStore.setexamList([])
    CourseStore.setCourse([])
    CourseStore.setSubCourse([])
    CourseServices?.getCourseFilterData({ label: "Exam" });
  }, []);
  const handleCourse = async (newCourseData) => {
    createCourse(newCourseData)
    setCourse(false)
  }
  const handleSubCourse = async (newSubCourseData) => {
    await createSubCourse(newSubCourseData)
    setSubCourse(false)
  }
 
  const setSelectCourse = async (props, entityName) => {
    if (props?.label === 'Course') {
      CourseStore.setCourse([])
      CourseStore.setSubCourse([])
      setSelectedItems({ ...selectedItems, Examtype: { selectedName: entityName, id: props?.id }, Coursetype: { selectedName: "", id: "" }, SubCoursetype: { selectedName: "", id: "" } })
      setIsSubCourseSelected(false)
    }
    if (props?.label === 'SubCourse') {
      CourseStore.setSubCourse([])
      setSelectedItems({ ...selectedItems, Coursetype: { selectedName: entityName, id: props?.id }, SubCoursetype: { selectedName: "", id: "" } })
      setIsSubCourseSelected(false)
    }
    if (props?.label === 'Subject') {
      setSelectedItems({ ...selectedItems, SubCoursetype: { selectedName: entityName, id: props?.id } })
      return handleSubjects(props?.id);
    }
    CourseServices?.getCourseFilterData(props);
  };

  const SubCourseClick = (e) => {
    checkDefault(e);
    if (course) return toast.error("Please Add Course First")
    else setSubCourse(!subCourse)
  }

  const createCourse = async (courseName) => {
    let coursedata = {
      courseName: removeExtraSpace(courseName),
      examTypeId: selectedItems?.Examtype?.id,
    }
    const res = await CourseServices.courseCreate(coursedata)
    if (res?.isSuccess) {
      toast.success(res?.messages)

      await CourseServices?.getCourseFilterData({ id: selectedItems?.Examtype?.id, label: "Course" })
      // await CourseServices?.getCourseFilterData({id:selectedItems?.Coursetype?.id,label:"Course"})
      setCourseValue("")
    } else {
      toast.error(res?.messages)
    }
  };

  const createSubCourse = async (subcourseName) => {
    let subCourseData = {
      subCourseName: removeExtraSpace(subcourseName),
      courseId: selectedItems?.Coursetype?.id
    }
    //call api for create  new  sub course
    const res = await CourseServices.subcourseCreate(subCourseData)
    if (res?.isSuccess) {
      toast.success(res?.messages)
      await CourseServices?.getCourseFilterData({ id: selectedItems?.Coursetype?.id, label: "SubCourse" })
      // await getSubCourseById(selectedItems?.Coursetype?.id)
      setCourseValue("")
    } else {
      toast.error(res?.messages)
    }
  };

  const checkDefault = async (e) => {
    e.preventDefault();
  }

  return (
    <div className="row m-0 mb-3 mt-3">
      <div className="row m-0 p-0">
        <div
          className="col-xl-2 col-lg-3 col-md-4 col-sm-4 ps-4 pe-0 d-flex justify-content-start align-items-center mb-0"

        >
          <label>Exam Type</label>
        </div>
        <div
          className="col-xl-4 col-lg-6 col-md-6 col-sm-6  ms-0 "
          style={{ paddingLeft: "25px" }}
        >
          <CustomDropdown
            menu={CourseStore?.examList}
            isSelect={true}
            customClass="form-dropdown"
            handlefunc={setSelectCourse}
            selectedEntity={selectedItems?.Examtype?.selectedName}
            placeholder="Select Exam"
            disable={!CourseStore?.examList?.length ? true : false}
            menuStyle={{border:'1px solid #E3E9EE'}}
          />
        </div>
      </div>
      <div
        className="col-xl-2 col-lg-3 col-md-4 col-sm-4  ps-4 pe-0 d-flex justify-content-start align-items-center mb-0"
      >
        <label>Course Name</label>
      </div>
      <div className="col-xl-10 col-lg-9 col-md-8 col-sm-8 ps-4 ps-2 ms-0 mb-1">
        <div className="row m-0 align-items-end">
          <div className="col-xl-10 col-lg-8 col-md-12 col-sm-12 ps-0">
            
            <CustomDropdown
              menu={CourseStore.course}
              isSelect={true}
              customClass="form-dropdown"
              handlefunc={setSelectCourse}
              selectedEntity={selectedItems?.Coursetype?.selectedName}
              placeholder="Select Course"
              disable={!CourseStore?.course?.length ? true : false}
              menuStyle={{border:'1px solid #E3E9EE'}}
            />
          </div>
          <div className="col-xl-2 col-lg-4 col-md-4 col-sm-6 mt-2 ps-0">
            <Button
              title="Add New"
              icon={<PlusIcon />}
              width="130px"
              func={(e) => { checkDefault(e); setCourse(!course) }}
              disable={!selectedItems?.Examtype?.id}

            />
          </div>
          <div className="col-xl-10 col-lg-11 col-md-12 col-sm-12 ps-0">
            {course && (
              <div className="card p-2 mt-4 rounded-1">
                <CreateEntity
                  lable="Add New Course"
                  placeholder="Ex. Medical"
                  value={courseValue?.newCourse}
                  onChange={(e) =>
                    setCourseValue({
                      ...courseValue,
                      newCourse: e.target.value,
                    })
                  }
                  func={(e) => { checkDefault(e); handleCourse(courseValue?.newCourse) }}
                />
              </div>
            )}
          </div>
        </div>
      </div>
      <div
        className="col-xl-2 col-lg-3 col-md-4 col-sm-4  ps-4 pe-0 d-flex justify-content-start align-items-center mb-0"
      >
        <label>Sub-course Name</label>
      </div>
      <div className="col-xl-10 col-lg-9 col-md-8 col-sm-8 ps-4 ps-2 ms-0">
        <div className="row m-0 align-items-end">
          <div className="col-xl-10 col-lg-8 col-md-12 col-sm-12 ps-0">
            
            <CustomDropdown
              menu={CourseStore?.subcourse}
              isSelect={true}
              customClass="form-dropdown"
              handlefunc={setSelectCourse}
              selectedEntity={selectedItems?.SubCoursetype?.selectedName}
              placeholder="Select Sub course"
              disable={!CourseStore?.subcourse?.length ? true : false}
              menuStyle={{border:'1px solid #E3E9EE'}}
            />
          </div>
          <div className="col-xl-2 col-lg-4 col-md-4 col-sm-6 mt-2 ps-0">
            <Button
              title="Add New"
              width="130px"
              icon={<PlusIcon />}
              func={(e) => SubCourseClick(e)}

              disable={!selectedItems?.Coursetype?.id }
            />
          </div>
          <div className="col-xl-10 col-lg-11 col-md-12 col-sm-12 ps-0">
            {subCourse && (
              <div className="card p-2 mt-4 rounded-1">
                <CreateEntity
                  lable="Add New Sub course"
                  placeholder="Ex. Physics"
                  value={courseValue?.newSubCourse}
                  onChange={(e) =>
                    setCourseValue({
                      ...courseValue,
                      newSubCourse: e.target.value,
                    })
                  }
                  func={(e) => { checkDefault(e); handleSubCourse( courseValue?.newSubCourse) }}
                />
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
export default observer(ExistingCourseCard)