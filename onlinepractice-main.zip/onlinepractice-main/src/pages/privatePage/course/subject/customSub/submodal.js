import React from "react";
import CustomInput from "../../../../../customcomponents/customTextInput";
import { InputLabel } from "../../../../../customcomponents/customTextInput/indexCss";
import Modal from "../../../../../customcomponents/modalPopup/CustomModal";
import { ThemeColors } from "../../../../../theme/theme";

const Subjectmodal = () => {
  return (
    <div>
      <Modal
        width="605px"
        closeBtn={false}
        noFooter={false}
        dynBtnSize="120px"
        dynButton="Update"
        maxModalWidth="null"
        backgroundColor={ThemeColors.primary}
        me=""
      >
        <div className="p-4">
          {/* <HeadTitle text="Edit New Subject" /> */}
          <InputLabel style={{ fontSize: "24px", fontWeight: "500" }}>
            Edit New Subject
          </InputLabel>
          {/* <InputLabel style={{ fontSize: "24px", fontWeight: "500" }}>Edit New Subject</InputLabel> */}
          <CustomInput />
          <div className="modal-footer mt-4">
            <button
              type="submit"
              className="btn btn-primary rounded-1 me-3 ps-4 pe-4"
              style={{ width: "122px", height: "48px" }}
            >
              Add
            </button>
            <button
              type="button"
              className="btn btn-secondary rounded-1 border-0 ps-4 pe-4"
              style={{
                background: ThemeColors.secondary,
                width: "122px",
                height: "48px",
              }}
            >
              Cancel
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default Subjectmodal;
// onClick={() => {
//     getPermissionModule(staffDetail);
//     setPermissionError(false);
//     setShowmodal('');
//   }}
