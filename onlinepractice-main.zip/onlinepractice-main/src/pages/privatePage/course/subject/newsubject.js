import React, { useEffect, useState } from "react";
import { toast } from "react-toastify";
import { DataNotFound2, PlusIcon } from "../../../../assets/svgs/svg";

import Button from "../../../../customcomponents/button/Button";
import CustomInput from "../../../../customcomponents/customTextInput";
import { CardData } from "../../../../customcomponents/DynamicText/Heading";
import { HeadTitle } from "../../../../customcomponents/headtitle/headTitle";
import Modal from "../../../../customcomponents/modalPopup/CustomModal";
import Pagination from "../../../../customcomponents/pagination/Pagination";

import Table from "../../../../customcomponents/table/Table";
import CourseStore from "../../../../MobX/Courses";
import CourseServices from "../../../../Services/CourseService";
import { ThemeColors } from "../../../../theme/theme";

const AddNewSubject = () => {
  const [subjectLength, setSubjectLength] = useState();
  const [popUp, setPopUp] = useState(false);

  const [subjectId, setSubjectId] = useState();

  const [addNewSubjects, setAddNewSubjects] = useState([]);
  const [editSubjects, seteditSubjects] = useState([]);

  const [selectsubject, setSelectsubject] = useState({});
  const tableHead = ["S. Number", "Subject Name"];
  const [pageNoSize, setPageNoSize] = useState({ no: 1, size: 10 });

  /* eslint-disable */
  useEffect(() => {
    getNewAllSubject();
  }, []);
  
  const getNewAllSubject = async (no = 1, size = 10) => {
    const resData = await CourseServices?.getNewAllSubject({
      pageNumber: no,
      pageSize: size,
    });
    if (!resData?.subjects) {
      setPageNoSize({ ...pageNoSize, no: pageNoSize.no - 1 });
      if (pageNoSize.no - 1 <= 0) {
        return false;
      } else {
        return getNewAllSubject(pageNoSize?.no, pageNoSize?.size);
      }
    }
    setSubjectLength(resData?.totalRecords);
  };
  const onSubmitSubject = async () => {
    let body = {
      subjectName: addNewSubjects,
    };
    const resp = await CourseServices.createNewsubject(body);

    if (resp?.isSuccess) {
      toast.success(resp?.messages);
      setPopUp("");
    } else {
      toast.error(resp?.messages);
    }
  };

  const onEditSubject = async () => {
    let editbody = {
      subjectName: editSubjects,
      id: subjectId,
    };
    const res = await CourseServices.editNewSubjects(editbody);
    if (res?.isSuccess) {
      toast.success(res?.messages);
      setPopUp("");
    } else {
      toast.error(res?.messages);
    }
  };

  const OnChangesubject = (e) => {
    setAddNewSubjects(e.target.value);
  };
  const Oneditsubject = (e) => {
    seteditSubjects(e.target.value);
    setSelectsubject({ ...selectsubject, Title: e.target.value });
  };

  return (
    <div>
      <HeadTitle
        text="Subjects"
        component2={
          <Button
            title="Add Subject"
            width="162px"
            height="48px"
            icon={<PlusIcon />}
            func={() => {
              setPopUp("add");
            }}
          />
        }
      />

      {!addNewSubjects === "" && (
        <div>
          <div className=" card border-0 ">
            <div className="SettingPreviewContainer">
              <DataNotFound2 />
            </div>
          </div>
        </div>
      )}
      <div>
        <div className="row mt-3 ">
          <div className="d-grid">
            <Table
              tableData={CourseStore?.allSubjectList}
              tableHead={tableHead}
              bgColorDelButton="#D03D3D"
              toggleEditModal={(e) => {
                setPopUp("edit");
                setSelectsubject(e);
              }}
              eye={false}
              del={false}
              setId={setSubjectId}
              SerialNumbers={true}
              action={true}
            />
          </div>
        </div>
      </div>

      {popUp === "add" && (
        <Modal
          onRequestClose={setPopUp}
          dynButton="Add"
          dynBtnSize="100px"
          wrap="nowrap"
          onPress={() => onSubmitSubject()}
          width="30vw"
          backgroundColor={ThemeColors.primary}
        >
          <CardData text={`Add New Subject`} />
          <CustomInput
            placeholder={`Please enter Subject name`}
            type="text"
            id="addSubject"
            onChange={OnChangesubject}
          />
        </Modal>
      )}
      {popUp === "edit" && (
        <Modal
          onRequestClose={setPopUp}
          dynButton="Update"
          dynBtnSize="100px"
          wrap="nowrap"
          onPress={() => onEditSubject()}
          width="30vw"
          backgroundColor={ThemeColors.primary}
        >
          <CardData text={`Edit Subject`} />
          <CustomInput
            placeholder={`Please enter Subject name`}
            type="text"
            id="editSubject"
            value={selectsubject?.Title}
            onChange={Oneditsubject}
          />
        </Modal>
      )}
      {subjectLength > 5 && (
        <Pagination
          getFunction={getNewAllSubject}
          totalLength={subjectLength}
          setPageNoSize={setPageNoSize}
          pageNoSize={pageNoSize}
          length={CourseStore?.allSubjectList.length}
        />
      )}
    </div>
  );
};

export default AddNewSubject;
