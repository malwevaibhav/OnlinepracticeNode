import { toJS } from 'mobx'
import React, { useState } from 'react'
import CourseAction from '../../../../../customcomponents/courseAction/courseAction'
import CourseStore from '../../../../../MobX/Courses'
import "../createCourse.css"

const SubCourseRow = ({ item, ind, setEditCategory }) => {
  let org_course = toJS(CourseStore?.orgCourse)
  const [subCourse, setSubCourse] = useState({ index: "", value: item?.subCourseName })
  return (
    <div className="subCategory d-grid p-3 position-relative">
      <span className="courseAction pe-3">
        <CourseAction rightFunction={() => { setEditCategory(''); CourseStore.setOrgCourse(ind, subCourse?.value) }}
          crossFunction={() => { setEditCategory(''); CourseStore.setDupCourse(ind); setSubCourse({ ...subCourse, value: org_course.subCourses[ind]?.subCourseName }) }} /></span>
      <input placeholder="Enter sub-course name " value={subCourse.value} className="form-control" onChange={(e) => { setSubCourse({ ...subCourse, index: ind, value: e?.target?.value }) }} />
    </div>
  )
}

export default SubCourseRow