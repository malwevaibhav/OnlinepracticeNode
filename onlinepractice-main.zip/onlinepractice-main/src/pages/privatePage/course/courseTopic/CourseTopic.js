import { toJS } from "mobx";
import { observer } from "mobx-react-lite";
import React, { useLayoutEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import { toast } from "react-toastify";
import {
  AddIcon,
  DataNotFound2,
  SearchIcon,
  VerticalDots
} from "../../../../assets/svgs/svg";
import ActionButton from "../../../../customcomponents/actionbutton/ActionButton";
import Button from "../../../../customcomponents/button/Button";
import CustomInput from "../../../../customcomponents/customTextInput";
import { InputLabel } from "../../../../customcomponents/customTextInput/indexCss";
import CustomDropdown from "../../../../customcomponents/custom_Dropdown/CustomDropdown";
import { CardData, TitleHeading } from "../../../../customcomponents/DynamicText/Heading";
import { HeadTitle } from "../../../../customcomponents/headtitle/headTitle";
import Modal from "../../../../customcomponents/modalPopup/CustomModal";
import DeleteModal from "../../../../customcomponents/modalPopup/deleteModal/DeleteModal";
import CourseStore from "../../../../MobX/Courses";
import CourseServices from "../../../../Services/CourseService";
import TopicServices from "../../../../Services/TopicService";
import { ThemeColors } from "../../../../theme/theme";
import { removeExtraSpace } from "../../../../utils/helper";
import "./courseTopic.css";

const CourseTopic = observer(() => {
  const location = useLocation();
  const [popUp, setPopUp] = useState();
  const [deleteModal, setDeleteModal] = useState(false);
  const [showIcon, setShowIcon] = useState();
  const [modalTitle, setModalTitle] = useState("");
  const [inputValue, setInputValue] = useState("");
  const [toggle, setToggle] = useState(false);
  const [topicId, setTopicId] = useState("");
  const [topicName, setTopicName] = useState({ error: "Enter Valid Name" });
  const [subtopicId, setSubTopicId] = useState("");
  const [isShow, setIsShow] = useState(false);

  const [selectedItems, setSelectedItems] = useState({
    Coursetype: { selectedName: "", id: "" },
    SubCoursetype: { selectedName: "", id: "" },
    Subjecttype: { selectedName: "", id: "" },
  })
  const { title, examId, obj } = location?.state;

  /* eslint-disable */
  useLayoutEffect(() => {
    setSelectedItems({ ...selectedItems, Coursetype: { selectedName: obj?.courseName, id: obj?.id }, SubCoursetype: { selectedName: "", id: "" }, Subjecttype: { selectedName: "", id: "" } })
    CourseStore.setSubCourse([])
    CourseStore.setSubjectSelected([])
    CourseStore.setTopicList([])
    CourseStore.setSubTopicList([])
    setIsShow(false)
    CourseServices?.getCourseFilterData({ id: obj?.id, label: "SubCourse" })
    setToggle(true);
  }, [examId, obj, title]);

  const course = toJS(CourseStore?.course);
  const topic = toJS(CourseStore?.topicList);
  const subtopic = toJS(CourseStore?.subTopicList);
  /// get data from menu
  const setSelectCourse = async (props, entityName) => {
    if (props?.label === "Subject") {
      setSelectedItems({ ...selectedItems, SubCoursetype: { selectedName: entityName, id: props?.id }, Subjecttype: { selectedName: "", id: "" } })
      setIsShow(false)
      CourseStore.setSubjectSelected([])
      CourseStore.setTopicList([])
      CourseStore.setSubTopicList([])
    }
    if (props?.label === 'Topic') {
      setIsShow(false)
      CourseStore.setTopicList([])
      CourseStore.setSubTopicList([])
      return setSelectedItems({ ...selectedItems, Subjecttype: { selectedName: entityName, id: props?.id } })
    }

    CourseServices?.getCourseFilterData(props);


  };

  const getTopic = async () => {
    const data = await CourseServices.getCourseFilterData({ id: selectedItems?.Subjecttype?.id, label: "Topic" });
    setIsShow(true)
    if (data) {
      setTopicId(data[0]?.id);
      getSubTopic(data[0]?.id)
    }
    else {
      CourseStore.setTopicList([]);
      CourseStore.setSubTopicList([]);

    }
    setToggle(true)
  };

  const getSubTopic = async (Id) => {
    // may be remove or change//
    const data = await CourseServices.getCourseFilterData({ id: Id, label: "SubTopic" });
    if (data) {
      // setTopicId(Id);
    } else {
      CourseStore.setSubTopicList([])
    }
  };

  const handleTopicName = (value) => {
    // setTopicName({ ...topicName, newTopicName: removeExtraSpace(value), error: "" })
    if (removeExtraSpace(value) === "") {
      setTopicName({ ...topicName, error: "Enter Valid Name" })
    }
    else {
      setTopicName({ ...topicName, newTopicName: removeExtraSpace(value), error: "" })
    }
  }

  const addTopicModule = async (values, title) => {
    if (values?.error) return toast.error(values?.error)
    let addTopicMoule;
    if (title === "Topic") {
      addTopicMoule = {
        topicName: removeExtraSpace(values?.newTopicName),
        subjectCategoryId: selectedItems?.Subjecttype?.id,
      };

      const res = await CourseServices.addTopicModule(addTopicMoule, title);
      if (res) {
        setPopUp("");
        getTopic()
        handleActiveTopic(topicId)
        setTopicName({ error: "Enter Valid Name" })
      }
    } else if (title === "Sub Topic") {
      addTopicMoule = {
        subTopicName: values?.newTopicName,
        subTopicDescription: values?.newTopicName,
        topicId,
      };
      const res = await CourseServices.addTopicModule(addTopicMoule, title);
      if (res) {
        setPopUp("");
        getSubTopic(topicId);
      }
    }
  };

  const editTopicModule = async (values, title) => {
    if (values?.error) return toast.error(values?.error)
    if (title === "Topic") {
      let editTopicData = {
        topicName: removeExtraSpace(values?.newTopicName),
        SubjectCategoryId: selectedItems?.Subjecttype?.id,
        id: topicId,
      };
      const res = await CourseServices.updateTopicModule(editTopicData, title);
      if (res) {
        setPopUp("");
        getTopic()
        handleActiveTopic(topicId)
        setTopicName({ error: "Enter Valid Name" })
      }
    } else if (title === "Sub Topic") {
      let editSubTopicData = {
        subTopicName: removeExtraSpace(values?.newTopicName),
        subTopicDescription: removeExtraSpace(values?.newTopicName),
        topicId: topicId,
        id: subtopicId,
      };
      const res = await CourseServices.updateTopicModule(
        editSubTopicData,
        title
      );
      if (res) {
        setPopUp("");
        getSubTopic(topicId);
      }
    }
  };

  const deleteTopic = async (data) => {
    const res = await TopicServices.deleteTopic(data);
    if (res?.isSuccess) {
      toast.success(res?.messages);
      getTopic()
    } else {
      toast.error(res?.messages);
    }

    setDeleteModal(false);
  };

  const deleteSubTopic = async (data) => {
    const res = await TopicServices.deleteSubTopic(data);
    if (res?.isSuccess) {
      toast.success(res?.messages);
      getSubTopic(topicId);
    } else {
      toast.error(res?.messages);
    }
    setDeleteModal(false);
  };

  const deleteTopicModule = async () => {
    if (modalTitle === "Topic") {
      deleteTopic(topicId);
    } else if (modalTitle === "Sub Topic") {
      deleteSubTopic(subtopicId);
    }
  };

  const handleActiveTopic = (id, ind) => {
    const TopicsCopy = [...CourseStore?.topicList];
    let index = TopicsCopy?.findIndex((item) => item?.id === id)
    TopicsCopy[index].active = true;
    TopicsCopy.forEach((item, ind) => {
      if (ind !== index) {
        item.active = false;
      }
    });
    CourseStore.setTopicList([...TopicsCopy]);
    setTopicId(id)
    getSubTopic(id);
  };

  if (!toggle) return <></>;
  return (
    <div>
      <div className="d-grid  my-2 pe-2">
        <HeadTitle text={title} />
      </div>
      <div className="pe-2 ">
        <div className="card p-4 border-0 rounded-1 ps-2 pe-2">
          <div className="row m-0 mb-4">
            <div className="col-lg-3 mt-1">
              <span className="mb-2">
                <InputLabel> Course</InputLabel>
              </span>
              <CustomDropdown
                menu={course}
                isSelect={true}
                customClass="form-dropdown"
                handlefunc={setSelectCourse}
                selectedEntity={selectedItems?.Coursetype?.selectedName}
                placeholder="select Course"
                disable={true}
                menuStyle={{ border: '1px solid #E3E9EE' }}
              />
            </div>
            <div className="col-lg-3 mt-1">
              <span className="mb-2">
                <InputLabel>SubCourse</InputLabel>
              </span>
              <CustomDropdown
                menu={CourseStore?.subcourse}
                isSelect={true}
                customClass="form-dropdown"
                handlefunc={setSelectCourse}
                selectedEntity={selectedItems?.SubCoursetype?.selectedName}
                placeholder="Select Sub course"
                disable={!CourseStore?.subcourse?.length ? true : false}
                menuStyle={{ border: '1px solid #E3E9EE' }}
              />
            </div>
            <div className="col-lg-3 mt-1">
              <span className="mb-2">
                <InputLabel>Subject</InputLabel>
              </span>
              <CustomDropdown
                menu={CourseStore?.selectedSubjectList}
                isSelect={true}
                customClass="form-dropdown"
                handlefunc={setSelectCourse}
                selectedEntity={selectedItems?.Subjecttype?.selectedName}
                placeholder="Select Subject"
                disable={!CourseStore?.selectedSubjectList?.length > 0 ? true : false}
                menuStyle={{ border: '1px solid #E3E9EE' }}
              />
            </div>

            <div className="col-lg-3 d-flex align-items-end mt-1">
              {" "}
              <Button
                title="Apply"
                width="114px"
                height="50px"
                disable={!selectedItems?.Subjecttype?.id ? true : false}
                func={() => getTopic()}
              />{" "}
            </div>
          </div>
        </div>
      </div>
      {/* topic subtopic show after search */}
      {isShow && (
        <div className="row m-0 mt-4 ">
          <div className="col-xl-3 col-lg-3 col-md-4 col-sm-4 mb-3 ps-0 pe-2">
            <div className="d-flex justify-content-between align-items-center ">
              <strong>Topics</strong>
              <Button
                func={() => {
                  setTopicName({ newTopicName: "", error: "Enter Valid Name" })
                  setPopUp("add");
                  setModalTitle("Topic");
                }}
                title="Add Topic"
                icon={<AddIcon />}
                width="115px"
                height="35px"
                fontSize="13px"
                background={ThemeColors.selectButton}
                textColor={ThemeColors.primary}
              />
            </div>
            <div className="row m-0 ">
              <div className="card border-0 rounded-1 mt-3 p-0">
                <div className="card-header border-0 p-2 m-3">
                  <div className="search-bar">
                    <input
                      style={{
                        border: "none",
                        backgroundColor: "#f6f6f6",
                        fontSize: "13px",
                        paddingBlock: "5px",
                        width: "90%",
                      }}
                      className="search ms-2"
                      placeholder="Search topic"
                    />
                    <SearchIcon />
                  </div>
                </div>
                <hr className="text-muted mt-0" />
                <div >
                  {topic?.length > 0 ? (
                    topic?.map((elm, i) => (
                      <tr
                        onClick={() => {
                          handleActiveTopic(elm?.id, i);

                        }}
                        className={`topicRow d-flex justify-content-between align-items-center p-2 flex-wrap ${elm?.active && "topicRow-active"
                          }`}
                      >
                        <div className={`p-2 fs-6`}>{elm?.Title} </div>
                        <div className="topicIcon">
                          <div
                            onClick={() => {
                              setShowIcon(i + "topic");
                            }}
                            onMouseOver={() => setShowIcon(i + "topic")}
                          >
                            {!(showIcon === i + "topic") && <VerticalDots />}
                          </div>
                          <div>
                            {showIcon === i + "topic" && (
                              <ActionButton
                                eye={false}
                                editfunction={() => {
                                  setPopUp("edit");
                                  setModalTitle("Topic");
                                  setInputValue(elm?.Title);
                                  setTopicId(elm?.id);
                                  setTopicName({ ...topicName, error: "" })
                                }}
                                deletefunction={() => {
                                  setModalTitle("Topic");
                                  setDeleteModal(!deleteModal);
                                  setInputValue(elm?.Title);
                                  setTopicId(elm?.id);
                                }}
                              />
                            )}
                          </div>
                        </div>
                      </tr>
                    ))
                  ) : (
                    <div className="p-4 ">
                      <div
                        className="card d-flex align-items-center p-3  spCard2 pointer"
                        onClick={() => {
                          setPopUp("add");
                          setModalTitle("Topic");
                          setTopicName({ newTopicName: "", error: "Enter Valid Name" })
                        }}
                      >
                        {/* <h5> Create your first topic</h5> */}
                        <TitleHeading text="Create your first topic" />
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
          <div className="col-xl-9 col-lg-9 col-md-8 col-sm-8 p-0 ps-2 pe-2">
            <div className="d-flex justify-content-between align-items-center ">
              <strong>Sub topics</strong>
              {topic?.length > 0 &&
                <Button
                  func={() => {
                    setPopUp("add");
                    setModalTitle("Sub Topic");
                    setTopicName({ newTopicName: "", error: "Enter Valid Name" })
                  }}
                  title="Add Sub topic"
                  icon={<AddIcon />}
                  width="135px"
                  height="35px"
                  fontSize="13px"
                  background={ThemeColors.selectButton}
                  textColor={ThemeColors.primary}
                />}
            </div>
            <div className="row m-0 ">
              <div className="card border-0 rounded-1 mt-3 p-0">
                <div className="card-header col-xl-3 col-lg-4 col-md-5 col-sm-6 border-0 p-2 m-3">
                  <div className="search-bar">
                    <input
                      style={{
                        border: "none",
                        backgroundColor: "#f6f6f6",
                        fontSize: "13px",
                        paddingBlock: "5px",
                        width: "90%",
                      }}
                      className="search ms-2"
                      placeholder="Search sub topic"
                    />
                    <SearchIcon />
                  </div>
                </div>
                <div >
                  <div className="row m-0 p-2 ">
                    {subtopic?.length > 0 ? (
                      subtopic?.map((obj, i) => (
                        <div className="trow col-xl-4 col-lg-2 col-md-6 col-sm-6 d-flex justify-content-between align-items-center flex-wrap p-2" key={i}>
                          <div className="p-2 fs-6">{obj?.Title} </div>
                          <div className="topicIcon">
                            <div
                              onClick={() => {
                                setShowIcon(i + "sub");
                              }}
                              onMouseOver={() => { setShowIcon(i + "sub"); }}
                            >
                              {!(showIcon === i + "sub") && <VerticalDots />}
                            </div>
                            <div>
                              {showIcon === i + "sub" && (
                                <ActionButton
                                  eye={false}
                                  editfunction={() => {
                                    setPopUp("edit");
                                    setModalTitle("Sub Topic");
                                    setInputValue(obj?.Title);
                                    setSubTopicId(obj?.id);
                                    setTopicName({ ...topicName, error: "" })
                                  }}
                                  deletefunction={() => {
                                    setDeleteModal(!deleteModal);
                                    setModalTitle("Sub Topic");
                                    setSubTopicId(obj?.id);
                                    setInputValue(obj?.Title);
                                  }}
                                />
                              )}
                            </div>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="p-5  d-flex justify-content-center">
                        <DataNotFound2 />
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {popUp === "add" && (
        <Modal
          onRequestClose={() => setPopUp("")}
          dynButton="Add"
          dynBtnSize="100px"
          wrap="nowrap"
          onPress={() => addTopicModule(topicName, modalTitle)}
          width="30vw"
          backgroundColor={ThemeColors.primary}
        >
          <CardData text={`Add New ${modalTitle}`} />
          <CustomInput
            placeholder={`please enter ${modalTitle} name`}
            type="text"
            id="name"
            onChange={(e) => handleTopicName(e.target.value)}
          />

          {/* {topicName?.error &&
            <div className="input-feedback postion-absolute">
              {topicName?.error}
            </div>
          } */}
        </Modal>
      )}

      {popUp === "edit" && (
        <Modal
          onRequestClose={() => setPopUp("")}
          dynButton="Save"
          dynBtnSize="100px"
          wrap="nowrap"
          onPress={() => editTopicModule(topicName, modalTitle)}
          width="30vw"
          backgroundColor={ThemeColors.primary}
        >

          <CardData text={`Edit ${modalTitle}`} />
          <CustomInput
            placeholder={`please enter ${modalTitle} name`}
            type="text"
            id="name"
            value={inputValue}
            onChange={(e) => { setInputValue(e.target.value); handleTopicName(e.target.value) }}
          />
          {/* {topicName?.error &&
            <div className="input-feedback postion-absolute">
              {topicName?.error}
            </div>
          } */}
        </Modal>
      )}
      {deleteModal && (
        <DeleteModal
          onRequestClose={() => setDeleteModal(!deleteModal)}
          name={inputValue}
          onPress={deleteTopicModule}
        />
      )}
    </div>
  );
});
export default CourseTopic;
