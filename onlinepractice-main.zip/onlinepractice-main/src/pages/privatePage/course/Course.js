import { toJS } from "mobx";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import {
  BlankAreaIcon,
  ExistingIcon,
  NewCourseIcon
} from "../../../assets/svgs/svg";
import ActionButton from "../../../customcomponents/actionbutton/ActionButton";
import Button from "../../../customcomponents/button/Button";
import CourseAction from "../../../customcomponents/courseAction/courseAction";
import CustomInput from "../../../customcomponents/customTextInput";
import {
  CardData, NormalHeading, SubHeading
} from "../../../customcomponents/DynamicText/Heading";
import { HeadTitle } from "../../../customcomponents/headtitle/headTitle";
import Modal from "../../../customcomponents/modalPopup/CustomModal";
import CourseStore from "../../../MobX/Courses";
import CourseServices from "../../../Services/CourseService";
import ExamTypeService from "../../../Services/ExamTypeService";
import { ClientRoutesConstants } from "../../../shared/constant";
import { ThemeColors } from "../../../theme/theme";
import { removeExtraSpace } from "../../../utils/helper";
import "./course.css";
import CourseCard from "./courseComp/courseCard";
import SubCourseRow from "./createCourse/component/SubCourseRow";

export default function Course() {
  const navigate = useNavigate();
  const [addCourse, setAddCourse] = useState(false);
  const [examType, setExamType] = useState([]);
  const [popup, setPopup] = useState(false);
  const [value, setValue] = useState("");
  const [editCategory, setEditCategory] = useState("");
  const [courseData, setCourseData] = useState();
  const [exammodal, setExamModal] = useState({
    popup: false,
    modalTitle: "",
    examId: "",
    examName: "",
    error: false
  });

  const org_course = toJS(CourseStore?.orgCourse);

  useEffect(() => {
    getAllCourses();
  }, []);

  const getAllCourses = async () => {
    const resData = await ExamTypeService.getExamlistWithCourses();
    setExamType(resData);
  };

  const setcourseId = (props) => {
    if (props) {
      subCoursesbyCourseId(props);
    }
  };

  const subCoursesbyCourseId = async (id) => {
    const resData = await CourseServices.getCourseFilterData({
      id: id,
      label: "SubCourse",
    });
    CourseStore.setCompCourse(resData?.data);
    setValue(resData?.data?.courseName);
    setCourseData(resData?.data);
    setPopup(true);
  };

  const handleValue = (e) => {
    if (e.target.value) {
      setValue(e.target.value);
    }
  };

  const updateMultiple = async () => {
    let updateCourse = {
      courseID: courseData?.courseID,
      courseName: org_course?.courseName,
      subCourses: org_course.subCourses ? org_course?.subCourses : [],
    };
    const res = await CourseServices.updateCourse(updateCourse);
    if (res?.isSuccess) {
      toast.success(res?.messages);
      setPopup(false);
      getAllCourses();
    } else {
      toast.error(res?.messages);
      setPopup(false);
      getAllCourses();
    }
  };

  const AddNewSubbtn = () => {
    navigate("/new-subject")
  };

  const updateExam = async () => {
  
    if (removeExtraSpace(exammodal.examName) === "") {
       setExamModal({ ...exammodal, error: true })
      return false;
    }
    if (!exammodal.error) {
      let updateExamDetail = {
        examName: removeExtraSpace(exammodal?.examName),
        id: exammodal?.examId,
      };
      const res = await ExamTypeService.updateExam(updateExamDetail);
      if (res?.isSuccess) {
        toast.success(res?.messages);
        setExamModal({ ...exammodal, popup: false })
        getAllCourses();
      } else {
        toast.error(res?.messages);
      }
    }
  };

  const setExamData = (value) => {
      setExamModal({ ...exammodal, examName: value, error: false })
   
  }
  const setDelete = async (data) => {
    const res = await CourseServices.deleteCourse(data);
    if (res?.isSuccess) {
      toast.success(res?.messages);
      getAllCourses();
      setPopup("")
    } else {
      toast.error(res?.messages);
      getAllCourses();

    }
  };

  const SubCourseDelete = async (data, courseId) => {
    const res = await CourseServices.deleteSubCourse(data);
    if (res?.isSuccess) {
      toast.success(res?.messages);
      getAllCourses();
      setcourseId(courseId)
    } else {
      toast.error(res?.messages);
      getAllCourses();
    }
  };

  return (
    <div>
      <div >
        <HeadTitle text="Courses and Subjects" component2={
          <Button
            title="All Subjects"
            width="162px"
            height="48px"
            func={AddNewSubbtn}

          />
        } />
      </div>
      <div className="row m-0 gap-4">
        <div className="col-xl-3 col-lg-5 col-md-6 col-sm-12 p-0 ">
          <div
            className="card d-flex align-items-center p-4 spCard"
            onClick={() => setAddCourse(!addCourse)}
          >
            <NewCourseIcon />
            <NormalHeading text="Add New Course" />
          </div>
        </div>
        <hr  />
      </div>
      <div className="mb-3 mt-0">
        <HeadTitle text="Courses" />
      </div>
      <div className="row m-0 gap-3">

        {examType?.map((exam, key) => {
          return (
            <div className="col-12  p-0" key={key}>
              <CourseCard
                cardHeading={exam?.examName}
                examId={exam?.id}
                cardArray={exam?.coursesList}
                setcourseId={setcourseId}
                setDelete={setDelete}
                setExamModal={setExamModal}
                exammodal={exammodal}
                getAllCourses={getAllCourses}
              />
            </div>
          );
        })}
      </div>

      {
        addCourse && (
          <Modal onRequestClose={() => setAddCourse(!addCourse)} closeBtn={false} backgroundColor={ThemeColors.primary}>
            <div className="d-flex">
              <div className="row m-0 p-0 pe-4 py-5 gap-2 justify-content-center text-center align-items-center">
                <BlankAreaIcon />
                <SubHeading text="New Course" />
                <Button
                  title="Choose"
                  width="85px"
                  height="35px"
                  func={() => navigate(ClientRoutesConstants.courseModule)}
                />
              </div>
              <hr
                className="p-0"
                style={{
                  border: "1px solid rgb(177 180 183)",
                  margin: "10px 0 -10px 0",
                }}
              />
              <div className="row m-0 p-0 py-5 gap-2 justify-content-center text-center align-items-center">
                <ExistingIcon />
                <SubHeading text="Already Existing" />

                <Button
                  title="Choose"
                  width="85px"
                  height="35px"
                  func={() =>
                    navigate(ClientRoutesConstants.courseModule, {
                      state: { isExisting: true },
                    })
                  }
                />
              </div>
            </div>
          </Modal>
        )
      }

      {
        popup && (
          <Modal
            onRequestClose={() => setPopup("")}
            dynButton="Update"
            dynBtnSize="124px"
            width={"100%"}
            onPress={() => {
              updateMultiple();
            }}
            backgroundColor={ThemeColors.primary}
            me="me-3"
          >
            <div className="card border-0 rounded-0 p-3 pe-0">
              <div className="row m-0" style={{ minWidth: "500px" }}>
                {!(editCategory === courseData?.courseID) ? (
                  <div className="d-flex gap-3 mb-3">
                    <CardData text={value} />
                    <ActionButton
                      eye={false}
                      del={false}
                      editfunction={() => setEditCategory(courseData?.courseID)}
                      deletefunction={() => {
                        setDelete(courseData?.courseID);
                        // setPopup(false);
                      }}
                    />

                  </div>
                ) : (
                  <div className="category mb-3 pe-3">
                    <span className="courseAction me-3">
                      <CourseAction
                        rightFunction={() => {
                          CourseStore.setRightFunction(value);
                          setEditCategory("");
                        }}
                        crossFunction={() => {
                          CourseStore.setCrossFunction();
                          setValue(org_course?.courseName);
                          setEditCategory("");
                        }}
                      />
                    </span>
                    <input
                      placeholder="Ex. Engineering"
                      className="form-control"
                      value={value}
                      onChange={(e) => handleValue(e)}
                      required
                    />
                  </div>
                )}
                {org_course?.subCourses &&
                  org_course?.subCourses.map((cat, key) => {
                    return (
                      <>
                        {!(editCategory === cat.id) ? (
                          <tr key={key}
                            className="d-flex justify-content-between align-items-center p-2 ps-4 mt-2 categoryTr"
                            style={{ height: "45px" }}
                          >
                            <label>{cat.subCourseName}</label>
                            <div className="categoryActionBtn pe-3">
                              <ActionButton
                                eye={false}
                                editfunction={() => setEditCategory(cat.id)}
                                deletefunction={() => {
                                  SubCourseDelete(cat?.id, courseData?.courseID);
                                }}
                              />
                            </div>
                          </tr>
                        ) : (
                          <SubCourseRow
                            item={cat}
                            ind={key}
                            orgCourse={org_course?.subCourses}
                            setEditCategory={setEditCategory}
                          />
                        )}
                      </>
                    );
                  })}
              </div>
            </div>
          </Modal>
        )
      }

      {
        exammodal && exammodal?.popup && (
          <Modal
            onRequestClose={() => { setExamModal({ ...exammodal, popup: false }) }}
            dynButton="Update"
            dynBtnSize="100px"
            wrap="nowrap"
            onPress={() => updateExam()}
            width="30vw"
            backgroundColor={ThemeColors.primary}
          >
            <CardData text={`Update ${exammodal?.modalTitle}`} />
            <CustomInput
              placeholder={`please  update exam type name`}
              type="text"
              id="name"
              name="name"
              value={exammodal?.examName}
              onChange={(e) => setExamData(e.target.value)}
            />
            {exammodal.error && (
              <div className="input-feedback position-absolute">
                Enter valid exam type
              </div>
            )}
          </Modal>
        )
      }
    </div >
  );
}
