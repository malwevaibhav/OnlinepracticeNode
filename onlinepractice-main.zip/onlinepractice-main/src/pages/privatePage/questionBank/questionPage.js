import { MathJax } from "better-react-mathjax";
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import DataExtractor from "../../../component/hooks/dataExtractor";
import Button from "../../../customcomponents/button/Button";
import { HeadTitle } from "../../../customcomponents/headtitle/headTitle";
import Modal from "../../../customcomponents/modalPopup/CustomModal";
import Pagination from "../../../customcomponents/pagination/Pagination";
import Table from "../../../customcomponents/table/Table";
import AuthStore from "../../../MobX/Auth";
import QuestionStore from "../../../MobX/Question";
import QuestionBankServices from "../../../Services/QuestionbankService";
import { ClientRoutesConstants } from "../../../shared/constant";
import { ThemeColors } from "../../../theme/theme";
import QuestionBankCard from "./component/questionBankCard";
import "./questionbank.css";

const tableHead = [
  "Question ID",
  "Question Type",
  "Question Level",
  "Course",
  "Sub-course ",
  "Subject ",
  "Created By ",
];

const QuestionPage = () => {
  const Role = AuthStore?.user?.user;
  const navigate = useNavigate();
  const [isShow, setIsShow] = useState(false);
  const [pageNoSize, setPageNoSize] = useState({ no: 1, size: 10 });
  const [questionBankList, setQuestionBankList] = useState([]);
  const [questionDetail, setQuestionDetail] = useState({});
  const [qtypeID, setQTypeID] = useState("")
  const [totalRecords, setTotalRecords] = useState("")

  const uploadButton = () => {
    navigate("/question-upload", {
      state: { toggle: true },
    });
    localStorage.removeItem("SelectedFilters");
    QuestionStore.setSelectedItemsNw({ selectedName: "Exam", props: {}, entityName: "" })
  };

  const quickView = (data) => {
    // scriptFunc()
    getQuestionByID(data.id)
  };

  const getQuestionByID = async (id) => {
    const res = await QuestionBankServices.getQuestionByID(id)
    setQTypeID(res?.data?.questionType)
    let detail = res?.data?.questionTableData['english'];
    setQuestionDetail(detail)
    if (detail) {
      setIsShow(true)
    }

  };

  const getAllquestionBank = async (no = 1, size = 10) => {
    setPageNoSize({ no: 1, size: 10 })
    let post = {
      subjectCategoryId: QuestionStore.selectedItemsNw.SubjectList.id,
      topicId: QuestionStore.selectedItemsNw.TopicList.id,
      subTopicId: QuestionStore.selectedItemsNw.SubTopicList.id,
      questionType: QuestionStore.selectedItemsNw.questionType.id,
      creatorUserId: QuestionStore.selectedItemsNw.addedBY?.id,
      questionLevel: QuestionStore.selectedItemsNw.level.id,
      pageNumber: no,
      pageSize: size,
    }
    if (Role?.role === "Staff") {
      post.creatorUserId = Role?.userId
    }
    localStorage.setItem("SelectedFilters", JSON.stringify(QuestionStore.selectedItemsNw))
    const res = await QuestionBankServices.getQuestionBankList(post);
    if (!res) {
      setQuestionBankList([])
      if ((pageNoSize.no - 1) <= 1) {
        return false
      }
      else {
        setPageNoSize({ ...pageNoSize, no: pageNoSize.no - 1 })
        return getAllquestionBank(pageNoSize?.no - 1, pageNoSize?.size)
      }
    }
    setTotalRecords(res?.data?.totalRecords)
    const data=res?.data?.questionBanks.map((emp)=>
    {return {...emp, action:true}}
  )
    let extracted = DataExtractor(data, [
      "creationDate",
    ]);
    let list = extracted?.map((elm) => {
      return {
        ...elm,
      };
    });
    setQuestionBankList(list);
    return extracted.length;
  };

  const deleteQuestion = async (id) => {
    const deleteData = await QuestionBankServices.deleteQuestion({ questionRefId: id });
    if (deleteData?.isSuccess) {
      toast.success(deleteData?.messages);
      getAllquestionBank(pageNoSize?.no, pageNoSize?.size);
    } else {
      toast.error(deleteData?.messages);
    }

  };

  return (
    <div>
      <HeadTitle
        text="Question Bank"
        component2={
          <Button
            title="+ Add Question"
            width="162px"
            height="48px"
            func={uploadButton}
          />
        }
      />
      <QuestionBankCard toggle={false} questionTable={true} filterdData={true} applyFunc={() => getAllquestionBank(pageNoSize.no, pageNoSize.size)} setQuestionBankList={setQuestionBankList} />
      <div className="row mt-3 ">
        <div className="d-grid">
          <Table
            tableData={questionBankList}
            tableHead={tableHead}
            isQuickView={true}
            showId={true}
            QuickViewClick={quickView}
            navigateTo={"question-detail"}
            deleteData={deleteQuestion}
            toggleEditModal={(data) => {
              navigate(ClientRoutesConstants?.questionUpload, {
                state: { isEdit: true, toggle: true, Id: data?.id },
              });
            }}
          />
          {totalRecords &&
            <Pagination
              getFunction={getAllquestionBank}
              totalLength={totalRecords}
              setPageNoSize={setPageNoSize}
              pageNoSize={pageNoSize}
              length={questionBankList?.length}
            />}
        </div>
      </div>

      {isShow && (
        <Modal
          closeBtn={true}
          onRequestClose={() => setIsShow(false)}
          backgroundColor={ThemeColors.primary}
          width="30vw"
          maxModalWidth="null"
        >
          <div style={{ height: "600px", overflowY: 'auto' }}>
            <div className="col-md-3 d-flex align-items-center">
              <b>Question Detail -</b>
            </div>
            <hr />
            {!AuthStore.isLoading &&
              (qtypeID !== 3) ?
              <div>
                <div >
                  <b style={{ fontSize: "15px" }}> Question :</b> {questionDetail.questionText && <MathJax> <p className="ms-3" dangerouslySetInnerHTML={{ __html: questionDetail?.questionText }} /></MathJax>}
                </div>
                <div >
                  <b style={{ fontSize: "15px" }}>Option A:</b> {questionDetail.optionA && <MathJax><p className="ms-3" dangerouslySetInnerHTML={{ __html: questionDetail?.optionA }} /></MathJax>}
                </div>
                <div >
                  <b style={{ fontSize: "15px" }}>Option B:</b> {questionDetail.optionB && <MathJax><p className="ms-3" dangerouslySetInnerHTML={{ __html: questionDetail?.optionB }} /></MathJax>}
                </div>
                <div >
                  <b style={{ fontSize: "15px" }}>Option C:</b> {questionDetail.optionC && <MathJax><p className="ms-3" dangerouslySetInnerHTML={{ __html: questionDetail?.optionC }} /></MathJax>}
                </div>
                <div >
                  <b style={{ fontSize: "15px" }}>Option D:</b> {questionDetail.optionD && <MathJax><p className="ms-3" dangerouslySetInnerHTML={{ __html: questionDetail?.optionD }} /></MathJax>}
                </div>
              </div>
              :
              <div>
                <div >
                  <b style={{ fontSize: "15px" }}> Question :</b> {questionDetail.questionText && <MathJax> <p className="ms-3" dangerouslySetInnerHTML={{ __html: questionDetail?.questionText }} /></MathJax>}
                </div>
                <div >
                  <b style={{ fontSize: "15px" }}>Answer:</b> {questionDetail.optionA && <MathJax><p className="ms-3" dangerouslySetInnerHTML={{ __html: questionDetail?.optionA }} /></MathJax>}
                </div>

              </div>

            }

          </div>
        </Modal>
      )}
    </div>
  );
};

export default QuestionPage;










































