import { MathJax, MathJaxContext } from "better-react-mathjax";
import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { DeleteIcon, EditIcon } from "../../../../../assets/svgs/svg";
import Button from "../../../../../customcomponents/button/Button";
import CustomDropdown from "../../../../../customcomponents/custom_Dropdown/CustomDropdown";
import { HeadTitle } from "../../../../../customcomponents/headtitle/headTitle";
import DeleteModal from "../../../../../customcomponents/modalPopup/deleteModal/DeleteModal";
import AuthStore from "../../../../../MobX/Auth";
import QuestionBankServices from "../../../../../Services/QuestionbankService";
import QuestionTypeServices from "../../../../../Services/QuestionTypeService";
import { ClientRoutesConstants } from "../../../../../shared/constant";
import { ThemeColors } from "../../../../../theme/theme";
import "./questionDetail.css";
/* eslint-disable */
const QuestionDetails = () => {
  const [showModal, setShowmodal] = useState("");
  const [questionBankDetail, setQuestionBankDetail] = useState([]);
  const [optionDetail, setOptionDetail] = useState([]);
  const [language, setLanguage] = useState([]);
  const [toggle, setToggle] = useState(false);
  const { state } = useLocation();
  const navigate = useNavigate();
  const [selectedItems, setSelectedItems] = useState({
    language: { selectedName: "", id: "" },
  });
  const [qtypeID, setQTypeID] = useState("")

 // console.log("use state?.id Effect call");
  useEffect(() => {
   // console.log("use Effect call");
    if (state?.id) {
      getQuestionByID(state?.id);
    }
    setToggle(true);
  }, [state?.id]);
  
  const getQuestionByID = async (id) => {
    const res = await QuestionBankServices.getQuestionByID(id);
    setQuestionBankDetail(res?.data);
    setQTypeID(res?.data?.questionType)
    let viewDetails = res?.data?.questionTableData["english"];
    setOptionDetail(viewDetails);
    getAllLanguage();
  };

  const getAllLanguage = async () => {
    const res = await QuestionTypeServices.getAllLanguage();
    if (res?.isSuccess) {
      if (res?.data) {
        let language = res?.data.map((item) => {
          return {
            id: item?.value,
            Title: item?.name,
          };
        });
        setLanguage(language);
      }
    }
  };

  const getLanguageID = async (props) => {
    setSelectedItems({
      ...selectedItems,
      language: { selectedName: props?.Title, id: props?.id },
    });
    if (props?.Title) {
      if (questionBankDetail?.questionTableData) {
        let viewDetails =
          questionBankDetail?.questionTableData[props?.Title.toLowerCase()];
        setOptionDetail({});
        AuthStore.setLoading(true)
        setTimeout(() => { setOptionDetail(viewDetails); AuthStore.setLoading(false) }, 100)
      }
    }


  };

  const deleteQuestion = async () => {
    const deleteData = await QuestionBankServices.deleteQuestion({
      questionRefId: state?.id,
    });
    if (deleteData?.isSuccess) {
      toast.success(deleteData?.messages);
      navigate(ClientRoutesConstants?.questionBank);
    } else {
      toast.error(deleteData?.messages);
    }
  };
  if (!toggle) return AuthStore?.setLoading(true);
  return (
    <MathJaxContext>
      <div className="ps-1">
        <div >
          <HeadTitle
            text="Question Details"
            component1={
              <Button
                icon={<EditIcon />}
                background={ThemeColors?.link}
                title="Edit"
                height="42px"
                width="104px"
                func={() => {
                  navigate(ClientRoutesConstants?.questionUpload, {
                    state: { isEdit: true, toggle: true, Id: state?.id },
                  });
                }}
              />
            }
            component2={
              <Button
                icon={<DeleteIcon />}
                background={ThemeColors.danger}
                title="Delete"
                height="42px"
                width="121px"
                func={() => setShowmodal("delete")}
              />
            }
          />
        </div>
        {questionBankDetail && (
          <>
            <div
              className="d-flex justify-content-between flex-wrap p-2  "
              style={{ background: "#E3E9EE" }}
            >
              <div className="col-lg-6 col-md-6  col-sm-6  col-xs-6 mt-1 d-flex  align-items-center">
                <div className="questionIdText">Question ID : {state?.id}</div>
              </div>
              <div className="col-lg-6 col-md-6  col-xs-6  cm-justify-content d-flex  gap-3 d-flex  align-items-center">
                <div className="questionIdText">Language</div>
                <div>
                  <CustomDropdown
                    customClass="QuestionIdDropDown"
                    placeholder="English"
                    isSelect={true}
                    menu={language}
                    handlefunc={getLanguageID}
                    selectedEntity={selectedItems?.language?.selectedName}
                  />
                </div>
              </div>
            </div>
            <div className="card rounded-0 border-0 pt-3">
              {!AuthStore.isLoading && (
                <div className="CardLabel ps-3 d-flex">
                  <div className="rounded-1 me-4 Optiondiv">Question</div>
                  {!AuthStore.isLoading && (
                    <MathJax>
                      <p
                        className="ms-3 mt-1"
                        dangerouslySetInnerHTML={{
                          __html: optionDetail.questionText,
                        }}
                      />
                    </MathJax>
                  )}
                </div>
              )}
              <div className="Card-UpperLine"></div>

              {
                (qtypeID !== 3) ?
                  <div className="p-3 mt-3">
                    <div className="CardLabel d-flex mb-3 ">
                      <div className="rounded-0  Optiondiv">
                        <span>
                          <input
                            type="checkbox"
                            name="option1"
                            className="optionn"
                            checked={optionDetail.isCorrectA}
                          />
                        </span>
                        <div>
                          <div className="ms-2">Option 1</div>
                        </div>
                      </div>
                      {optionDetail.optionA && (
                        <MathJax>
                          <p
                            className="ms-3 mt-1"
                            dangerouslySetInnerHTML={{
                              __html: optionDetail.optionA,
                            }}
                          />
                        </MathJax>
                      )}
                    </div>
                    <div className="CardLabel d-flex mb-3">
                      <div className="rounded-1  Optiondiv">
                        <span>
                          <input
                            type="checkbox"
                            name="option1"
                            className="optionn"
                            checked={optionDetail.isCorrectB}
                          />
                        </span>
                        <div className="ms-2">Option 2</div>
                      </div>
                      {optionDetail.optionB && (
                        <MathJax>
                          <p
                            className="ms-3 mt-1"
                            dangerouslySetInnerHTML={{
                              __html: optionDetail.optionB,
                            }}
                          />
                        </MathJax>
                      )}
                    </div>
                    <div className="CardLabel d-flex mb-3 ">
                      <div className="rounded-1  Optiondiv">
                        <span>
                          <input
                            type="checkbox"
                            name="option1"
                            className="optionn"
                            checked={optionDetail.isCorrectC}
                          />
                        </span>
                        <div className="ms-2">Option 3</div>
                      </div>
                      {optionDetail.optionC && (
                        <MathJax>
                          <p
                            className="ms-3 mt-1"
                            dangerouslySetInnerHTML={{
                              __html: optionDetail.optionC,
                            }}
                          />
                        </MathJax>
                      )}
                    </div>
                    <div className="CardLabel d-flex  ">
                      <div className="rounded-1  Optiondiv">
                        <span>
                          <input
                            type="checkbox"
                            name="option1"
                            className="optionn"
                            checked={optionDetail.isCorrectD}
                          />
                        </span>
                        <div className="ms-2">Option 4</div>
                      </div>
                      {!AuthStore.isLoading && (
                        <MathJax>
                          <p
                            className="ms-3 mt-1"
                            dangerouslySetInnerHTML={{
                              __html: optionDetail.optionD,
                            }}
                          />
                        </MathJax>
                      )}
                    </div>
                  </div>
                  :
                  <div className="CardLabel ps-3 d-flex pt-4">
                    <div className="me-3" style={{ fontSize: "15px" }}>Answer:</div>
                    {/* <div className="rounded-1 d-flex Optiondiv">
                  <span>
                    <input
                      type="checkbox"
                      name="option1"
                      className="optionn"
                      checked={optionDetail.isCorrectA}
                    />
                  </span>
                  Option 1
                </div> */}
                    {optionDetail.optionA && (
                      <MathJax>
                        <p
                          className="ms-3"
                          dangerouslySetInnerHTML={{
                            __html: optionDetail.optionA,
                          }}
                        />
                      </MathJax>
                    )}
                  </div>
              }
            </div>
            {
              (optionDetail.explanation) &&
              <>
                <div className="col-lg-6 col-md-6  col-sm-6  col-xs-6 mt-1 d-flex  align-items-center">
                  <div className="questionIdText pt-3 pb-3">Explanation</div>
                </div>
                <div>
                  <div className="card border-0 rounded-0 p-2 pb-0">
                      {!AuthStore.isLoading && (
                        <MathJax>
                          <p
                            
                            dangerouslySetInnerHTML={{
                              __html: optionDetail.explanation,
                            }}
                          />
                        </MathJax>
                      )}
                  </div>
                </div>
              </>
            }

            <div className="d-flex mt-3 gap-2">
              <div className="card rounded-0 border-0 px-3 py-2">
                  <div className="marksfield">
                    Marks : {questionBankDetail?.mark}
                  </div>
              </div>
              <div className="card rounded-0 border-0 px-3 py-2">
                  <div className="marksfield">
                    Negative Marks : {questionBankDetail?.negativeMark}
                  </div>
              </div>
              <div className="card rounded-0 border-0 px-3 py-2">
                  <div className="marksfield">
                    Difficulty Level : {questionBankDetail?.questionLevel}
                  </div>
              </div>
            </div>
          </>
        )}
        {showModal === "delete" && (
          <DeleteModal
            onRequestClose={() => {
              setShowmodal("");
            }}
            onPress={() => {
              setShowmodal("");
              deleteQuestion();
            }}
            name={"Question"}
          />
        )}
      </div>
    </MathJaxContext>
  );
};
export default QuestionDetails;
