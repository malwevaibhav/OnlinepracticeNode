import React from 'react';
import EditorCK from '../../../../../component/CKEditor/EditorCK';
import CustomInput from '../../../../../customcomponents/customTextInput';
import QuestionStore from '../../../../../MobX/Question';
import { ThemeColors } from '../../../../../theme/theme';
import "./questionUpload.css";
import ToggleComp from './toggleComp';
export function Integeroption({ switchToggle, value, qtype }) {
    const setOptionsA = async (optionData) => {
        let questionCopy = { ...QuestionStore?.questionData };
        questionCopy = {
            ...questionCopy,
            [QuestionStore?.languageSelected]: {
                ...questionCopy[QuestionStore?.languageSelected],
                questionText: QuestionStore?.questionData[`${QuestionStore?.languageSelected}`].questionText,
                optionA: optionData,
                isCorrectA: true
            },
        };
        QuestionStore.setQuestionData(questionCopy);
    };
    return (
        <div className='mt-3'>
            {/* <EditorCK value={value} setOptionsA={setOptionsA} />        */}
            <CustomInput background={ThemeColors.white} placeholder={"Type Answer"} value={value} onChange={(e)=>setOptionsA(e.target.value)} />
            
        </div>
    )
}
export function OptioncontainerA({ switchToggle, value, qtype }) {
    function handleKeyPress(e) {
        if (qtype === 'MCQ') {
            switchToggle({ isCorrectA: e?.target?.checked, value: 'optionA' });
        } else {
            switchToggle({ isCorrectA: e?.target?.checked, value: 'optionA' });
            switchToggle({ isCorrectB: false, value: 'optionB' });
            switchToggle({ isCorrectC: false, value: 'optionC' });
            switchToggle({ isCorrectD: false, value: 'optionD' });
        }

    }
    const setOptionsA = async (optionData) => {
        let questionCopy = { ...QuestionStore?.questionData };
        questionCopy = {
            ...questionCopy,
            [QuestionStore?.languageSelected]: {
                ...questionCopy[QuestionStore?.languageSelected],
                questionText: QuestionStore?.questionData[`${QuestionStore?.languageSelected}`].questionText,
                optionA: optionData,
            },
        };
        QuestionStore.setQuestionData(questionCopy);

    };

    return (
        <div className='mt-3'>
            <EditorCK value={value} setOptionsA={setOptionsA} />
            <div className="py-3 mb-3 d-flex gap-3" style={{ backgroundColor: ThemeColors.white }}>
                <ToggleComp handleKeyPress={handleKeyPress} label="optionA" checked={QuestionStore?.questionData[`${QuestionStore?.languageSelected}`]?.isCorrectA} />
            </div>
        </div>
    )
}
export function OptioncontainerB({ switchToggle, value, qtype }) {
    function handleKeyPress(e) {
        if (qtype === 'MCQ') {
            switchToggle({ isCorrectB: e?.target?.checked, value: 'optionB' });
        } else {
            switchToggle({ isCorrectB: e?.target?.checked, value: 'optionB' });
            switchToggle({ isCorrectA: false, value: 'optionA' });
            switchToggle({ isCorrectC: false, value: 'optionC' });
            switchToggle({ isCorrectD: false, value: 'optionD' });
        }
    }
    const setOptionsB = async (optionData) => {

        let questionCopy = { ...QuestionStore?.questionData };
        questionCopy = {
            ...questionCopy,
            [QuestionStore?.languageSelected]: {
                ...questionCopy[QuestionStore?.languageSelected],
                questionText: QuestionStore?.questionData[`${QuestionStore?.languageSelected}`].questionText,
                optionB: optionData,
            },
        };
        QuestionStore.setQuestionData(questionCopy);

    };
    return (
        <div className='mt-3'>
            <EditorCK value={value} setOptionsB={setOptionsB} />
            <div className="py-3 mb-3 d-flex gap-3" style={{ backgroundColor: ThemeColors.white }}>
                <ToggleComp handleKeyPress={handleKeyPress} label="optionB" checked={QuestionStore?.questionData[`${QuestionStore?.languageSelected}`]?.isCorrectB} />
            </div>
        </div>
    )
}
export function OptioncontainerC({ switchToggle, value, qtype }) {

    function handleKeyPress(e) {
        if (qtype === 'MCQ') {
            switchToggle({ isCorrectC: e?.target?.checked, value: 'optionC' });
        } else {
            switchToggle({ isCorrectC: e?.target?.checked, value: 'optionC' });
            switchToggle({ isCorrectB: false, value: 'optionB' });
            switchToggle({ isCorrectA: false, value: 'optionA' });
            switchToggle({ isCorrectD: false, value: 'optionD' });
        }
    }
    const setOptionsC = async (optionData) => {

        let questionCopy = { ...QuestionStore?.questionData };
        questionCopy = {
            ...questionCopy,
            [QuestionStore?.languageSelected]: {
                ...questionCopy[QuestionStore?.languageSelected],
                questionText: QuestionStore?.questionData[`${QuestionStore?.languageSelected}`].questionText,
                optionC: optionData,
            },
        };
        QuestionStore.setQuestionData(questionCopy);

    };
    return (
        <div className='mt-3'>
            <EditorCK value={value} setOptionsC={setOptionsC} />
            <div className="py-3 mb-3 d-flex gap-3" style={{ backgroundColor: ThemeColors.white }}>
                <ToggleComp handleKeyPress={handleKeyPress} label="optionC" checked={QuestionStore?.questionData[`${QuestionStore?.languageSelected}`]?.isCorrectC} />
            </div>
        </div>
    )
}
export function OptioncontainerD({ switchToggle, value, qtype }) {
    function handleKeyPress(e) {
        if (qtype === 'MCQ') {
            switchToggle({ isCorrectD: e?.target?.checked, value: 'optionD' });
        } else {
            switchToggle({ isCorrectD: e?.target?.checked, value: 'optionD' });
            switchToggle({ isCorrectB: false, value: 'optionB' });
            switchToggle({ isCorrectA: false, value: 'optionA' });
            switchToggle({ isCorrectC: false, value: 'optionC' });
        }

    }
    const setOptionsD = async (optionData) => {
        let questionCopy = { ...QuestionStore?.questionData };
        questionCopy = {
            ...questionCopy,
            [QuestionStore?.languageSelected]: {
                ...questionCopy[QuestionStore?.languageSelected],
                questionText: QuestionStore?.questionData[`${QuestionStore?.languageSelected}`].questionText,
                optionD: optionData,

            },
        };
        // enable create button will chng after  some time 
        // setIsEnable(false)
        QuestionStore.setQuestionData(questionCopy);

    };
    return (
        <div className='mt-3'>
            <EditorCK value={value} setOptionsD={setOptionsD} />
            <div className="py-3 mb-3 d-flex gap-3" style={{ backgroundColor: ThemeColors.white }}>
                <ToggleComp handleKeyPress={handleKeyPress} label="optionD" checked={QuestionStore?.questionData[`${QuestionStore?.languageSelected}`]?.isCorrectD} />
            </div>
        </div>
    )
}

