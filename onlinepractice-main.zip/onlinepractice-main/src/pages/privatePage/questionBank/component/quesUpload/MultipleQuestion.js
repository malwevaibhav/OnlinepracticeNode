import React, { useState } from "react";
import Input from "../../../../../customcomponents/input/input";

const MultipleQuestion = () => {
    const [, setValue] = useState("");
    const Inputvalue = (e) => {
        setValue(e.target.value);
    };
    return (
        <>
            <div className="select-head">
                Answer
                <span className="select-one">(write answer)</span>
            </div>

            <div>
                <Input onChange={(e) => Inputvalue(e)} />
            </div>
        </>
    );
};

export default MultipleQuestion;
