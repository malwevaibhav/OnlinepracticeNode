import React, { useEffect, useRef, useState } from "react";
import { FileUploadIcon } from "../../../../../assets/svgs/svg";
import { ThemeColors } from "../../../../../theme/theme";
// import Button from "../DisebleButton/DisebleButton";
// import Modal from "../PreviewModal/previewModal";

function removeItems(arr, item) {
  for (var i = 0; i < item; i++) {
    arr.pop();
  }
}

function useFiles({ initialState = [], maxFiles }) {
  const [state, setstate] = useState(initialState);
  function withBlobs(files) {
    const destructured = [...files];
    if (destructured.length > maxFiles) {
      const difference = destructured.length - maxFiles;
      removeItems(destructured, difference);
    }
    const blobs = destructured
      .map((file) => {
        if (file.type.includes("image")) {
          file.preview = URL.createObjectURL(file);
          return file;
        }
        return null;
      })
      .filter((elem) => elem !== null);

    setstate(blobs);
  }
  return [state, withBlobs];
}

function UploadImg({ onDrop, maxFiles = 1, value }) {
  const [isFile, setIsFile] = useState(true);
  const [over, setover] = useState(false);
  const [files, setfiles] = useFiles({ maxFiles });
  const [isShow, setIsShow] = useState(false);

  const $input = useRef(null);
  useEffect(() => {
    if (onDrop) {
      onDrop(files);
    }
  }, [files, onDrop]);
  return (
    <>
      <div className="blob-buttons mt-3 d-flex gap-3 ">
        {isFile === true ? (
          <>
            <div
              onClick={() => {
                value === "" && $input.current.click();
              }}
              onDrop={(e) => {
                e.preventDefault();
                e.persist();
                //setfiles(e.dataTransfer.files);
                setIsFile(false);
                setover(false);
              }}
              onDragOver={(e) => {
                e.preventDefault();
                setover(true);
              }}
              onDragLeave={(e) => {
                e.preventDefault();
                setover(false);
              }}
            >
              <div
                className={over ? "upload-container over" : "upload-container"}
              >
                <input
                  style={{ display: "none" }}
                  type="file"
                  // accept="image/*"
                  ref={$input}
                  onChange={(e) => {
                    setfiles(e.target.files);
                    setIsFile(false);
                  }}
                  multiple={maxFiles > 1}
                />
                <div >
                  {/* <Button
                    title={"Upload Image"}
                    icon={<FileUploadIcon />}
                    width="160px"
                    value={value}
                  /> */}
                </div>
              </div>
            </div>
          </>
        ) : (
          <>
            <div
              onClick={() => {
                value === "" && $input.current.click();
              }}
              onDrop={(e) => {
                e.preventDefault();
                e.persist();
                //setfiles(e.dataTransfer.files);
                setIsFile(false);
                setover(false);
              }}
              onDragOver={(e) => {
                e.preventDefault();
                setover(true);
              }}
              onDragLeave={(e) => {
                e.preventDefault();
                setover(false);
              }}
            >
              <div
                className={over ? "upload-container over" : "upload-container"}
              >
                <input
                  style={{ display: "none" }}
                  type="file"
                  // accept="image/*"
                  ref={$input}
                  onChange={(e) => {
                    setfiles(e.target.files);
                    setIsFile(false);
                  }}
                  multiple={maxFiles > 1}
                />
                <div >
                  {/* <Button
                    title={"Change Image"}
                    icon={<FileUploadIcon />}
                    width="163px"
                    value={value}
                  /> */}
                </div>
              </div>
            </div>
          </>
        )}
        {files?.length > 0 && (
          <div onClick={() => setIsShow(true)}>
            {/* <Button
              title="Preview"
              textColor="#0075FF"
              background="#ECF5FF"
              border="1px solid #E3E9EE"
              width="104px"
            /> */}
          </div>
        )}
        {/* {isShow && (
          <Modal
            toggle={() => setIsShow(!isShow)}
            closeBtn={false}
            files={files}
            onClick={() => setIsShow(false)}
            backgroundColor={ThemeColors.primary}
          ></Modal>
        )} */}
      </div>
      <div></div>
    </>
  );
}

export { UploadImg };
