import React from 'react'
import "./toggleComp.css";
export default function ToggleComp({handleKeyPress ,label ,checked}) {
    return (
            <div className="toggle-switch ms-2">
                <input type="checkbox" className="switchcheckbox"
                    name={label} id={label} onChange={(e)=>handleKeyPress(e)} checked={checked}/>
                <label className="label" htmlFor={label}>
                    <span className="inner" />
                    <span className="switch" />
                </label>
            </div>
    )
}
