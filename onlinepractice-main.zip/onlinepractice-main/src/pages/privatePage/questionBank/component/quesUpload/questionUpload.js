import { toJS } from "mobx";
import { observer } from "mobx-react";
import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { EditIcon, PlusIcon } from "../../../../../assets/svgs/svg";
import EditorCK from "../../../../../component/CKEditor/EditorCK";
import Button from "../../../../../customcomponents/button/Button";
import { NormalHeading } from "../../../../../customcomponents/DynamicText/Heading";
import { HeadTitle } from "../../../../../customcomponents/headtitle/headTitle";
import AuthStore from "../../../../../MobX/Auth";
import QuestionStore from "../../../../../MobX/Question";
import QuestionBankServices from "../../../../../Services/QuestionbankService";
import QuestionTypeServices from "../../../../../Services/QuestionTypeService";
import { ClientRoutesConstants } from "../../../../../shared/constant";
import { ThemeColors } from "../../../../../theme/theme";
import { validateQuestion, validateUpdateQuestion } from "../../../../../utils/helper";
import QuestionBankCard from "../questionBankCard";
import QuestionHeadCard from "../questionHeadCard";
import SingleChoiceModal from "../singleChoicePopup/SingleChoiceModal";
import {
  Integeroption,
  OptioncontainerA,
  OptioncontainerB,
  OptioncontainerC,
  OptioncontainerD
} from "./optioncontainer";
import "./questionUpload.css";

const QuestionUpload = () => {
  const [modal, setModal] = useState("");
  const [qtype, setQtype] = useState(QuestionStore.selectedItemsNw.questionType.selectedName ? QuestionStore.selectedItemsNw.questionType.selectedName : "");
  const [detail, setDetails] = useState("");
  const [show, setShow] = useState(false);
  const [Qcard, setQcard] = useState(true);
  const navigate = useNavigate()
  const [marks, setMarks] = useState({
    mark: 0,
    negativeMark: 0,
    isPartiallyCorrect: false,
    partialThreeCorrectMark: 0,
    partialTwoCorrectMark: 0,
    partialOneCorrectMark: 0,
  });
  const location = useLocation();
  const { toggle, isEdit, Id } = location?.state;
/* eslint-disable */

//  console.log("gsvdsvdhsgd" ,location);
  useEffect(() => {
    getAllLevel();
  }, [])

  useEffect(() => {
    getAllLanguage();
    getAllLevel();
    if (isEdit) {
      setQcard(true)
      getQuestionbyid(Id)
    }
    return () => {
      QuestionStore.setMarks(marks)
    }
  }, [Id]);

  const getQuestionbyid = async (id) => {
    const res = await QuestionBankServices.getQuestionByID(id);

    if (res?.isSuccess) {
      if (res?.responseCode) {
        setMarks({
          ...marks, mark: res?.data?.mark, negativeMark: res?.data?.negativeMark, partialOneCorrectMark: res?.data.partialOneCorrectMark, partialThreeCorrectMark: res?.data?.partialThreeCorrectMark, partialTwoCorrectMark: res?.data?.partialTwoCorrectMark, isPartiallyCorrect
            : res?.data?.isPartiallyCorrect
        })
        QuestionStore?.setQuesiton(res?.data)
      }
      setShow(true)
    }
  };

  const getAllLanguage = async () => {
    const res = await QuestionTypeServices.getAllLanguage();
    if (res?.isSuccess) {
      QuestionStore?.setLanguage(res?.data);
      setDetails(res?.data)
      setselected(res?.data[0]?.name, "language", res?.data[0].value);
      if (!isEdit) {
        createQuestion(res?.data);
      }
    }
  };

  const getAllLevel = async () => {
    const res = await QuestionTypeServices.getAllLevel();
    let level = res?.data?.map((elm) => {
      return {
        id: elm?.value,
        Title: elm?.name,
        label: "Level",
      };
    });
    QuestionStore.setLevelList(level)
    QuestionStore.setSelectedItemsNw({ selectedName: "Level", props: level[0], entityName: level[0].Title })
    if (res?.isSuccess) {
      QuestionStore?.setLevel(res?.data);
      setselected(res?.data[0]?.name, "level", res?.data[0].value);
    }
  };

  const setselected = async (value, name, id) => {
    if (name === "level") {
      QuestionStore?.setlevelSelected(value);
      QuestionStore?.setlevelID(id);
    }
    if (name === "language") {
      if (!isEdit) {
        QuestionStore?.setlanguageSelected(value);
      } else {
        QuestionStore?.setlanguageSelected(value.toLowerCase());
      }
    }
  };

  const createQuestion = (data) => {
    if (data) {
      let questionTableData = {
        questionRefId: "",
      };
      data.map((item) => {
        questionTableData = {
          ...questionTableData,
          [item?.name]: {
            questionText: "",
            optionA: "",
            isCorrectA: false,
            optionB: "",
            isCorrectB: false,
            optionC: "",
            isCorrectC: false,
            optionD: "",
            isCorrectD: false,
            explanation: "",
          },
        };
      });
      QuestionStore?.setQuestionData(questionTableData);
    }
  };

  const setQuestion = async (data) => {
    let questionCopy = { ...QuestionStore?.questionData };
    questionCopy = {
      ...questionCopy,
      [QuestionStore?.languageSelected]: {
        ...questionCopy[QuestionStore?.languageSelected],
        questionText: data,
      },
    };
    QuestionStore.setQuestionData(questionCopy);
  };

  const switchToggle = async (props) => {
    let questionCopy = { ...QuestionStore?.questionData };
    QuestionStore?.Language.map((item) => {
      if (isEdit) {
        if (props?.value === 'optionA') {
          questionCopy = {
            ...questionCopy,
            [item?.name.toLowerCase()]: {
              ...questionCopy[item?.name.toLowerCase()],
              questionText: QuestionStore?.questionData[item?.name.toLowerCase()]?.questionText,
              optionA: QuestionStore?.questionData[item?.name.toLowerCase()]?.optionA,
              isCorrectA: props?.isCorrectA
            },
          };
        }
        if (props?.value === 'optionB') {
          questionCopy = {
            ...questionCopy,
            [item?.name.toLowerCase()]: {
              ...questionCopy[item?.name.toLowerCase()],
              questionText: QuestionStore?.questionData[item?.name.toLowerCase()]?.questionText,
              optionB: QuestionStore?.questionData[item?.name.toLowerCase()]?.optionB,
              isCorrectB: props?.isCorrectB
            },
          };
        }
        if (props?.value === 'optionC') {
          questionCopy = {
            ...questionCopy,
            [item?.name.toLowerCase()]: {
              ...questionCopy[item?.name.toLowerCase()],
              questionText: QuestionStore?.questionData[item?.name.toLowerCase()]?.questionText,
              optionC: QuestionStore?.questionData[item?.name.toLowerCase()]?.optionC,
              isCorrectC: props?.isCorrectC
            },
          };
        }
        if (props?.value === 'optionD') {
          questionCopy = {
            ...questionCopy,
            [item?.name.toLowerCase()]: {
              ...questionCopy[item?.name.toLowerCase()],
              questionText: QuestionStore?.questionData[item?.name.toLowerCase()]?.questionText,
              optionD: QuestionStore?.questionData[item?.name.toLowerCase()]?.optionD,
              isCorrectD: props?.isCorrectD
            },
          };
        }
      } else {
        if (props?.value === 'optionA') {
          questionCopy = {
            ...questionCopy,
            [item?.name]: {
              ...questionCopy[item?.name],
              questionText: QuestionStore?.questionData[item?.name]?.questionText,
              optionA: QuestionStore?.questionData[item?.name]?.optionA,
              isCorrectA: props?.isCorrectA
            },
          };
        }
        if (props?.value === 'optionB') {
          questionCopy = {
            ...questionCopy,
            [item?.name]: {
              ...questionCopy[item?.name],
              questionText: QuestionStore?.questionData[item?.name]?.questionText,
              optionB: QuestionStore?.questionData[item?.name]?.optionB,
              isCorrectB: props?.isCorrectB
            },
          };
        }
        if (props?.value === 'optionC') {
          questionCopy = {
            ...questionCopy,
            [item?.name]: {
              ...questionCopy[item?.name],
              questionText: QuestionStore?.questionData[item?.name]?.questionText,
              optionC: QuestionStore?.questionData[item?.name]?.optionC,
              isCorrectC: props?.isCorrectC
            },
          };
        }
        if (props?.value === 'optionD') {
          questionCopy = {
            ...questionCopy,
            [item?.name]: {
              ...questionCopy[item?.name],
              questionText: QuestionStore?.questionData[item?.name]?.questionText,
              optionD: QuestionStore?.questionData[item?.name]?.optionD,
              isCorrectD: props?.isCorrectD
            },
          };
        }
      }
    })
    QuestionStore.setQuestionData(questionCopy);
  };

  const setExplanation = async (props) => {
    let questionCopy = { ...QuestionStore?.questionData };
    questionCopy = {
      ...questionCopy,
      [QuestionStore?.languageSelected]: {
        ...questionCopy[QuestionStore?.languageSelected],
        questionText: QuestionStore?.questionData[`${QuestionStore?.languageSelected}`].questionText,
        optionA: QuestionStore?.questionData[`${QuestionStore?.languageSelected}`].optionA,
        isCorrectA: QuestionStore?.questionData[`${QuestionStore?.languageSelected}`].isCorrectA,
        explanation: props
      },
    };
    QuestionStore.setQuestionData(questionCopy);
  }

  const createQuestionBank = async () => {
    let questionDetail = {
      questionTableData: {
        ...QuestionStore?.questionData,
        questionRefId: `${Date.now()}`
      },
      subjectCategoryId: QuestionStore.selectedItemsNw.SubjectList.id,
      topicId: QuestionStore.selectedItemsNw.TopicList.id,
      subTopicId: QuestionStore.selectedItemsNw.SubTopicList.id,
      questionType: QuestionStore.selectedItemsNw.questionType.id,
      questionLevel: QuestionStore.selectedItemsNw.level.id,
      mark: QuestionStore?.marks?.mark,
      negativeMark: QuestionStore?.marks?.negativeMark,
      isPartiallyCorrect: QuestionStore?.marks?.isPartiallyCorrect,
      partialThreeCorrectMark: QuestionStore?.marks?.partialThreeCorrectMark,
      partialTwoCorrectMark: QuestionStore?.marks?.partialTwoCorrectMark,
      partialOneCorrectMark: QuestionStore?.marks?.partialOneCorrectMark,
    }
    let author = QuestionStore.authorList.find(item => item?.id === AuthStore.user?.user.id)
    QuestionStore.setSelectedItemsNw({ selectedName: "Author", props: author, entityName: author?.Title })
    if (validateQuestion(questionDetail) === true) {
      const res = await QuestionBankServices.createQuestionbank(questionDetail);
      if (res?.isSuccess) {
        localStorage.setItem("SelectedFilters", JSON.stringify(QuestionStore.selectedItemsNw))
        toast.success(res?.messages)
        navigate(ClientRoutesConstants.questionBank)
      } else {
        toast.error(res?.messages)
      }
    }
  }

  const updateQuestionBank = async () => {
    let questionDetail = {
      questionTableData: {
        ...QuestionStore?.questionData,
        questionRefId: QuestionStore?.questionData?.questionRefId

      },
      subjectCategoryId: QuestionStore.selectedItemsNw.SubjectList.id,
      topicId: QuestionStore.selectedItemsNw.TopicList.id,
      subTopicId: QuestionStore.selectedItemsNw.SubTopicList.id,
      questionType: QuestionStore.selectedItemsNw.questionType.id,
      questionLevel: QuestionStore.selectedItemsNw.level.id,
      mark: QuestionStore?.marks?.mark,
      negativeMark: QuestionStore?.marks?.negativeMark,
      isPartiallyCorrect: QuestionStore?.marks?.isPartiallyCorrect,
      partialThreeCorrectMark: QuestionStore?.marks?.partialThreeCorrectMark,
      partialTwoCorrectMark: QuestionStore?.marks?.partialTwoCorrectMark,
      partialOneCorrectMark: QuestionStore?.marks?.partialOneCorrectMark,
    }
    if (validateUpdateQuestion(questionDetail) === true) {
      const res = await QuestionBankServices.updateQuestionbank(questionDetail);
      if (res?.isSuccess) {
        toast.success(res?.messages)
        navigate(ClientRoutesConstants.questionBank)
      } else {
        toast.error(res?.messages)
      }
    }
  }

  const reset = async () => {
    if (!isEdit) {
      createQuestion(detail)
      setselected(detail[0]?.name, "language", detail[0].value);
      getAllLevel();
    } else {
      getQuestionByID(Id)
    }
  }

  const handleShow = () => {
    setShow(true)
    getAllLevel()
  }
  
  return (
    <div style={{ flexShrink: 1, width: "98.9%" }}>
      <div className="mb-3">
        <HeadTitle text="Question Bank" />
      </div>
      {
        Qcard && <QuestionBankCard filterdData={isEdit} toggle={toggle} setQtype={setQtype} isEdit={isEdit} setMarks={setMarks} switchToggle={switchToggle} editFunc={() => getQuestionByID(Id)} setShow={() => handleShow()} />
      }
      {
        show &&
        <>
          <div className="row mt-3 m-0">
            <QuestionHeadCard
              title="Select Language"
              type="radio"
              name="language"
              data={QuestionStore?.Language}
              setselected={setselected}
              isEdit={isEdit} />
            <QuestionHeadCard
              title="Difficulty Level"
              type="radio"
              name="level"
              data={QuestionStore?.Level}
              setselected={setselected} />
          </div>
          <div className="d-flex flex-column m-0 my-2 ">
            <HeadTitle
              text={<NormalHeading text="Question" />}
              component1={isEdit ? <Button
                icon={<EditIcon />}
                title={"Edit Marks"}
                func={() => { setModal(!QuestionStore.selectedItemsNw.questionType.selectedName ? qtype : QuestionStore.selectedItemsNw.questionType.selectedName) }}
              /> :
                <Button
                  icon={<PlusIcon />}
                  title={"Add Marks"}
                  func={() => setModal(!QuestionStore.selectedItemsNw.questionType.selectedName ? qtype : QuestionStore.selectedItemsNw.questionType.selectedName)}
                />} />

            <div className="d-flex flex-column">
              <div>
                <EditorCK
                  value={!Object.keys(QuestionStore?.questionData).length < 1
                    ? QuestionStore?.questionData[`${QuestionStore?.languageSelected}`]?.questionText
                    : ""}
                  setQuestion={setQuestion} />
                {
                  qtype !== 'Integer Type' ?
                    <div>
                      <div className="mt-3">
                        <NormalHeading text="Options A" />
                        <OptioncontainerA
                          switchToggle={switchToggle}
                          value={!Object.keys(QuestionStore?.questionData).length < 1
                            ? QuestionStore?.questionData[`${QuestionStore?.languageSelected}`]?.optionA
                            : ""}
                          qtype={qtype} />
                      </div>
                      <div className="mt-3">
                        <NormalHeading text="Options B" />
                        <OptioncontainerB
                          switchToggle={switchToggle}
                          value={!Object.keys(QuestionStore?.questionData).length < 1
                            ? QuestionStore?.questionData[`${QuestionStore?.languageSelected}`]?.optionB
                            : ""}
                          qtype={qtype} />
                      </div>
                      <div className="mt-3">
                        <NormalHeading text="Options C" />
                        <OptioncontainerC
                          switchToggle={switchToggle}
                          value={!Object.keys(QuestionStore?.questionData).length < 1
                            ? QuestionStore?.questionData[`${QuestionStore?.languageSelected}`]?.optionC
                            : ""}
                          qtype={qtype} />
                      </div>
                      <div className="mt-3">
                        <NormalHeading text="Options D" />
                        <OptioncontainerD
                          switchToggle={switchToggle}
                          value={!Object.keys(QuestionStore?.questionData).length < 1
                            ? QuestionStore?.questionData[`${QuestionStore?.languageSelected}`]?.optionD
                            : ""}
                          qtype={qtype} />
                      </div>
                    </div>
                    :
                    <>
                      <div className="mt-3">
                        <NormalHeading text="Answer" />
                        <Integeroption
                          value={!Object.keys(QuestionStore?.questionData).length < 1
                            ? QuestionStore?.questionData[`${QuestionStore?.languageSelected}`]?.optionA
                            : ""}
                          qtype={qtype} />
                      </div>
                    </>

                }
                <div className="mt-3">
                  <NormalHeading text="Explanation" />
                  <div className='mt-3'>
                    <EditorCK
                      value={!Object.keys(QuestionStore?.questionData).length < 1
                        ? QuestionStore?.questionData[`${QuestionStore?.languageSelected}`]?.explanation
                        : ""}
                      setExplanation={setExplanation} />
                  </div>
                </div>
              </div>
              <div className="modal-footer mt-4 gap-3">
                {!isEdit ?
                  <Button title="Create" width="120px" func={createQuestionBank}></Button>
                  : <Button title="Update" width="124px" func={updateQuestionBank}></Button>}
                <Button title="Cancel" width="96px" func={reset} background={ThemeColors?.secondary}></Button>
              </div>
            </div>
          </div>
        </>
      }

      {(modal) && (
        <SingleChoiceModal
          isEdit={isEdit}
          setModal={setModal}
          Title={modal}
          setMarks={setMarks}
          marks={marks}
        />
      )}
    </div>
  );
};

export default observer(QuestionUpload);
