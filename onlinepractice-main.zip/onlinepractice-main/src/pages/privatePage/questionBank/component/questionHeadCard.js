import React, { useState } from "react";
import { NormalHeading } from "../../../../customcomponents/DynamicText/Heading";
import QuestionStore from "../../../../MobX/Question";
import { ThemeColors } from "../../../../theme/theme";
import "../questionbank.css";
export default function QuestionHeadCard({ title, data, name, isEdit }) {
  const [toggle,setToggle]= useState(false)
  const setdata = (elm, name) => {

    if (name === "language") {
      if (!isEdit) {
        QuestionStore?.setlanguageSelected(elm?.name);
      } else {
        QuestionStore?.setlanguageSelected(elm?.name.toLowerCase());
      }
  
    }
    if (name === "level") {
      QuestionStore?.setlevelID(elm?.value);
      QuestionStore?.setlevelSelected(elm?.name);
     
      setToggle(!toggle)
    }
  };
  
  const radioinput = {
    padding: "2px 10px",
    gap: " 20px",
    minWidth: "max-content",
    height: "29px",
    borderRadius: "3px",
    color: "rgb(0, 117, 255)",
    margin: "0px",
    background: "rgb(236, 245, 255)",
    border: "1px solid rgb(208, 230, 255)",
  };

  return (
    
    <div
      className="py-4 mb-3 d-flex gap-3 "
      style={{ backgroundColor: ThemeColors.white }}
    >
      <div className="pe-3">
        <NormalHeading text={title} />
      </div>
      <div className="d-flex gap-3 flex-wrap">
        
        {data && 
          data?.map((elm, key) => (
            <div style={radioinput} key={key}>
              {
                !isEdit ? <input
                type="radio"
                id={elm?.name}
                name={name}
                value={elm?.name}
                onChange={(e) => setdata(elm, name)}
                checked={
                  name !== "level"
                    ? QuestionStore?.languageSelected === elm?.name
                    : QuestionStore?.questionlevel === elm?.name
                }
              />:
              <input
                type="radio"
                id={elm?.name}
                name={name}
                value={elm?.name}
                onChange={(e) => setdata(elm, name)}
                checked={
                  name !== "level"
                    ? QuestionStore?.languageSelected === (elm?.name).toLowerCase()
                    : QuestionStore?.questionlevel === (elm?.name)
                }
              />
              }
              
              <label className="ms-2" htmlFor={elm?.name}>
                {elm?.name}
              </label>
            </div>
          ))}
      </div>
    </div>
  );
}
