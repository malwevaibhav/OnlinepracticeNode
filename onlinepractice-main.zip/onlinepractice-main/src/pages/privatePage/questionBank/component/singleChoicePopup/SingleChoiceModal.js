import React, { useState } from 'react';

import { numberGreaterThanOne, positiveNumber } from '../../../../../assets/regex';
import Checkbox from '../../../../../customcomponents/checkbox/Checkbox';
import CustomInput from '../../../../../customcomponents/customTextInput';
import { InputLabel } from '../../../../../customcomponents/customTextInput/indexCss';
import { NormalHeading } from '../../../../../customcomponents/DynamicText/Heading';
import Modal from '../../../../../customcomponents/modalPopup/CustomModal';
import QuestionStore from '../../../../../MobX/Question';
import { ThemeColors } from '../../../../../theme/theme';
const cardStyle = {
    minWidth: 'fitContent',
    height: 'fitContent',
    minHeight: "45px"
}
export default function SingleChoiceModal({ setModal, Title, setMarks, marks }) {
    const [errors, setErrors] = useState({
        mark: false,
        negativeMark: false,
        partialThreeCorrectMark: false,
        partialTwoCorrectMark: false,
        partialOneCorrectMark: false
    });
    const setInitMarks = () => {
        setMarks(QuestionStore.marks);
        setModal("");
    }
    const selectAll = (e) => {
        if (!e.target.checked) {
            // setInitMarks()
            setMarks({
                ...marks,
                isPartiallyCorrect: false,
                partialThreeCorrectMark: 0,
                partialTwoCorrectMark: 0,
                partialOneCorrectMark: 0
            })
        }
        else {
            setMarks({ ...marks, isPartiallyCorrect: e.target.checked })
        }
    };
    const setData = (value, fieldName) => {

        switch (fieldName) {
            case 'mark':
                if (!numberGreaterThanOne.test(value)) {
                    setErrors({ ...errors, mark: true })
                    setMarks({ ...marks, mark: value })
                }
                else {
                    setErrors({ ...errors, mark: false })
                    setMarks({ ...marks, mark: value })
                }
                return
            case 'negativeMark':
                if (!positiveNumber.test(value)) {
                    setErrors({ ...errors, negativeMark: "Number should NOT less than 0" })
                    setMarks({ ...marks, negativeMark: value })
                } else if (JSON.parse(value) > JSON.parse(marks?.mark)) {
                    setErrors({ ...errors, negativeMark: "Number should NOT be greater than Total Marks" })
                    setMarks({ ...marks, negativeMark: value })
                }
                else {
                    setErrors({ ...errors, negativeMark: "" })
                    setMarks({ ...marks, negativeMark: value })
                }
                return
            case 'partialThreeCorrectMark':
                if (!numberGreaterThanOne.test(value)) {
                    setErrors({ ...errors, partialThreeCorrectMark: "Number should be greater than 0" })
                    setMarks({ ...marks, partialThreeCorrectMark: value })
                } else if (JSON.parse(value) > JSON.parse(marks?.mark)) {
                    setErrors({ ...errors, partialThreeCorrectMark: "Number should NOT be greater than Total Marks" })
                    setMarks({ ...marks, partialThreeCorrectMark: value })
                }
                else {
                    setErrors({ ...errors, partialThreeCorrectMark: "" })
                    setMarks({ ...marks, partialThreeCorrectMark: value })
                }
                return
            case 'partialTwoCorrectMark':
                if (!numberGreaterThanOne.test(value)) {
                    setErrors({ ...errors, partialTwoCorrectMark: "Number should be greater than 0" })
                    setMarks({ ...marks, partialTwoCorrectMark: value })
                } else if (JSON.parse(value) > JSON.parse(marks?.mark)) {
                    setErrors({ ...errors, partialTwoCorrectMark: "Number should NOT be greater than Total Marks" })
                    setMarks({ ...marks, partialTwoCorrectMark: value })
                }
                else {
                    setErrors({ ...errors, partialTwoCorrectMark: "" })
                    setMarks({ ...marks, partialTwoCorrectMark: value })
                }
                return
            case 'partialOneCorrectMark':
                if (!numberGreaterThanOne.test(value)) {
                    setErrors({ ...errors, partialOneCorrectMark: "Number should be greater than 0" })
                    setMarks({ ...marks, partialOneCorrectMark: value })
                } else if (JSON.parse(value) > JSON.parse(marks?.mark)) {
                    setErrors({ ...errors, partialOneCorrectMark: "Number should NOT be greater than Total Marks" })
                    setMarks({ ...marks, partialOneCorrectMark: value })
                }
                else {
                    setErrors({ ...errors, partialOneCorrectMark: "" })
                    setMarks({ ...marks, partialOneCorrectMark: value })
                }
                return
            default:
                return
        }
    };
    const submitFunc = () => {
        if (errors?.mark || errors?.negativeMark || errors?.partialThreeCorrectMark || errors?.partialTwoCorrectMark || errors?.partialOneCorrectMark) {
            return
        }
        else {
            QuestionStore.setMarks({ ...marks })
            setModal('')
        }
    }
    return (
        <Modal
            onRequestClose={setInitMarks}
            dynButton="Set"
            dynBtnSize="97px"
            wrap="nowrap"
            width="55vw"
            maxModalWidth='685px'
            me="me-2"
            backgroundColor={ThemeColors.primary}
            onPress={() => submitFunc()}
        >

            <div style={{
                background: '#ECF5FF',
                padding: '10px',
                position: 'absolute',
                top: 0,
                left: 0,
                display: 'flex',
                width: '100%',
            }}>
                <NormalHeading text={Title} color="#0075FF" />
            </div>
            <div className="row m-0 align-items-center mt-4">
                <div className="col-xl-3 col-lg-3 col-md-3 col-sm-12">
                    <InputLabel className='pt-4'>Total Marks</InputLabel>
                </div>
                <div className="col-xl-9 col-lg-9 col-md-8 col-sm-12">
                    <CustomInput
                        height="48px"
                        name="totalmarks"
                        value={marks?.mark}
                        onChange={(e) => { setData(e.target.value, "mark") }}
                    // onChange={(e) => { setMarks({ ...marks, mark: e.target.value }) }}
                    />
                    {(errors?.mark)
                        && <div className="input-feedback postion-absolute">
                            Enter positive number
                        </div>
                    }
                </div>
                <div className="col-xl-3 col-lg-3 col-md-3 col-sm-12">
                    <InputLabel className='pt-4'>Negative Marks</InputLabel>
                </div>
                <div className="col-xl-9 col-lg-9 col-md-8 col-sm-12">
                    <CustomInput
                        height="48px"
                        name="negativemarks"
                        value={marks?.negativeMark}
                        onChange={(e) => { setData(e.target.value, "negativeMark") }}
                    // onChange={(e) => { setMarks({ ...marks, negativeMark: e.target.value }) }}
                    />
                    {(errors?.negativeMark)
                        && <div className="input-feedback postion-absolute">
                            {errors?.negativeMark}
                        </div>
                    }
                </div>
                {Title === "MCQ" &&
                    <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12 mt-3">
                        <div className="card rounded-0" >
                            <ul className="list-group list-group-flush">
                                <li className="list-group-item py-2 ">
                                    <div className='d-flex align-items-center gap-3 ms-0 py-2'>
                                        <Checkbox id="selectAll"
                                            handleClick={selectAll}
                                            isChecked={marks?.isPartiallyCorrect} /><InputLabel> Partial Marks</InputLabel>
                                    </div>
                                </li>
                                <li className="list-group-item pb-3 p-0 py-2 ps-2">
                                    <div className="row align-items-center m-0 position-relative">
                                        <div className="col-xl-10 col-lg-9 col-md-11 col-sm-11 card d-flex flex-row  justify-content-start align-items-center me-3 mt-2 ms-0 ps-2 gap-3 " style={cardStyle}>
                                            <Checkbox id="p2"
                                                isChecked={marks.isPartiallyCorrect} />
                                            <InputLabel >If all 4 options are correct but only 3 correct options are chosen</InputLabel>
                                        </div>
                                        <div className="col-xl-1 col-lg-2 col-md-11 col-sm-11 d-flex m-0 p-0 ">
                                            {/* {marks?.partialThreeCorrectMark} */}
                                            <CustomInput background="white" height="45px" width="80px" isDisabled={!marks?.isPartiallyCorrect} value={marks?.partialThreeCorrectMark} onChange={(e) => { setData(e.target.value, "partialThreeCorrectMark") }} />
                                        </div>
                                        {(errors?.partialThreeCorrectMark)
                                            && <div className="input-feedback postion-absolute">
                                                {errors?.partialThreeCorrectMark}
                                            </div>
                                        }
                                    </div>
                                </li>
                                <li className="list-group-item pb-3 p-0 py-2 ps-2">
                                    <div className="row align-items-center m-0 position-relative">
                                        <div className="col-xl-10 col-lg-9 col-md-11 col-sm-11 card d-flex flex-row   justify-content-start align-items-center me-3 mt-2 ms-0 ps-2 gap-3 " style={cardStyle}>
                                            <Checkbox id="p2"
                                                isChecked={marks.isPartiallyCorrect} />
                                            <InputLabel >If all 3 or more options are correct but only 2 correct options are chosen</InputLabel>
                                        </div>
                                        <div className="col-xl-1 col-lg-2 col-md-11 col-sm-11 d-flex m-0 p-0 ">
                                            <CustomInput background="white" height="45px" width="80px" isDisabled={!marks?.isPartiallyCorrect} value={marks?.partialTwoCorrectMark} onChange={(e) => { setData(e.target.value, "partialTwoCorrectMark") }} />
                                        </div>
                                        {(errors?.partialTwoCorrectMark)
                                            && <div className="input-feedback postion-absolute">
                                                {errors?.partialTwoCorrectMark}
                                            </div>
                                        }
                                    </div>
                                </li>
                                <li className="list-group-item pb-3 p-0 py-2 ps-2">
                                    <div className="row align-items-center m-0 position-relative">
                                        <div className="col-xl-10 col-lg-9 col-md-11 col-sm-11 card d-flex flex-row  justify-content-start align-items-center me-3 mt-2 ms-0 ps-2 gap-3 " style={cardStyle}>
                                            <Checkbox id="p3"
                                                isChecked={marks.isPartiallyCorrect} />
                                            <InputLabel >If all 2 or more options are correct but only 1 correct options are chosen</InputLabel>
                                        </div>
                                        <div className="col-xl-1 col-lg-2 col-md-11 col-sm-11 d-flex m-0 p-0 ">
                                            <CustomInput background="white" height="45px" width="80px" isDisabled={!marks?.isPartiallyCorrect} value={marks?.partialOneCorrectMark} onChange={(e) => { setData(e.target.value, "partialOneCorrectMark") }} />
                                        </div>
                                        {(errors?.partialOneCorrectMark)
                                            && <div className="input-feedback postion-absolute">
                                                {errors?.partialOneCorrectMark}
                                            </div>
                                        }
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>}
            </div>
        </Modal>
    )
}