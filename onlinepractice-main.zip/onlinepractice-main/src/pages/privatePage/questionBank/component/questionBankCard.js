import { toJS } from "mobx";
import { observer } from "mobx-react-lite";
import React, { useEffect, useLayoutEffect, useState } from "react";
import Button from "../../../../customcomponents/button/Button";
import { InputLabel } from "../../../../customcomponents/customTextInput/indexCss";
import CustomDropdown from "../../../../customcomponents/custom_Dropdown/CustomDropdown";
import AuthStore from "../../../../MobX/Auth";
import CourseStore from "../../../../MobX/Courses";
import QuestionStore from "../../../../MobX/Question";
import CourseServices from "../../../../Services/CourseService";
import QuestionTypeServices from "../../../../Services/QuestionTypeService";
import { checkDefault } from "../../../../utils/helper";
import "../questionbank.css";
const QuestionBankCard = observer((props) => {
  const Role = AuthStore?.user?.user;
  const {
    filterdData,
    questionTable,
    toggle,
    setQtype,
    applyFunc,
    isEdit,
    setMarks,
    setShow,
    setQuestionBankList,
    editFunc,
  } = props;
  const [questionType, setQuestionType] = useState([]);
  const [addedBY, setAddedBY] = useState([]);
  const [level, setLevel] = useState([]);
  /* eslint-disable */
  useEffect(() => {
    let data = JSON.parse(localStorage?.getItem("SelectedFilters"));
    if (filterdData) {
      getCheckedData(data);
    }
  }, []);

  const getCheckedData = async (data) => {
    // console.log("data=>>>",data)
    // const {
    //   examList,
    //   courseList,
    //   SubCourseList,
    //   SubjectList,
    //   TopicList,
    //   SubTopicList,
    //   questionType,
    //   addedBY,
    //   level,
    // } = data;
    const respE = await getDataForModule(
      examList?.props,
      examList?.selectedName
    );

    if (respE) {
      const respC = await getDataForModule(
        courseList?.props,
        courseList?.selectedName
      );
      if (respC) {
        const respSc = await getDataForModule(
          SubCourseList?.props,
          SubCourseList?.selectedName
        );
        if (respSc) {
          const respSub = await getDataForModule(
            SubjectList?.props,
            SubjectList?.selectedName
          );
          if (respSub) {
            const respTop = await getDataForModule(
              TopicList?.props,
              TopicList?.selectedName
            );
            if (respTop) {
              const respST = await getDataForModule(
                SubTopicList?.props,
                SubTopicList?.selectedName
              );
              if (respST) {
                const respQ = await getDataForModule(
                  questionType?.props,
                  questionType?.selectedName
                );
                if (respQ) {
                  const respA = await getDataForModule(
                    addedBY?.props,
                    addedBY?.selectedName
                  );
                  if (respA || Role.role === "Staff") {
                    const respL = await getDataForModule(
                      level?.props,
                      level?.selectedName
                    );
                    if (respL) {
                      if (questionTable) {
                        applyFunc();
                      }
                      if (isEdit) {
                        editFunc();
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  };
  useLayoutEffect(() => {
    CourseStore.setexamList([]);
    CourseStore.setCourse([]);
    CourseStore.setSubCourse([]);
    CourseStore.setSubjectSelected([]);
    CourseStore.setTopicList([]);
    CourseStore.setSubTopicList([]);
    CourseStore.setQuestionTypeList([]);
    CourseServices?.getCourseFilterData({ label: "Exam" });
    getAllQuesType();
    getAllAddedBy();
    getAllLevel();
  }, []);

  const examList = toJS(CourseStore?.examList);
  const courseList = toJS(CourseStore?.course);
  const subcourseList = toJS(CourseStore?.subcourse);
  const subjectList = toJS(CourseStore?.selectedSubjectList);
  const topicList = toJS(CourseStore?.topicList);
  const subTopicList = toJS(CourseStore?.subTopicList);

  const getAllQuesType = async () => {
    const resData = await QuestionTypeServices.getAllQuestionType();
    let queType = resData?.map((elm) => {
      return {
        id: elm?.value,
        Title: elm?.name,
        label: "QuestionType",
      };
    });
    setQuestionType(queType);
    QuestionStore.setQuestionType(queType);
    CourseStore.setQuestionTypeList(queType);
  };
  //#endregion
  const getDataForModule = (props, entityName) => {
    if (questionTable) {
      setQuestionBankList([]);
    }
    if (props?.label === "Course") {
      CourseStore.setSubCourse([]);
      CourseStore.setSubjectSelected([]);
      CourseStore.setTopicList([]);
      CourseStore.setSubTopicList([]);
      CourseStore.setQuestionTypeList([]);
      QuestionStore.setSelectedItemsNw({
        selectedName: "Exam",
        props,
        entityName,
      });
    }
    if (props?.label === "SubCourse") {
      CourseStore.setSubCourse([]);
      CourseStore.setSubjectSelected([]);
      CourseStore.setTopicList([]);
      CourseStore.setSubTopicList([]);
      CourseStore.setQuestionTypeList([]);
      QuestionStore.setSelectedItemsNw({
        selectedName: "Course",
        props,
        entityName,
      });
    }
    if (props?.label === "Subject") {
      CourseStore.setSubjectSelected([]);
      CourseStore.setTopicList([]);
      CourseStore.setSubTopicList([]);
      CourseStore.setQuestionTypeList([]);
      QuestionStore.setSelectedItemsNw({
        selectedName: "SubCourse",
        props,
        entityName,
      });
    }
    if (props?.label === "Topic") {
      CourseStore.setTopicList([]);
      CourseStore.setSubTopicList([]);
      CourseStore.setQuestionTypeList([]);
      QuestionStore.setSelectedItemsNw({
        selectedName: "Subject",
        props,
        entityName,
      });
    }
    if (props?.label === "SubTopic") {
      CourseStore.setSubTopicList([]);
      CourseStore.setQuestionTypeList([]);
      QuestionStore.setSelectedItemsNw({
        selectedName: "Topic",
        props,
        entityName,
      });
    }
    if (props?.label === "QuestionType") {
      QuestionStore.setSelectedItemsNw({
        selectedName: "QuestionType",
        props,
        entityName,
      });

      if (setMarks) {
        setMarks({
          mark: 0,
          negativeMark: 0,
          isPartiallyCorrect: false,
          partialThreeCorrectMark: 0,
          partialTwoCorrectMark: 0,
          partialOneCorrectMark: 0,
        });
      }

      if (setQtype) {
        setQtype(entityName);
      }
      return true;
    }

    if (props?.label === "AddedBy") {
      QuestionStore.setSelectedItemsNw({
        selectedName: "Author",
        props,
        entityName,
      });
      return true;
    }
    if (props?.label === "Level") {
      QuestionStore.setSelectedItemsNw({
        selectedName: "Level",
        props,
        entityName,
      });
      return true;
    }
    if (props?.label === "") {
      QuestionStore.setSelectedItemsNw({
        selectedName: "SubTopic",
        props,
        entityName,
      });
      return true;
    }
    return CourseServices?.getCourseFilterData(props);
  };

  const getAllAddedBy = async () => {
    const resData = await QuestionTypeServices.getAllAddedBy();
    let addedby = resData?.staffList?.map((elm) => {
      return {
        id: elm?.id,
        Title: elm?.name,
        label: "AddedBy",
      };
    });
    QuestionStore.setAuthorList(addedby);
    setAddedBY(addedby);
  };

  const getAllLevel = async () => {
    const res = await QuestionTypeServices.getAllLevel();
    let level = res?.data?.map((elm) => {
      return {
        id: elm?.value,
        Title: elm?.name,
        label: "Level",
      };
    });
    QuestionStore.setLevelList(level);
    setLevel(level);
  };
  return (
    <form className="card px-3 pb-4 border-0">
      <div className="row m-0 gy-3">
        <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
          <InputLabel>Exam Type</InputLabel>
          <CustomDropdown
            height="48px"
            menu={examList}
            customClass="form-dropdown"
            placeholder="Select Exam"
            isSelect={true}
            disable={isEdit}
            handlefunc={!isEdit && getDataForModule}
            menuStyle={{ border: "1px solid #E3E9EE" }}
            selectedEntity={QuestionStore.selectedItemsNw.examList.selectedName}
          />
        </div>
        <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
          <InputLabel>Course</InputLabel>
          <CustomDropdown
            height="48px"
            menu={courseList}
            customClass="form-dropdown"
            placeholder="Select Course"
            isSelect={true}
            menuStyle={{ border: "1px solid #E3E9EE" }}
            handlefunc={getDataForModule}
            selectedEntity={
              QuestionStore.selectedItemsNw.courseList.selectedName
            }
            disable={
              isEdit ? true : !CourseStore?.course?.length ? true : false
            }
          />
        </div>
        <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
          <InputLabel>Sub-course</InputLabel>
          <CustomDropdown
            height="48px"
            menu={subcourseList}
            customClass="form-dropdown"
            placeholder="Select SubCourse"
            isSelect={true}
            handlefunc={getDataForModule}
            selectedEntity={
              QuestionStore.selectedItemsNw.SubCourseList.selectedName
            }
            disable={
              isEdit ? true : !CourseStore?.subcourse?.length ? true : false
            }
            menuStyle={{ border: "1px solid #E3E9EE" }}
          />
        </div>
        <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
          <InputLabel>Subject</InputLabel>
          <CustomDropdown
            height="48px"
            menu={subjectList}
            customClass="form-dropdown"
            placeholder="Select Subject"
            isSelect={true}
            handlefunc={getDataForModule}
            selectedEntity={
              QuestionStore.selectedItemsNw.SubjectList.selectedName
            }
            disable={
              isEdit
                ? true
                : !CourseStore?.selectedSubjectList?.length
                  ? true
                  : false
            }
            menuStyle={{ border: "1px solid #E3E9EE" }}
          />
        </div>
        <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
          <InputLabel>Topic</InputLabel>
          <CustomDropdown
            height="48px"
            menu={topicList}
            customClass="form-dropdown"
            placeholder="Select Topic"
            isSelect={true}
            handlefunc={getDataForModule}
            selectedEntity={
              QuestionStore.selectedItemsNw.TopicList.selectedName
            }
            disable={
              isEdit ? true : !CourseStore?.topicList?.length ? true : false
            }
            menuStyle={{ border: "1px solid #E3E9EE" }}
          />
        </div>
        <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
          <InputLabel>Sub topic</InputLabel>
          <CustomDropdown
            height="48px"
            menu={subTopicList}
            customClass="form-dropdown"
            placeholder="Select Sub topic"
            isSelect={true}
            handlefunc={getDataForModule}
            selectedEntity={
              QuestionStore.selectedItemsNw.SubTopicList.selectedName
            }
            disable={
              isEdit ? true : !CourseStore?.subTopicList?.length ? true : false
            }
            menuStyle={{ border: "1px solid #E3E9EE" }}
          />
        </div>
        <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
          <InputLabel>Question Type</InputLabel>
          <CustomDropdown
            height="48px"
            menu={questionType}
            customClass="form-dropdown"
            placeholder="Select SubCourse"
            isSelect={true}
            disable={isEdit || !QuestionStore.selectedItemsNw.SubTopicList.id}
            handlefunc={getDataForModule}
            selectedEntity={
              QuestionStore.selectedItemsNw.questionType.selectedName
            }
            menuStyle={{ border: "1px solid #E3E9EE" }}
          />
        </div>
        {!toggle && (
          <>
            {Role?.role === "Admin" && (
              <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
                <InputLabel>Added By</InputLabel>
                <CustomDropdown
                  height="48px"
                  menu={addedBY}
                  customClass="form-dropdown"
                  placeholder="Select Added BY"
                  isSelect={true}
                  handlefunc={getDataForModule}
                  selectedEntity={
                    QuestionStore.selectedItemsNw.addedBY.selectedName
                  }
                  menuStyle={{ border: "1px solid #E3E9EE" }}
                  disable={isEdit}
                />
              </div>
            )}
            <div className="col-xl-3 col-lg-4  col-md-6 col-sm-12">
              <InputLabel>Level</InputLabel>
              <CustomDropdown
                height="48px"
                menu={level}
                customClass="form-dropdown"
                placeholder="Select level"
                isSelect={true}
                handlefunc={getDataForModule}
                selectedEntity={
                  QuestionStore.selectedItemsNw.level.selectedName
                }
                menuStyle={{ border: "1px solid #E3E9EE" }}
                disable={isEdit}
              />
            </div>
          </>
        )}
        <div className="w-25 d-flex align-items-end">
          {!isEdit && (
            <Button
              title="Apply"
              width="114px"
              height="48px"
              disable={!QuestionStore.selectedItemsNw.questionType.selectedName}
              func={(e) => {
                checkDefault(e);
                setShow && setShow();
                applyFunc && applyFunc();
              }}
            />
          )}
        </div>
      </div>
    </form>
  );
});

export default QuestionBankCard;
