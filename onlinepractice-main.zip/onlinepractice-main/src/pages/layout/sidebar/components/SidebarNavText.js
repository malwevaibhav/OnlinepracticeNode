import React from "react";
import styled from "styled-components";
import {
  ArrowBlueIcon,
  ArrowWhiteIcon,
} from "../../../../assets/svgs/svg";
import { ThemeColors } from "../../../../theme/theme";
const SidebarText = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  font-weight: ${(props) => (props.fontSize === "heading" ? 600 : 400)};
  text-align: left;
  background-color: ${(props) =>
    props.fontSize === "heading"
      ? props?.isOpen && ThemeColors.primary
      : props?.active && "#ECF5FF"};
  color: ${(props) => props?.isOpen && ThemeColors.white};
  padding:  7px;
  border-radius: 5px;
  padding-left: 10%;
  cursor:pointer;
`;

const SidebarNavText = ({ handleClick, item, isTabWidth, index }) => {
  let arrow = !item?.opened ? "arrow-left" : "arrow-down";
  return (
    <SidebarText
      isTabWidth={isTabWidth}
      isOpen={item?.opened}
      fontSize={item?.tooltip}
      active={item?.active}
      onClick={() => handleClick(item, index)}
    >
      <div
        className={`d-flex align-items-center w-90 ${
          item?.tooltip === "heading" ? "sideHead" : "sideSubhead"
        }`}
      >
        {item?.icon && (
          <span className={`w-20 h-100 ${item?.isOpen && "filterSvg"}`}>
            {item?.opened ? item?.icon?.clickedicon : item?.icon?.blueicon}
          </span>
        )}

        <span style={{ paddingTop: "2px" }} className="mb-0 ms-2 w-80">
          {item?.text}
        </span>
      </div>
      {item?.submenus && (
        <span className={arrow}>
          {item?.opened ? <ArrowWhiteIcon /> : <ArrowBlueIcon />}
        </span>
      )}
    </SidebarText>
  );
};

export default SidebarNavText;
