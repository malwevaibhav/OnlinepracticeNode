import React from "react";
import styled from "styled-components";
import SidebarNavText from "./SidebarNavText";
const SubHeading = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: start;
  background: white;
  z-index: 10;
  margin-top: 14px;
  cursor:pointer;
`;
//tttrrt
const SidebarLink = ({ item, isTabWidth, MenuClickHandle, index }) => {
  return (
    <div style={{ position: "relative" }} className="w-100">
      <SidebarNavText
        handleClick={MenuClickHandle}
        item={item}
        isTabWidth={isTabWidth}
        index={index}
      />
      {item?.submenus && item?.opened && <SubHeading isTabWidth={isTabWidth}>

        {
          item?.submenus.map((subItem, key) => (
            <SidebarNavText
              key={key}
              handleClick={MenuClickHandle}
              isTabWidth={isTabWidth}
              index={index}
              item={subItem}
            />
          ))}
      </SubHeading>}
    </div>
  );
};

export default SidebarLink;
