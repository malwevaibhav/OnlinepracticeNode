import React, { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
// import logo from "../../../assets/Images/Logo.png";
import Commonservice from "../../../Services/commonService";
import { PNG } from "../../../assets";
import { PrivacyHeading } from "../../../customcomponents/DynamicText/Heading";
import SidebarLink from "./components/SidebarLink";
import "./sidebar.css";
import AuthStore from "../../../MobX/Auth";
const version = process.env.REACT_APP_VERSION

 /* eslint-disable */
export default function Sidebar({
  isTabWidth,
  setbreadcrumb,
  setMenu,
  setSidebarActive,
}) {

  const [sidebarMenu, setSidebarMenu] = useState(Commonservice.getLeftMenuOptions());
  const [toggle, setToggle] = useState(false);
  const Role = AuthStore?.user?.user;
  useEffect(() => {
    const authUser = JSON.parse(localStorage.getItem("key")).user
    let currenturl = window.location?.pathname;
    let currentitem = [];
    let dummy = sidebarMenu;
    let ind = dummy?.findIndex(x => x.text === 'Mock Test')
    if (ind > -1) {
      if (!authUser?.permision.includes('MockTest')) {
        dummy.splice(ind, 1);
      }
    }
    dummy.forEach((item, index) => {
      if (item.url === currenturl) return (currentitem = [item, index]);
      else {
        if (item.submenus) {
          let founditem = item?.submenus.find((sub) => sub.url === currenturl);
          if (founditem) {
            return (currentitem = [founditem, index]);
          }
        }
      }
    });

    const listener = (event) => {

      if (!sidebarRef.current || sidebarRef.current.contains(event.target)) {
        return;
      }
      let arr = [...sidebarMenu];
      // arr.forEach((m, i) => (m.opened = false));
      setSidebarMenu([...arr]);
      setSidebarActive(false);
    };
    if (currenturl === "/") {
      if (sidebarMenu[0]?.url) {
        MenuClickHandle(sidebarMenu[0], 0);
      }
      MenuClickHandle(sidebarMenu[0]?.submenus[0], 0);
    } else {
      if (currentitem.length > 0) {
        MenuClickHandle(sidebarMenu[currentitem[1]], currentitem[1]);

        MenuClickHandle(currentitem[0], currentitem[1]);
      }
    }

    document.addEventListener("mousedown", listener);
    document.addEventListener("touchstart", listener);
    setToggle(true);
    return () => {
      document.removeEventListener("mousedown", listener);
      document.removeEventListener("touchstart", listener);
    };
  }, [window.location?.pathname]);

  const sidebarRef = useRef();
  const navigate = useNavigate();


  // end of useEffect

  const MenuClickHandle = (item, parIndex) => {
    let arr = [...sidebarMenu];
    if (item?.tooltip === "heading") {
      let index = arr.indexOf(item);
      if (!arr[index]?.submenus?.length) {
        setSidebarActive(false);

        arr.forEach((i, ind) => {
          i?.submenus &&
            i?.submenus.forEach((subi, subind) => (subi.active = false));
        });
        arr[index].opened = true;
        arr[index].active = true;
        setbreadcrumb(item?.text);
        setMenu("");
        setSidebarMenu([...arr]);
        arr?.forEach((m, i) => {
          if (i !== index) {
            m.opened = false;
            m.active = false;
          }
        });
        item.url && navigate(item?.url);
      } else {
        arr[index].active = true;
        arr[index].opened = !arr[index].opened;
        arr.forEach((m, i) => {
          if (i !== index) {
            m.opened = false;
            m.active = false;
          }
        });

        setSidebarMenu([...arr]);
      }
    } else {
      if (arr[parIndex].opened) {
        let submenuIndex = arr[parIndex]?.submenus?.indexOf(item);
        let url = item?.url;

        arr[parIndex].submenus[submenuIndex].active = true;
        arr[parIndex]?.submenus?.forEach((m, i) => {
          if (i !== submenuIndex) {
            m.active = false;
          }
        });
        navigate(url);
        setbreadcrumb(arr[parIndex]?.text);
        setSidebarActive(false);
        setSidebarMenu([...arr]);
        setMenu(item?.text);
      } else {
        arr[parIndex].opened = !arr[parIndex].opened;
      }
    }
  };

  if (!toggle) {
    return <></>;
  }
  return (
    <div style={{ height: "100%" }}>
      <main
        style={{
          height: "100%",
          width: "250px",
        }}
      >
        <div className="flex-shrink-0 h-100 px-0 bg-white side-nav">
          <a href="/" className="d-flex  flex-column align-items-center mb-3"
          >
           <img src={PNG.Logo} alt="" className="mt-3" />
          </a>
          <div style={{ height: "93%" }} className="d-flex flex-column justify-content-between ">
            <ul ref={sidebarRef} className=" ps-0 ">
              {sidebarMenu.map((item, key) => (
                <div
                  style={{ marginBottom: "0.55rem" }}
                  className=" w-100 d-flex flex-column justify-content-start align-items-start"
                  key={key}
                >
                  <SidebarLink
                    isTabWidth={isTabWidth}
                    MenuClickHandle={MenuClickHandle}
                    index={key}
                    item={item}
                  />
                </div>
              ))}
            </ul>
            <div className="d-flex  flex-column fixed-bottom ms-3 mb-3" style={{ width: "fit-content" }} >
               <PrivacyHeading text={`Version ${version}`} />
            </div>
     
          </div>
        </div>

      </main>

    </div>
  );
}
