import React from "react";

import { toJS } from "mobx";
import { Navigate, Outlet, Route, Routes } from "react-router-dom";
import { PNG } from "../../assets/index";
import ImageSlider from "../../customcomponents/slider";
import AuthStore from "../../MobX/Auth";
import Login from "../../pages/auth/login/index";
import ForgotPassword from "../../pages/auth/password/index";
import SuccessEmail from "../../pages/auth/success-email";
import "./layout.css";
export function Layout() {
  const auth = toJS(AuthStore?.user?.token);
  return (
    <div className="w-100 main-height">
      <div className="outerdiv">
        <div className="left-flex">
          <div className="LogoImg-containershow">
            {/* <img src={PNG.WhiteLogo} alt="" className="LogoImg-show" /> */}
          </div>
          <div className="Checkstatus-field  f-center-col  w-100  ">
            <div className="logo_Head">Check the status</div>

            <div className="logo_Para">
              <ImageSlider />
            </div>
            <div className="footer">
              {/* <div>Privacy Policy</div>

              <div>Contact Us</div>

              <div>@2022 Online Practice</div> */}
            </div>
          </div>
        </div>

        <div className="right-flex">
          <div className="LogoImg-container">
            <img src={PNG.Logo} alt="" className="Logo-img" />
          </div>
          <div className="signin-field">
            {" "}
            {!auth ? <Outlet /> : <Navigate to={"/dashboard"} replace />}
          </div>
          <div className="footer-field">
            <div className="footer-show">
              {/* <div>Privacy Policy</div>

              <div>Contact Us</div>1

              <div>@2022 Online Practice</div> */}
            </div>
            <div className="layout-footer">
              {/* Having troubles? <span>Get Help</span> */}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
const BaseLayout = () => {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Navigate to={"login"} />} />
        <Route path="login" element={<Login />} />
        <Route path="forgot-password" element={<ForgotPassword />} />
        <Route path="success-Email" element={<SuccessEmail />} />
        <Route />
      </Route>
    </Routes>
  );
};
export default BaseLayout;
