import React from 'react'

const NewPage = () => {
  return (
    <div>
      
    </div>
  )
}

export default NewPage
