import { CKEditor } from '@ckeditor/ckeditor5-react';
import Editor from 'ckeditor5-custom-build/build/ckeditor';
import React, { useLayoutEffect } from 'react';

export default function EditorCK({ value, setValue, setQuestion, setOptionsA, setOptionsB, setOptionsC, setOptionsD, setExplanation }) {
  useLayoutEffect(() => {
    const script = document.createElement("script");
    script.src = "http://cdn.mathjax.org/mathjax/latest/MathJax.js?config=TeX-AMS-MML_HTMLorMML";
    script.async = true;
    document.body.appendChild(script);
  }, [])
  function uploadAdapter(loader) {
    return {
      upload: () => {
        return new Promise((resolve) => {
          loader.file.then((file) => {
             let resize_width = 1000;
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = (event) => {

              let img = new Image();//create a image
              img.src = event.target.result;//result is base64-encoded Data URI
              img.name = event.target.name;//set name (optional)
              img.size = event.target.size;//set size (optional)
              img.onload = function (el) {
                let elem = document.createElement('canvas');//create a canvas

                //scale the image to 600 (width) and keep aspect ratio
                let scaleFactor =  el.target.width;

                elem.width =  el.target.width;
                elem.height =  el.target.height;


                //draw in canvas
                 let ctx = elem.getContext('2d');
                 ctx.drawImage(el.target, 0, 0);

                //get the base64-encoded Data URI from the resize image
                let srcEncoded = ctx.canvas.toDataURL('image/png', 1);
                resolve({ default: srcEncoded })
                //assign it to thumb src

                /*Now you can send "srcEncoded" to the server and
                convert it to a png o jpg. Also can send
                "el.target.name" that is the file's name.*/
              }
            }
          });
        });
      },
    };
  }

  function uploadPlugin(editor) {
    editor.plugins.get("FileRepository").createUploadAdapter = (loader) => {
      return uploadAdapter(loader);
    };
  }

  const handleData = (editor) => {
    setQuestion && setQuestion(editor.getData())
    if (setOptionsA) {
      setOptionsA(editor.getData())
    }
    if (setOptionsB) {
      setOptionsB(editor.getData())
    }
    if (setOptionsC) {
      setOptionsC(editor.getData())
    }
    if (setOptionsD) {
      setOptionsD(editor.getData())
    }
    if (setExplanation) {
      setExplanation(editor.getData())
    }
    if (setValue) {
      setValue(editor.getData())
    }

  };

  return (
    <div >
      <CKEditor
        editor={Editor}
        config={{
          extraPlugins: [uploadPlugin],
        }}
        data={value}
        onReady={(editor) => {
        }}
        onChange={(event, editor) => {
          handleData(editor);
        }}
        onBlur={(event, editor) => {
        }}
        onFocus={(event, editor) => {

        }}
      />

    </div>
  )
}
