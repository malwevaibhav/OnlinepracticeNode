import { ThemeColors } from "../theme/theme"

const CheckStatus = (Status) => {
    const myStyle = {
        padding: '4px 10px',
        gap: '20px',
        textAlign: "center",
        height: '30px',
        borderRadius: '3px',
        margin: "0",
        border: 0,
        width: "96px",
        fontSize: " 14px",
        fontFamily: "Medium",
        color: ((Status === "Pending" && "#EAB600") || (Status === "Cancel" && "#D00000") || (Status === "Added" && "#009B06")|| (Status === "Completed" && ThemeColors.txtEasy)),
        backgroundColor: ((Status === "Pending" && ThemeColors.bgMedium) || (Status === "Cancel" && "#FFD2D2") || (Status === "Added" && "#AFFFB3") || (Status === "Completed" && ThemeColors.bgEasy))

    }
    return (<p style={myStyle} Status={Status} className="me-2" >{Status}</p>)
}

export default CheckStatus