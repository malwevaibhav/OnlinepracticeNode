 export const downloadpdf = (url, fileName) => {
    const fileURL = url;
    let alink = document.createElement('a');
    alink.href = fileURL;
    alink.target = "_blank"
    alink.download = fileName;
    alink.click();
}