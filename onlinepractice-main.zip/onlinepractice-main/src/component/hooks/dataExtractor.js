const DataExtractor = (...arg) => {
    var getData = arg[0].map(function (value, index, arr) {
        arg[1].map((deleval) => delete value[deleval])
        return value
    });
    return getData;
}

export default DataExtractor
