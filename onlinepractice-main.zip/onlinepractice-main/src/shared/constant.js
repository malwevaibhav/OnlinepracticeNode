export const ClientRoutesConstants = {
  notFound: "/notFound",
  unauthorized: "/unauthorized",
  dashboard: "/dashboard",
  login: "/auth/login",
  logout: "/logout",
  forgetPassword: "/auth/forgot-password",
  register: "/register",
  mocktest: "/mocktest",
  stafflist: "/staff-list",
  staffDetails: "/staff-details",
  ebook: "/ebook",
  purchaseEbook: "/purchase-Ebook",
  addnewbook: "/add-newbook",
  successEmail: "/success-Email",
  users: "/staff-list",
  videoPurchase: "/Video-purchase",
  studentDetails: "/student-details",
  studentlist: "/student-list",
  courses: "/courses",
  addNewvideo: "/add-NewVideo",
  courseTopic: "/course-topic",
  courseType: "/course-type",
  createCourse: "/create-course",
  courseModule: "/createCourse",
  questionBank: "/question-bank",
  questionUpload: "/question-upload",
  createMockTest: "/create-Mocktest",
  institute: "/institute",
  instituteDetail: "/institute-detail",
  questionDetail: "/question-detail",
  settings: "/settings",
  subject: "/subject",
  pattern: "/pattern",
  addPattern: "/add-pattern",
  patternDetails: "/pattern-details",
  addNewSubject: "/new-subject",
  generalInstruction: "/general-instruction",
  videos: "/video",
  viewMockAutomatic: "/viewAutomatic",
  previousYearPaper: "/previous-year-paper",
  addUpdatePYP: "/new-paper",
  PYPDetail: "/paper-detail",
  result:"/result",
  transaction:"/transaction",
  resultAnalysis:"/resultAnalysis"
};
export const ApiRoutes = {
  //#region Account
  login: "api/Account/login",
  forgotPasswod: "api/Account/forgetpassword",
  resendPassword: "api/Account/resendpassword",
  getAdminProfile: "api/Account/getadminprofile",
  adminUploadImage: "api/Account/uploadimage",
  removeprofileimage: "api/Account/removeprofileimage",
  updateAdmin: "api/Account/updateadmin",
  changePassword: "api/Account/changepassword",
  //#endregion

  //#region Staff
  createStaff: "api/Staff/createstaff",
  getAllStaff: "api/Staff/getallstaff",
  getStaffById: "api/Staff/getstaffbyid",
  editStaff: "api/Staff/editstaff",
  deleteStaff: "api/Staff/deletestaff",
  getAllAddedBy: 'api/Staff/getallstaffandadmin',
  getAllModules: "api/Staff/getmodulelist",
  //#endregion

  //#region ExamType
  getExamListWithCourses: "api/ExamType/getexamlistwithcourses",
  getAllExam: "api/ExamType/getall",
  deleteExam: 'api/ExamType/delete',
  updateExam: 'api/ExamType/edit',
  createCourse: "api/ExamType/createexamflow",
  //#endregion

  //#region subCourses
  getSubCoursesByCourseId: "api/SubCourse/getsubcoursesbycourseid",
  subCourseCreate: 'api/SubCourse/create',
  updateCourse: 'api/SubCourse/editmultiple',
  deleteSubCourse: 'api/SubCourse/delete',
  //#endregion

  //#region course
  getCoursebyExamId: "api/Course/getcoursesbyexamid",
  getAllCourse: "api/Course/getallcourses",
  courseCreate: 'api/Course/create',
  deleteCourse: 'api/Course/delete',
  //#endregion

  //#region Question bank
  getQuestionbyQuestionId: "",
  getQuestionBankList: "",
  getallquestiontype: "api/QuestionBank/getallquestiontype",
  getAllQuestionBank: "api/QuestionBank/getall",
  createQuestion: 'api/QuestionBank/create',
  updateQuestion: 'api/QuestionBank/edit',
  getQuestionById: 'api/QuestionBank/getbyid',
  deleteQuestion: "api/QuestionBank/delete",
  getAllLanguage: 'api/QuestionBank/getallquestionlanguage',
  getAllLevel: 'api/QuestionBank/getallquestionlevel',
  //#endregion

  //#region Institue
  getAllInstitute: "api/Institute/getall",
  getInstituteById: "api/Institute/getbyid",
  createInst: "api/Institute/create",
  updateInst: "api/Institute/edit",
  deleteInst: "api/Institute/delete",
  InstitueImgUpload: "api/Institute/uploadimage",
  //#endregion

  //#region topic
  getalltopicbysubjectID: "api/Topic/getalltopicbysubjectcategoryid",
  createTopic: "api/Topic/create",
  updateTopic: "api/Topic/edit",
  deleteTopic: 'api/Topic/delete',
  //#endregion

  //#region subtopic
  createsubTopic: "api/SubTopic/create",
  updatesubTopic: "api/SubTopic/edit",
  createsubject: "api/Subject/create",
  deleteSubTopic: 'api/SubTopic/delete',
  getsubtopicbyId: "api/SubTopic/getallsubtopicbyTopicid",
  //#endregion

  //#region subject
  createsubjectcategory: 'api/Subject/createsubjectcategory',
  getSubjectssubCoursesId: "api/Subject/getallsubjectscategorybysubcoursesid",
  getallsubjectBymasterId: "api/Subject/getallsubjectsmasterbysubcoursesid",
  updatesubjectcategory: 'api/Subject/updateubjectcategory',
  getSubject: "api/Subject/getallsubjects",
  createSubject: "api/Subject/create",
  editSubject: "api/Subject/edit",
  //#endregion

  //#region  ExamPattern
  getAllPattern: 'api/ExamPattern/getall',
  createExamPattern: 'api/ExamPattern/create',
  editInstruction: 'api/ExamPattern/editgeneralinstructions',
  examPatternById: 'api/ExamPattern/getbyid',
  updatePattern: 'api/ExamPattern/edit',
  deletePattern: 'api/ExamPattern/delete',
  getSectionbyPatternId: 'api/ExamPattern/getsectionlistbypatternidandsubjectid',
  getSubjectbyPatternId: 'api/ExamPattern/getsubjectlistbyexampatternid',
  getMockQuestionById: 'api/MockTest/getall',
  getTopicListbySubjectpattern: 'api/Topic/gettopiclistbysubjectidandsubcourseid',
  //#endregion

  //#region MockTest
  getAllMockTest: "api/MockTest/getAll",
  getQuesByFilter: "api/MockTest/getquestionsbyfilter",
  getQueForPdf: "api/MockTest/mocktestquestionspdf",
  createmocktestquestions: "api/MockTest/createmocktestquestions",
  generateautomatictmocktest: "api/MockTest/generateautomatictmocktest",
  updatemocktestquestions: "api/MockTest/updatemocktestquestions",
  mockTestById: "api/MockTest/getbyid",
  mockTestQuestionById: "api/MockTest/mocktestquestiongetbyid",
  createMockTest: "api/MockTest/create",
  updateMockTest: "api/MockTest/edit",
  publishMockTest: "api/MockTest/publishmocktest",
  deleteMockTest: "api/MockTest/delete",
  //#endregion

  //#region 
  getAllPapers: "api/PreviousYearPaper/getAllpapers",
  getPaperById: "api/PreviousYearPaper/getbyid",
  getYearList: "api/PreviousYearPaper/getyearlist",
  createPaper: "api/PreviousYearPaper/create",
  updatePaper: "api/PreviousYearPaper/edit",
  deletePaper: "api/PreviousYearPaper/delete",
  uploadPaperPdf: "api/PreviousYearPaper/uploadPaperPdf",

  //#endregion
  //#region 
  createEbook: "api/Ebook/create",
  uploadebookthumbnail: "api/Ebook/uploadebookthumbnail",
  uploadebookpdf: "api/Ebook/uploadebookpdf",
  editEbook: "api/Ebook/edit",
  getAllEbook: "api/Ebook/getall",
  getallauthers: "api/Ebook/getallauthors",
  deleteEbook: "api/Ebook/delete",
  getbyEbookid: "api/Ebook/getbyid",

  //#endregion

  //#region 
  getAllVideos: "api/Video/getall",
  getallauthors: "api/Video/getallauthors",
  getvideoById: "api/Video/getbyid",
  deleteVideo: "api/Video/delete",
  uploadVideourl: "api/Video/uploadvideourl",
  uploadThumbnail: "api/Video/uploadevideothumbnail",
  createVideo: "api/Video/create",
  updateVideo: "api/Video/edit",
  //#endregion


  //#region Result Performance 
  getallResults:"api/AdminResult/getallresults",
 getResultByMocktestId:"api/AdminResult/getresultbymocktestid",
 addStudent:"api/AdminStudentRegistration/addstudent",
 bulkUpload:"api/AdminStudentRegistration/bulkupload",
 getAllStudentlist:"/api/AdminStudentRegistration/getall",
 getSampleExcel:"api/AdminStudentRegistration/getsampleexcelurl",
 getStudentById:"api/AdminStudentRegistration/getbyid",
 updateStudent:"api/AdminStudentRegistration/updatestudent",
 deleteStudent:"api/AdminStudentRegistration/delete",
 getallmocktest:"api/AdminResult/getallmocktest",
 getAllTransaction:"api/AdminWallet/getalltransactions",
 getTransactionDetail:"api/AdminWallet/gettransactiondetails",


 //dashboard
 getTotalSales:"api/AdminDashboard/gettotalsales",
 getTotalEnrollment:"api/AdminDashboard/gettotalenrollment",
 getInstituteStudent:"api/AdminDashboard/getinstitutestudent",

getTransactionTimeline: "api/AdminDashboard/getrecenttransactionandtimeline",
getSalesGraph:"/api/AdminDashboard/gettotalsalesgraph",
getEnrollmentGraph:"api/AdminDashboard/getstudentenrollmentgraph"

 

  //#endregion
};

export const allowedRoles = { admin: "Admin", staff: "Staff" };
