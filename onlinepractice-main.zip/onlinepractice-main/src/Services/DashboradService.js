
import { ApiRoutes } from "../shared/constant";
import MainService from "../utils/ServiceInterceptors";

class DashboardService {

    getSales = async (data) => {
        try {
          const resp = await MainService.post(`${ApiRoutes?.getTotalSales}`,{
            "durationFilter": data
          });
          return resp?.data?.data;
        } catch (error) {
          console.log("Error on  --> ", error);
          throw new Error(error);
        }
      };

      getTransactionTimeline= async () => {
        try {
          const resp = await MainService.get(`${ApiRoutes?.getTransactionTimeline}`);
          return resp?.data?.data;
        } catch (error) {
          console.log("Error on  --> ", error);
          throw new Error(error);
        }
      };
      getTotalEnrollment = async (data) => {
        try {
          const resp = await MainService.post(`${ApiRoutes?.getTotalEnrollment}`,{
            "durationFilter": data
          });
          return resp?.data?.data;
        } catch (error) {
          console.log("Error on  --> ", error);
          throw new Error(error);
        }
      };
      getInstituteStudent = async (data) => {
        try {
          const resp = await MainService.post(`${ApiRoutes?.getInstituteStudent}`,{
            "durationFilter": data
          });
          return resp?.data?.data;
        } catch (error) {
          console.log("Error on  --> ", error);
          throw new Error(error);
        }
      };

    //   graph

    getSalesGraph = async (data) => {
        try {
          const resp = await MainService.post(`${ApiRoutes?.getSalesGraph}`,{
            "durationFilter": data
          });
          return resp?.data?.data;
        } catch (error) {
          console.log("Error on  --> ", error);
          throw new Error(error);
        }
      };

      getEnrollmentGraph = async (data) => {
        try {
          const resp = await MainService.post(`${ApiRoutes?.getEnrollmentGraph}`,{
            "durationFilter": data
          });
          return resp?.data?.data;
        } catch (error) {
          console.log("Error on  --> ", error);
          throw new Error(error);
        }
      };

}


const DashboardServices = new DashboardService()
export default DashboardServices;