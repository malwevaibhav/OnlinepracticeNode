import { toast } from "react-toastify";
import AuthStore from "../MobX/Auth";
import { ApiRoutes } from "../shared/constant";
import MainService from "../utils/ServiceInterceptors";


class InstituteService {
  getAllInstitute = async (payload) => {
    if (!payload) {
      payload = { pageNumber: 0, pageSize: 0 }
    }
    try {
      AuthStore.setLoading(true);
      const resp = await MainService.post(`${ApiRoutes?.getAllInstitute}`, payload);
      AuthStore.setLoading(false);
      return resp?.data?.data;
    } catch (error) {
      console.log("Error on getAllInstitute --> ", error);
      AuthStore.setLoading(false);
      toast.error(error?.response?.data?.data[0]?.message)
      throw new Error(error);
    }
  };

  getInstituteById = async (payload) => {
    try {
      AuthStore.setLoading(true);
      const resp = await MainService.post(
        `${ApiRoutes?.getInstituteById}`,
        payload
      );
      AuthStore.setLoading(false);
      return resp?.data?.data;
    } catch (error) {
      console.log("Error on getAllInstitute --> ", error);
      AuthStore.setLoading(false);
      toast.error(error?.response?.data?.data[0]?.message)
      throw new Error(error);
    }
  };

  createInstitute = async (payload) => {
    try {
      AuthStore.setLoading(true);
      const resp = await MainService.post(`${ApiRoutes?.createInst}`, payload);
      AuthStore.setLoading(false);
      return resp?.data;
    } catch (error) {
      console.log("Error on createInstitute --> ", error);
      AuthStore.setLoading(false);
      toast.error(error?.response?.data?.data[0]?.message)
     // throw new Error(error);
    }
  };

  updateInstitute = async (payload) => {
    try {
      AuthStore.setLoading(true);
      const resp = await MainService.put(`${ApiRoutes?.updateInst}`, payload);
      AuthStore.setLoading(false);
      return resp?.data;
    } catch (error) {
      console.log("Error on updateInstitute --> ", error);
      AuthStore.setLoading(false);
      toast.error(error?.response?.data?.data[0]?.message)
      throw new Error(error);
    }
  };
  deleteInstitute = async (payload) => {
    let config;
         
          config = {
            headers: {
              "Content-Type": "application/json",
            },
            
          };
    try {
      AuthStore.setLoading(true);
      const resp = await MainService.delete(
        `${ApiRoutes?.deleteInst}`,
        { ...config, data: payload }
      );
      AuthStore.setLoading(false);
      return resp?.data;
    } catch (error) {
      console.log("Error on updateInstitute --> ", error);
      AuthStore.setLoading(false);
      toast.error(error?.response?.data?.data[0]?.message)
      throw new Error(error);
    }
  };

  UploadImage = async (payLoad) => {
    let config;
         
          config = {
            headers: {
              "Content-Type": "multipart/form-data",
            },
            
          };
    try {
      AuthStore.setLoading(true);
      const resp = await MainService.post(
        `${ApiRoutes?.InstitueImgUpload}`,payLoad,
        {headers: config.headers}
      );
      AuthStore.setLoading(false);
      return resp.data;
    } catch (error) {
      console.log("Error on permission module List staff --> ", error);
      AuthStore.setLoading(false);
      toast.error(error?.response?.data?.data[0]?.message)
      throw new Error(error);
    }
  };
}
const InstituteServices = new InstituteService();
export default InstituteServices;
