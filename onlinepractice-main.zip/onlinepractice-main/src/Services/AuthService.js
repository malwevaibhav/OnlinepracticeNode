import jwt_decode from "jwt-decode";
import { toast } from "react-toastify";
import AuthStore from "../MobX/Auth";
import CourseStore from "../MobX/Courses";
import EbookStore from "../MobX/Ebook";
import MockTestStore from "../MobX/MockTestStore";
import PatternStore from "../MobX/Pattern";
import PYPStores from "../MobX/PYPStore";
import QuestionStore from "../MobX/Question";
import VideoStore from "../MobX/videostore";
import { ApiRoutes } from "../shared/constant";

import MainService from "../utils/ServiceInterceptors";
const permisions = ["MockTest", "Videos", "Ebook", "Previous Year Paper", "Live Classes", "Staff", "Student", "Result", "Result Analysis"]

class Auth {
  login = async (data) => {
    AuthStore.setLoading(true);

    const loginres = await MainService.post(`${ApiRoutes?.login}`, {
      email: data?.email,
      password: data?.password,
    });
    if (loginres.data.isSuccess && loginres.data.responseCode === 200) {
      if (data?.rememberme) {
        sessionStorage.setItem("Credential", JSON.stringify(data));
      }
      let decoded = jwt_decode(loginres?.data?.data?.token);
      //
      // let userToken = JSON.stringify({
      //   token: loginres?.data?.data?.token,
      //   user: { ...decoded },
      // });

      let userToken = {
        token: loginres?.data?.data?.token,
        user: { ...decoded },
      }
      if (userToken.user.role === "Admin") {
        userToken.user.permision = permisions
        //
      }
      localStorage.setItem("key", JSON.stringify(userToken));
      // localStorage.setItem("key", userToken);
      AuthStore.setUser({
        token: loginres?.data?.data?.token,
        user: userToken.user,
        // user: { ...decoded },
      });

      AuthStore.setLoading(false);
      return loginres?.data;
    } else {
      AuthStore.setLoading(false);
      return loginres?.data;
    }
  };

  forgot = async (data) => {
    try {
      AuthStore.setLoading(true);
      const forgotresp = await MainService.post(
        `${ApiRoutes?.forgotPasswod}`,
        {
          email: data?.email,
        }
      );
      AuthStore.setLoading(false);
      return forgotresp?.data;
    } catch (e) {
      AuthStore.setLoading(false);
      toast.error(e?.response?.data?.data[0]?.message)
      throw e;
    }
  };

  resendPassword = async (email) => {
    try {
      AuthStore?.setLoading(true);
      const resendresp = await MainService.post(`${ApiRoutes.resendPassword}`, email)
      AuthStore?.setLoading(false);
      return resendresp?.data;
    } catch (e) {
      AuthStore?.setLoading(false);
      toast.error(e?.response?.data?.data[0]?.message)
      throw e;
    }
  }

  checkLogin = async () => {
    try {
      const loginData = localStorage.getItem("key");
      if (loginData !== undefined) {
        let userDetalils = await jwt_decode(loginData);
        AuthStore.setUser({ token: loginData, user: { ...userDetalils } });
        return loginData;
      } else {
        return null;
      }
    } catch (e) {
      console.log("Error on check login --> ", e);
      toast.error(e?.response?.data?.data[0]?.message)
    }
  };

  removeLogin = async () => {
    localStorage.removeItem("key");
    // localStorage.clear();
    AuthStore.clear();
    CourseStore.clear();
    EbookStore.clear();
    MockTestStore.clear();
    PatternStore.clear();
    PYPStores.clear();
    QuestionStore.clear();
    VideoStore.clear();
  };

  updateAdmin = async (payload) => {
    try {
      const res = await MainService.put(
        `${ApiRoutes?.updateAdmin}`,
        payload
      );
      return res?.data;
    } catch (error) {
      console.log("update admin --> ", error);
      toast.error(error?.response?.data?.data[0]?.message)
      throw new Error(error);
    }
  };

  changePassword = async (payload) => {
    try {
      const res = await MainService.post(
        `${ApiRoutes?.changePassword}`,
        payload
      );
      return res?.data;
    } catch (error) {
      console.log("update admin --> ", error);
      toast.error(error?.response?.data?.data[0]?.message)
      throw new Error(error);
    }
  };

  getAdminProfile = async (payload) => {
    try {
      const res = await MainService.post(
        `${ApiRoutes?.getAdminProfile}`,
        payload
      );
      return res?.data;
    } catch (error) {
      console.log("update admin --> ", error);
      toast.error(error?.response?.data?.data[0]?.message)
      throw new Error(error);
    }
  };
  removeAdminProfile = async (payload) => {
    try {
      const res = await MainService.put(
        `${ApiRoutes?.removeprofileimage}`,
        payload
      );
      return res?.data;
    } catch (error) {
      console.log("update admin --> ", error);
      toast.error(error?.response?.data?.data[0]?.message)
      throw new Error(error);
    }
  };
  
  uploadImage = async (payload) => {
    let config;

    config = {
      headers: {
        "Content-Type": "multipart/form-data",
      },

    };
    try {
      AuthStore.setLoading(true);
      const resp = await MainService.post(
        `${ApiRoutes?.adminUploadImage}`, payload,
        { headers: config.headers }
      );
      AuthStore.setLoading(false);
      return resp.data;
    } catch (error) {
      console.log("Error on permission module List staff --> ", error);
      // toast.error(error?.response?.data?.data[0]?.message)
      AuthStore.setLoading(false);
      throw new Error(error);
    }
  };
}
const AuthServices = new Auth();
export default AuthServices;
