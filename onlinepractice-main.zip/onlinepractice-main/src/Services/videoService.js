import { toast } from "react-toastify";
import AuthStore from "../MobX/Auth";
import VideoStore from "../MobX/videostore";
import { ApiRoutes } from "../shared/constant";

import MainService from "../utils/ServiceInterceptors";

class VideoService {

    getAllVideos = async (payload) => {
        if (!payload) {
            payload = { pageNumber: 0, pageSize: 0 }
        }
        try {
            AuthStore.setLoading(true);
            const resp = await MainService.post(`${ApiRoutes?.getAllVideos}`, payload);
            AuthStore.setLoading(false);
            return resp?.data;
        } catch (error) {
            console.log("Error on getAllVideos --> ", error);
            AuthStore.setLoading(false);
            toast.error(error?.response?.data?.data[0]?.message)
            throw new Error(error);
        }
    };

    createVideo = async (payload) => {
        try {
            AuthStore.setLoading(true);
            const resp = await MainService.post(`${ApiRoutes?.createVideo}`, payload);
            AuthStore.setLoading(false);
            return resp?.data;
        } catch (error) {
            console.log("Error on createPaper --> ", error);
            AuthStore.setLoading(false);
            toast.error(error?.response?.data?.data[0]?.message)
            throw new Error(error);
        }
    };
    updateVideo = async (payload) => {
        try {
            AuthStore.setLoading(true);
            const resp = await MainService.put(`${ApiRoutes?.updateVideo}`, payload);
            AuthStore.setLoading(false);
            return resp?.data;
        } catch (error) {
            console.log("Error on createPaper --> ", error);
            AuthStore.setLoading(false);
            toast.error(error?.response?.data?.data[0]?.message)
            throw new Error(error);
        }
    };

    getallauthors = async (payload) => {
        try {
            AuthStore.setLoading(true);
            const resp = await MainService.post(`${ApiRoutes?.getallauthors}`, payload);
            AuthStore.setLoading(false);
            return resp?.data?.data;
        } catch (error) {
            console.log("Error on createPaper --> ", error);
            AuthStore.setLoading(false);
            toast.error(error?.response?.data?.data[0]?.message)
            throw new Error(error);
        }
    };

    getAllvideo = async (body) => {
        try {
            const resp = await MainService.post(`${ApiRoutes?.getAllvideo}`, body);
            if (resp?.data?.isSuccess) {
                return resp.data;
            } else {
                return resp.data;
            }
        } catch (error) {
            console.log("err");
            return Promise.reject(error);
        }
    };

    getvideoById = async (payload) => {
        try {
            AuthStore.setLoading(true);
            const resp = await MainService.post(`${ApiRoutes?.getvideoById}`, payload);
            AuthStore.setLoading(false);
            return resp?.data;
        } catch (error) {
            console.log("Error on getVideoById --> ", error);
            AuthStore.setLoading(false);
            toast.error(error?.response?.data?.data[0]?.message)
            throw new Error(error);
        }
    };

    uploadVideo = async (payLoad) => {
        let config;
        config = {
            headers: {
                "Content-Type": "multipart/form-data",
                accept: "application/json",
            },
        };
        try {
            AuthStore.setLoading(true);
            const resp = await MainService.post(`${ApiRoutes?.uploadVideourl}`, payLoad, { headers: config.headers });
            AuthStore.setLoading(false);
            return resp.data;
        } catch (error) {
            console.log("Error on uploadFile --> ", error);
            AuthStore.setLoading(false);
            toast.error(error?.response?.data?.data[0]?.message)
            throw new Error(error);
        }
    };
    
    thumbUpload = async (payLoad) => {
    
        let config;
        config = {
            headers: {
                "Content-Type": "multipart/form-data",
                accept: "application/json",
            },
        };
        try {
            AuthStore.setLoading(true);
            const resp = await MainService.post(`${ApiRoutes?.uploadThumbnail}`, payLoad, { headers: config.headers });
            AuthStore.setLoading(false);
            return resp.data;
        } catch (error) {
            console.log("Error on uploadFile --> ", error);
            AuthStore.setLoading(false);
            toast.error(error?.response?.data?.data[0]?.message)
            throw new Error(error);
        }
    };

    deleteVideo = async (payload) => {
        let config;
        config = {
            headers: {
                "Content-Type": "application/json",
            },

        };
        try {
            AuthStore.setLoading(true);
            const resp = await MainService.delete(`${ApiRoutes?.deleteVideo}`, { ...config, data: payload });
            AuthStore.setLoading(false);
            return resp?.data;
        } catch (error) {
            console.log("Error on deletePaper --> ", error);
            AuthStore.setLoading(false);
            toast.error(error?.response?.data?.data[0]?.message)
            throw new Error(error);
        }
    };

    getFilterData = async (props) => {
        const { id, label } = props;
        if (label === 'Exam') {
            try {
                AuthStore.setLoading(true);
                const resp = await MainService.get(`${ApiRoutes?.getAllExam}`);
                let examlist = resp?.data?.data?.examType?.map((elm, i) => {
                    return {
                        id: elm?.id,
                        Title: elm?.examName,
                        label: "Course",
                    };
                });
                AuthStore.setLoading(false);
                return examlist;
                // return resp?.data?.data;
            } catch (error) {
                AuthStore.setLoading(false);
                console.log("Error on get ExamList WithCourses ExamType --> ", error);
                toast.error(error?.response?.data?.data[0]?.message);
                throw new Error(error);
            }
        }
        if (label === "Course") {
            if (id) {
                try {
                    AuthStore.setLoading(true);
                    const resp = await MainService.post(
                        `${ApiRoutes?.getCoursebyExamId}`,
                        {
                            examId: id,
                        }
                    );
                    let courseList = resp?.data?.data?.courses?.map((elm, i) => {
                        return {
                            id: elm?.id,
                            Title: elm?.courseName,
                            label: "SubCourse",
                        };
                    });
                    AuthStore.setLoading(false);
                    return courseList;
                    // return resp?.data?.data;
                } catch (error) {
                    AuthStore.setLoading(false);
                    console.log("Error on get course --> ", error);
                    toast.error(error?.response?.data?.data[0]?.message);
                    throw new Error(error);
                }
            }
        }
        if (label === "SubCourse") {
            if (id) {
                try {
                    AuthStore.setLoading(true);
                    const res = await MainService.post(
                        `${ApiRoutes?.getSubCoursesByCourseId}`,
                        { id: id }
                    );
                    if (res?.data?.isSuccess) {
                        // this.getSubCourseMenu(res?.data?.data);
                        AuthStore.setLoading(false);
                        let subCourse = res?.data?.data?.subCourses?.map((elm) => {
                            return {
                                id: elm?.id,
                                Title: elm?.subCourseName,
                                label: "Subject",
                            };
                        });
                        return subCourse;
                        // return res?.data;
                    }
                } catch (error) {
                    AuthStore.setLoading(false);
                    console.log("Get sub course by id error --> ", error);
                    toast.error(error?.response?.data?.data[0]?.message);
                    // throw new Error(error);
                }
            }
        }
        if (label === "Subject") {
            if (id) {
                try {
                    AuthStore.setLoading(true);
                    const res = await MainService.post(
                        `${ApiRoutes?.getSubjectssubCoursesId}`,
                        { subCourseId: id }
                    );
                    if (res?.data?.isSuccess) {
                        this.getsubjectMenu(res?.data?.data);
                        AuthStore.setLoading(false);
                        return res?.data;
                    } else {
                        AuthStore.setLoading(false);
                        toast.error(res?.data?.messages);
                    }
                } catch (error) {
                    AuthStore.setLoading(false);
                    console.log("Get sub course by id error --> ", error);
                    throw new Error(error);
                }
            }
        }
        if (label === "Topic") {
            if (id) {
                try {
                    AuthStore.setLoading(true);
                    const resp = await MainService.post(
                        `${ApiRoutes?.getalltopicbysubjectID}`,
                        {
                            id: id,
                        }
                    );
                    if (resp?.data?.isSuccess) {
                        AuthStore.setLoading(false);
                        this.getTopicList(resp?.data?.data?.topic);
                        return resp?.data?.data?.topic;
                    } else {
                        AuthStore.setLoading(false);
                        toast.error(resp?.data?.messages);
                    }
                } catch (e) {
                    AuthStore.setLoading(false);
                    console.log("Error on get course by id --> ", e);
                    toast.error(e?.response?.data?.message);
                    throw e;
                }
            }
        };

    }

    getsubjectMenu = (value) => {
        let subjectMenu = value?.subjectCategories.map((elm) => {
            return {
                id: elm?.subjectCategoryId,
                Title: elm?.subjectName,
                label: "Topic",
            };
        });
        VideoStore.setSubject(subjectMenu);
    };

    getTopicList = async (data) => {
        if (data) {
            let topicList = data?.map((elm, i) => {
                return {
                    id: elm?.id,
                    Title: elm?.topicName,
                    active: i === 0 ? true : false,
                    label: "SubTopic",
                };
            });
            VideoStore.setTopic(topicList);
        }
        else {
            VideoStore.setTopic([])
        }
    };
}
const VideoServices = new VideoService();
export default VideoServices;

