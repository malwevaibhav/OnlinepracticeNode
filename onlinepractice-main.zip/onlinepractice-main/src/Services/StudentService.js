import { toast } from "react-toastify";
import AuthStore from "../MobX/Auth";
import { ApiRoutes } from "../shared/constant";
import MainService from "../utils/ServiceInterceptors";
class StudentService {

     createStudent = async (payload) => {
        try {
          AuthStore?.setLoading(true);
          const resp = await MainService.post(
            `${ApiRoutes?.addStudent}`,
            payload
          );
          AuthStore?.setLoading(false);
          return resp?.data;
        } catch (error) {
          AuthStore?.setLoading(false);
          toast.error(error?.response?.data?.data[0]?.message)
          console.log("Error on subject--> ", error);
          throw new Error(error);
        }
      };
      updateStudent = async (payload) => {
        try {
          AuthStore?.setLoading(true);
          const resp = await MainService.post(
            `${ApiRoutes?.updateStudent}`,
            payload
          );
          AuthStore?.setLoading(false);
          return resp?.data;
        } catch (error) {
          AuthStore?.setLoading(false);
          toast.error(error?.response?.data?.data[0]?.message)
          console.log("Error on subject--> ", error);
          throw new Error(error);
        }
      };
      getSampleReport = async () => {
        try {
          AuthStore?.setLoading(true);
          const resp = await MainService.get(`${ApiRoutes?.getSampleExcel}`,'');
          AuthStore?.setLoading(false);
          return resp?.data;
        } catch (error) {
          AuthStore?.setLoading(false);
          toast.error(error?.response?.data?.data[0]?.message)
          console.log("Error on subject--> ", error);
          throw new Error(error);
        }
      };

      getAllStudentlist = async (payload) => {
        try {
          AuthStore?.setLoading(true);
          const resp = await MainService.post(
            `${ApiRoutes?.getAllStudentlist}`,
            payload
          );
          AuthStore?.setLoading(false);
          return resp?.data;
        } catch (error) {
          AuthStore?.setLoading(false);
          toast.error(error?.response?.data?.data[0]?.message)
          console.log("Error on subject--> ", error);
          throw new Error(error);
        }
      };

      getStudentById = async (Id) => {
        try {
          AuthStore?.setLoading(true);
          const resp = await MainService.post(
            `${ApiRoutes?.getStudentById}`,
            {
              id: Id
            }
          );
          AuthStore?.setLoading(false);
          return resp?.data;
        } catch (error) {
          AuthStore?.setLoading(false);
          toast.error(error?.response?.data?.data[0]?.message)
          console.log("Error on subject--> ", error);
          throw new Error(error);
        }
      };
      
      deleteStudent = async (Id) => {
        let config = {
          headers: {
            "Content-Type": "application/json",
          },
    
        };
         let payload = {
          id: Id
        }
        try {
          AuthStore?.setLoading(true);
          const resp = await MainService.delete(`${ApiRoutes?.deleteStudent}`,
            {
              ...config,
              data: payload 
           
            }
          );
          AuthStore?.setLoading(false);
          return resp?.data;
        } catch (error) {
          AuthStore?.setLoading(false);
          toast.error(error?.response?.data?.data[0]?.message)
          console.log("Error on subject--> ", error);
          throw new Error(error);
        }
      };

      UploadExcel = async (payload) => {
        let config;
        config = {
            headers: {
                "Content-Type": "multipart/form-data",
            },
        };
        try {
          AuthStore?.setLoading(true);
          const resp = await MainService.post(
            `${ApiRoutes?.bulkUpload}`, payload ,{ headers: config.headers }
          );
          AuthStore?.setLoading(false);
          return resp?.data;
        } catch (error) {
          AuthStore?.setLoading(false);
          toast.error(error?.response?.data?.data?.[0]?.message)
          console.log("Error on subject--> ", error);
          throw new Error(error);
        }
      };

}


const StudentServices = new StudentService();
export default StudentServices;