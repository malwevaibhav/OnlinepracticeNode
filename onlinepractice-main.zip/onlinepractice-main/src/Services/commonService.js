import { toJS } from "mobx";
import AuthStore from "../MobX/Auth";
import { Navmenu } from "../utils/nav-menu-util";

export default class Commonservice {
  static cachedRole = "";
  // static get key() {
  //   // return Constants.authSessionKey;
  // }
  static setLogin(data) {
    localStorage.setItem(this.key, data);
  }
  static currentRole() {
    const userData = {
      role: toJS(AuthStore?.user?.user?.role),
      // permissions: [],
      permissions: toJS(AuthStore?.user?.user?.permision),
    };
    return userData;
  }
  static setLogout() {
    localStorage.removeItem(this.key);
    this.cachedRole = "";
  }
  static getLeftMenuOptions() {
    let options = [];
    const user = this.currentRole();
    Navmenu.forEach((menu) => {
      if (menu?.allowedRole?.includes(user?.role)) {
        if (menu?.submenus?.length) {
          // const availSubMenus = menu?.submenus.filter((x) => !user?.permissions.includes(x.permissions));
          const availSubMenus = menu?.submenus.filter((x) => user?.permissions.includes(x.permissions));
          if (availSubMenus?.length) {
            options.push({
              ...menu,
              submenus: availSubMenus,
            });
          }
        } else {
          if (menu?.allowedRole?.includes(user?.role)) {
            options.push({ ...menu });
          }
        }
      }
    });
    return options;
  }
  static handleScroll = (scrollclass) => {
    //  console.log(scrollclass,"scroll-class")
    let scrollItem = document.getElementsByClassName(`${scrollclass}`);
    let top = document.getElementsByClassName("scroll-view")[0];
    // console.log("scroll-height->>>>>>>>",top.scrollHeight)
    setTimeout(() => {
      // console.log("scroll->>top",scrollItem[0].offsetTop)
      top.scrollTo({ top: scrollItem[0].offsetTop - 200, behavior: "smooth" })
    }, 500);
  };

}

// function compare(arr1, arr2) {
//   const finalarray = [];
//   arr1.forEach((e1) => arr2.forEach((e2) => {
//     if (e1 === e2) {
//       finalarray.push(e1)
//     }
//   }
//   ));
//   return finalarray;
// }
