import { toast } from "react-toastify";
import AuthStore from "../MobX/Auth";
import CourseStore from "../MobX/Courses";
import QuestionStore from "../MobX/Question";
import { ApiRoutes } from "../shared/constant";
import MainService from "../utils/ServiceInterceptors";

class CourseService {
  getSubCourseMenu = (value) => {
    AuthStore.setLoading(true);
    if (!value?.subCourses)
      return toast.error("SubCourses Not Found Please add!!");
    let subcourseMenu = value?.subCourses?.map((elm) => {
      return {
        id: elm?.id,
        Title: elm?.subCourseName,
        label: "Subject",
      };
    });
    AuthStore.setLoading(false);
    CourseStore.setSubCourse(subcourseMenu);
    // console.log("get SubCourse Menu");
  };

  getCourseList = async () => {
    try {
      const resp = await MainService.get(`${ApiRoutes?.getAllCourse}`);
      return resp?.data?.data;
    } catch (error) {
      console.log("Error on get ExamList WithCourses ExamType --> ", error);
      throw new Error(error);
    }
  };

  getsubjectMenu = (value) => {
    let subjectMenu = value?.subjectCategories.map((elm) => {
      return {
        id: elm?.subjectCategoryId,
        Title: elm?.subjectName,
        label: "Topic",
      };
    });
    CourseStore.setSubjectSelected(subjectMenu);
    // CourseStore.setsubject(subjectMenu)
  };

  getSubCourseById = async (Id) => {
    try {
      const res = await MainService.post(
        `${ApiRoutes?.getSubCoursesByCourseId}`,
        { id: Id }
      );
      if (res?.data?.isSuccess) {
        this.getSubCourseList(res?.data?.data);
        return res?.data?.data;
      } else {
         toast.error(res?.data?.messages)
      }
    } catch (error) {
      console.log("Get sub course by id error --> ", error);
      toast.error(error?.response?.data?.data[0]?.message);
      // throw new Error(error);
    }
  };

  getSubjectById = async (Id) => {
    try {
      const res = await MainService.post(
        `${ApiRoutes?.getallsubjectBymasterId}`,
        { subCourseId: Id }
      );
      if (res?.data?.isSuccess) {
        // this.getSubjectList(res?.data?.data)
        return res?.data?.data;
      } else {
        toast.error(res?.data?.messages);
      }
    } catch (error) {
      console.log("Get subject --> ", error);
      toast.error(error?.response?.data?.data[0]?.message);
      throw new Error(error);
    }
  };
  getNewAllSubject = async (payload) => {
    if (!payload) {
      payload = { pageNumber: 0, pageSize: 0 }

    }
    try {
      AuthStore.setLoading(true);
      const resp = await MainService.post(`${ApiRoutes?.getSubject}`, payload);
      AuthStore.setLoading(false);

      let allSubjects = resp?.data?.data?.subjects?.map((elm) => {
        return {
          id: elm?.id,
          Title: elm?.subjectName,
          action:true
        };
      });
      CourseStore.setAllSubject(allSubjects);
      return resp?.data?.data;
    } catch (error) {
      AuthStore.setLoading(false);

      throw new Error(error);
    }
  };

  createNewsubject = async (body) => {
    try {
      const resp = await MainService.post(`${ApiRoutes?.createSubject}`, body);
      //console.log("apidata create subject", resp);
      if (resp?.data?.isSuccess) {
        this.getNewAllSubject(resp?.data);
       //console.log("apidata msg ");
        return resp.data;
      } else {
        return resp.data;
      }
    } catch (error) {
      console.log("err");

      return Promise.reject(error);
    }
  };

  editNewSubjects = async (editbody) => {
    try {
      const resp = await MainService.put(
        `${ApiRoutes?.editSubject}`,
        editbody
      );
      if (resp?.data?.isSuccess) {
        this.getNewAllSubject(resp?.data);
        return resp.data;
      } else {
        return resp?.data;
      }
    } catch (error) {
      console.log("err");

      return Promise.reject(error);
    }
  };


  getCourseFilterData = async (props) => {
    
    if (props?.label === 'Exam') {
      try {
        AuthStore.setLoading(true);
        const resp = await MainService.get(`${ApiRoutes?.getAllExam}`);
        let examlist = resp?.data?.data?.examType?.map((elm) => {
          return {
            id: elm?.id,
            Title: elm?.examName,
            label: "Course",
          };
        });
        CourseStore.setexamList(examlist);
        AuthStore.setLoading(false);
        return resp?.data?.data;
      } catch (error) {
        AuthStore.setLoading(false);
        console.log("Error on get ExamList WithCourses ExamType --> ", error);
        toast.error(error?.response?.data?.data[0]?.message);
        throw new Error(error);
      }
    }
    if (props?.label === "Course") {
      if (props?.id) {
        try {
          AuthStore.setLoading(true);
          const resp = await MainService.post(
            `${ApiRoutes?.getCoursebyExamId}`,
            {
              examId: props?.id,
            }
          );
          let courseList = resp?.data?.data?.courses?.map((elm) => {
            return {
              id: elm?.id,
              Title: elm?.courseName,
              label: "SubCourse",
            };
          });
          if (resp?.data.responseCode === 400) {
            QuestionStore.setSelectedItemsNw({ selectedName: "Exam", props: {}, entityName: "" })
          }
          CourseStore.setCourse(courseList);
          AuthStore.setLoading(false);
          return resp?.data?.data;
        } catch (error) {
          AuthStore.setLoading(false);
          console.log("Error on get course --> ", error);
          toast.error(error?.response?.data?.data[0]?.message);
          throw new Error(error);
        }
      }
    }
    if (props?.label === "SubCourse") {
      if (props?.id) {
        try {
          AuthStore.setLoading(true);
          const res = await MainService.post(
            `${ApiRoutes?.getSubCoursesByCourseId}`,
            { id: props?.id }
          );
          if (res?.data?.isSuccess) {
            this.getSubCourseMenu(res?.data?.data);
            AuthStore.setLoading(false);
            return res?.data;
          }
        } catch (error) {
          AuthStore.setLoading(false);
          console.log("Get sub course by id error --> ", error);
          toast.error(error?.response?.data?.data[0]?.message);
          // throw new Error(error);
        }
      }
    } else if (props?.label === "Subject") {
      if (props?.id) {
        try {
          AuthStore.setLoading(true);
          const res = await MainService.post(
            `${ApiRoutes?.getSubjectssubCoursesId}`,
            { subCourseId: props?.id }
          );
          if (res?.data?.isSuccess) {
            this.getsubjectMenu(res?.data?.data);
            AuthStore.setLoading(false);

            return res?.data;
          } else {
            AuthStore.setLoading(false);

            toast.error(res?.data?.messages);
          }
        } catch (error) {
          AuthStore.setLoading(false);
          console.log("Get sub course by id error --> ", error);
          throw new Error(error);
        }
      }
    } else if (props?.label === "Topic") {
      if (props?.id) {
        try {
          AuthStore.setLoading(true);
          const resp = await MainService.post(
            `${ApiRoutes?.getalltopicbysubjectID}`,
            {
              id: props?.id,
            }
          );
          if (resp?.data?.isSuccess) {
            AuthStore.setLoading(false);
            this.getTopicList(resp?.data?.data?.topic);
            // console.log("resp?.data?.data?.topic---",resp?.data?.data?.topic);
            return resp?.data?.data?.topic;
          } else {
            // console.log("resp?.data?.data?.topic---",resp?.data?.data?.topic);
            AuthStore.setLoading(false);
            toast.error(resp?.data?.messages);
          }
        } catch (e) {
          AuthStore.setLoading(false);
          console.log("Error on get course by id --> ", e);
          toast.error(e?.response?.data?.message);
          throw e;
        }
      }
    } else if (props?.label === "SubTopic") {
      if (props?.id) {
        try {
          AuthStore.setLoading(true);
          const resp = await MainService.post(
            `${ApiRoutes?.getsubtopicbyId}`,
            {
              id: props?.id,
            }
          );
          if (resp?.data?.isSuccess) {
            this.getSubTopicList(resp?.data?.data?.subTopics);
            AuthStore.setLoading(false);
            return resp?.data?.data?.subTopics;
          } else {
            this.getSubTopicList(false);
            // toast.error(resp?.data?.messages);
            AuthStore.setLoading(false);
          }
        } catch (e) {
          console.log("Error on get course by id --> ", e);
          toast.error(e?.response?.data?.message);
          throw e;
        }
      }
    }
  };

  getTopicBySubjectId = async (Id) => {
    try {
      AuthStore.setLoading(true);
      const resp = await MainService.post(
        `${ApiRoutes?.getalltopicbysubjectID}`,
        {
          id: Id,
        }
      );
      if (resp?.data?.isSuccess) {
        AuthStore.setLoading(false);
        console.log("resp?.data?.data?.topic====", resp?.data?.data?.topic);
        this.getTopicList(resp?.data?.data?.topic);
        return resp?.data?.data?.topic;
      } else {
        AuthStore.setLoading(false);
        toast.error(resp?.data?.messages);
      }
    } catch (e) {
      AuthStore.setLoading(false);
      console.log("Error on get course by id --> ", e);
      toast.error(e?.response?.data?.message);
      throw e;
    }
  };

  getSubTopicById = async (Id) => {
    try {
      const resp = await MainService.post(`${ApiRoutes?.getsubtopicbyId}`, {
        id: Id,
      });
      if (resp?.data?.isSuccess) {
        this.getSubTopicList(resp?.data?.data?.subTopics);
        return resp?.data?.data?.subTopics;
      } else {
        // toast.error(resp?.data?.messages)
      }
    } catch (e) {
      console.log("Error on get course by id --> ", e);
      toast.error(e?.response?.data?.message);
      throw e;
    }
  };

  addTopicModule = async (topicModule, title) => {
    if (title === "Topic") {
      try {
        const resp = await MainService.post(
          `${ApiRoutes?.createTopic}`,
          topicModule
        );
        if (resp?.data?.isSuccess) {
          toast.success(resp?.data?.messages);
          return resp?.data;
        } else {
          toast.error(resp?.data?.messages);
        }
      } catch (e) {
        console.log("Error on get course by id --> ", e);
        toast.error(e?.response?.data?.data[0]?.message);
        throw e;
      }
    } else if (title === "Sub Topic") {
      try {
        const resp = await MainService.post(`${ApiRoutes?.createsubTopic}`, {
          subTopicName: topicModule?.subTopicName,
          subTopicDescription: topicModule?.subTopicDescription,
          topicId: topicModule?.topicId,
        });
        if (resp?.data?.isSuccess) {
          toast.success(resp?.data?.messages);
          return resp?.data;
        } else {
          toast.error(resp?.data?.messages);
        }
      } catch (e) {
        console.log("Error on get course by id --> ", e);
        throw e;
      }
    }
  };

  updateTopicModule = async (topicModule, title) => {
    //
    if (title === "Topic") {
      try {
        const res = await MainService.put(
          `${ApiRoutes?.updateTopic}`,
          topicModule
        );
        if (res?.data?.isSuccess) {
          toast.success(res?.data?.messages);
          return res?.data;
        } else {
          toast.error(res?.data?.messages);
        }
      } catch (error) {
        console.log("Error updatwe topic--> ", error);
        toast.error(error?.response?.data?.message);
        throw new Error(error);
      }
    } else if (title === "Sub Topic") {
      try {
        const resp = await MainService.put(
          `${ApiRoutes?.updatesubTopic}`,
          topicModule
        );
        if (resp?.data?.isSuccess) {
          toast.success(resp?.data?.messages);
          return resp?.data;
        } else {
          toast.error(resp?.data?.messages);
        }
      } catch (e) {
        console.log("Error updatwe sub topic--> ", e);
        throw e;
      }
    }
  };

  // create Course//

  createCourseModule = async (payload) => {
    try {
      const res = await MainService.post(
        `${ApiRoutes?.createCourse}`,
        payload
      );
      if (res?.data?.isSuccess) {
        toast.success(res?.data?.messages);
        return res?.data;
      } else {
        toast.error(res?.data?.messages);
      }
    } catch (error) {
      toast.error(error?.response?.data?.message);
      throw new Error(error?.response?.data?.message);
    }
  };
  // update Course
  updateCourseModule = async (payload) => {
    try {
      const res = await MainService.post(
        `${ApiRoutes?.updatesubjectcategory}`,
        payload
      );
      if (res?.data?.isSuccess) {
        toast.success(res?.data?.messages);
        return res?.data;
      } else {
        toast.error(res?.data?.messages);
      }
    } catch (error) {
      toast.error(error?.response?.data?.message);
      throw new Error(error?.response?.data?.message);
    }
  };

  courseCreate = async (payload) => {
    try {
      AuthStore?.setLoading(true);
      const resp = await MainService.post(
        `${ApiRoutes?.courseCreate}`,
        payload
      );
      AuthStore?.setLoading(false);
      return resp?.data;
    } catch (error) {
      AuthStore?.setLoading(false);
      console.log("Error on subject--> ", error);
      toast.error(error?.response?.data?.data[0]?.message);
      throw new Error(error);
    }
  };

  subcourseCreate = async (payload) => {
    try {
      AuthStore?.setLoading(true);
      const resp = await MainService.post(
        `${ApiRoutes?.subCourseCreate}`,
        payload
      );
      AuthStore?.setLoading(false);
      return resp?.data;
    } catch (error) {
      AuthStore?.setLoading(false);
      console.log("Error on subject--> ", error);
      toast.error(error?.response?.data?.data[0]?.message);
      throw new Error(error);
    }
  };

  updateCourse = async (payload) => {
    try {
      AuthStore?.setLoading(true);
      const resp = await MainService.put(
        `${ApiRoutes?.updateCourse}`,
        payload
      );
      AuthStore?.setLoading(false);
      return resp?.data;
    } catch (error) {
      AuthStore?.setLoading(false);
      console.log("Error on course update--> ", error);
      toast.error(error?.response?.data?.data[0]?.message);
      throw new Error(error);
    }
  };

  deleteExam = async (id) => {
    try {
      let config;
      let payload = {
        id: id
      }
      config = {
        headers: {
          "Content-Type": "application/json",
        },

      };
      AuthStore?.setLoading(true);
      const resp = await MainService.delete(`${ApiRoutes?.deleteExam}`, { ...config, data: payload });
      AuthStore?.setLoading(false);
      return resp?.data;
    } catch (err) {
      AuthStore?.setLoading(false);
      console.log("Error on course update--> ", err);
      throw new Error(err);
    }
  };

  deleteCourse = async (id) => {
    try {
      let config;
      let payload = {
        id: id
      }
      config = {
        headers: {
          "Content-Type": "application/json",
        },

      };
      AuthStore?.setLoading(true);
      const resp = await MainService.delete(`${ApiRoutes?.deleteCourse}`, { ...config, data: payload });
      AuthStore?.setLoading(false);
      return resp?.data;
    } catch (error) {
      AuthStore?.setLoading(false);
      console.log("Error on course update--> ", error);
      toast.error(error?.response?.data?.data[0]?.message);
      throw new Error(error);
    }
  };

  deleteSubCourse = async (id) => {
    try {
      let config;
      let payload = {
        id: id
      }
      config = {
        headers: {
          "Content-Type": "application/json",
        },

      };
      AuthStore?.setLoading(true);
      const resp = await MainService.delete(`${ApiRoutes?.deleteSubCourse}`, { ...config, data: payload });
      AuthStore?.setLoading(false);
      return resp?.data;
    } catch (error) {
      AuthStore?.setLoading(false);
      console.log("Error on course delete--> ", error);
      toast.error(error?.response?.data?.data[0]?.message);
      throw new Error(error);
    }
  };

  getSubjectBySubCourse = async (Id) => {
    try {
      AuthStore.setLoading(true);
      const res = await MainService.post(
        `${ApiRoutes?.getSubjectssubCoursesId}`,
        { subCourseId: Id }
      );
      if (res?.data?.isSuccess) {
      //  console.log("res?.data---", res?.data);
        this.getSubjectList(res?.data?.data);
        AuthStore.setLoading(false);
        return res?.data;
      } else {
        AuthStore.setLoading(false);
        toast.error(res?.data?.messages);
      }
    } catch (error) {
      AuthStore.setLoading(false);
      console.log("Get sub course by id error --> ", error);
      throw new Error(error);
    }
  };

  getSubCourseList = async (data) => {
    let subcourselist = data?.subCourses?.map((elm) => {
      return {
        id: elm?.id,
        Title: elm?.subCourseName,
        label: "Subject",
      };
    });
    CourseStore.setSubCourse(subcourselist);
  };

  getSubjectList = async (data) => {
    let subjectList = data?.subjectCategories?.map((elm) => {
      return {
        id: elm?.subjectCategoryId,
        title: elm?.subjectName,
      };
    });
    CourseStore.setsubject(subjectList);
  };

  getTopicList = async (data) => {
    if (data) {
      let topicList = data?.map((elm, i) => {
        return {
          id: elm?.id,
          Title: elm?.topicName,
          active: i === 0 ? true : false,
          label: "SubTopic",
        };
      });
      // console.log("topic list ----",topicList);
      CourseStore.setTopicList(topicList);
    }
    else {
      CourseStore.setTopicList([])
    }
  };

  getSubTopicList = async (data) => {
    let topicList
    if (data) {
      topicList = data?.map((elm, i) => {
        return {
          id: elm?.id,
          Title: elm?.subTopicName,
          label: "",
          active: i === 0 ? true : false,
        };
      });
    } else {
      topicList = [];
    }
    CourseStore.setSubTopicList(topicList)
  }

}

const CourseServices = new CourseService();
export default CourseServices;
