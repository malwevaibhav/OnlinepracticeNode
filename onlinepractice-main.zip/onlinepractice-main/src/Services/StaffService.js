import { toast } from "react-toastify";
import AuthStore from "../MobX/Auth";
import { ApiRoutes } from "../shared/constant";
import MainService from "../utils/ServiceInterceptors";

// let baseURL=process.env.REACT_APP_API_URL

class StaffService {
  getAllModules = async () => {
    try {
      const resp = await MainService.get(`${ApiRoutes?.getAllModules}`);
      return resp?.data?.data?.modulesList;
    } catch (error) {
      console.log("Error on permission module List staff --> ", error);
      toast.error(error?.response?.data?.data[0]?.message);
      throw new Error(error);
    }
  };

  createStaff = async (payload) => {
    try {
      AuthStore?.setLoading(true);
      const resp = await MainService.post(`${ApiRoutes?.createStaff}`, payload);
      AuthStore?.setLoading(false);
      return resp?.data;
    } catch (error) {
      AuthStore?.setLoading(false);
      console.log("Error on create staff --> ", error);
      toast.error(error?.response?.data?.data[0]?.message);
      throw new Error(error);
    }
  };

  getAllStaff = async (payload) => {
    try {
      AuthStore?.setLoading(true);
      const res = await MainService.post(`${ApiRoutes?.getAllStaff}`, payload);
      AuthStore?.setLoading(false);
      return res?.data;
    } catch (error) {
      AuthStore?.setLoading(false);
      console.log("All staff list error --> ", error);
      toast.error(error?.response?.data?.data[0]?.message);
      throw new Error(error);
    }
  };

  getStaffById = async (payload) => {
    try {
      const res = await MainService.post(`${ApiRoutes?.getStaffById}`, payload);
      return res?.data;
    } catch (error) {
      console.log("Get staff by id error --> ", error);
      toast.error(error?.response?.data?.data[0]?.message);
      throw new Error(error);
    }
  };

  // deleteStaff = async (payload) => {
  //   try {
  //     const res = await apiDelete(
  //       `${baseURL}${ApiRoutes?.deleteStaff}`,
  //       payload
  //     );
  //     return res?.data;
  //   } catch (error) {
  //     console.log("Delete staff error --> ", error);
  //     toast.error(error?.response?.data?.data[0]?.message)
  //     throw new Error(error);
  //   }
  // };
  deleteStaff = async (payload) => {
    console.log("Payload delete --> ", payload);
    let config;

    config = {
      headers: {
        "Content-Type": "application/json",
      },
    };

    try {
      const res = await MainService.delete(`${ApiRoutes?.deleteStaff}`, {
        ...config,
        data: payload,
      });
      return res?.data;
    } catch (error) {
      console.log("Delete staff error --> ", error);
      toast.error(error?.response?.data?.data[0]?.message);
      throw new Error(error);
    }
  };

  editStaff = async (payload) => {
    try {
      const res = await MainService.put(`${ApiRoutes?.editStaff}`, payload);
      return res?.data;
    } catch (error) {
      console.log("update staff --> ", error);
      toast.error(error?.response?.data?.data[0]?.message);
      throw new Error(error);
    }
  };
}
const StaffServices = new StaffService();
export default StaffServices;
