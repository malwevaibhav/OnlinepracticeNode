import { toast } from "react-toastify";
import AuthStore from "../MobX/Auth";
import { ApiRoutes } from "../shared/constant";
import MainService from "../utils/ServiceInterceptors";



class TopicService {
    deleteTopic = async (id)=>{
      let config;
          let payload= {
            id: id
          }
          config = {
            headers: {
              "Content-Type": "application/json",
            },
            
          };
        try {
          AuthStore?.setLoading(true);
          const resp = await MainService.delete(
            `${ApiRoutes?.deleteTopic}`, { ...config, data: payload }
          );
          AuthStore?.setLoading(false);
          return resp?.data;
        } catch (error) {
          AuthStore?.setLoading(false);
          console.log("Error on--> ", error);
          toast.error(error?.response?.data?.data[0]?.message)
          throw new Error(error);
        }
      };

    deleteSubTopic = async (id)=>{
        try {
          AuthStore?.setLoading(true);
          let config;
          let payload= {
            id: id
          }
          config = {
            headers: {
              "Content-Type": "application/json",
            },
            
          };
          const resp = await MainService.delete(
            `${ApiRoutes?.deleteSubTopic}`, 
            { ...config, data: payload }
          );
          AuthStore?.setLoading(false);
          return resp?.data;
        } catch (error) {
          AuthStore?.setLoading(false);
          console.log("Error on--> ", error);
          toast.error(error?.response?.data?.data[0]?.message)
          throw new Error(error);
        }
      };
  }
const TopicServices = new TopicService();
export default TopicServices;