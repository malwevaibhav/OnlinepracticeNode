import { toast } from "react-toastify";
import AuthStore from "../MobX/Auth";
import { ApiRoutes } from "../shared/constant";

import MainService from "../utils/ServiceInterceptors";

class QuestionBankService {

    getQuestionBankList = async (payload) => {
        try {
            const resp = await MainService.post(`${ApiRoutes?.getAllQuestionBank}`, payload);
            if (resp?.data?.isSuccess) {
                return resp?.data
            } else {
              toast.error(resp?.data?.messages)
            }
        } catch (error) {
            console.log("Error on get Questionbank --> ", error);
            toast.error(error?.response?.data?.data[0]?.message)
            throw error;
        }
    }
 
    createQuestionbank = async(payload)=>{
        try {
            AuthStore?.setLoading(true);
            const resp = await MainService.post(
              `${ApiRoutes?.createQuestion}`,
              payload
            );
            AuthStore?.setLoading(false);
            return resp?.data;
          } catch (error) {
            AuthStore?.setLoading(false);
            console.log("Error on Question bank--> ", error);
            toast.error(error.response.data.data[0].message);
            throw new Error(error);
          } 
    }
    updateQuestionbank = async(payload)=>{
        try {
            AuthStore?.setLoading(true);
            const resp = await MainService.put(
              `${ApiRoutes?.updateQuestion}`,
              payload
            );
            AuthStore?.setLoading(false);
            return resp?.data;
          } catch (error) {
            AuthStore?.setLoading(false);
            console.log("Error on Question bank--> ", error);
            toast.error(error.response.data.data[0].message);
            throw new Error(error);
          } 
    }

    deleteQuestion = async(payload)=>{
      let config;
         
          config = {
            headers: {
              "Content-Type": "application/json",
            },
            
          };
        try {
            AuthStore?.setLoading(true);
            const resp = await MainService.delete(
              `${ApiRoutes?.deleteQuestion}`,
              { ...config, data: payload }
            );
            AuthStore?.setLoading(false);
            return resp?.data;
          } catch (error) {
            AuthStore?.setLoading(false);
            console.log("Error on Question bank--> ", error);
            toast.error(error);
            throw new Error(error);
          } 
    }

    getQuestionByID = async(Id)=>{
      try {
        AuthStore?.setLoading(true);
        const resp = await MainService.post(
          `${ApiRoutes?.getQuestionById}`,
          {
            questionRefId: Id
          }
        );
        AuthStore?.setLoading(false);
        return resp?.data;
      } catch (error) {
        AuthStore?.setLoading(false);
        console.log("Error on Question bank--> ", error);
        toast.error(error);
        throw new Error(error);
      } 
    }

}
const QuestionBankServices = new QuestionBankService()
export default QuestionBankServices;