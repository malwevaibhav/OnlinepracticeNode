import { toast } from "react-toastify";
import AuthStore from "../MobX/Auth";
import CourseStore from "../MobX/Courses";
import { ApiRoutes } from "../shared/constant";
import MainService from "../utils/ServiceInterceptors";


class ExamTypeService {

  getExamlistWithCourses = async () => {
    try {
      AuthStore.setLoading(true)
      const resp = await MainService.get(`${ApiRoutes?.getExamListWithCourses}`);
      // CourseStore.setExamListWithDetails(resp?.data?.data?.examType)
      AuthStore.setLoading(false)
      return resp?.data?.data?.examType;
    } catch (error) {
      console.log("Error on get ExamList WithCourses ExamType --> ", error);
      AuthStore.setLoading(false)
      toast.error(error?.response?.data?.data[0]?.message)
      throw new Error(error);
    }
  };
 
  getCourseById = async (Id) => {
    try {
      const resp = await MainService.post(`${ApiRoutes?.getCoursebyExamId}`, {
        examId: Id
      });
      CourseStore.setCourse(resp?.data?.data)
      return resp?.data?.data;
    } catch (error) {
      console.log("Error on get course --> ", error);
      toast.error(error?.response?.data?.data[0]?.message)
      throw new Error(error);
    }
  };

  deleteExam = async (id) => {
    try {
      let config;
          let payload= {
            id: id
          }
          config = {
            headers: {
              "Content-Type": "application/json",
            },
            
          };
      AuthStore?.setLoading(true);
      const resp = await MainService.delete(
        `${ApiRoutes?.deleteExam}`,{ ...config, data: payload }
      );
      AuthStore?.setLoading(false);
      return resp?.data;
    } catch (error) {
      AuthStore?.setLoading(false);
      console.log("Error on course update--> ", error);
      toast.error(error?.response?.data?.data[0]?.message)
      throw new Error(error);
    }
  };


  updateExam = async (payload) => {
    try {
      AuthStore?.setLoading(true);
      const resp = await MainService.put(
        `${ApiRoutes?.updateExam}`,
        payload
      );
      AuthStore?.setLoading(false);
      return resp?.data;
    } catch (error) {
      AuthStore?.setLoading(false);
      console.log("Error on exam--> ", error);
      toast.error(error?.response?.data?.data[0]?.message)
      throw new Error(error);
    }
  };

};


const ExamTypeServices = new ExamTypeService();
export default ExamTypeServices;
