import { toast } from "react-toastify";
import AuthStore from "../MobX/Auth";
import { ApiRoutes } from "../shared/constant";
import MainService from "../utils/ServiceInterceptors";


class PatternService {
    getAllPattern = async (payload) => {
        if (!payload) {
            payload = { pageNumber: 0, pageSize: 0 }
        }
        try {
            AuthStore.setLoading(true);
            const resp = await MainService.post(`${ApiRoutes?.getAllPattern}`, payload);
            AuthStore.setLoading(false);
            return resp?.data?.data;
        } catch (error) {
            console.log("Error on getAllPattern --> ", error);
            AuthStore.setLoading(false);
            toast.error(error?.response?.data?.data[0]?.message)
            throw new Error(error);
        }
    };

    getPatternById = async (payload) => {
        try {
            AuthStore.setLoading(true);
            const resp = await MainService.post(
                `${ApiRoutes?.examPatternById}`,
                payload
            );
            AuthStore.setLoading(false);
            return resp?.data;
        } catch (error) {
        
            AuthStore.setLoading(false);
            toast.error(error?.response?.data?.data[0]?.message)
            throw new Error(error);
        }
    };

    createPattern = async (payload) => {
        try {
            AuthStore.setLoading(true);
            const resp = await MainService.post(`${ApiRoutes?.createExamPattern}`, payload);
            AuthStore.setLoading(false);
            return resp?.data;
        } catch (error) {
            console.log("Error on create Pattern --> ", error);
            AuthStore.setLoading(false);
            toast.error(error?.data[0]?.message)
            throw new Error(error);
        }
    };

    updatePattern = async (payload) => {
        try {
            AuthStore.setLoading(true);
            const resp = await MainService.put(`${ApiRoutes?.updatePattern}`, payload);
            AuthStore.setLoading(false);
            return resp?.data;
        } catch (error) {
            console.log("Error on updatePattern --> ", error);
            AuthStore.setLoading(false);
            toast.error(error?.response?.data?.data[0]?.message)
            throw new Error(error);
        }
    };

    deletePattern = async (payload) => {
        let config;
          
          config = {
            headers: {
              "Content-Type": "application/json",
            },
            
          };
        try {
            AuthStore.setLoading(true);
            const resp = await MainService.delete(`${ApiRoutes?.deletePattern}`,{ ...config, data: payload });
            AuthStore.setLoading(false);
            return resp?.data;
        } catch (error) {
            console.log("Error on updatePattern --> ", error);
            AuthStore.setLoading(false);
            toast.error(error?.response?.data?.data[0]?.message)
            throw new Error(error);
        }
    };

    editInstruction = async (payload) => {
        try {
            AuthStore.setLoading(true);
            const resp = await MainService.put(`${ApiRoutes?.editInstruction}`, payload);
            AuthStore.setLoading(false);
            return resp?.data;
        } catch (error) {
            console.log("Error on create Instruction --> ", error);
            AuthStore.setLoading(false);
            toast.error(error?.data[0]?.message)
            throw new Error(error);
        }
    };

}
const PatternServices = new PatternService();
export default PatternServices;
