import { toast } from "react-toastify";
import AuthStore from "../MobX/Auth";
import { ApiRoutes } from "../shared/constant";

import MainService from "../utils/ServiceInterceptors";

class PYPService {

    getAllPaper = async (payload) => {
        if (!payload) {
            payload = { pageNumber: 0, pageSize: 0 }
        }
        try {
            AuthStore.setLoading(true);
            const resp = await MainService.post(`${ApiRoutes?.getAllPapers}`, payload);
            AuthStore.setLoading(false);
            return resp?.data;
        } catch (error) {
            console.log("Error on getAllPaper --> ", error);
            AuthStore.setLoading(false);
            toast.error(error?.response?.data?.data[0]?.message)
            throw new Error(error);
        }
    };

    getPaperById = async (payload) => {
        try {
            AuthStore.setLoading(true);
            const resp = await MainService.post(`${ApiRoutes?.getPaperById}`, payload);
            AuthStore.setLoading(false);
            return resp?.data;
        } catch (error) {
            console.log("Error on getPaperById --> ", error);
            AuthStore.setLoading(false);
            toast.error(error?.response?.data?.data[0]?.message)
            throw new Error(error);
        }
    };
    
    getYearList = async () => {
        try {
            AuthStore.setLoading(true);
            const resp = await MainService.get(`${ApiRoutes?.getYearList}`);
            AuthStore.setLoading(false);
            return resp?.data?.data;
        } catch (error) {
            console.log("Error on getPaperById --> ", error);
            AuthStore.setLoading(false);
            toast.error(error?.response?.data?.data[0]?.message)
            throw new Error(error);
        }
    };

    createPaper = async (payload) => {
        try {
            AuthStore.setLoading(true);
            const resp = await MainService.post(`${ApiRoutes?.createPaper}`, payload);
            AuthStore.setLoading(false);
            return resp?.data;
        } catch (error) {
            console.log("Error on createPaper --> ", error);
            AuthStore.setLoading(false);
            toast.error(error?.response?.data?.data[0]?.message)
            throw new Error(error);
        }
    };

    updatePaper = async (payload) => {
        try {
            AuthStore.setLoading(true);
            const resp = await MainService.put(`${ApiRoutes?.updatePaper}`, payload);
            AuthStore.setLoading(false);
            return resp?.data;
        } catch (error) {
            console.log("Error on updatePaper --> ", error);
            AuthStore.setLoading(false);
            toast.error(error?.response?.data?.data[0]?.message)
            throw new Error(error);
        }
    };

    deletePaper = async (payload) => {
        let config;

        config = {
            headers: {
                "Content-Type": "application/json",
            },

        };
        try {
            AuthStore.setLoading(true);
            const resp = await MainService.delete(`${ApiRoutes?.deletePaper}`, { ...config, data: payload });
            AuthStore.setLoading(false);
            return resp?.data;
        } catch (error) {
            console.log("Error on deletePaper --> ", error);
            AuthStore.setLoading(false);
            toast.error(error?.response?.data?.data[0]?.message)
            throw new Error(error);
        }
    };

    uploadFile = async (payLoad) => {
        let config;
        config = {
            headers: {
                "Content-Type": "multipart/form-data",
            },
        };
        try {
            AuthStore.setLoading(true);
            const resp = await MainService.post(`${ApiRoutes?.uploadPaperPdf}`, payLoad, { headers: config.headers });
            AuthStore.setLoading(false);
            return resp.data;
        } catch (error) {
            console.log("Error on uploadFile --> ", error);
            AuthStore.setLoading(false);
            toast.error(error?.response?.data?.data[0]?.message)
            throw new Error(error);
        }
    };

    getPYPFilterData = async (props) => {
        const { id, label } = props;
        if (label === 'Exam') {
            try {
                AuthStore.setLoading(true);
                const resp = await MainService.get(`${ApiRoutes?.getAllExam}`);
                let examlist = resp?.data?.data?.examType?.map((elm) => {
                    return {
                        id: elm?.id,
                        Title: elm?.examName,
                        label: "Course",
                    };
                });
                AuthStore.setLoading(false);
                return examlist;
                // return resp?.data?.data;
            } catch (error) {
                AuthStore.setLoading(false);
                console.log("Error on get ExamList WithCourses ExamType --> ", error);
                toast.error(error?.response?.data?.data[0]?.message);
                throw new Error(error);
            }
        }
        if (label === "Course") {
            if (id) {
                try {
                    AuthStore.setLoading(true);
                    const resp = await MainService.post(
                        `${ApiRoutes?.getCoursebyExamId}`,
                        {
                            examId: id,
                        }
                    );
                    let courseList = resp?.data?.data?.courses?.map((elm) => {
                        return {
                            id: elm?.id,
                            Title: elm?.courseName,
                            label: "SubCourse",
                        };
                    });
                    AuthStore.setLoading(false);
                    return courseList;
                    // return resp?.data?.data;
                } catch (error) {
                    AuthStore.setLoading(false);
                    console.log("Error on get course --> ", error);
                    toast.error(error?.response?.data?.data[0]?.message);
                    throw new Error(error);
                }
            }
        }
        if (label === "SubCourse") {
            if (id) {
                try {
                    AuthStore.setLoading(true);
                    const res = await MainService.post(
                        `${ApiRoutes?.getSubCoursesByCourseId}`,
                        { id: id }
                    );
                    if (res?.data?.isSuccess) {
                        // this.getSubCourseMenu(res?.data?.data);
                        AuthStore.setLoading(false);
                        let subCourse = res?.data?.data?.subCourses?.map((elm) => {
                            return {
                                id: elm?.id,
                                Title: elm?.subCourseName,
                                label: "Subject",
                            };
                        });
                        return subCourse;
                        // return res?.data;
                    }
                } catch (error) {
                    AuthStore.setLoading(false);
                    console.log("Get sub course by id error --> ", error);
                    toast.error(error?.response?.data?.data[0]?.message);
                    // throw new Error(error);
                }
            }
        }
    };

    // getSubCourseMenu = (value) => {
    //     AuthStore.setLoading(true);
    //     if (!value?.subCourses)
    //         return toast.error("SubCourses Not Found Please add!!");
    //     let subcourseMenu = value?.subCourses?.map((elm) => {
    //         return {
    //             id: elm?.id,
    //             Title: elm?.subCourseName,
    //             label: "Subject",
    //         };
    //     });
    //     AuthStore.setLoading(false);
    //     PYPStores.setSubCourse(subcourseMenu);
    // };
}

const PYPServices = new PYPService();
export default PYPServices;
