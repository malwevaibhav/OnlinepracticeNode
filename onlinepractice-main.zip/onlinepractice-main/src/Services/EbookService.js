import { toast } from "react-toastify";
import AuthStore from "../MobX/Auth";
import CourseStore from "../MobX/Courses";
import EbookStore from "../MobX/Ebook";
import { ApiRoutes } from "../shared/constant";
import MainService from "../utils/ServiceInterceptors";

class EbookService {

  createNewebook = async (body) => {
    try {
      const resp = await MainService.post(`${ApiRoutes?.createEbook}`, body);

      if (resp?.data?.isSuccess) {
        return resp.data;
      } else {
        return resp.data;
      }
    } catch (error) {
      console.log("err");

      return Promise.reject(error);
    }
  };

  updateNewebook = async (body) => {
    try {
      const resp = await MainService.put(`${ApiRoutes?.editEbook}`, body);
      if (resp?.data?.isSuccess) {
        return resp.data;
      } else {
        return resp.data;
      }
    } catch (error) {
      console.log("err");
      return Promise.reject(error);
    }
  };

  getAllauthor = async (body) => {
    try {
      const resp = await MainService.post(`${ApiRoutes?.getallauthers}`, body);
      this.getAllauthorlist(resp?.data?.data)
      if (resp?.data?.isSuccess) {
        return resp.data;
      } else {
        return resp.data;
      }
    } catch (error) {
      console.log("err");
      return Promise.reject(error);
    }
  };
  // getAllauthor = async (body) => {
  //   try {
  //     const resp = await MainService.post(`${ApiRoutes?.getallauthers}`, body);
  //     this.getAllauthorlist(resp?.data?.data)
  //     if (resp?.data?.isSuccess) {
  //       return resp.data;
  //     } else {
  //       return resp.data;
  //     }
  //   } catch (error) {
  //     console.log("err");
  //     return Promise.reject(error);
  //   }
  // };

  getEbookById = async (Id) => {
    try {
      const resp = await MainService.post(`${ApiRoutes?.getbyEbookid}`, {
        id: Id
      });
      if (resp?.data?.isSuccess) {
        return resp.data;
      } else {
        return resp.data;
      }
    } catch (error) {
      console.log("err");
      return Promise.reject(error);
    }
  };


  getAllEbook = async (body) => {
    try {
      const resp = await MainService.post(`${ApiRoutes?.getAllEbook}`, body);
      if (resp?.data?.isSuccess) {
        return resp.data;
      } else {
        return resp.data;
      }
    } catch (error) {
      console.log("err");
      return Promise.reject(error);
    }
  };

  mockTestType= async(data)=>{
    try {
      const resp = await MainService.post(`${ApiRoutes?.getallmocktest}`, data);  
      if (resp?.data?.isSuccess) {
        let MockTest = resp?.data?.data?.mockTestInfoModels && resp?.data?.data?.mockTestInfoModels.map((elm) => {
          return {
            id: elm?.mockTestId,
            Title: elm?.mockTestName,
            label: "MockTest",
          };
        });
        // console.log("MockTest",MockTest);
        return MockTest;
      } else {
        toast.error(resp?.data?.messages)
        return resp?.data?.data?.mockTestInfoModels;
      }
    } catch (error) {
      console.log("err");
      return Promise.reject(error);
    }

  }

  getCourseFilterData = async (props) => {
    const { id, label } = props;
    if (label === 'Exam') {
      try {
        AuthStore.setLoading(true);
        const resp = await MainService.get(`${ApiRoutes?.getAllExam}`);
        let examlist = resp?.data?.data?.examType?.map((elm) => {
          return {
            id: elm?.id,
            Title: elm?.examName,
            label: "Course",
          };
        });
        CourseStore.setexamList(examlist);
        AuthStore.setLoading(false);
        return resp?.data?.data;
      } catch (error) {
        AuthStore.setLoading(false);
        console.log("Error on get ExamList WithCourses ExamType --> ", error);
        toast.error(error?.response?.data?.data[0]?.message);
        throw new Error(error);
      }
    }
    if (label === "Course") {
      if (id) {
        try {
          AuthStore.setLoading(true);
          const resp = await MainService.post(
            `${ApiRoutes?.getCoursebyExamId}`,
            {
              examId: id,
            }
          );
          let courseList = resp?.data?.data?.courses?.map((elm) => {
            return {
              id: elm?.id,
              Title: elm?.courseName,
              label: "SubCourse",
            };
          });
          CourseStore.setCourse(courseList);
          AuthStore.setLoading(false);
          return resp?.data?.data;
        } catch (error) {
          AuthStore.setLoading(false);
          console.log("Error on get course --> ", error);
          toast.error(error?.response?.data?.data[0]?.message);
          throw new Error(error);
        }
      }
    }
    if (label === "SubCourse") {
      if (id) {
        try {
          AuthStore.setLoading(true);
          const res = await MainService.post(
            `${ApiRoutes?.getSubCoursesByCourseId}`,
            { id: id }
          );
          if (res?.data?.isSuccess) {
            this.getSubCourseMenu(res?.data?.data);
            AuthStore.setLoading(false);
            return res?.data;
          }
        } catch (error) {
          AuthStore.setLoading(false);
          console.log("Get sub course by id error --> ", error);
          toast.error(error?.response?.data?.data[0]?.message);
          // throw new Error(error);
        }
      }
    } else if (label === "Subject") {
      if (id) {
        try {
          AuthStore.setLoading(true);
          const res = await MainService.post(
            `${ApiRoutes?.getSubjectssubCoursesId}`,
            { subCourseId: id }
          );
          if (res?.data?.isSuccess) {
            this.getsubjectMenu(res?.data?.data);
            AuthStore.setLoading(false);

            return res?.data;
          } else {
            AuthStore.setLoading(false);

            toast.error(res?.data?.messages);
          }
        } catch (error) {
          AuthStore.setLoading(false);
          console.log("Get sub course by id error --> ", error);
          throw new Error(error);
        }
      }
    } else if (label === "Topic") {
      if (id) {
        try {
          AuthStore.setLoading(true);
          const resp = await MainService.post(
            `${ApiRoutes?.getalltopicbysubjectID}`,
            {
              id: id,
            }
          );
          if (resp?.data?.isSuccess) {
            AuthStore.setLoading(false);
            this.getTopicList(resp?.data?.data?.topic);
            // console.log("resp?.data?.data?.topic---",resp?.data?.data?.topic);
            return resp?.data?.data?.topic;
          } else {
           
            // console.log("resp?.data?.data?.topic---",resp?.data?.data?.topic);
            AuthStore.setLoading(false);
            toast.error(resp?.data?.messages);
            return resp?.data?.data;
          }
        } catch (e) {
          AuthStore.setLoading(false);
          console.log("Error on get course by id --> ", e);
          toast.error(e?.response?.data?.message);
          throw e;
        }
      }
    }
  }

  getsubjectMenu = (value) => {
    let subjectMenu = value?.subjectCategories.map((elm) => {
      return {
        id: elm?.subjectCategoryId,
        Title: elm?.subjectName,
        label: "Topic",
      };
    });
    CourseStore.setsubject(subjectMenu)
  };

  getAllauthorlist = (value) => {
    let writer = value?.ebookAuthers.map((elm, i) => {
      return {
        id: i + 1,
        Title: elm?.autherName,
        label: "Writer",
      };
    });
    EbookStore.setWriter(writer)
  };

  getSubCourseMenu = (value) => {
    AuthStore.setLoading(true);
    if (!value?.subCourses)
      return toast.error("SubCourses Not Found Please add!!");
    let subcourseMenu = value?.subCourses?.map((elm) => {
      return {
        id: elm?.id,
        Title: elm?.subCourseName,
        label: "Subject",
      };
    });
    AuthStore.setLoading(false);
    CourseStore.setSubCourse(subcourseMenu);
    // console.log("get SubCourse Menu");
  };

  getTopicList = async (data) => {
    if (data) {
      let topicList = data?.map((elm, i) => {
        return {
          id: elm?.id,
          Title: elm?.topicName,
          active: i === 0 ? true : false,
          label: "SubTopic",
        };
      });
      CourseStore.setTopicList(topicList);
    }
    else {
      CourseStore.setTopicList([])
    }
  };

  UploadEbookImage = async (payLoad) => {
    let config;
    config = {
      headers: {
        "Content-Type": "multipart/form-data",
      },

    };
    try {
      AuthStore.setLoading(true);
      const resp = await MainService.post(
        `${ApiRoutes?.uploadebookthumbnail}`, payLoad,
        { headers: config.headers }
      );
      AuthStore.setLoading(false);
      return resp.data;
    } catch (error) {
      console.log("Error on upload ", error);
      AuthStore.setLoading(false);
      toast.error(error?.response?.data?.message)
      throw new Error(error);
    }
  };

  UploadEbookPdf = async (payLoad) => {
    let config;
    config = {
      headers: {
        "Content-Type": "multipart/form-data",
      },

    };
    try {
      AuthStore.setLoading(true);
      const resp = await MainService.post(
        `${ApiRoutes?.uploadebookpdf}`, payLoad,
        { headers: config.headers }
      );
      AuthStore.setLoading(false);
      return resp.data;
    } catch (error) {
      console.log("Error on upload ", error);
      AuthStore.setLoading(false);
      toast.error(error?.response?.data?.message)
      throw new Error(error);
    }
  };


  deleteEbook = async (data) => {
    let config = {
      headers: {
        "Content-Type": "application/json",
      },

    };
    try {
      AuthStore.setLoading(true);
      const resp = await MainService.delete(`${ApiRoutes?.deleteEbook}`, { ...config, data });
      AuthStore.setLoading(false);
      return resp?.data;
    } catch (error) {
      console.log("Error on deleteMockTest --> ", error);
      AuthStore.setLoading(false);
      toast.error(error?.response?.data?.message)
      throw new Error(error);
    }
  }


}
const EbookServices = new EbookService();
export default EbookServices;
