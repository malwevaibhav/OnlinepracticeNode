import { toast } from "react-toastify";
import AuthStore from "../MobX/Auth";
import { ApiRoutes } from "../shared/constant";
import MainService from "../utils/ServiceInterceptors";


class ResultService {
    getAllResult = async (payload) => {
        if (!payload) {
          payload = { pageNumber: 0, pageSize: 0 }
        }
        try {
          AuthStore.setLoading(true);
          const resp = await MainService.post(`${ApiRoutes?.getallResults}`, payload);
          AuthStore.setLoading(false);
          return resp?.data;
        } catch (error) {
          console.log("Error on getAllInstitute --> ", error);
          AuthStore.setLoading(false);
          toast.error(error?.response?.data?.data[0]?.message)
          throw new Error(error);
        }
      };
      getResultDetail = async (payload) => {
        try {
          AuthStore.setLoading(true);
          const resp = await MainService.post(`${ApiRoutes?.getResultByMocktestId}`, payload);
          AuthStore.setLoading(false);
          return resp?.data;
        } catch (error) {
          console.log("Error on getAllInstitute --> ", error);
          AuthStore.setLoading(false);
          toast.error(error?.response?.data?.data[0]?.message)
          throw new Error(error);
        }
      };

      getAllTransaction = async (payload) => {
        if (!payload) {
          payload = { pageNumber: 0, pageSize: 0 }
        }
        try {
          AuthStore.setLoading(true);
          const resp = await MainService.post(`${ApiRoutes?.getAllTransaction}`, payload);
          AuthStore.setLoading(false);
          return resp?.data;
        } catch (error) {
          console.log("Error on getAllInstitute --> ", error);
          AuthStore.setLoading(false);
          toast.error(error?.response?.data?.data[0]?.message)
          throw new Error(error);
        }
      };

      getTransactionDetail = async (payload) => {
        try {
          AuthStore.setLoading(true);
          const resp = await MainService.post(`${ApiRoutes?.getTransactionDetail}`, payload);
          AuthStore.setLoading(false);
          return resp?.data;
        } catch (error) {
          console.log("Error on getAllInstitute --> ", error);
          AuthStore.setLoading(false);
          toast.error(error?.response?.data?.data[0]?.message)
          throw new Error(error);
        }
      };

}


const ResultData = new ResultService();
export default ResultData;