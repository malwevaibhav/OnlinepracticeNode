import { toast } from "react-toastify";
import AuthStore from "../MobX/Auth";
import { ApiRoutes } from "../shared/constant";
import MainService from "../utils/ServiceInterceptors";


// let baseURL=process.env.REACT_APP_API_URL

class SubjectService {

  createSubject = async (payload) => {
    try {
      AuthStore?.setLoading(true);
      const resp = await MainService.post(
        `${ApiRoutes?.createsubject}`,
        payload
      );
      AuthStore?.setLoading(false);
      return resp?.data;
    } catch (error) {
      AuthStore?.setLoading(false);
      toast.error(error?.response?.data?.data[0]?.message)
      console.log("Error on subject--> ", error);
      throw new Error(error);
    }
  };

  getAllSubject = async (payload) => {
    if (!payload) {
      payload = { pageNumber: 0, pageSize: 0 }
    }
    try {
      AuthStore.setLoading(true)
      const resp = await MainService.post(`${ApiRoutes?.getSubject}`, payload);
      AuthStore.setLoading(false)
      return resp?.data?.data;
    } catch (error) {
      console.log("Error on get ExamList WithCourses ExamType --> ", error);
      AuthStore.setLoading(false)
      toast.error(error?.response?.data?.data[0]?.message)
      throw new Error(error);
    }
  };
}


const SubjectServices = new SubjectService();
export default SubjectServices;
