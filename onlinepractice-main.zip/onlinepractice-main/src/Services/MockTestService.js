import { toast } from "react-toastify";
import AuthStore from "../MobX/Auth";
import PatternStore from "../MobX/Pattern";
import QuestionStore from "../MobX/Question";
import { ApiRoutes } from "../shared/constant";
import MainService from "../utils/ServiceInterceptors";
import { data } from "../customcomponents/Chart/PieChart";

let config;
config = {
  headers: {
    "Content-Type": "application/json",
  },

};
class MocktestService {
  //#region  Mocktest setting page api 


  getAllMockTest = async (payload) => {
    if (!payload) {
      payload = { pageNumber: 0, pageSize: 0 }
    }
    try {
      AuthStore.setLoading(true);
      const resp = await MainService.post(`${ApiRoutes?.getAllMockTest}`, payload);
      AuthStore.setLoading(false);
      console.log("data=>>>>>",data)
      return resp?.data;
    } catch (error) {
      console.log("Error on getAllMockTest --> ", error);
      AuthStore.setLoading(false);
      toast.error(error?.response?.data?.data[0]?.message)
      throw new Error(error);
    }
  };

  getMockTestById = async (payload) => {
    try {
      AuthStore.setLoading(true);
      const resp = await MainService.post(`${ApiRoutes?.mockTestById}`, payload)
      if (resp) AuthStore.setLoading(false);
      return resp?.data;
    } catch (error) {
      console.log("Error on getMockTestById --> ", error);
      AuthStore.setLoading(false);
      toast.error(error?.response?.data?.data[0]?.message)
      throw new Error(error);
    }
  };

  getMockQuestionById = async (payload) => {
    try {
      AuthStore.setLoading(true);
      const resp = await MainService.post(`${ApiRoutes?.getMockQuestionById}`, payload)
      AuthStore.setLoading(false);
      return resp?.data;
    } catch (error) {
      console.log("Error on getMockTestById --> ", error);
      AuthStore.setLoading(false);
      toast.error(error?.response?.data?.data)
      throw new Error(error);
    }
  }

  createMockTest = async (payload) => {
    try {
      AuthStore.setLoading(true);
      const resp = await MainService.post(`${ApiRoutes?.createMockTest}`, payload);
      AuthStore.setLoading(false);
      return resp?.data;
    } catch (error) {
      console.log("Error on create MockTest --> ", error);
      AuthStore.setLoading(false);
      toast.error(error.response.data.data[0]?.message);
      throw new Error(error);
    }
  };

  updateMockTest = async (payload) => {
    try {
      AuthStore.setLoading(true);
      const resp = await MainService.put(`${ApiRoutes?.updateMockTest}`, payload);
      AuthStore.setLoading(false);
      return resp?.data;
    } catch (error) {
      console.log("Error on updateMockTest --> ", error);
      AuthStore.setLoading(false);
      toast.error(error?.response?.data?.data[0]?.message)
      throw new Error(error);
    }
  };

  deleteMockTest = async (payload) => {
    try {
      AuthStore.setLoading(true);
      const resp = await MainService.delete(`${ApiRoutes?.deleteMockTest}`, { ...config, data: payload }
      );
      AuthStore.setLoading(false);
      return resp?.data;
    } catch (error) {
      console.log("Error on deleteMockTest --> ", error);
      AuthStore.setLoading(false);
      toast.error(error?.response?.data?.data[0]?.message)
      throw new Error(error);
    }
  };

  //#endregion
  //#region  step 2 API's
  getSubjectByPatternId = async (Id) => {
    try {
      AuthStore.setLoading(true);
      const resp = await MainService.post(
        `${ApiRoutes?.getSubjectbyPatternId}`,
        {
          id: Id,
        }
      );
      if (resp?.data?.isSuccess) {
        AuthStore.setLoading(false);
        this.getSubjectList(resp?.data?.data);
        return resp?.data?.data;
      } else {
        AuthStore.setLoading(false);
        toast.error(resp?.data?.messages);
      }
    } catch (e) {
      AuthStore.setLoading(false);
      console.log("Error on get course by id --> ", e);
      toast.error(e?.response?.data?.message);
      throw e;
    }
  };

  getSubjectList = async (data) => {
    let subjectList = data?.examPatternSubjects?.map((elm) => {
      return {
        id: elm?.subjectId,
        Title: elm?.subjectName,
        label: 'SubjectPattern'
      };
    });
    PatternStore.setsubject(subjectList);
  };

  getTopicListbySubjectpattern = async (Id) => {
    try {
      AuthStore.setLoading(true);
      const resp = await MainService.post(
        `${ApiRoutes?.getTopicListbySubjectpattern}`,
        {
          subCourseId: QuestionStore.selectedItemsNw.SubCourseList?.id,
          subjectId: Id
        }
      );
      if (resp?.data?.isSuccess) {
        AuthStore.setLoading(false);
        this.getTopicList(resp?.data?.data);
        return resp?.data?.data;
      } else {
        AuthStore.setLoading(false);
        toast.error(resp?.data?.messages);
      }
    } catch (e) {
      AuthStore.setLoading(false);
      console.log("Error on get course by id --> ", e);
      toast.error(e?.response?.data?.message);
      throw e;
    }
  };

  getSubTopic = async (Id) => {
    try {
      AuthStore.setLoading(true);
      const resp = await MainService.post(
        `${ApiRoutes?.getsubtopicbyId}`,
        {
          id: Id,
        }
      );
      if (resp?.data?.isSuccess) {
        this.getSubTopicList(resp?.data?.data?.subTopics);
        AuthStore.setLoading(false);
        return resp?.data?.data?.subTopics;
      } else {
        this.getSubTopicList(false);
        toast.error(resp?.data?.messages);
        AuthStore.setLoading(false);
      }
    } catch (e) {
      console.log("Error on get course by id --> ", e);
      toast.error(e?.response?.data?.message);
      throw e;
    }
  };

  getSectionbyPatternId = async (payload) => {
    try {
      AuthStore.setLoading(true);
      const resp = await MainService.post(
        `${ApiRoutes?.getSectionbyPatternId}`, payload
      );
      if (resp?.data?.isSuccess) {
        this.getSectionList(resp?.data?.data?.examPatternSections);
        AuthStore.setLoading(false);
        return resp?.data?.data?.examPatternSections;
      } else {
        toast.error(resp?.data?.messages);
        AuthStore.setLoading(false);
      }
    } catch (e) {
      console.log("Error on get course by id --> ", e);
      toast.error(e?.response?.data?.message);
      throw e;
    }
  };

  getTopicList = async (data) => {
    let topicList = data?.topic?.map((elm) => {
      return {
        id: elm?.id,
        Title: elm?.topicName,
        label: 'TopicPattern'
      };
    });
    PatternStore.setTopics(topicList);
  };

  getSubTopicList = async (data) => {
    let subtopicList = data?.map((elm) => {
      return {
        id: elm?.id,
        Title: elm?.subTopicName,
        label: 'SubTopicPattern'
      };
    });
    PatternStore.setSubTopics(subtopicList);
  };

  getSectionList = async (data) => {
    let SectionList = data?.map((elm) => {
      return {
        // ...elm,
        id: elm?.id,
        Title: elm?.sectionName,
        totalAttempt: elm.totalAttempt,
        totalQuestions: elm.totalQuestions,
        label: 'SectionList',
      };
    });
    PatternStore.setSectionList(SectionList);
  };

  getQuestionByFilter = async (payload) => {
    if (!payload) {
      payload = { pageNumber: 0, pageSize: 0 }
    }
    try {
      AuthStore.setLoading(true);
      const resp = await MainService.post(`${ApiRoutes?.getQuesByFilter}`, payload);
      AuthStore.setLoading(false);
      return resp?.data;
    } catch (error) {
      console.log("Error on getQuesByFilter --> ", error);
      AuthStore.setLoading(false);
      toast.error(error?.response?.data?.data[0]?.message)
      throw new Error(error);
    }
  };

  updatemocktestquestions = async (payload) => {
    try {
      AuthStore.setLoading(true);
      const resp = await MainService.post(`${ApiRoutes?.updatemocktestquestions}`, payload);
      AuthStore.setLoading(false);
      return resp?.data;
    } catch (error) {
      console.log("Error on create mock test questions --> ", error);
      AuthStore.setLoading(false);
      toast.error(error.response.data.data[0]?.message);
      throw new Error(error);
    }
  };

  mockTestQuestionById = async (payload) => {
    try {
      AuthStore.setLoading(true);
      const resp = await MainService.post(`${ApiRoutes?.mockTestQuestionById}`, payload)
      AuthStore.setLoading(false);
      return resp?.data;
    } catch (error) {
      console.log("Error on mockTestQuestionById --> ", error);
      AuthStore.setLoading(false);
      // toast.error(error?.response?.data?.data)
      throw new Error(error);
    }
  }

  generateAutoMockTest = async (payload) => {
    try {
      AuthStore.setLoading(true);
      const resp = await MainService.post(`${ApiRoutes?.generateautomatictmocktest}`, payload)
      AuthStore.setLoading(false);
      return resp?.data;
    } catch (error) {
      console.log("Error on mockTestQuestionById --> ", error);
      AuthStore.setLoading(false);
      toast.error(error?.response?.data?.data)
      throw new Error(error);
    }
  }
  //#endregion
  //#region  3rd Step
  publishMockTest = async (payload) => {
    try {
      AuthStore.setLoading(true);
      const resp = await MainService.post(`${ApiRoutes?.publishMockTest}`, payload);
      AuthStore.setLoading(false);
      return resp?.data;
    } catch (error) {
      console.log("Error on Publish mock test --> ", error);
      AuthStore.setLoading(false);
      toast.error(error.response.data.data[0]?.message);
      throw new Error(error);
    }
  };
  
  MockTestPdf = async (payload) => {
    console.log("payload-from-pdf=>>>>",payload)
    try {
      AuthStore.setLoading(true);
      const resp = await MainService.post(`${ApiRoutes?.getQueForPdf}`, payload);
      AuthStore.setLoading(false);
      return resp?.data;
    } catch (error) {
      console.log("Error on pdf mock test --> ", error);
      AuthStore.setLoading(false);
      toast.error(error.response.data.data[0]?.message);
      throw new Error(error);
    }
  };
  //#endregion


}
const MocktestServices = new MocktestService();
export default MocktestServices;


