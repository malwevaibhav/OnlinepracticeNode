import { toast } from "react-toastify";
import { ApiRoutes } from "../shared/constant";
import MainService from "../utils/ServiceInterceptors";



class QuestionTypeService {
    getQuestionBankList = async () => {
        try {
            const resp = await MainService.get(`${ApiRoutes?.getQuestionBankList}`);
            return resp?.data?.data?.QuestionType;
        } catch (error) {
            console.log("Error on get QuestionList WithCourses QuestionType --> ", error);
            toast.error(error?.response?.data?.message)
            throw new Error(error);
        }
    };

    getAllLanguage = async () => {
        try {
            const resp = await MainService.get(`${ApiRoutes?.getAllLanguage}`);
            return resp?.data;
        } catch (error) {
            console.log("Error on get QuestionList WithCourses QuestionType --> ", error);
            toast.error(error?.response?.data?.message)
            throw new Error(error);
        }
    };

    getAllLevel = async () => {
        try {
            const resp = await MainService.get(`${ApiRoutes?.getAllLevel}`);
            return resp?.data;
        } catch (error) {
            console.log("Error on get QuestionList WithCourses QuestionType --> ", error);
            toast.error(error?.response?.data?.message)
            throw new Error(error);
        }
    };

    getQuestionbyQuestionId = async (payload) => {
        try {
            const resp = await MainService.post(`${ApiRoutes?.getQuestionbyQuestionId}`, {
                QuestionId: payload
            });
            if (resp?.data?.isSuccess) {

                return resp?.data
            } else {

            }

        } catch (error) {
            console.log("Error on get QuestionId by id --> ", error);
            toast.error(error?.response?.data?.message)
            throw error;
        }

    }

    getAllQuestionType = async () => {
        try {
            const resp = await MainService.get(`${ApiRoutes?.getallquestiontype}`);
            return resp?.data?.data;
        } catch (error) {
            console.log("Error on get QuestionList WithCourses QuestionType --> ", error);
            toast.error(error?.response?.data?.data[0]?.message)
            throw new Error(error);
        }
    };
    
    getAllAddedBy = async () => {
        try {
            const resp = await MainService.get(`${ApiRoutes?.getAllAddedBy}`);
            return resp?.data?.data;
        } catch (error) {
            console.log("Error on get getAllAddedBy --> ", error);
            toast.error(error?.response?.data?.message)
            throw new Error(error);
        }
    };

    
}
const QuestionTypeServices = new QuestionTypeService()
export default QuestionTypeServices;