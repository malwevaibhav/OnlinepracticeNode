import { MathJaxContext } from "better-react-mathjax";
import { toJS } from "mobx";
import { observer } from "mobx-react-lite";
import { useLayoutEffect } from "react";
import { Navigate, Outlet, Route, Routes } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import "./App.css";
import AuthStore from "./MobX/Auth";
import Loader from "./customcomponents/loader/loader";
import BaseLayout from "./pages/layout/layout";
import AddUpdatePYP from "./pages/privatePage/PreviouseYrPaper/AddUpdatePYP";
import PYP from "./pages/privatePage/PreviouseYrPaper/PYP";
import PYPDetail from "./pages/privatePage/PreviouseYrPaper/PYPDetail";
import PrivateLayout from "./pages/privatePage/PrivateRoute";
import Course from "./pages/privatePage/course/Course";
import CourseModule from "./pages/privatePage/course/courseModule/courseModule";
import CourseTopic from "./pages/privatePage/course/courseTopic/CourseTopic";
import AddNewSubject from "./pages/privatePage/course/subject/newsubject";
import Dashboard from "./pages/privatePage/dashboard";
import Ebook from "./pages/privatePage/ebook/Ebook";
import AddNewBook from "./pages/privatePage/ebook/component/addNewBook";
import PurchaseEbook from "./pages/privatePage/ebook/component/purchaseEbook";
import Institute from "./pages/privatePage/institute/institute";
import InstituteDetail from "./pages/privatePage/institute/instituteDetail/instituteDetail";
import MocktestPage from "./pages/privatePage/mockTest/MocktestPage";
import ViewMocktest from "./pages/privatePage/mockTest/component/viewMocktest";
import MockTestCreate from "./pages/privatePage/mockTest/createMockTest/MockTestCreat";
import AddPattern from "./pages/privatePage/pattern/AddPattern";
import Pattern from "./pages/privatePage/pattern/Pattern";
import GeneralInstruction from "./pages/privatePage/pattern/generalInstruction";
import PatternDetails from "./pages/privatePage/pattern/patternDetails";
import QuestionUpload from "./pages/privatePage/questionBank/component/quesUpload/questionUpload";
import QuestionDetails from "./pages/privatePage/questionBank/component/quetionDetails/questionDetails";
import QuestionPage from "./pages/privatePage/questionBank/questionPage";
import Result from "./pages/privatePage/result/Result";
import ResultDetail from "./pages/privatePage/result/ResultDetail";
import AdminSetting from "./pages/privatePage/settings/AdminSetting";
import StaffList from "./pages/privatePage/staff/staffList";
import StaffDetails from "./pages/privatePage/staffDetails/StaffDetails";
import StudentDetails from "./pages/privatePage/student/studentDetails";
import StudentList from "./pages/privatePage/student/studentList";
import Subject from "./pages/privatePage/subject/Subject";
import AddNewVideo from "./pages/privatePage/video/component/addNewVideo";
import VideoPurchase from "./pages/privatePage/video/component/videoPurchase";
import Video from "./pages/privatePage/video/video";
import { ClientRoutesConstants, allowedRoles } from "./shared/constant";
import Transaction from "./pages/privatePage/Transaction/Transaction";
import TransactionDetail from "./pages/privatePage/Transaction/component/transactionDetail";
function App() {
  const auth = toJS(AuthStore?.user?.user);
  const loading = toJS(AuthStore?.isLoading);
  useLayoutEffect(() => {
    const loginData = localStorage.getItem("key");
    AuthStore.setUser(JSON.parse(loginData));
  }, []);
  const config = { loader: { load: ["[tex]/html"] }, tex: { packages: { "[+]": ["html"] }, inlineMath: [["$", "$"], ["\\(", "\\)"]], displayMath: [["$$", "$$"], ["\\[", "\\]"]] } };
  return (
    <MathJaxContext config={config}>
      <div className="App">
        <ToastContainer />
        {loading && <Loader />}
        {auth && (
          <Routes>
            <Route
              element={<PrivateLayout allowedroles={[allowedRoles?.admin]} />}
            >
              <Route path="dashboard" element={<Dashboard />} />
              <Route index element={<Navigate to="/dashboard" />} />
              <Route path="staff-list" element={<StaffList />} />
              <Route path="staff-details" element={<StaffDetails />} />
              <Route path="courses" element={<Course />} />
              <Route path="course-topic" element={<CourseTopic />} />
              <Route path="createCourse" element={<CourseModule />} />
              <Route path="new-subject" element={<AddNewSubject />} />
              <Route path="subject" element={<Subject />} />
              <Route path="institute" element={<Institute />} />
              <Route path="institute-detail" element={<InstituteDetail />} />
              <Route path="pattern" element={<Pattern />} />
              <Route path="add-pattern" element={<AddPattern />} />
              <Route path="pattern-details" element={<PatternDetails />} />
              <Route path="student-details" element={<StudentDetails />} />
              <Route path="student-list" element={<StudentList />} />
              <Route path="transaction" element={<Transaction />} />
              <Route path="translation-details" element={<TransactionDetail/>} />
              <Route path="general-instruction" element={<GeneralInstruction />} />
              <Route path="result" element={ <Result />}/>
              <Route path="resultDetail" element={<ResultDetail /> } />

            </Route>
            <Route
              element={<PrivateLayout allowedroles={[allowedRoles?.staff, allowedRoles?.admin]} />}
            >
              <Route path="question-bank" element={<QuestionPage />} />
              <Route path="question-upload" element={<QuestionUpload />} />
              <Route path="question-detail" element={<QuestionDetails />} />

              <Route path="mocktest" element={<ProtectedRoute
                redirectPath="/settings"
                isAllowed={!!auth && auth?.permision?.includes('MockTest')}>
                <MocktestPage />
              </ProtectedRoute>
              } />
              <Route path="create-Mocktest" element={
                <ProtectedRoute
                  redirectPath="/settings"
                  isAllowed={!!auth && auth?.permision?.includes('MockTest')}>
                  <MockTestCreate />
                </ProtectedRoute>} />

              <Route path="viewAutomatic" element={<ProtectedRoute
                redirectPath="/settings"
                isAllowed={!!auth && auth?.permision?.includes('MockTest')}>
                <ViewMocktest />
              </ProtectedRoute>} />

              <Route path="ebook" element={<ProtectedRoute
                redirectPath="/settings"
                isAllowed={!!auth && auth?.permision?.includes('Ebook')}>
                <Ebook />
              </ProtectedRoute>} />

              <Route path="add-newbook" element={<ProtectedRoute
                redirectPath="/settings"
                isAllowed={!!auth && auth?.permision?.includes('Ebook')}>
                <AddNewBook />
              </ProtectedRoute>
              } />

              <Route path="purchase-Ebook" element={<ProtectedRoute
                redirectPath="/settings"
                isAllowed={!!auth && auth?.permision?.includes('Ebook')}>
                <PurchaseEbook />
              </ProtectedRoute>
              } />

             
              <Route path="video" element={<ProtectedRoute
                redirectPath="/settings"
                isAllowed={!!auth && auth?.permision?.includes('Videos')}>
                <Video />
              </ProtectedRoute>
              } />

              <Route path="video-purchase" element={<ProtectedRoute
                redirectPath="/settings"
                isAllowed={!!auth && auth?.permision?.includes('Videos')}>
                <VideoPurchase />
              </ProtectedRoute>
              } />

              <Route path="add-NewVideo" element={
                <ProtectedRoute
                  redirectPath="/settings"
                  isAllowed={!!auth && auth?.permision?.includes('Videos')}>
                  <AddNewVideo />
                </ProtectedRoute>} />

              <Route path="previous-year-paper" element={
                <ProtectedRoute
                  redirectPath="/settings"
                  isAllowed={!!auth && auth?.permision?.includes('Previous Year Paper')}>
                  <PYP />
                </ProtectedRoute>} />

              <Route path="new-paper" element={<ProtectedRoute
                redirectPath="/settings"
                isAllowed={!!auth && auth?.permision?.includes('Previous Year Paper')}>
                <AddUpdatePYP />
              </ProtectedRoute>} />

              <Route path="paper-detail" element={<ProtectedRoute
                redirectPath="/settings"
                isAllowed={!!auth && auth?.permision?.includes('Previous Year Paper')}>
                <PYPDetail />
              </ProtectedRoute>
              } />
              <Route path="settings" element={<AdminSetting />} />
            </Route>
            <Route
              index
              element={
                auth?.role === "Admin" ? (
                  <Navigate to="/dashboard" />
                ) : (
                  <Navigate to="/mocktest" />
                )
              }
            />
            <Route
              path="*"
              element={
                auth?.role === "Admin" ? (
                  <Navigate to="/dashboard" />
                ) : (
                  <Navigate to="/settings" />
                )
              }
            />
          </Routes>
        )}
        {!auth && (
          <>
            <Routes>
            {/* <Route
               path="/"
                element={<Navigate to={ClientRoutesConstants.login} />}
              /> */}
              <Route path="auth/*" element={<BaseLayout />} />
              <Route
                index
                element={<Navigate to={ClientRoutesConstants.login} />}
              />
             

            </Routes>
          </>
        )}
      </div>
    </MathJaxContext>
  );
  // updated new 
}
const ProtectedRoute = ({
  isAllowed,
  redirectPath = 'settings',
  children,
}) => {
  if (!isAllowed) {
    return <Navigate to={redirectPath} replace />;
  }

  return children ? children : <Outlet />;
};

export default observer(App);
