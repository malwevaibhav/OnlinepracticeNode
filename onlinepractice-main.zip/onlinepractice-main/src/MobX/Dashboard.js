import { makeAutoObservable, toJS } from "mobx";
class Dashboard {

    sales= {selectedName:"Monthly", id: 3 };
    enrollment= {selectedName:"Monthly", id: 3 };
    totalSales={selectedName:"This month", id: 3};
    studentEnrollment= {selectedName:"This month", id: 3};
    instituteCount= {selectedName:"This month", id: 3}

    constructor() {
        makeAutoObservable(this)
     }  

     selectedsales = (data) => {
        this.sales = { ...this.sales, ...data } 
      }

     selectedenrollment = (data) => {
        this.enrollment = { ...this.enrollment, ...data }
      }

     selectedtotalSales = (data) => {
        this.totalSales = { ...this.totalSales, ...data }
      }

     selectedstudentEnrollment = (data) => {
        this.studentEnrollment= { ...this.studentEnrollment, ...data }
      }
      
     selectedinstituteCount = (data) => {
        this.instituteCount = { ...this.instituteCount, ...data }
      }
     


}
const DashboardStore = new Dashboard();
export default DashboardStore