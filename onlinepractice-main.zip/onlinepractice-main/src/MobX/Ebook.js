import { makeAutoObservable } from "mobx";
class Ebook {

  ebookselectedids = {
    examTypeId: "",
    courseId: "",
    subCourseId: "",
    subjectCategory: "",
    topicId: "",
    instituteId: "",
    writer: "",
    mocktestId:""

  }
  writer = [];

  constructor() {
    makeAutoObservable(this)
  }

  setEbookSelectedid = (data) => {
    this.ebookselectedids = { ...this.ebookselectedids, ...data }
  }

  setWriter = (data) => {
    this.writer = data
  }
  clear = () => {
    this.ebookselectedids = {
      examTypeId: "",
      courseId: "",
      subCourseId: "",
      subjectCategory: "",
      topicId: "",
      instituteId: "",
      writer: "",
    }
    this.writer = [];
  }

}
const EbookStore = new Ebook();
export default EbookStore