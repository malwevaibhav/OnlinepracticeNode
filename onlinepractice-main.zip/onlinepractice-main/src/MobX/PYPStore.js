import { makeAutoObservable } from "mobx";
class PYPStore {
    constructor() {
        makeAutoObservable(this)
    }
    examList = [];
    course = [];
    subcourse = [];
    selectedItemsNw = {
        examList: { selectedName: "", id: "", props: {} },
        courseList: { selectedName: "", id: "", props: {} },
        SubCourseList: { selectedName: "", id: "", props: {} },
        InstituteList: { selectedName: "", id: "", props: {} },
        YearList: { selectedName: "", id: "", props: {} },
        addedByList: { selectedName: "", id: "", props: {} },
    };

    setexamList = (examdata) => {
        this.examList = examdata
    }

    setCourse = (courseData) => {
        this.course = courseData
    }

    setSubCourse = (subcourseData) => {
        this.subcourse = subcourseData
    }

    setSelectedItems = (payload) => {
        this.selectedItemsNw = payload
    }
    clear = () => {
        this.examList = [];
        this.course = [];
        this.subcourse = [];
        this.selectedItemsNw = {
            examList: { selectedName: "", id: "", props: {} },
            courseList: { selectedName: "", id: "", props: {} },
            SubCourseList: { selectedName: "", id: "", props: {} },
            InstituteList: { selectedName: "", id: "", props: {} },
            YearList: { selectedName: "", id: "", props: {} },
            addedByList: { selectedName: "", id: "", props: {} },
        };
    }

    setSelectedItemsNw = (payload) => {
        if (payload?.selectedName === "Exam") {
            this.selectedItemsNw = {
                ...this.selectedItemsNw,
                examList: { id: payload?.props.id, selectedName: payload.entityName, props: payload?.props },
                courseList: { selectedName: "", id: "", props: {} },
                SubCourseList: { selectedName: "", id: "", props: {} },
            }
        }
        if (payload?.selectedName === "Course") {
            this.selectedItemsNw = {
                ...this.selectedItemsNw, courseList: { id: payload?.props.id, selectedName: payload.entityName, props: payload?.props },
                SubCourseList: { selectedName: "", id: "", props: {} },
            }
        }
        if (payload?.selectedName === "SubCourse") {
            this.selectedItemsNw = {
                ...this.selectedItemsNw, SubCourseList: { id: payload?.props.id, selectedName: payload.entityName, props: payload?.props },
            }

        }
        if (payload?.selectedName === "Year") {
            this.selectedItemsNw = {
                ...this.selectedItemsNw, YearList: { id: payload?.props.id, selectedName: payload.entityName, props: payload?.props },
            }

        }
        if (payload?.selectedName === "Institute") {

            this.selectedItemsNw = {
                ...this.selectedItemsNw, InstituteList: { id: payload?.props.id, selectedName: payload.entityName, props: payload?.props },

            }

        }
        if (payload?.selectedName === "AddedBy") {
            this.selectedItemsNw = {
                ...this.selectedItemsNw, addedByList: { id: payload?.props.id, selectedName: payload.entityName, props: payload?.props },
            }

        }
    }
}


const PYPStores = new PYPStore();
export default PYPStores