import { makeAutoObservable } from "mobx";
import QuestionStore from "./Question";
class Pattern {
    selectedItemsPattern = {
        pattern: { selectedName: "", id: "", props: {} },
        Institute: { selectedName: "", id: "", props: {} },
        Language: { selectedName: "", id: "", props: {} },
        SubjectList: { selectedName: "", id: "", props: {} },
        TopicList: { selectedName: "", id: "", props: {} },
        SubTopicList: { selectedName: "", id: "", props: {} },
        SectionList: { selectedName: "", id: "", props: {} },
        QuestionTypeList: { selectedName: "", id: "", props: {} },
        mockTestType: { selectedName: "", id: "", props: {} }
    }
    subjectList = []
    TopicList = []
    SubTopicList = []
    SectionList = []
    constructor() {
        makeAutoObservable(this)
    }
    setSelectedItemsPattern = (payload) => {
        if (payload?.selectedName === "Pattern") {
            this.selectedItemsPattern = { ...this.selectedItemsPattern, pattern: { id: payload?.props.id, selectedName: payload.entityName, props: payload?.props } }
            this.selectedItemsPattern = { ...this.selectedItemsPattern, SubjectList: {} }
            this.selectedItemsPattern = { ...this.selectedItemsPattern, TopicList: {} }
            this.selectedItemsPattern = { ...this.selectedItemsPattern, SubTopicList: {} }
            this.selectedItemsPattern = { ...this.selectedItemsPattern, SectionList: {} }
            QuestionStore.selectedItemsNw.questionType = {}
        }
        if (payload?.selectedName === "Institute") {
            this.selectedItemsPattern = { ...this.selectedItemsPattern, Institute: { id: payload?.props.id, selectedName: payload.entityName, props: payload?.props } }

        }
        if (payload?.selectedName === "Language") {
            this.selectedItemsPattern = { ...this.selectedItemsPattern, Language: { id: payload?.props.id, selectedName: payload.entityName, props: payload?.props } }
        }
        if (payload?.selectedName === "SubjectPattern") {
            this.selectedItemsPattern = { ...this.selectedItemsPattern, TopicList: {} }
            this.selectedItemsPattern = { ...this.selectedItemsPattern, SubTopicList: {} }
            this.selectedItemsPattern = { ...this.selectedItemsPattern, SectionList: {} }
            QuestionStore.selectedItemsNw.questionType = {}
            this.selectedItemsPattern = { ...this.selectedItemsPattern, SubjectList: { id: payload?.props.id, selectedName: payload.entityName, props: payload?.props } }
        }
        if (payload?.selectedName === "TopicPattern") {
            this.selectedItemsPattern = { ...this.selectedItemsPattern, SubTopicList: {} }
            this.selectedItemsPattern = { ...this.selectedItemsPattern, SectionList: {} }
            QuestionStore.selectedItemsNw.questionType = {}
            this.selectedItemsPattern = { ...this.selectedItemsPattern, TopicList: { id: payload?.props.id, selectedName: payload.entityName, props: payload?.props } }
        }
        if (payload?.selectedName === "SubTopicPattern") {
            this.selectedItemsPattern = { ...this.selectedItemsPattern, SectionList: {} }
            QuestionStore.selectedItemsNw.questionType = {}
            this.selectedItemsPattern = { ...this.selectedItemsPattern, SubTopicList: { id: payload?.props.id, selectedName: payload.entityName, props: payload?.props } }
        }
        if (payload?.selectedName === "SectionList") {
            this.selectedItemsPattern = { ...this.selectedItemsPattern, SectionList: { id: payload?.props.id, selectedName: payload.entityName, props: payload?.props } }
        }
        if(payload?.selectedName ==="mockTestType"){
            this.selectedItemsPattern = { ...this.selectedItemsPattern, mockTestType: { id: payload?.props.id, selectedName: payload.entityName, props: payload?.props } }

        }
    }
    setsubject = async (data) => {
        this.subjectList = data
    }
    setTopics = (data) => {
        this.TopicList = data
    }
    setSubTopics = (data) => {
        this.SubTopicList = data
    }
    setSectionList = (data) => {
        this.SectionList = data
    }
    clear = () => {
        this.selectedItemsPattern = {
            pattern: { selectedName: "", id: "", props: {} },
            Institute: { selectedName: "", id: "", props: {} },
            Language: { selectedName: "", id: "", props: {} },
            SubjectList: { selectedName: "", id: "", props: {} },
            TopicList: { selectedName: "", id: "", props: {} },
            SubTopicList: { selectedName: "", id: "", props: {} },
            SectionList: { selectedName: "", id: "", props: {} },
            QuestionTypeList: { selectedName: "", id: "", props: {} }
        }
        this.subjectList = []
        this.TopicList = []
        this.SubTopicList = []
        this.SectionList = []
    }
}


const PatternStore = new Pattern();
export default PatternStore