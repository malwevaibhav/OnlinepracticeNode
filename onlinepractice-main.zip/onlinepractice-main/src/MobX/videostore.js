import { makeAutoObservable } from "mobx";
class Video {
    // constructor() {
    //     makeAutoObservable(this)
    // }
    examList = [];
    course = [];
    subcourse = [];
    subject = [];
    topic = [];
    selectedItemsNw = {
        examList: { selectedName: "", id: "", props: {} },
        courseList: { selectedName: "", id: "", props: {} },
        SubCourseList: { selectedName: "", id: "", props: {} },
        subjectList: { selectedName: "", id: "", props: {} },
        topicList: { selectedName: "", id: "", props: {} },
        facultyList: { selectedName: "", id: "", props: {} },
        InstituteList: { selectedName: "", id: "", props: {} },
        addedByList: { selectedName: "", id: "", props: {} },
    };
    faculty = [];
    selectedLanguage = "";

    constructor() {
        makeAutoObservable(this);
    }
    setexamList = (examdata) => {
        this.examList = examdata;
    };

    setCourse = (courseData) => {
        this.course = courseData;
    };

    setSubCourse = (subcourseData) => {
        this.subcourse = subcourseData;
    };
    setSubject = (SubjectData) => {
        this.subject = SubjectData;
    };
    setTopic = (TopictData) => {
        this.topic = TopictData;
        this.topic.push({ id: "00000000-0000-0000-0000-000000000000", Title: "None", label: 'SubTopic' })
    };

    setSelectedItemsNw = (payload) => {
        if (payload?.selectedName === "Exam") {
            this.selectedItemsNw = {
                ...this.selectedItemsNw,
                examList: {
                    id: payload?.props.id,
                    selectedName: payload.entityName,
                    props: payload?.props,
                },
                courseList: { selectedName: "", id: "", props: {} },
                SubCourseList: { selectedName: "", id: "", props: {} },
                SubjectList: { selectedName: "", id: "", props: {} },
                TopicList: { selectedName: "", id: "", props: {} },
            };
        }
        if (payload?.selectedName === "Course") {
            this.selectedItemsNw = {
                ...this.selectedItemsNw,
                courseList: {
                    id: payload?.props.id,
                    selectedName: payload.entityName,
                    props: payload?.props,
                },
                SubCourseList: { selectedName: "", id: "", props: {} },
                SubjectList: { selectedName: "", id: "", props: {} },
                TopicList: { selectedName: "", id: "", props: {} },
            };
        }
        if (payload?.selectedName === "SubCourse") {
            this.selectedItemsNw = {
                ...this.selectedItemsNw,
                SubCourseList: {
                    id: payload?.props.id,
                    selectedName: payload.entityName,
                    props: payload?.props,
                },
                SubjectList: { selectedName: "", id: "", props: {} },
                TopicList: { selectedName: "", id: "", props: {} },
            };
        }
        if (payload?.selectedName === "Subject") {
            this.selectedItemsNw = {
                ...this.selectedItemsNw,
                subjectList: {
                    id: payload?.props.id,
                    selectedName: payload.entityName,
                    props: payload?.props,
                },
                TopicList: { selectedName: "", id: "", props: {} },
            };
        }
        if (payload?.selectedName === "Topic") {
            this.selectedItemsNw = {
                ...this.selectedItemsNw,
                topicList: {
                    id: payload?.props.id,
                    selectedName: payload.entityName,
                    props: payload?.props,
                },
            };
        }

        if (payload?.selectedName === "Institute") {
            this.selectedItemsNw = {
                ...this.selectedItemsNw,
                InstituteList: {
                    id: payload?.props.id,
                    selectedName: payload.entityName,
                    props: payload?.props,
                },
            };
        }
        if (payload?.selectedName === "author") {
            this.selectedItemsNw = {
                ...this.selectedItemsNw, facultyList: { id: payload?.props.id, selectedName: payload.entityName, props: payload?.props },
            }
        }
    };

    setSelectedItems = (payload) => {
        this.selectedItemsNw = payload;
    };
    setvideo = (data) => {
        this.video = { ...this.video, ...data };
    };

    setVideoSelectedid = (data) => {
        this.videoselecte = { ...this.videoselecte, ...data };
    };

    setFaculty = (data) => {
        this.faculty = data;
    };

    setSelectedlanguage = (data) => {
        this.selectedLanguage = data
    };
    clear = () => {
        this.examList = [];
        this.course = [];
        this.subcourse = [];
        this.subject = [];
        this.topic = [];
        this.selectedItemsNw = {
            examList: { selectedName: "", id: "", props: {} },
            courseList: { selectedName: "", id: "", props: {} },
            SubCourseList: { selectedName: "", id: "", props: {} },
            subjectList: { selectedName: "", id: "", props: {} },
            topicList: { selectedName: "", id: "", props: {} },
            facultyList: { selectedName: "", id: "", props: {} },
            InstituteList: { selectedName: "", id: "", props: {} },
            addedByList: { selectedName: "", id: "", props: {} },
        };
        this.faculty = [];
        this.selectedLanguage = "";
    }
}
const VideoStore = new Video();
export default VideoStore; 