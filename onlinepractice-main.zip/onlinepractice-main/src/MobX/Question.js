import { makeAutoObservable } from "mobx";
class Question {

    languageSelected = {};
    levelSelected = {};
    questionData = {};
    authorList = [];
    responseData = {};
    questionlevel = "";
    marks =
        {
            mark: 0,
            negativeMark: 0,
            isPartiallyCorrect: false,
            partialThreeCorrectMark: 0,
            partialTwoCorrectMark: 0,
            partialOneCorrectMark: 0
        };
    selectedItems = [];
    levelId = "";
    Language = [];
    questionType = [];
    Level = [];
    LevelList = []
    selectedfilter = {};
    selectedItemsNw = {
        examList: { selectedName: "", id: "", props: {} },
        courseList: { selectedName: "", id: "", props: {} },
        SubCourseList: { selectedName: "", id: "", props: {} },
        SubjectList: { selectedName: "", id: "", props: {} },
        TopicList: { selectedName: "", id: "", props: {} },
        SubTopicList: { selectedName: "", id: "", props: {} },
        questionType: { selectedName: "", id: "", props: {} },
        addedBY: { selectedName: "", id: "", props: {} },
        level: { selectedName: "", id: "", props: {} },
        Writerlist: { selectedName: "", id: "", props: {} },
    };

    constructor() {
        makeAutoObservable(this)
    }
    setlanguageSelected = (languageSelected) => {
        this.languageSelected = languageSelected
    }
    setlevelSelected = (questionlevel) => {
        this.questionlevel = questionlevel
        let LevelList = this.LevelList
        let item = LevelList.find(item => item?.Title === questionlevel)
        this.setSelectedItemsNw({ selectedName: "Level", props: item, entityName: item?.Title })
    }
    setLanguage = (Language) => {
        this.Language = Language
    }
    setLevel = (data) => {
        this.Level = data
    }
    setLevelList = (data) => {
        this.LevelList = data
    }
    setQuestionData = (data) => {
        this.questionData = data
    }

    setSelectedItems = (data) => {
        this.selectedItems = data
    }
    setSelectedfilter = (data) => {
        this.selectedfilter = data
    }
    setMarks = (data) => {
        this.marks = data
    }
    setQuestionType = (data) => {
        this.questionType = data
    }
    setAuthorList = (data) => {

        this.authorList = data
    }
    setlevelID = (id) => {
        this.levelId = id;
    }
    setQuesiton = (data, items) => {
        this.setlevelSelected(data?.questionLevel)
        this.setlevelID(data?.questionType);
        this.setMarks({ ...this.marks, mark: data?.mark, negativeMark: data?.negativeMark, partialOneCorrectMark: data.partialOneCorrectMark, partialThreeCorrectMark: data?.partialThreeCorrectMark, partialTwoCorrectMark: data?.partialTwoCorrectMark })
        this.setQuestionData(data?.questionTableData);
    }
    setSelectedItemsNw = (payload) => {
        // console.log("payload=====",payload);
        if (payload?.selectedName === "Exam") {
            this.selectedItemsNw = {
                ...this.selectedItemsNw,
                examList: { id: payload?.props.id, selectedName: payload.entityName, props: payload?.props },
                courseList: { selectedName: "", id: "", props: {} },
                SubCourseList: { selectedName: "", id: "", props: {} },
                SubjectList: { selectedName: "", id: "", props: {} },
                TopicList: { selectedName: "", id: "", props: {} },
                SubTopicList: { selectedName: "", id: "", props: {} },
                questionType: { selectedName: "", id: "", props: {} },
                addedBY: { selectedName: "", id: "", props: {} },
                level: { selectedName: "", id: "", props: {} },
            }
        }
        if (payload?.selectedName === "Course") {
            this.selectedItemsNw = {
                ...this.selectedItemsNw, courseList: { id: payload?.props.id, selectedName: payload.entityName, props: payload?.props },
                SubCourseList: { selectedName: "", id: "", props: {} },
                SubjectList: { selectedName: "", id: "", props: {} },
                TopicList: { selectedName: "", id: "", props: {} },
                SubTopicList: { selectedName: "", id: "", props: {} },
                questionType: { selectedName: "", id: "", props: {} },
                addedBY: { selectedName: "", id: "", props: {} },
                level: { selectedName: "", id: "", props: {} },
            }
        }
        if (payload?.selectedName === "SubCourse") {
            this.selectedItemsNw = {
                ...this.selectedItemsNw, SubCourseList: { id: payload?.props.id, selectedName: payload.entityName, props: payload?.props },
                SubjectList: { selectedName: "", id: "", props: {} },
                TopicList: { selectedName: "", id: "", props: {} },
                SubTopicList: { selectedName: "", id: "", props: {} },
                questionType: { selectedName: "", id: "", props: {} },
                addedBY: { selectedName: "", id: "", props: {} },
                level: { selectedName: "", id: "", props: {} },
            }

        }
        if (payload?.selectedName === "Subject") {
            this.selectedItemsNw = {
                ...this.selectedItemsNw, SubjectList: { id: payload?.props.id, selectedName: payload.entityName, props: payload?.props },
                TopicList: { selectedName: "", id: "", props: {} },
                SubTopicList: { selectedName: "", id: "", props: {} },
                questionType: { selectedName: "", id: "", props: {} },
                addedBY: { selectedName: "", id: "", props: {} },
                level: { selectedName: "", id: "", props: {} },
            }
        }
        if (payload?.selectedName === "Topic") {
            this.selectedItemsNw = {
                ...this.selectedItemsNw, TopicList: { id: payload?.props.id, selectedName: payload.entityName, props: payload?.props },
                SubTopicList: { selectedName: "", id: "", props: {} },
                questionType: { selectedName: "", id: "", props: {} },
                addedBY: { selectedName: "", id: "", props: {} },
                level: { selectedName: "", id: "", props: {} },
            }
        }
        if (payload?.selectedName === "SubTopic") {
            this.selectedItemsNw = { ...this.selectedItemsNw, SubTopicList: { id: payload?.props.id, selectedName: payload.entityName, props: payload?.props } }

        }
        if (payload?.selectedName === "QuestionType") {
            this.selectedItemsNw = { ...this.selectedItemsNw, questionType: { id: payload?.props.id, selectedName: payload.entityName, props: payload?.props } }
        }
        if (payload?.selectedName === "Author") {
            this.selectedItemsNw = { ...this.selectedItemsNw, addedBY: { id: payload?.props?.id, selectedName: payload?.entityName, props: payload?.props } }
        }
        if (payload?.selectedName === "Level") {
            this.selectedItemsNw = { ...this.selectedItemsNw, level: { id: payload?.props.id, selectedName: payload.entityName, props: payload?.props } }
        }
        if (payload?.selectedName === "Writer") {
            this.selectedItemsNw = { ...this.selectedItemsNw, Writerlist: { id: payload?.props.id, selectedName: payload.entityName, props: payload?.props } }
        }
    }
    clear = () => {
        this.languageSelected = {};
        this.levelSelected = {};
        this.questionData = {};
        this.authorList = [];
        this.responseData = {};
        this.questionlevel = "";
        this.marks =
        {
            mark: 0,
            negativeMark: 0,
            isPartiallyCorrect: false,
            partialThreeCorrectMark: 0,
            partialTwoCorrectMark: 0,
            partialOneCorrectMark: 0
        };
        this.selectedItems = [];
        this.levelId = "";
        this.Language = [];
        this.questionType = [];
        this.Level = [];
        this.LevelList = []
        this.selectedfilter = {};
        this.selectedItemsNw = {
            examList: { selectedName: "", id: "", props: {} },
            courseList: { selectedName: "", id: "", props: {} },
            SubCourseList: { selectedName: "", id: "", props: {} },
            SubjectList: { selectedName: "", id: "", props: {} },
            TopicList: { selectedName: "", id: "", props: {} },
            SubTopicList: { selectedName: "", id: "", props: {} },
            questionType: { selectedName: "", id: "", props: {} },
            addedBY: { selectedName: "", id: "", props: {} },
            level: { selectedName: "", id: "", props: {} },
            Writerlist: { selectedName: "", id: "", props: {} },
        };
    }
}


const QuestionStore = new Question();
export default QuestionStore