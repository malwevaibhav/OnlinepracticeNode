import { makeAutoObservable } from "mobx";
class MockTest {
  step1Response = {};
  mockTestArray = {};
  mocktestIDs = {
    mocktestSettingId: "",
    examTypeId: "",
    courseId: "",
    subCourseId: "",
    examPatternId: "",
    subjectId: "",
    topicId: "",
    subTopicId: "",
    sectionId: "",
    questionType: "",
    isDraft: true,
  };
  mocktest = {
    mockTestName: "",
    description: "",
    instituteId: "",
    isFree: true,
    price: 0,
    timeDurationHours: 0,
    timeDurationMinutes: 0,
    testAvailability: 2,
    testStartTime: null,
    testUpdatedTime: null,
    testSpecificToDate: null,
    testSpecificFromDate: null,
    isAllowReattempts: false,
    isUnlimitedAttempts: false,
    totalAttempts: 0,
    reattemptsDays: 0,
    reattemptsHours: 0,
    reattemptsMinutes: 0,
    isTestResume: false,
    isUnlimitedResume: false,
    totalResume: false,
    backButton: 1,
    isMarksResultFormat: true,
    isPassFailResultFormat: false,
    isRankResultFormat: false,
    resultDeclaration: 2,
    isShowCorrectAnswer: false,
    mockTestType: 1,
    mocktestLogoUrl: "",
    headerTitle: "",
    isDraft: true,
    language: "english",
    secondaryLanguage: ""
  };
  mockLanguage = ""
  currentStep = { step: 1, from: 0 }
  automaticMocktest = {}
  stepCount = 1;
  automock = {
    mockTestSettingId: "",
    examTypeId: "",
    courseId: "",
    subCourseId: "",
    examPatternId: "",
    questionLevel: "",
    language: "",
    automaticMockTestQuestionsList: []
  }
  generateMocktest = {}
  langlength=""
  constructor() {
    makeAutoObservable(this);
  }
  setStep1Response = (data) => {
    this.step1Response = data;
  };
  setSecondaryLanguage(value) {
    this.mocktest.secondaryLanguage = value
  }
  setLanglength(value) {
    this.langlength = value
  }
  setMockTestArray = (data) => {
    this.mockTestArray = data;
  };
  setMocktestIDs = (data) => {
    this.mocktestIDs = { ...this.mocktestIDs, ...data };
  };
  setLanguageMocktest = (data) => {
    this.mockLanguage = data
  }
  setCurrentStep = (step) => {
    this.currentStep = step
  }
  setStepCount = (count) => {
    this.stepCount = count
  }
  setautomaticMocktest = (data) => {
    this.automaticMocktest = data
  }
  setmocktest = (data) => {
    this.mocktest = { ...this.mocktest, ...data }
  }
  setautomock = (data) => {
    this.automock = { ...this.automock, ...data };
  }
  setgenerateMocktest = (data) => {
    this.generateMocktest = data;
  }
  clear = () => {
    this.step1Response = {};
    this.mockTestArray = {};
    this.mocktestIDs = {
      mocktestSettingId: "",
      examTypeId: "",
      courseId: "",
      subCourseId: "",
      examPatternId: "",
      subjectId: "",
      topicId: "",
      subTopicId: "",
      sectionId: "",
      questionType: "",
      isDraft: true,
    };
    this.mocktest = {
      mockTestName: "",
      description: "",
      instituteId: "",
      isFree: true,
      price: 0,
      timeDurationHours: 0,
      timeDurationMinutes: 0,
      testAvailability: 2,
      testStartTime: null,
      testUpdatedTime: null,
      testSpecificToDate: null,
      testSpecificFromDate: null,
      isAllowReattempts: false,
      isUnlimitedAttempts: false,
      totalAttempts: 0,
      reattemptsDays: 0,
      reattemptsHours: 0,
      reattemptsMinutes: 0,
      isTestResume: false,
      isUnlimitedResume: false,
      totalResume: false,
      backButton: 1,
      isMarksResultFormat: true,
      isPassFailResultFormat: false,
      isRankResultFormat: false,
      resultDeclaration: 2,
      isShowCorrectAnswer: false,
      mockTestType: 1,
      mocktestLogoUrl: "",
      headerTitle: "",
      isDraft: true,
      language: "",
      secondaryLanguage: ""
    };
    this.mockLanguage = ""
    this.currentStep = { step: 1, from: 0 }
    this.stepCount = 1
    this.automaticMocktest = {}
    this.stepCount = 1;
    this.automaticMocktest = {};
    this.automock = {
      mockTestSettingId: "",
      examTypeId: "",
      courseId: "",
      subCourseId: "",
      examPatternId: "",
      questionLevel: "",
      language: "",
      automaticMockTestQuestionsList: []
    }
    this.generateMocktest = {}
  }
}
const MockTestStore = new MockTest();
export default MockTestStore;
