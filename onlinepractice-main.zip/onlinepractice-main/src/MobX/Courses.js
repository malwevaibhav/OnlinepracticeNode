import { makeAutoObservable } from "mobx";
import { removeExtraSpace } from "../utils/helper";
class Course {
   orgCourse = {};
   dupCourse = {};
   course = [];
   subcourse = [];
   allSubjectList = [];
   selectedSubjectList = [];
   topicList = [];
   subTopicList = [];
   examList = [];
   examListWithDetails = [];
   courseId = "";
   setQuestionType = [];
   // questionData={}
   // languageSelected={}

   constructor() {
      makeAutoObservable(this)
   }
   setExamListWithDetails = (data) => {
      this.examListWithDetails = data
   }
   setCompCourse = (data) => {
      this.orgCourse = data
      this.dupCourse = data
   }

   setCourseName = (val) => {
      this.orgCourse.courseName = removeExtraSpace(val)

   }
   setRightFunction = (val) => {
      this.orgCourse.courseName = removeExtraSpace(val)
      this.dupCourse.courseName = removeExtraSpace(val)
   }
   setCrossFunction = () => {
      this.orgCourse.courseName = removeExtraSpace(this.dupCourse.courseName)
   }

   setOrgCourse = (index, value) => {
      this.orgCourse.subCourses[index].subCourseName = removeExtraSpace(value)
      this.dupCourse.subCourses[index].subCourseName = removeExtraSpace(value)
   }

   setDupCourse = (id) => {
      this.orgCourse.subCourses[id].subCourseName = removeExtraSpace(this.dupCourse.subCourses[id].subCourseName)
   }

   setCourse = (courseData) => {
      this.course = courseData
   }

   setSubCourse = (subcourseData) => {
      this.subcourse = subcourseData
   }

   setAllSubject = (subjectData) => {
      this.allSubjectList = subjectData
   }
   // new branch

   setSubjectSelected = (subjectdata) => {
      this.selectedSubjectList = subjectdata
   }


   setTopic = (topicData) => {
      this.topic = topicData

   }
   setsubTopic = (subTopicData) => {
      this.subTopic = subTopicData
   }
   setQuestionTypeList = (setQuestionType) => {
      this.setQuestionType = setQuestionType
   }

   setcourseId = (Id) => {
      this.courseId = Id
   }

   setexamList = (examdata) => {
      this.examList = examdata
   }

   setsubject = (subjectdata) => {
      this.subjectList = subjectdata
   }

   setTopicList = (topicData) => {
      this.topicList = topicData
   }
   setSubTopicList = (subtopicData) => {
      this.subTopicList = subtopicData
   }
   clear = () => {
      this.orgCourse = {};
      this.dupCourse = {};
      this.course = [];
      this.subcourse = [];
      this.allSubjectList = [];
      this.selectedSubjectList = [];
      this.topicList = [];
      this.subTopicList = [];
      this.examList = [];
      this.examListWithDetails = [];
      this.courseId = "";
      this.setQuestionType = [];
   }


}
const CourseStore = new Course();
export default CourseStore