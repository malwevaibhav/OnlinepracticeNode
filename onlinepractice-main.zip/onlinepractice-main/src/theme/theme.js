import { createContext } from "react";

export const ThemeColors = {
  primary: "#0075FF",
  Darkblue: "#0B1C30",
  secondary: "#ABB6C0",
  bg: "#F4F6F8",
  light: "#F8EFFB",
  other: "#7E7383",
  deactive: "#B3A7B7",
  black: "#000000",
  white: "#FFFFFF",
  icon: "#BA8ACE",
  inputbg: "#F3F3F3",
  link: "#0075FF",
  searchbtn: "#F4F6F8",
  selectButton: "#DCEEFF",
  chartFooter: "#B2BECD",
  tableHead: "#EDF1F5",
  dropdownColor: "#9D9D9D",
  green: "#8AD0AF",
  danger: "#D03D3D",
  darkSecondary: "#E3E9EE",
  lightBlue: "#ECF5FF",
  skyBlue: "#D8EAFF",
  bgEasy: "#DFFFE6",
  bgMedium: "#FFF2DF",
  bgHard: "#FFF0F0",
  txtEasy: "#1FB012",
  txtMedium: "#FFAC30",
  grey:"#787F86",
  blue:"#4FA4F4",
  transaction:"#F0F5FB",
  font: {
    SmallHeading: {
      fontSize: '14px',
      fontWeight: 500,
      lineHeight: "16px",
      color: "#3A3951",
      fontFamily: 'Medium'
    },
    TitleHeading: {
      fontSize: '16px',
      fontWeight: 500,
      lineHeight: "16px",
      color: "#3A3951",
      fontFamily: 'Medium'
    },

    tileHeading: {
      fontSize: '16px',
      fontWeight: 700,
      lineHeight: "16px",
      color: "#3A3951"
    },

    pdfFont: {
      fontSize: '14px',
      fontWeight: 500,
      lineHeight: "16px",
      color: "#ABB6C0",
      fontFamily: 'Medium'
    },

    NormalHeading: {
      fontSize: "18px",
      fontWeight: 500,
      lineHeight: "28px",
      fontFamily: 'Medium'
    },

    cardSubHeading: {
      fontSize: '18px',
      fontWeight: 600,
      lineHeight: "21px"
    },

    subHeading: {
      fontSize: '20px',
      fontWeight: 500,
      lineHeight: "23px"
    },
    boldHeading: {
      fontSize: '20px',
      fontWeight: 600,
      lineHeight: "23px"
    },

    Heading: {
      fontSize: "24px",
      fontWeight: 500,
      lineHeight: "28px"
    },

    PrivacyHeading: {
      fontSize: "16px",
      fontWeight: 500,
      lineHeight: "28px",
      color: "#787F86",
      fontFamily: 'Medium'
    },

    cardDetail: {
      fontSize: '25px',
      fontWeight: 500,
      lineHeight: "30px",

    },
  }
};


export const ThemeColorContext = createContext({
  color: ThemeColors.primary,
});

export default function ThemeColorWrapper() { }
