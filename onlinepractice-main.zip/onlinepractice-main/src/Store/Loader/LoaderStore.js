import { action, computed, makeObservable, observable } from "mobx";

class LoaderStore {
  initialState = {};
  constructor() {
    makeObservable(this, {
      initialState: observable,
    });
  }
}
export const loaderStore = new LoaderStore();
